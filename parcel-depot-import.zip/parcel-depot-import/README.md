# Parcel Depot builds with real element types and action ids

The same two builds as in the first pack (`haiku_fix`, `control_fix`), with the desktop object corrected: every UIA
element has the type Blue Prism gives its control (UIAButton, UIAEdit, UIACheckBox, UIARadio, UIATable, UIAWindow)
and every stage uses an id the estate uses on that type (UIAClickCentre, UIAGetValue, UIATableRows). Nothing else
changed. Both still pass all 26 checks against the test applications.

Import order per folder: the browser object first, then the objects, then the processes.

Look for:
1. Does each object import now? If one is refused, the message names the id or type: photograph it.
2. Blue Prism's Validate on each object and process: number of errors and warnings, and the text of the errors.
3. In an object's Application Modeller: do the elements show their type (Button, Edit ..) and the ticked attributes?
4. In a Navigate / Read stage's properties: is the action shown by name in the dropdown, not blank?
5. `control_real`, process Approve Orders, page "Wrap Up Run": the two globals validate (see the first pack's README).
