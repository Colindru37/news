"""Exports as Blue Prism itself writes them, not as our generator does: a process has NO type attribute and its
ProcessInfo stage has no <language>. Run: python test/realshape_test.py <generated process xml> (prints REALSHAPE-TEST PASS)"""
import os, sys, re, json, subprocess, tempfile, shutil
HERE = os.path.dirname(os.path.abspath(__file__)); LIB = os.path.join(HERE, '..', 'lib')
sys.path.insert(0, LIB)
import bprun, compile_check as cc

PROC = '''<process name="Real Shape" version="1.0" bpversion="7.2.1.15451" narrative="" byrefcollection="true">
<stage stageid="i1" name="Stage1" type="ProcessInfo"><narrative></narrative><displayx>-240</displayx><displayy>-90</displayy></stage>
<stage stageid="s1" name="Start" type="Start"><displayx>0</displayx><displayy>0</displayy><onsuccess>c1</onsuccess></stage>
<stage stageid="d1" name="Total" type="Data"><datatype>number</datatype><initialvalue>1</initialvalue><private /><alwaysinit /></stage>
<stage stageid="c1" name="Add" type="Calculation"><calculation expression="[Total] + 41" stage="Total" /><onsuccess>e1</onsuccess></stage>
<stage stageid="e1" name="End" type="End"></stage>
</process>'''
fails = []
def ok(name, cond, detail=''):
    print(('PASS ' if cond else 'FAIL ') + name + ('' if cond else '  | ' + str(detail)[:400]))
    if not cond: fails.append(name)

tmp = tempfile.mkdtemp()
try:
    x = os.path.join(tmp, 'x'); os.makedirs(x)
    with open(os.path.join(x, 'BPA Process - Real Shape.xml'), 'w', encoding='utf-8') as f: f.write(PROC)
    root = bprun.parse_xml(os.path.join(x, 'BPA Process - Real Shape.xml'))
    ok('realshape: a process with only its information box has no code to host', cc.build_source(root, 'Real Shape')[0] is None)
    out = os.path.join(tmp, 'out.json')
    r = subprocess.run([sys.executable, os.path.join(LIB, 'bprun_run.py'), '--xml', x, '--run', 'Real Shape', '--json', out], capture_output=True, text=True)
    res = json.load(open(out, encoding='utf-8'))
    ok('realshape: a process without a type attribute runs', res.get('ok') is True, res.get('exception') or r.stdout + r.stderr)
    ok('realshape: no host problem reported for the process', not res['host']['problems'], res['host']['problems'])
    obj = '<process name="O" type="object"><stage stageid="i" name="Code Options" type="ProcessInfo"></stage><stage stageid="k" name="K" type="Code"><code>x = 1</code></stage></process>'
    import xml.etree.ElementTree as ET
    ok('realshape: an object with no <language> is Visual Basic (Blue Prism default)', cc.build_source(ET.fromstring(obj), 'O')[1] == 'vb')
finally:
    shutil.rmtree(tmp, ignore_errors=True)
print('REALSHAPE-TEST ' + ('PASS' if not fails else 'FAIL: ' + ', '.join(fails)))
sys.exit(1 if fails else 0)
