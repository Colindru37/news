# Internal objects: the plan

Blue Prism's internal business objects (Work Queues, Credentials, Environment Locking, Calendars, Collections,
Session Variables, Sessions, Event Log, Encryption, Data Gateways, Licensing, Environment) are compiled into
Blue Prism itself. They are never in a release, cannot be exported from Studio and nothing is ever imported for them.
An Action stage names one by its CLASS: `<resource object="Blueprism.Automate.clsWorkQueuesActions" action="Get Next Item" />`;
Studio shows the display name. "Making" them means two things only:

1. gumball knows them: the Objects known list, the Action picker, the release checks (a wrong action name is an error,
   a call to one is never "not in this release"), the calls census.
2. Run simulates them: bprun answers each action the way Blue Prism would, including the exception text on failure.

## Where it stands (2026-11-16)

- `internal/internal.json` is the VERIFIED list of Blue Prism 7.2.1: 9 objects, 76 actions (Work Queues 24, Encryption 20,
  Calendars 9, Credentials 8, Collections 6, Windows Credentials 4, Environment Locking 3, Data Gateways 1, Radio buttons 1),
  read off the install by `internal-objects.ps1` on the bank machine. The copy in the repo is transcribed from photos of
  the report; the file `-Apply` writes on the machine is the exact one (run the script with `-Apply` after unpacking a zip).
  Event Log, Session Variables, Sessions, Environment and Licensing were in the old seed and are NOT internal objects there.
- The checks report a wrong action name on an internal object as an error; the census puts internal calls in their own section.
- bprun simulates every action of the list (test/internal_test.py, 67 checks, one of them walks the whole list). Real
  parameter and output names; the old seed names are still answered. **Collections** takes the NAME of a collection on
  the calling page and changes it in place, as Blue Prism does.
- Still approximations, to be replaced as real ones are seen: exception texts, the column names of returned collections
  (queue item lists, Credentials List, holiday lists, Queue Names), what Remove Row does to a running loop, Radio buttons.
  Acquire Lock does not wait for its Timeout. Get Transaction Data counts only what happened in this run.

## Steps, in order

1. **Census on the bank's releases.** `node gumball.js calls r.bprelease` on the real releases; the `== internal`
   section is the list of actions that matter and the order to build them in. One photo per release is enough.
2. **Verified action list.** Two ways, either is fine:
   - `internal-objects.ps1` next to gumball.js (2026-11-16, plain PowerShell reflection, nothing compiled): writes
     `internal\internal.new.json` + `internal\internal-report.txt`; `-Apply` replaces `internal.json` when the result is
     complete, `-Detail` prints the member names when a value was not found. Not yet run on Windows.
   - Copilot on the bank machine with `docs/copilot_internal_objects_handoff.md` (PowerShell reflection over
     AutomateAppCore.dll, reads type metadata only) -> `internal.json` with `verified: true` and `class` for every object.
   - By hand in Studio: an Action stage, Business Object dropdown, each internal object, each action's inputs/outputs
     tab. Photos are fine; they get transcribed into `internal.json`. The class name comes from any export that calls
     the object (Action stage's `resource object`).
   Once verified, the checks start reporting wrong action names on internal objects as errors, like Studio.
3. **Correct the simulation against the verified list.** Action and parameter names that differ get renamed (the
   simulation accepts the old and the new name for a while), exception texts get the real wording as incident folders
   show them, and the four objects without an action list (Session Variables, Sessions, Environment, Licensing) get
   theirs.
4. **Estate file.** `internal/estate.json` grows: holidays, credentials with properties, queue seed items, lock state.
   A release's own env vars and queues keep being added on top when running one of its members.
5. **Tests.** One small fixture process per object in `test/`, run through `lib/bprun_run.py`, asserting outputs and
   the exception text. The existing suite stays green on every step.

Out of scope: anything that changes Blue Prism. If a process needs a real queue or a real lock, that is a DEV run.
