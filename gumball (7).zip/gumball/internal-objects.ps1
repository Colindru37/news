<#
internal-objects.ps1 : list Blue Prism's internal business objects (Work Queues, Credentials, Environment
Locking, Calendars, ...) with their actions and parameters, for gumball's internal\internal.json.

  powershell -ExecutionPolicy Bypass -File .\internal-objects.ps1
  powershell -ExecutionPolicy Bypass -File .\internal-objects.ps1 -Apply      # also replace internal\internal.json
  powershell -ExecutionPolicy Bypass -File .\internal-objects.ps1 -BP "D:\Blue Prism Automate" -Detail

What it does: loads Blue Prism's own assemblies from the install folder into THIS PowerShell process, creates the
internal object classes in memory with no process and no session, and reads their action lists (name, inputs,
outputs, data types). Plain PowerShell reflection: nothing is compiled, no window, keyboard or screen is touched,
no network and no database connection is opened, Blue Prism itself is not started, nothing is installed.
It writes two files next to this script, and nothing else:
  internal\internal.new.json     the list in gumball's format
  internal\internal-report.txt   one line per action + how each value was found + everything that failed
With -Apply the old internal\internal.json is kept as internal.seed.json and replaced by the new list.
#>
param(
    [string]$BP = 'C:\Program Files\Blue Prism Limited\Blue Prism Automate',
    [switch]$Apply,
    [switch]$Detail
)
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$outDir = Join-Path $here 'internal'
if (-not (Test-Path $outDir)) { [void](New-Item -ItemType Directory -Path $outDir) }
$report = New-Object System.Collections.ArrayList
$problems = New-Object System.Collections.ArrayList
$used = @{}
$odd = @{}
function Say([string]$s) { [void]$report.Add($s); Write-Host $s }
function Note([string]$s) { [void]$problems.Add($s) }
function Inner($e) { $x = $e; while ($x.InnerException) { $x = $x.InnerException }; return ($x.GetType().Name + ': ' + $x.Message) }

if (-not (Test-Path $BP)) { Write-Host "Blue Prism folder not found: $BP  (pass -BP ""<folder>"")"; exit 1 }
$ALL = [Reflection.BindingFlags]'Public,NonPublic,Instance,DeclaredOnly'

# ---------------- load ----------------
$files = @()
foreach ($n in 'AutomateProcessCore.dll', 'AutomateAppCore.dll', 'Automate.exe') { $f = Join-Path $BP $n; if (Test-Path $f) { $files += $f } else { Note "not in the folder: $n" } }
$types = New-Object System.Collections.ArrayList
$version = ''
foreach ($f in $files) {
    try {
        $asm = [Reflection.Assembly]::LoadFrom($f)
        if (-not $version) { $version = $asm.GetName().Version.ToString() }
        $got = $null
        try { $got = $asm.GetTypes() }
        catch {
            $e = $_.Exception
            while ($e -ne $null -and -not ($e -is [Reflection.ReflectionTypeLoadException])) { $e = $e.InnerException }
            if ($e -eq $null) { throw }
            $got = @($e.Types | Where-Object { $_ -ne $null }); Note ("{0}: some types did not load ({1} did)" -f (Split-Path -Leaf $f), $got.Count)
        }
        foreach ($t in $got) { [void]$types.Add($t) }
    } catch { Note ("{0}: {1}" -f (Split-Path -Leaf $f), (Inner $_.Exception)) }
}
Say ("internal objects of Blue Prism {0}  ({1} types read from {2} files in {3})" -f $version, $types.Count, $files.Count, $BP)

# ---------------- helpers ----------------
function Chain($t) { $o = @(); $b = $t; while ($b -ne $null) { $o += $b; $b = $b.BaseType }; return ,$o }
function Derives($t, [string]$pattern) { foreach ($b in (Chain $t)) { if ($b -ne $t -and $b.Name -match $pattern) { return $true } }; return $false }
# a value of $obj by member name: property first, then a method without parameters; public or not, inherited or not
function Read-Named($obj, [string[]]$names, [string]$what) {
    if ($obj -eq $null) { return $null }
    foreach ($n in $names) {
        foreach ($b in (Chain $obj.GetType())) {
            $p = $null; $m = $null
            try { $p = $b.GetProperty($n, $ALL) } catch { }
            if ($p -ne $null -and $p.GetIndexParameters().Count -eq 0 -and $p.CanRead) {
                try { $v = $p.GetValue($obj, $null); if ($v -ne $null) { $used[$what] = "property $n"; return ,$v } } catch { }
            }
            try { $m = $b.GetMethod($n, $ALL, $null, [Type[]]@(), $null) } catch { }
            if ($m -ne $null -and $m.ReturnType -ne [void]) {
                try { $v = $m.Invoke($obj, [object[]]@()); if ($v -ne $null) { $used[$what] = "method $n()"; return ,$v } } catch { }
            }
        }
    }
    return $null
}
# first member whose NAME matches a pattern and that gives a list (not a string): for lists whose exact name is not known
function Read-ListLike($obj, [string]$pattern, [string]$what) {
    if ($obj -eq $null) { return $null }
    foreach ($b in (Chain $obj.GetType())) {
        foreach ($p in $b.GetProperties($ALL)) {
            if ($p.Name -match $pattern -and $p.GetIndexParameters().Count -eq 0 -and $p.CanRead -and $p.PropertyType -ne [string] -and [Collections.IEnumerable].IsAssignableFrom($p.PropertyType)) {
                try { $v = $p.GetValue($obj, $null); if ($v -ne $null) { $used[$what] = "property " + $p.Name; return ,$v } } catch { }
            }
        }
        foreach ($m in $b.GetMethods($ALL)) {
            if ($m.Name -match $pattern -and -not $m.IsSpecialName -and $m.GetParameters().Count -eq 0 -and $m.ReturnType -ne [string] -and [Collections.IEnumerable].IsAssignableFrom($m.ReturnType)) {
                try { $v = $m.Invoke($obj, [object[]]@()); if ($v -ne $null) { $used[$what] = "method " + $m.Name + "()"; return ,$v } } catch { }
            }
        }
    }
    return $null
}
function To-List($v) {
    $l = New-Object System.Collections.ArrayList
    if ($v -eq $null) { return ,$l }
    if ($v -is [Collections.IDictionary]) { foreach ($x in $v.Values) { [void]$l.Add($x) } }
    elseif ($v -is [string]) { }
    elseif ($v -is [Collections.IEnumerable]) { foreach ($x in $v) { [void]$l.Add($x) } }
    return ,$l
}
# an instance with nothing behind it: every constructor in turn, shortest first, null / zero for each argument
function New-Bare($t) {
    $why = ''
    $ctors = @($t.GetConstructors($ALL) | Sort-Object { $_.GetParameters().Count })
    foreach ($c in $ctors) {
        $a = New-Object System.Collections.ArrayList
        foreach ($p in $c.GetParameters()) {
            $pt = $p.ParameterType
            if ($pt.IsValueType) { [void]$a.Add([Activator]::CreateInstance($pt)) }
            elseif ($pt -eq [string]) { [void]$a.Add('') }
            elseif ($pt.IsArray) { [void]$a.Add([Array]::CreateInstance($pt.GetElementType(), 0)) }
            else { [void]$a.Add($null) }
        }
        try { $o = $c.Invoke([object[]]$a.ToArray()); if ($o -ne $null) { return ,$o } } catch { $why = Inner $_.Exception }
    }
    if ($ctors.Count -eq 0) { $why = 'no constructor' }
    Note ("{0}: could not be created ({1})" -f $t.FullName, $why)
    return $null
}
function Members-Of($obj) {     # names only, for the report: what exists when a value was not found
    $n = @()
    foreach ($b in (Chain $obj.GetType())) {
        if ($b -eq [object]) { continue }
        foreach ($p in $b.GetProperties($ALL)) { $n += $p.Name }
        foreach ($m in $b.GetMethods($ALL)) { if (-not $m.IsSpecialName -and $m.GetParameters().Count -eq 0 -and $m.ReturnType -ne [void]) { $n += ($m.Name + '()') } }
    }
    return (($n | Sort-Object -Unique) -join ' ')
}
$BPTYPES = 'text', 'number', 'flag', 'date', 'datetime', 'time', 'timespan', 'password', 'collection', 'image', 'binary'
function Param-Of($p) {
    $name = Read-Named $p @('Name', 'GetName', 'FriendlyName') 'parameter name'
    $dt = Read-Named $p @('GetDataType', 'DataType', 'ParamType', 'Type') 'parameter type'
    $dir = Read-Named $p @('Direction', 'GetDirection', 'ParamDirection') 'parameter direction'
    $type = ('' + $dt).ToLower()
    if (-not $type) { $type = 'unknown:' }
    elseif ($BPTYPES -notcontains $type) { $odd[$type] = 1 }     # a real Blue Prism type outside the Studio list: kept as it is
    return @{ name = ('' + $name); type = $type; out = (('' + $dir) -match '^out') ; dir = ('' + $dir) }
}
function Action-Of($a) {
    $name = Read-Named $a @('GetName', 'Name', 'FriendlyName') 'action name'
    $pl = Read-Named $a @('GetParameters', 'Parameters') 'action parameters'
    if ($pl -eq $null) { $pl = Read-ListLike $a 'param' 'action parameters' }
    $ins = @(); $outs = @()
    foreach ($p in (To-List $pl)) {
        if ($p -eq $null) { continue }
        $q = Param-Of $p
        if (-not $q.name) { continue }
        $e = [ordered]@{ name = $q.name; type = $q.type }
        if ($q.out) { $outs += $e } else { $ins += $e }
    }
    return [ordered]@{ name = ('' + $name); inputs = @($ins); outputs = @($outs) }
}

# ---------------- the objects ----------------
$objTypes = @($types | Where-Object { $_.IsClass -and -not $_.IsAbstract -and (Derives $_ 'InternalBusinessObject$') } | Sort-Object FullName)
$actTypes = @($types | Where-Object { $_.IsClass -and -not $_.IsAbstract -and (Derives $_ 'InternalBusinessObjectAction$') } | Sort-Object FullName)
Say ("{0} internal object classes, {1} internal action classes" -f $objTypes.Count, $actTypes.Count)
if ($objTypes.Count -eq 0) {
    Note 'no class derives from *InternalBusinessObject: the base class has another name in this version. Classes whose name holds "BusinessObject":'
    foreach ($t in @($types | Where-Object { $_.Name -match 'BusinessObject' } | Sort-Object FullName | Select-Object -First 40)) { Note ('   ' + $t.FullName + '  <  ' + $(if ($t.BaseType) { $t.BaseType.Name } else { '' })) }
}
$objects = @()
$attached = @{}
$created = @{}
$shapeShown = $false
foreach ($t in $objTypes) {
    $o = New-Bare $t
    if ($o -eq $null) { continue }
    $created[$t.FullName] = 1
    $friendly = '' + (Read-Named $o @('FriendlyName', 'GetFriendlyName') 'object display name')
    $inner = '' + (Read-Named $o @('Name', 'GetName') 'object name')
    if (-not $friendly) { $friendly = $inner }
    if (-not $friendly) { $friendly = $t.Name }
    $al = Read-Named $o @('GetActions', 'Actions') 'object actions'
    if ($al -eq $null) { $al = Read-ListLike $o 'action' 'object actions' }
    $acts = @()
    foreach ($a in (To-List $al)) {
        if ($a -eq $null) { continue }
        $attached[$a.GetType().FullName] = 1
        $x = Action-Of $a
        if ($x.name) { $acts += $x }
        if (-not $shapeShown -and $Detail) {
            $shapeShown = $true
            Say ('  [shape] object members:    ' + (Members-Of $o))
            Say ('  [shape] action members:    ' + (Members-Of $a))
            $fp = @(To-List (Read-Named $a @('GetParameters', 'Parameters') 'action parameters')) | Select-Object -First 1
            if ($fp) { Say ('  [shape] parameter members: ' + (Members-Of $fp)) }
        }
    }
    if ($al -eq $null) { Note ("{0}: no action list found. Members: {1}" -f $t.FullName, (Members-Of $o)) }
    $classes = @($t.FullName); if ($inner -and $inner -ne $t.FullName -and $inner -ne $friendly) { $classes += $inner }
    $objects += [ordered]@{ object = $friendly; classes = @($classes); verified = $true; actions = @($acts) }
}
# action classes no object handed out: listed on their own, so nothing is lost when an object could not be created
# ... and when they are nested in an object class that could not be created (Calendars wants a server), the object
# is rebuilt from them: the name comes from the class name, the seed adds the class an Action stage writes
$loose = @()
$rebuilt = [ordered]@{}
$notes = New-Object System.Collections.ArrayList
foreach ($t in $actTypes) {
    if ($attached.ContainsKey($t.FullName)) { continue }
    $a = New-Bare $t
    if ($a -eq $null) { continue }
    $x = Action-Of $a
    if (-not $x.name) { continue }
    $d = $t.DeclaringType
    if ($d -ne $null -and -not $created.ContainsKey($d.FullName) -and (Derives $d 'InternalBusinessObject$')) {
        if (-not $rebuilt.Contains($d.FullName)) { $rebuilt[$d.FullName] = @{ type = $d; actions = @() } }
        $rebuilt[$d.FullName].actions += $x
    } else { $loose += [ordered]@{ class = $t.FullName; action = $x } }
}
foreach ($k in @($rebuilt.Keys)) {
    $d = $rebuilt[$k].type
    $nm = (($d.Name -replace '^cls', '') -replace 'BusinessObject$', '') -creplace '(?<=[a-z])(?=[A-Z])', ' '
    $objects += [ordered]@{ object = $nm; classes = @($d.FullName); verified = $true; actions = @($rebuilt[$k].actions) }
    foreach ($p in @($problems)) { if ($p.StartsWith($d.FullName + ': could not be created')) { $problems.Remove($p); [void]$notes.Add($nm + ': rebuilt from its ' + $rebuilt[$k].actions.Count + ' action classes, display name taken from the class name (' + $p + ')') } }
}
# two classes with one display name (Windows Credentials): one object, every action once
$byName = [ordered]@{}
foreach ($o in $objects) {
    if (-not $byName.Contains($o.object)) { $byName[$o.object] = $o; continue }
    $keep = $byName[$o.object]
    foreach ($c in @($o.classes)) { if (@($keep.classes) -notcontains $c) { $keep['classes'] = @($keep.classes) + $c } }
    $have = @($keep.actions | ForEach-Object { $_.name })
    foreach ($a in @($o.actions)) { if ($have -notcontains $a.name) { $keep['actions'] = @($keep.actions) + $a } }
    [void]$notes.Add($o.object + ': two classes share this name, merged into one object')
}
$objects = @($byName.Values)

# ---------------- report ----------------
function Line($p) { return (@($p | ForEach-Object { $_.name + ':' + $_.type }) -join ', ') }
foreach ($o in ($objects | Sort-Object { $_.object })) {
    Say ''
    Say ("== {0}   [{1}]   {2} actions" -f $o.object, ($o.classes -join ' | '), $o.actions.Count)
    foreach ($a in $o.actions) { Say ("  {0}  |  in: {1}  |  out: {2}" -f $a.name, (Line $a.inputs), (Line $a.outputs)) }
}
if ($loose.Count) {
    Say ''
    Say ("== action classes not handed out by any object ({0})" -f $loose.Count)
    foreach ($l in $loose) { Say ("  {0}  ->  {1}  |  in: {2}  |  out: {3}" -f $l.class, $l.action.name, (Line $l.action.inputs), (Line $l.action.outputs)) }
}
Say ''
Say '== how each value was found'
foreach ($k in ($used.Keys | Sort-Object)) { Say ("  {0}: {1}" -f $k, $used[$k]) }
foreach ($k in 'object display name', 'object actions', 'action name', 'action parameters', 'parameter name', 'parameter type', 'parameter direction') { if (-not $used.ContainsKey($k)) { Say ("  {0}: NOT FOUND (run again with -Detail and send the [shape] lines)" -f $k) } }
if ($notes.Count) { Say ''; Say '== notes'; foreach ($p in $notes) { Say ('  ' + $p) } }
if ($odd.Count) { Say ('  data types outside the Studio list, kept as they are: ' + (($odd.Keys | Sort-Object) -join ', ')) }
if ($problems.Count) { Say ''; Say ("== problems ({0})" -f $problems.Count); foreach ($p in $problems) { Say ('  ' + $p) } }

# ---------------- files ----------------
$total = 0; foreach ($o in $objects) { $total += $o.actions.Count }
$unknown = 0; foreach ($o in $objects) { foreach ($a in $o.actions) { foreach ($p in (@($a.inputs) + @($a.outputs))) { if ($p.type -like 'unknown:*') { $unknown++ } } } }
$seedFile = Join-Path $outDir 'internal.json'
if (Test-Path $seedFile) {     # keep what gumball already knows about each object (which ones Run simulates)
    try {
        $seed = Get-Content -Raw -Encoding UTF8 $seedFile | ConvertFrom-Json
        foreach ($o in $objects) {
            $old = @($seed.objects | Where-Object { $_.object -eq $o.object }) | Select-Object -First 1
            if ($old) {
                if ($old.simulated) { $o['simulated'] = $true }
                foreach ($c in @($old.classes)) { if ($c -and (@($o.classes) -notcontains $c)) { $o['classes'] = @($o.classes) + $c } }
            }
        }
        $names = @($objects | ForEach-Object { $_.object })
        $gone = @($seed.objects | Where-Object { $names -notcontains $_.object } | ForEach-Object { $_.object })
        if ($gone.Count) { Say ''; Say ('in the old internal.json but not in this Blue Prism (dropped from the new list): ' + ($gone -join ', ')) }
    } catch { Note ('internal.json not read: ' + (Inner $_.Exception)) }
}
$doc = [ordered]@{ source = ("Blue Prism {0}, internal-objects.ps1, {1}" -f $version, (Get-Date -Format 'yyyy-MM-dd')); objects = @($objects | Sort-Object { $_.object }) }
$json = $doc | ConvertTo-Json -Depth 8
$newFile = Join-Path $outDir 'internal.new.json'
[IO.File]::WriteAllText($newFile, $json, (New-Object Text.UTF8Encoding($false)))
Say ''
$good = ($objects.Count -ge 5 -and $total -ge 20 -and $unknown -eq 0)
Say ("RESULT: {0} objects, {1} actions, {2} parameters with an unknown type, {3} problems  ->  {4}" -f $objects.Count, $total, $unknown, $problems.Count, $(if ($good) { 'LOOKS COMPLETE' } else { 'INCOMPLETE: send a photo of this report' }))
if ($Apply) {
    if ($good) {
        if ((Test-Path $seedFile) -and -not (Test-Path (Join-Path $outDir 'internal.seed.json'))) { Copy-Item $seedFile (Join-Path $outDir 'internal.seed.json') }
        Copy-Item $newFile $seedFile -Force
        Say 'applied: internal\internal.json replaced (the old one is internal.seed.json). Restart gumball.'
    } else { Say 'NOT applied: the list is incomplete, internal\internal.json is unchanged.' }
} else { Say 'internal\internal.json is unchanged. When the result looks complete, run again with -Apply.' }
[IO.File]::WriteAllLines((Join-Path $outDir 'internal-report.txt'), [string[]]$report.ToArray(), (New-Object Text.UTF8Encoding($false)))
Write-Host ("written: {0}  and  internal-report.txt" -f $newFile)
