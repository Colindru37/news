# Pdfx

Dependency-free PDF library for .NET Framework 4.8. It uses only the base class library: no NuGet packages and no native code, and it never touches the network.

| Area | Entry point |
|------|-------------|
| Open / create / save, merge, split, extract pages | `PdfDocument` |
| Open password-protected files (RC4, AES-128, AES-256), remove or add a password | `PdfDocument.Open(path, password)`, `PdfComposer.RemovePassword`, `AddPassword` |
| Text extraction in reading order (columns, tables) | `PdfPage.ExtractText()`, `PdfText` |
| Stamps, watermarks, images | `PdfStamp` |
| AcroForm fields: read, fill, flatten | `PdfForm` |
| Conversion to plain text and structural HTML | `PdfDocument.ToText()`, `ToHtml()` |
| Conversion to PDF/A-1/2/3, levels A, B and U | `PdfStandardsConverter` |
| JPEG / PNG / TIFF (multi-page, fax) / GIF / BMP to PDF, text to PDF | `PdfComposer.ImagesToPdf`, `TextToPdf`, `TextFileToPdf` |
| Export as plain text, Markdown or HTML | `PdfComposer.ConvertToText`, `PdfDocument.ToMarkdown()` |
| Text from scanned pages (OCR, Arabic included) through the Tesseract already on the machine | `PdfOcr.ExtractText`, `PdfOcr.ReadPages` |
| Every page onto A4 (or A3, Letter, any size), content scaled to fit | `PdfComposer.ResizePages` |
| Password-protect a file (AES-256, permissions) | `PdfComposer.AddPassword` |
| Split by keyword, by pattern (file named after the match), by bookmark, every N pages | `PdfComposer.SplitByText`, `SplitByPattern`, `SplitByBookmarks`, `SplitEvery` |
| Page numbers, Bates numbers | `PdfComposer.AddPageNumbers`, `AddBates` |
| Attachments (embed, extract; PDF/A-3) and bookmarks (read, create, one per merged file) | `PdfComposer.AddAttachments`, `ExtractAttachments`, `PdfDocument.Attachments`, `Bookmarks` |
| Make files smaller | `PdfComposer.Compress` |
| Built-in help, from any code stage | `PdfHelp.Show()`, `PdfHelp.Show("split")` |
| Library version, for logs | `PdfHelp.Version` |

## Common tasks

```csharp
using Pdfx;

// Archive a file. Level is text, so it can come straight from configuration.
PdfStandardsConverter.ConvertFile(@"C:\in\statement.pdf", @"C:\out\statement.pdf", "2B");
PdfStandardsConverter.ConvertFile(@"C:\in\locked.pdf", @"C:\out\locked.pdf", "2B", "password");

// Skip files that already claim PDF/A ("2B", "1A", ... or null).
string level = PdfStandardsConverter.GetDeclaredLevel(@"C:\in\statement.pdf");

// Several levels from one read, plus what the conversion changed.
PdfStandardsConverter c = new PdfStandardsConverter(@"C:\in\statement.pdf");
c.ToPdfA2B(@"C:\out\a2b.pdf");
c.ToPdfA2A(@"C:\out\a2a.pdf");          // tagged: headings, paragraphs, reading order
foreach (string w in c.Warnings) Console.WriteLine(w);   // cleared on each call

// Text.
using (PdfDocument d = PdfDocument.Open(@"C:\in\statement.pdf"))
{
    string all = d.ToText();
    string first = PdfText.Extract(d.GetPage(0));
}

// Scans and photos. JPEG, PNG, TIFF, GIF and BMP work everywhere a PDF does: ConvertFile, Merge, Open.
PdfComposer.ImagesToPdf(new[] { @"C:\in\fax.tif" }, @"C:\out\fax.pdf");             // one page per TIFF frame
PdfStandardsConverter.ConvertFile(@"C:\in\scan.jpg", @"C:\out\scan.pdf", "2B");
PdfComposer.ImagesToPdf(new[] { @"C:\in\p1.jpg", @"C:\in\p2.png" }, @"C:\out\scans.pdf");
PdfComposer.Merge(new[] { @"C:\in\letter.pdf", @"C:\in\id-card.jpg" }, @"C:\out\case.pdf");

// Text (email bodies, logs). Diacritics are kept; a form feed starts a new page.
PdfComposer.TextToPdf("Extras de cont\nTitular: Ștefan Țărănescu", @"C:\out\note.pdf");
PdfComposer.TextFileToPdf(@"C:\in\log.txt", @"C:\out\log.pdf");

// Export. The output's extension picks the form: .md, .html or anything else for plain text.
PdfComposer.ConvertToText(@"C:\in\statement.pdf", @"C:\out\statement.md");

// Scans: OCR through the Tesseract already on the machine (a bundled copy is found by itself).
string scanned = PdfOcr.ExtractText(@"C:\in\scan.pdf");
PdfOcrOptions ocr = new PdfOcrOptions();
ocr.Language = "ara+eng";                                  // each language needs its .traineddata file
foreach (PdfOcrPage pg in PdfOcr.ReadPages(@"C:\in\arabic-scan.pdf", ocr))
    Console.WriteLine(pg.Number + ": " + pg.Method + " " + pg.Text.Length + " characters");

// Every page onto A4: scaled to fit, centred, links and fields follow; landscape pages get A4 landscape.
PdfComposer.ResizePages(@"C:\in\mixed-sizes.pdf", @"C:\out\a4.pdf", "A4");

// Protect. The first password opens the file, the second lifts the permissions; either may be empty.
PdfComposer.AddPassword(@"C:\in\statement.pdf", @"C:\out\locked.pdf", "open-me", "owner-only");
PdfPasswordOptions pw = new PdfPasswordOptions("", "owner-only");
pw.AllowPrinting = false; pw.AllowCopying = false;                                   // opens freely, no print/copy
PdfComposer.AddPassword(@"C:\in\statement.pdf", @"C:\out\view-only.pdf", pw);

// Quick questions.
int pages = PdfComposer.GetPageCount(@"C:\in\a.pdf");
bool locked = PdfComposer.NeedsPassword(@"C:\in\a.pdf");
PdfComposer.RemovePassword(@"C:\in\locked.pdf", "password", @"C:\out\open.pdf");

// Help: what the library does, and an example for every action (VB.NET).
string overview = PdfHelp.Show();
string howToSplit = PdfHelp.Show("split");
string everyMethod = PdfHelp.Show("reference");
string build = PdfHelp.Version;                       // "1.2.0"; log it so a run can be tied to a DLL

// Split a batch of statements: at a keyword, or one file per client number.
PdfComposer.SplitByText(@"C:\in\batch.pdf", @"C:\out\stmts", "Extras de cont", "stmt");
PdfComposer.SplitByPattern(@"C:\in\batch.pdf", @"C:\out\clients", @"Client no\.?\s*(\d+)");   // 4711.pdf, 815.pdf
PdfComposer.SplitEvery(@"C:\in\batch.pdf", @"C:\out\pairs", 2, "form");

// Page numbers and Bates numbers.
PdfComposer.AddPageNumbers(@"C:\in\a.pdf", @"C:\out\numbered.pdf");
int nextBates = PdfComposer.AddBates(@"C:\in\a.pdf", @"C:\out\bates.pdf", "ACME", 1);

// Attachments, kept through PDF/A-3.
PdfComposer.AddAttachments(@"C:\in\a.pdf", new[] { @"C:\in\invoice.xml" }, @"C:\out\with-xml.pdf", "Data");
PdfStandardsConverter.ConvertFile(@"C:\out\with-xml.pdf", @"C:\out\archived.pdf", "3B");
string[] extracted = PdfComposer.ExtractAttachments(@"C:\out\with-xml.pdf", @"C:\out\attachments");

// Smaller files (scans and photos scaled to 150 dpi; everything else untouched).
long newSize = PdfComposer.Compress(@"C:\in\scan.pdf", @"C:\out\scan-small.pdf");

// Pages.
PdfComposer.Merge(new[] { @"C:\in\a.pdf", @"C:\in\b.pdf" }, @"C:\out\ab.pdf");
PdfComposer.Merge(new[] { @"C:\in\a.pdf", @"C:\in\b.pdf" }, @"C:\out\ab-bookmarked.pdf", true);   // a bookmark per file
PdfComposer.SplitToPages(@"C:\out\ab.pdf", @"C:\out\pages", "page");
PdfComposer.Extract(@"C:\out\ab.pdf", new[] { 0, 2 }, @"C:\out\first-and-third.pdf");   // 0-based

// Remove a known password.
using (PdfDocument d = PdfDocument.Open(@"C:\in\locked.pdf", "password"))
    d.Save(@"C:\out\unlocked.pdf");

// Stamp.
using (PdfDocument d = PdfDocument.Open(@"C:\in\a.pdf"))
{
    PdfStampOptions o = new PdfStampOptions();
    o.FontSize = 48; o.Opacity = 0.2;
    PdfStamp.AddWatermark(d.GetPage(0), "COPY", o);
    d.Save(@"C:\out\copy.pdf");
}

// Forms.
using (PdfDocument d = PdfDocument.Open(@"C:\in\form.pdf"))
{
    PdfForm.SetValue(d, "name", "Ion Popescu");
    PdfForm.Flatten(d);
    d.Save(@"C:\out\form-filled.pdf");
}
```

Errors about the document itself (not a PDF, wrong password, page out of range) are
`PdfException`; bad arguments are `ArgumentException`. Pages are numbered from 0.

Paths may be wrapped in quotes (Explorer's "Copy as path"); output folders are created when
missing.

Images: a scan keeps its paper size (from its DPI); a photo or screenshot is fitted on A4,
turned upright from its EXIF orientation. Truncated images are refused rather than archived
half-drawn. A TIFF gives one page per frame; fax-compressed (CCITT) pages are kept as they are,
so they stay small. HEIC and WebP are refused with a message: save as JPEG, PNG or TIFF.

Resizing keeps text, links and form fields; accessibility tags are dropped (a PDF/A-2A
conversion afterwards rebuilds them). Protection uses AES-256 (AES-128 on request); a PDF/A file
loses its PDF/A status when protected, as the standard forbids encryption.

Text: A4, 10 pt, in Arial (Courier New with `TextToPdf(text, output, true)`). Characters the
font does not have (emoji, Chinese) print as "?". Right-to-left scripts are not shaped. A text
file without a byte-order mark is read as UTF-8, else in the machine's ANSI code page.

Saving keeps bookmarks, attachments, language and layers. A changed document does not keep a
PDF/A claim: convert it again after editing.

Not supported: rendering pages to images, OCR without Tesseract on the machine.

## OCR (scanned pages)

`PdfOcr` reads scanned PDFs and TIFF, JPEG and PNG scans with Tesseract, which must already be
installed. It looks for it in this order: a `Tesseract` folder beside the running program (where
automation platforms keep a bundled copy, e.g. `tesseract-4.0.0.exe`), a standalone install
(`Tesseract-OCR` under Program Files or the user's programs), then PATH. `TesseractPath` and
`TessdataFolder` override both.

- Each page is checked first. Typed text is read directly; a scanned page is drawn from its
  images at the scan's own resolution and handed to Tesseract. `ReadPages` says per page which
  happened (`ocr`, `text`, `text+ocr`, `none`, `failed`) and why a page failed.
- Scans in every common encoding are decoded: JPEG, fax (CCITT Group 3 and 4), Flate, LZW,
  1/2/4/8/16-bit, grey, RGB, CMYK, palette, masks, inline images, pages turned by `/Rotate` or by
  their content. JBIG2 and JPEG 2000 scans are reported as failed pages, not read.
- Languages: Tesseract codes joined with `+` (`eng`, `deu+eng`, `ara+eng`). Each needs its
  `.traineddata` file in the tessdata folder, in the version that matches the installed
  Tesseract (4.0 files for Tesseract 4.0). A missing one gives an error that names the folder.
- Typed text whose characters cannot be read (it pastes as rubbish, e.g. Type 3 fonts named
  `T3Font_0` with private codes, or fonts without a character map) is drawn from the PDF's own fonts
  (TrueType, CFF and Type 3 glyphs, vector or bitmap) and read by Tesseract; the page's note says so.
  `ForceOcr` does that for every page.
- Typed Arabic and Hebrew come back in reading order with ordinary letters (PDF producers store
  them in drawing order, often as presentation forms). `PdfText` and `ToText` are unchanged and
  still return drawing order.
- Image files go to Tesseract directly: a TIFF with all its pages, a photo turned upright first as
  its camera recorded.
- The `Tesseract OCR` automation object in `vbo/` carries this code inside itself (generated from these
  sources), so it needs no DLL: import it and it runs. Its Output File input also writes the text to
  a .txt file (UTF-8 with byte-order mark, Windows line breaks).
- Tesseract runs once per document, hidden, with a time limit of one minute plus 30 seconds a
  page (`TimeoutSeconds` changes it). Page images go to a folder in the user's temp directory and
  are deleted afterwards.

## Compatibility

The library is meant to sit under long-lived automations, so new versions follow these rules:

- Existing public methods keep their names, parameters, return types and behaviour. A feature
  that extends an existing method arrives as a new overload or a new optional parameter whose
  default reproduces today's output byte for byte.
- Existing actions in the automation object keep their names, inputs and outputs. New features
  add actions; nothing is renamed or removed.
- `PdfHelp.Version` (also shown in the DLL's file properties) is `major.minor.patch`: the minor
  number rises when methods or actions are added, the patch number for fixes. A change that
  breaks one of the rules above, which is not planned, would raise the major number and be
  listed here.
- The internal check suite runs against every build, so an unintended change in an old method's
  output fails the build rather than reaching a process.

Replacing the DLL: it is one file shared by every object that references it, and it is loaded
into memory while automations run. Stop the runtime resources that use it, swap the file, and
start them again. Processes need no change and no republishing.

## Build

`Pdfx.dll` in this folder is the release build of `src/`. It is deterministic, so the same sources always produce the same bytes. To rebuild it yourself:

```
dotnet build Pdfx.csproj -c Release
```

Or, with the C# compiler that ships with the .NET Framework itself (the code is C# 5 compatible):

```
C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe /target:library /out:Pdfx.dll /optimize+ /r:System.dll /r:System.Core.dll /r:System.Drawing.dll src\*.cs
```

## Verification

- An internal suite of 158 checks covers every module, and each check has been made to fail by breaking the behaviour it guards.
- PDF/A output was validated with veraPDF 1.30 across 344 conversions: 11 synthetic files and 32 real-world PDFs from 18 producers, each at all 8 levels. Every one is compliant.
- Every output was also rendered and compared against its source.
- OCR: 23 scan fixtures (every image encoding above, rotations, forms, inline images, typed and
  blank pages, multi-page TIFF, rotated phone photos, English and Arabic) read as well as Tesseract
  reads the original scans; fax decoding matches libtiff bit for bit; pages drawn from a scan
  reproduce it pixel for pixel; typed Arabic from three producer styles comes back exactly; seven
  typed PDFs with unreadable text layers (vector and bitmap Type 3, two-byte TrueType, CFF, symbolic
  TrueType, rotated) are drawn from their fonts within 85-92% ink overlap of an independent renderer
  and read in full. The OCR fixtures pass on Tesseract 4.0.0 (the version automation platforms
  bundle) and on 5.5.

## Using the DLL from a download

Windows marks files extracted from a downloaded zip, and .NET Framework refuses to load a
marked assembly ("An attempt was made to load an assembly from a network location"). Clear
the mark once, in PowerShell, from the extracted folder:

```powershell
Get-ChildItem -Recurse | Unblock-File
```

Check the DLL is the published one (works with FIPS mode on):

```powershell
$h=(New-Object Security.Cryptography.SHA256CryptoServiceProvider).ComputeHash([IO.File]::ReadAllBytes("$PWD\Pdfx.dll")); ($h|%{$_.ToString('x2')}) -join ''
```

Expected: `e3499b353e0f328336dc632b6e29d60f9205efba7ed92cada1a57944bed12d71`
