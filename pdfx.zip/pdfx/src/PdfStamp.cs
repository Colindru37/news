using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using Pdfx.Internal;

namespace Pdfx
{
    public sealed class PdfStampOptions
    {
        public string FontName = "Helvetica";
        public double FontSize = 12;
        public double Rotation;
        public double Opacity = 1;
        public double Red;
        public double Green;
        public double Blue;

        internal PdfStampOptions Copy() { return (PdfStampOptions)MemberwiseClone(); }
    }

    public static class PdfStamp
    {
        public static void AddText(PdfPage page, string text, double x, double y, PdfStampOptions o)
        {
            AddText(page, text, x, y, o, null);
        }

        // Text outside the standard Latin set (\u0219 \u021B \u0102 \u20AC ...) cannot be written with the
        // built-in fonts; it gets an embedded subset instead. shared lets one font serve many pages.
        internal static void AddText(PdfPage page, string text, double x, double y, PdfStampOptions o, EmbeddedFont shared)
        {
            if (page == null) throw new ArgumentNullException("page");
            if (string.IsNullOrEmpty(text)) return;
            if (o == null) o = new PdfStampOptions();
            if (!Plain(text) || shared != null)
            {
                EmbeddedFont font = shared ?? EmbeddedFont.Load(IsMono(o.FontName));
                AddUnicode(page, text, x, y, o, font, shared == null);
                return;
            }

            string fontKey = EnsureFont(page, o.FontName);
            string gsKey = o.Opacity < 1 ? EnsureAlpha(page, o.Opacity) : null;

            StringBuilder c = new StringBuilder();
            c.Append("q\n");
            Unrotate(c, page);
            if (gsKey != null) c.Append("/").Append(gsKey).Append(" gs\n");
            c.Append(N(o.Red)).Append(' ').Append(N(o.Green)).Append(' ').Append(N(o.Blue)).Append(" rg\n");
            c.Append("BT\n/").Append(fontKey).Append(' ').Append(N(o.FontSize)).Append(" Tf\n");

            double rad = o.Rotation * Math.PI / 180.0;
            double cos = Math.Cos(rad), sin = Math.Sin(rad);
            c.Append(N(cos)).Append(' ').Append(N(sin)).Append(' ')
             .Append(N(-sin)).Append(' ').Append(N(cos)).Append(' ')
             .Append(N(x)).Append(' ').Append(N(y)).Append(" Tm\n");

            c.Append(PdfSerializer.LiteralString(Latin1(text))).Append(" Tj\nET\nQ\n");

            Append(page, Encoding.ASCII.GetBytes(c.ToString()));
        }

        public static void AddWatermark(PdfPage page, string text, PdfStampOptions o)
        {
            AddWatermark(page, text, o, null);
        }

        internal static void AddWatermark(PdfPage page, string text, PdfStampOptions o, EmbeddedFont shared)
        {
            if (o == null)
            {
                o = new PdfStampOptions();
                o.FontSize = 48;
                o.Opacity = 0.15;
                o.Red = 0.5; o.Green = 0.5; o.Blue = 0.5;
            }
            // The caller's options are not changed: reusing them for a footer must not tilt it.
            o = o.Copy();
            o.Rotation = 45;

            double w = shared != null ? Measure(text, o.FontSize, shared) : Measure(text, o);
            double rad = 45 * Math.PI / 180.0;
            double x = page.VisibleWidth / 2 - (w / 2) * Math.Cos(rad);
            double y = page.VisibleHeight / 2 - (w / 2) * Math.Sin(rad);
            AddText(page, text, x, y, o, shared);
        }

        public static void AddJpeg(PdfPage page, byte[] jpeg, double x, double y, double width, double height)
        {
            if (page == null) throw new ArgumentNullException("page");
            if (jpeg == null || jpeg.Length < 4) throw new Internal.PdfException("no JPEG data");

            int pw, ph, comps;
            if (!JpegSize(jpeg, out pw, out ph, out comps))
                throw new Internal.PdfException("not a JPEG, or its size marker could not be read");

            if (width <= 0) width = pw;
            if (height <= 0) height = ph;

            PdfDictionary d = new PdfDictionary();
            d.Set("Type", new PdfName("XObject"));
            d.Set("Subtype", new PdfName("Image"));
            d.Set("Width", new PdfNumber(pw, true));
            d.Set("Height", new PdfNumber(ph, true));
            d.Set("ColorSpace", new PdfName(comps == 1 ? "DeviceGray" : comps == 4 ? "DeviceCMYK" : "DeviceRGB"));
            d.Set("BitsPerComponent", new PdfNumber(8, true));
            d.Set("Filter", new PdfName("DCTDecode"));

            string key = EnsureXObject(page, new PdfStream(d, jpeg));

            StringBuilder c = new StringBuilder();
            c.Append("q\n");
            Unrotate(c, page);
            c.Append(N(width)).Append(" 0 0 ").Append(N(height)).Append(' ')
             .Append(N(x)).Append(' ').Append(N(y)).Append(" cm\n")
             .Append("/").Append(key).Append(" Do\nQ\n");

            Append(page, Encoding.ASCII.GetBytes(c.ToString()));
        }

        internal static bool Plain(string s)
        {
            foreach (char c in s) if (c >= 0x80 && (c < 0xA0 || c > 0xFF)) return false;
            return true;
        }

        private static bool IsMono(string fontName)
        {
            return fontName != null && fontName.IndexOf("Courier", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        // Width in points, whichever font the text will actually be drawn with.
        internal static double Measure(string text, PdfStampOptions o)
        {
            if (Plain(text)) return MeasureText(text, o.FontName, o.FontSize);
            return Measure(text, o.FontSize, EmbeddedFont.Load(IsMono(o.FontName)));
        }

        internal static double Measure(string text, double size, EmbeddedFont f)
        {
            double w = 0;
            for (int i = 0; i < text.Length; i++)
            {
                w += f.Width(char.ConvertToUtf32(text, i));
                if (char.IsSurrogatePair(text, i)) i++;
            }
            return w / 1000.0 * size;
        }

        private static void AddUnicode(PdfPage page, string text, double x, double y, PdfStampOptions o, EmbeddedFont font, bool finish)
        {
            PdfDictionary fonts = OwnSub(page, "Font");
            PdfDictionary type0 = font.Type0();
            string key = null;
            foreach (KeyValuePair<string, PdfObject> kv in fonts.Map) if (ReferenceEquals(kv.Value, type0)) key = kv.Key;
            if (key == null)
            {
                int n = 1;
                while (fonts.Has("PdfxU" + n)) n++;
                key = "PdfxU" + n;
                fonts.Set(key, type0);
            }
            string gsKey = o.Opacity < 1 ? EnsureAlpha(page, o.Opacity) : null;
            StringBuilder c = new StringBuilder();
            c.Append("q\n");
            Unrotate(c, page);
            if (gsKey != null) c.Append("/").Append(gsKey).Append(" gs\n");
            c.Append(N(o.Red)).Append(' ').Append(N(o.Green)).Append(' ').Append(N(o.Blue)).Append(" rg\n");
            c.Append("BT\n/").Append(key).Append(' ').Append(N(o.FontSize)).Append(" Tf\n");
            double rad = o.Rotation * Math.PI / 180.0;
            double cos = Math.Cos(rad), sin = Math.Sin(rad);
            c.Append(N(cos)).Append(' ').Append(N(sin)).Append(' ').Append(N(-sin)).Append(' ').Append(N(cos)).Append(' ')
             .Append(N(x)).Append(' ').Append(N(y)).Append(" Tm\n");
            c.Append('<').Append(font.Hex(text)).Append("> Tj\nET\nQ\n");
            Append(page, Encoding.ASCII.GetBytes(c.ToString()));
            if (finish) font.Finish();
        }

        public static double MeasureText(string text, string fontName, double size)
        {
            int[] widths = StandardWidths.For(fontName ?? "Helvetica");
            double total = 0;
            for (int i = 0; i < text.Length; i++)
            {
                int code = text[i];
                int w = (code >= 32 && code <= 126 && widths != null) ? widths[code - 32] : 500;
                total += w;
            }
            return total / 1000.0 * size;
        }

        internal static bool JpegSize(byte[] d, out int width, out int height, out int components)
        {
            width = height = components = 0;
            if (d.Length < 4 || d[0] != 0xFF || d[1] != 0xD8) return false;

            int i = 2;
            while (i + 3 < d.Length)
            {
                if (d[i] != 0xFF) { i++; continue; }
                int marker = d[i + 1];
                if (marker == 0xD8 || marker == 0x01 || (marker >= 0xD0 && marker <= 0xD7)) { i += 2; continue; }
                if (i + 3 >= d.Length) break;
                int len = (d[i + 2] << 8) | d[i + 3];
                bool isSof = (marker >= 0xC0 && marker <= 0xCF)
                             && marker != 0xC4 && marker != 0xC8 && marker != 0xCC;
                if (isSof)
                {
                    if (i + 9 >= d.Length) return false;
                    height = (d[i + 5] << 8) | d[i + 6];
                    width = (d[i + 7] << 8) | d[i + 8];
                    components = d[i + 9];
                    return width > 0 && height > 0;
                }
                i += 2 + len;
            }
            return false;
        }

        internal static void AppendContent(PdfPage page, byte[] content)
        {
            Append(page, content);
        }

        internal static string AddFormXObject(PdfPage page, PdfStream form)
        {
            return EnsureXObject(page, form);
        }

        // Stamp coordinates are VISIBLE-page coordinates: (0,0) is the bottom-left
        // of the page as a reader displays it, whatever /Rotate says. Without this
        // a footer at y=24 lands up the side of a /Rotate 90 page - valid file,
        // right text, wrong place, and nothing reports an error.
        // Emits nothing when the page is unrotated, so existing output is unchanged.
        private static void Unrotate(StringBuilder c, PdfPage page)
        {
            int r = page.Rotation;
            if (r == 0) return;

            double[] box = page.MediaBox;
            double mw = Math.Abs(box[2] - box[0]);
            double mh = Math.Abs(box[3] - box[1]);

            // Inverse of the viewer's display transform, so visible coords map
            // back into user space. Derived in PDF user space (y up), NOT from
            // MuPDF's rotation_matrix - that one is top-down, and mixing the two
            // conventions silently flips the y axis.
            //   /Rotate 90  displays user (x,y) at (y, MW - x)
            //   /Rotate 180 displays user (x,y) at (MW - x, MH - y)
            //   /Rotate 270 displays user (x,y) at (MH - y, x)
            double a, b, cc, d, e, f;
            if (r == 90) { a = 0; b = 1; cc = -1; d = 0; e = mw; f = 0; }
            else if (r == 180) { a = -1; b = 0; cc = 0; d = -1; e = mw; f = mh; }
            else { a = 0; b = -1; cc = 1; d = 0; e = 0; f = mh; }

            e += box[0];
            f += box[1];

            c.Append(N(a)).Append(' ').Append(N(b)).Append(' ').Append(N(cc)).Append(' ')
             .Append(N(d)).Append(' ').Append(N(e)).Append(' ').Append(N(f)).Append(" cm\n");
        }

        private static void Append(PdfPage page, byte[] content)
        {
            PdfArray list = new PdfArray();
            list.Items.Add(new PdfStream(new PdfDictionary(), Encoding.ASCII.GetBytes("q\n")));

            PdfObject existing = page.Dictionary.Get("Contents");
            // Some producers point /Contents at an array object. Nested inside the new array, that
            // reference would be an array where a stream must be, and viewers drop the page's
            // original content. Resolve it and splice its streams in instead.
            PdfArray existingArray = existing as PdfArray;
            if (existingArray == null && existing is PdfRef && page.Source != null)
                existingArray = page.Source.Resolve(existing) as PdfArray;
            if (existingArray != null)
                for (int i = 0; i < existingArray.Count; i++) list.Items.Add(existingArray[i]);
            else if (existing != null && !(existing is PdfNull))
                list.Items.Add(existing);

            list.Items.Add(new PdfStream(new PdfDictionary(), Encoding.ASCII.GetBytes("\nQ\n")));
            list.Items.Add(new PdfStream(new PdfDictionary(), content));

            page.Dictionary.Set("Contents", list);
        }

        private static readonly string[] Subs = { "Font", "XObject", "ExtGState" };

        private static PdfDictionary OwnResources(PdfPage page)
        {
            if (page.OwnedResources != null) return page.OwnedResources;

            PdfObject r = page.Dictionary.Get("Resources");
            PdfDictionary source = (page.SourceFile != null ? page.SourceFile.Resolve(r) : r) as PdfDictionary;

            PdfDictionary copy = new PdfDictionary();
            if (source != null)
                foreach (KeyValuePair<string, PdfObject> kv in source.Map) copy.Set(kv.Key, kv.Value);

            for (int i = 0; i < Subs.Length; i++)
            {
                PdfObject sub = copy.Get(Subs[i]);
                PdfDictionary subSource =
                    (page.SourceFile != null ? page.SourceFile.Resolve(sub) : sub) as PdfDictionary;
                PdfDictionary subCopy = new PdfDictionary();
                if (subSource != null)
                    foreach (KeyValuePair<string, PdfObject> kv in subSource.Map) subCopy.Set(kv.Key, kv.Value);
                copy.Set(Subs[i], subCopy);
            }

            page.Dictionary.Set("Resources", copy);
            page.OwnedResources = copy;
            return copy;
        }

        private static PdfDictionary OwnSub(PdfPage page, string name)
        {
            PdfDictionary res = OwnResources(page);
            PdfDictionary sub = res.Get(name) as PdfDictionary;
            if (sub == null) { sub = new PdfDictionary(); res.Set(name, sub); }
            return sub;
        }

        private static string EnsureFont(PdfPage page, string baseFont)
        {
            PdfDictionary fonts = OwnSub(page, "Font");
            string key = "PdfxF" + Sanitise(baseFont);
            if (!fonts.Has(key))
            {
                PdfDictionary f = new PdfDictionary();
                f.Set("Type", new PdfName("Font"));
                f.Set("Subtype", new PdfName("Type1"));
                f.Set("BaseFont", new PdfName(baseFont));
                f.Set("Encoding", new PdfName("WinAnsiEncoding"));
                fonts.Set(key, f);
            }
            return key;
        }

        private static string EnsureAlpha(PdfPage page, double alpha)
        {
            PdfDictionary states = OwnSub(page, "ExtGState");
            string key = "PdfxGS" + ((int)Math.Round(alpha * 100)).ToString(CultureInfo.InvariantCulture);
            if (!states.Has(key))
            {
                PdfDictionary gs = new PdfDictionary();
                gs.Set("Type", new PdfName("ExtGState"));
                gs.Set("ca", new PdfNumber(alpha, false));
                gs.Set("CA", new PdfNumber(alpha, false));
                states.Set(key, gs);
            }
            return key;
        }

        private static string EnsureXObject(PdfPage page, PdfStream image)
        {
            PdfDictionary xobjects = OwnSub(page, "XObject");
            int n = 1;
            while (xobjects.Has("PdfxIm" + n)) n++;
            string key = "PdfxIm" + n;
            xobjects.Set(key, image);
            return key;
        }

        private static string Sanitise(string s)
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < s.Length; i++)
                if (char.IsLetterOrDigit(s[i])) sb.Append(s[i]);
            return sb.Length == 0 ? "X" : sb.ToString();
        }

        private static byte[] Latin1(string s)
        {
            byte[] b = new byte[s.Length];
            for (int i = 0; i < s.Length; i++) b[i] = s[i] < 256 ? (byte)s[i] : (byte)'?';
            return b;
        }

        private static string N(double v)
        {
            return PdfSerializer.Number(v, false);
        }
    }
}
