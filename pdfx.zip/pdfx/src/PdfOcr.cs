using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using Pdfx.Internal;

namespace Pdfx
{
    // Settings for PdfOcr. Every field has a working default.
    public sealed class PdfOcrOptions
    {
        // Full path of tesseract.exe. Empty: look in the usual install folders and on PATH.
        public string TesseractPath;
        // Tesseract language codes joined with '+', e.g. "eng", "deu+eng", "ara+eng".
        public string Language = "eng";
        // Folder holding the *.traineddata files, when it is not the one next to tesseract.exe.
        public string TessdataFolder;
        // Password of a protected PDF.
        public string Password;
        // How long Tesseract may take for the whole document; 0 = one minute plus 30 seconds a page.
        public int TimeoutSeconds;
        // Resolution of the page images handed to Tesseract; 0 picks it from the scan (150-400).
        public int Dpi;
        // Read every page with Tesseract, also pages whose typed text looks fine. Typed text is drawn
        // from the PDF's fonts for that. Use it when a PDF's text comes out as rubbish.
        public bool ForceOcr;
    }

    // One page's result. Method: "ocr" (read by Tesseract), "text" (the page carries real text,
    // taken as it is), "text+ocr" (both), "none" (nothing to read), "failed" (see Note).
    public sealed class PdfOcrPage
    {
        public int Number;
        public string Text = "";
        public string Method = "none";
        public string Note = "";
    }

    // Text from scanned PDFs (and TIFF/JPEG/PNG scans) through Tesseract, which must already be on
    // the machine. Pages that already carry real text are read directly, without OCR.
    public static class PdfOcr
    {
        public static string ExtractText(string input)
        {
            return ExtractText(input, new PdfOcrOptions());
        }

        public static string ExtractText(string input, PdfOcrOptions options)
        {
            PdfOcrPage[] pages = ReadPages(input, options);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < pages.Length; i++)
            {
                if (i > 0) sb.Append('\f');
                sb.Append(pages[i].Text);
            }
            return sb.ToString();
        }

        public static PdfOcrPage[] ReadPages(string input, PdfOcrOptions options)
        {
            if (options == null) throw new ArgumentNullException("options");
            string exe = ResolveTesseract(options.TesseractPath);
            string lang = (options.Language ?? "").Trim();
            if (lang.Length == 0) lang = "eng";
            foreach (char c in lang)
                if (!(char.IsLetterOrDigit(c) || c == '+' || c == '_' || c == '-'))
                    throw new ArgumentException("Language must look like eng, deu+eng or ara+eng, not '" + options.Language + "'");
            if (options.Dpi != 0 && (options.Dpi < 70 || options.Dpi > 1200)) throw new ArgumentException("Dpi must be 0 (automatic) or between 70 and 1200");
            if (options.TimeoutSeconds < 0) throw new ArgumentException("TimeoutSeconds must be 0 (automatic) or more");
            byte[] data = ReadFile(input);

            string dir = Path.Combine(TempRoot ?? Path.GetTempPath(), "pdfx-ocr-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(dir);
            try
            {
                string kind = ImageKind(data);
                if (kind != null) return ReadImage(exe, dir, data, kind, lang, options);
                using (PdfFile f = PdfFile.Open(data))
                {
                    if (f.IsEncrypted && f.Decryptor == null && options.Password != null) f.Unlock(options.Password);
                    if (f.IsEncrypted && f.Decryptor == null)
                        throw new Internal.PdfException("cannot open the document: " + (f.DecryptionProblem ?? "it is encrypted and could not be unlocked"));
                    return ReadPdf(exe, dir, PdfPageTree.Pages(f), lang, options);
                }
            }
            finally
            {
                try { Directory.Delete(dir, true); } catch (Exception) { }
            }
        }

        private static PdfOcrPage[] ReadPdf(string exe, string dir, List<PdfPage> pdfPages, string lang, PdfOcrOptions options)
        {
            List<PdfOcrPage> result = new List<PdfOcrPage>();
            List<int> queued = new List<int>();
            List<string> files = new List<string>();
            List<string> textLayer = new List<string>();
            for (int i = 0; i < pdfPages.Count; i++)
            {
                PdfOcrPage r = new PdfOcrPage();
                r.Number = i + 1;
                result.Add(r);
                PdfPage page = pdfPages[i];
                string text = "";
                bool visibleText = false;
                List<PdfGlyph> exact = null;
                int shown = 0, untrusted = 0;
                try
                {
                    exact = PdfContentReader.Extract(page, true);
                    foreach (PdfGlyph g in exact)
                    {
                        if (g.RenderMode == 3 || g.RenderMode == 7) continue;
                        bool blank = g.Text == null || g.Text.Trim().Length == 0;
                        if (blank && g.Trusted) continue;           // a real space
                        shown++;
                        if (!g.Trusted) untrusted++;
                        if (!blank) visibleText = true;
                    }
                    if (visibleText)
                    {
                        List<PdfGlyph> plain = PdfContentReader.Extract(page);
                        text = (RtlText.HasRtl(plain) ? RtlText.Read(plain) : PdfText.Extract(page)).Trim();
                    }
                }
                catch (Exception e) { r.Note = "text layer unreadable: " + e.Message; }

                // Typed text that cannot be trusted (fonts without a character map, Type 3 fonts with
                // private codes, or text that is mostly not letters) is drawn and read by OCR instead.
                string why = null;
                if (shown > 0 && options.ForceOcr) why = "OCR forced";
                else if (shown >= 10 && untrusted * 2 >= shown) why = "the text layer has no usable character map";
                else if (shown >= 10 && LetterShare(text) < 0.35) why = "the text layer does not read as words";

                PdfScanPage scan;
                try { scan = PdfScanPage.Collect(page, why != null ? exact : null); }
                catch (Exception e) { scan = null; r.Note = Join(r.Note, "images unreadable: " + e.Message); }

                bool hasScan = scan != null && scan.Coverage >= 0.05;
                if (why != null && scan != null)
                {
                    string name = "p" + (i + 1).ToString("D5") + ".png";
                    scan.Render(Path.Combine(dir, name), options.Dpi);
                    queued.Add(i);
                    files.Add(name);
                    textLayer.Add("\u0001" + text);              // marked: kept only if OCR finds nothing
                    r.Method = "ocr";
                    r.Note = Join(r.Note, "typed text read by OCR: " + why);
                }
                else if (hasScan && scan.Images.Count > 0)
                {
                    string name = "p" + (i + 1).ToString("D5") + ".png";
                    scan.Render(Path.Combine(dir, name), options.Dpi);
                    queued.Add(i);
                    files.Add(name);
                    textLayer.Add(text);
                    r.Method = visibleText && text.Length > 0 ? "text+ocr" : "ocr";
                }
                else if (text.Length > 0) { r.Method = "text"; r.Text = text; }
                else if (hasScan) r.Method = "failed";
                if (scan != null && scan.Problems.Count > 0) r.Note = Join(r.Note, string.Join("; ", scan.Problems.ToArray()));
            }
            if (queued.Count > 0)
            {
                string[] read = Tesseract.Run(exe, dir, files, lang, options);
                for (int q = 0; q < queued.Count; q++)
                {
                    PdfOcrPage r = result[queued[q]];
                    string ocr = Clean(read[q]);
                    string layer = textLayer[q];
                    if (layer.StartsWith("\u0001", StringComparison.Ordinal))
                    {
                        layer = layer.Substring(1);
                        if (ocr.Trim().Length == 0 && layer.Length > 0)
                        {
                            // nothing could be drawn (fonts not embedded): the text layer is all there is
                            r.Method = "text";
                            r.Text = layer;
                            r.Note = Join(r.Note, "OCR found nothing to read, so the text layer was kept");
                            continue;
                        }
                        layer = "";
                    }
                    r.Text = (r.Method == "text+ocr" ? layer + "\r\n" + ocr : ocr).Trim();
                }
            }
            return result.ToArray();
        }

        // An image file goes to Tesseract as it is (TIFF, every page) or, for photos, upright first.
        private static PdfOcrPage[] ReadImage(string exe, string dir, byte[] data, string kind, string lang, PdfOcrOptions options)
        {
            string name;
            if (kind == "tiff")
            {
                name = "p00001.tif";
                File.WriteAllBytes(Path.Combine(dir, name), data);
            }
            else
            {
                name = "p00001.png";
                double dpi;
                GreyImage g = ImageDecoder.Photo(data, out dpi);
                if (options.Dpi > 0) dpi = options.Dpi;
                Png.WriteGrey(Path.Combine(dir, name), g, dpi);
            }
            string[] parts = Tesseract.RunFile(exe, dir, name, lang, options);
            PdfOcrPage[] r = new PdfOcrPage[parts.Length];
            for (int i = 0; i < parts.Length; i++)
            {
                r[i] = new PdfOcrPage();
                r[i].Number = i + 1;
                r[i].Text = Clean(parts[i]);
                r[i].Method = r[i].Text.Length > 0 ? "ocr" : "none";
            }
            return r;
        }

        private static string ImageKind(byte[] b)
        {
            if (b.Length < 8) return null;
            if (b[0] == 0xFF && b[1] == 0xD8) return "jpeg";
            if (b[0] == 0x89 && b[1] == 'P' && b[2] == 'N' && b[3] == 'G') return "png";
            if ((b[0] == 'I' && b[1] == 'I' && b[2] == 42 && b[3] == 0) || (b[0] == 'M' && b[1] == 'M' && b[2] == 0 && b[3] == 42)) return "tiff";
            if (b[0] == 'B' && b[1] == 'M') return "bmp";
            if (b[0] == 'G' && b[1] == 'I' && b[2] == 'F' && b[3] == '8') return "gif";
            return null;
        }

        private static string CleanPath(string path)
        {
            if (path == null) throw new ArgumentNullException("path");
            string p = path.Trim();
            if (p.Length >= 2 && p[0] == '"' && p[p.Length - 1] == '"') p = p.Substring(1, p.Length - 2).Trim();
            if (p.Length == 0) throw new ArgumentException("the file path is empty");
            return p;
        }

        private static byte[] ReadFile(string path)
        {
            path = CleanPath(path);
            if (Directory.Exists(path)) throw new Internal.PdfException("expected a file but got a folder: " + path);
            if (!File.Exists(path)) throw new Internal.PdfException("file not found: " + path);
            byte[] b = File.ReadAllBytes(path);
            if (b.Length == 0) throw new Internal.PdfException("the file is empty: " + path);
            return b;
        }

        // Where page images are written; null = the user's temp folder. Set by the self-test only.
        internal static string TempRoot;

        // The tesseract.exe this machine would use, or null when none is found: a Tesseract folder
        // beside the running program first, then a standalone install, then PATH.
        public static string FindTesseract()
        {
            foreach (string p in Candidates()) if (File.Exists(p)) return p;
            return null;
        }

        private static bool Windows { get { return Path.DirectorySeparatorChar == '\\'; } }

        private static IEnumerable<string> Roots()
        {
            string[] env = { "ProgramFiles", "ProgramW6432", "ProgramFiles(x86)" };
            foreach (string e in env) { string v = Environment.GetEnvironmentVariable(e); if (!string.IsNullOrEmpty(v)) yield return v; }
        }

        internal static IEnumerable<string> Folders()
        {
            // an automation platform that bundles Tesseract keeps it in a Tesseract folder beside its
            // own program, and a code stage runs inside that program
            string host = AppDomain.CurrentDomain.BaseDirectory;
            if (!string.IsNullOrEmpty(host)) yield return Path.Combine(host, "Tesseract");
            foreach (string r in Roots()) yield return Path.Combine(r, "Tesseract-OCR");
            // a Tesseract folder that another product bundles, two levels down (vendor, product)
            foreach (string r in Roots())
            {
                string[] vendors;
                try { vendors = Directory.GetDirectories(r); } catch (Exception) { continue; }
                Array.Sort(vendors, StringComparer.OrdinalIgnoreCase);
                foreach (string v in vendors)
                {
                    string[] products;
                    try { products = Directory.GetDirectories(v); } catch (Exception) { continue; }
                    Array.Sort(products, StringComparer.OrdinalIgnoreCase);
                    foreach (string pr in products) yield return Path.Combine(pr, "Tesseract");
                }
            }
            string la = Environment.GetEnvironmentVariable("LOCALAPPDATA");
            if (!string.IsNullOrEmpty(la))
            {
                yield return Path.Combine(Path.Combine(la, "Programs"), "Tesseract-OCR");
                yield return Path.Combine(la, "Tesseract-OCR");
            }
            foreach (string part in (Environment.GetEnvironmentVariable("PATH") ?? "").Split(Path.PathSeparator))
            {
                string t = part.Trim().Trim('"');
                if (t.Length > 0 && t.IndexOfAny(Path.GetInvalidPathChars()) < 0) yield return t;
            }
        }

        private static IEnumerable<string> Candidates()
        {
            foreach (string dir in Folders())
            {
                string hit = InFolder(dir);
                if (hit != null) yield return hit;
            }
        }

        // tesseract.exe in a folder, or a versioned name such as tesseract400.exe
        internal static string InFolder(string dir)
        {
            try
            {
                if (!Directory.Exists(dir)) return null;
                string plain = Path.Combine(dir, Windows ? "tesseract.exe" : "tesseract");
                if (File.Exists(plain)) return plain;
                string[] any = Directory.GetFiles(dir, "tesseract*.exe");
                Array.Sort(any, StringComparer.OrdinalIgnoreCase);
                return any.Length > 0 ? any[0] : null;
            }
            catch (Exception) { return null; }
        }

        private static string ResolveTesseract(string given)
        {
            if (!string.IsNullOrEmpty(given) && given.Trim().Length > 0)
            {
                string p = CleanPath(given);
                if (Directory.Exists(p))
                {
                    string inside = InFolder(p);
                    if (inside != null) return Path.GetFullPath(inside);
                    throw new Internal.PdfException("no tesseract executable in the folder " + p);
                }
                if (File.Exists(p)) return Path.GetFullPath(p);
                throw new Internal.PdfException("tesseract not found at " + p);
            }
            string found = FindTesseract();
            if (found != null) return found;
            string host = AppDomain.CurrentDomain.BaseDirectory ?? "";
            throw new Internal.PdfException("tesseract was not found; give its full path. Looked for a Tesseract folder beside "
                + host + ", for Tesseract-OCR and <vendor>\\<product>\\Tesseract under Program Files, and on PATH");
        }

        // Language files: the folder given, else the tessdata folder next to the executable.
        internal static string Tessdata(string exe, string given)
        {
            if (!string.IsNullOrEmpty(given) && given.Trim().Length > 0)
            {
                string g = CleanPath(given);
                if (!Directory.Exists(g)) throw new Internal.PdfException("tessdata folder not found: " + g);
                return Path.GetFullPath(g);
            }
            string next = Path.Combine(Path.GetDirectoryName(Path.GetFullPath(exe)), "tessdata");
            return Directory.Exists(next) ? next : null;
        }

        // Share of letters among the visible characters; rubbish from private font codes is mostly not.
        private static double LetterShare(string s)
        {
            int all = 0, letters = 0;
            foreach (char c in s ?? "")
            {
                if (char.IsWhiteSpace(c)) continue;
                all++;
                if (char.IsLetter(c)) letters++;
            }
            return all == 0 ? 1 : (double)letters / all;
        }

        private static string Join(string a, string b) { return a.Length == 0 ? b : a + "; " + b; }

        private static string Clean(string s)
        {
            if (s == null) return "";
            s = s.Replace("\r\n", "\n").Replace('\f', '\n');
            StringBuilder sb = new StringBuilder();
            int blank = 0;
            foreach (string line in s.Split('\n'))
            {
                string t = line.TrimEnd();
                if (t.Length == 0) { blank++; continue; }
                if (sb.Length > 0) sb.Append(blank > 0 ? "\r\n\r\n" : "\r\n");       // Windows line breaks, as PdfText
                sb.Append(t);
                blank = 0;
            }
            return sb.ToString();
        }
    }
}

namespace Pdfx.Internal
{
    // Runs tesseract.exe over page images: one process for the whole document, falling back to one
    // per page when the output cannot be split back into pages.
    internal static class Tesseract
    {
        private const string Break = "@@PDFX-PAGE-BREAK@@";

        public static string[] Run(string exe, string dir, List<string> files, string lang, PdfOcrOptions o)
        {
            StringBuilder list = new StringBuilder();
            foreach (string f in files) list.Append(f).Append('\n');
            File.WriteAllText(Path.Combine(dir, "pages.txt"), list.ToString(), new UTF8Encoding(false));
            DateTime deadline = Deadline(o, files.Count);
            if (files.Count > 1)
            {
                string[] parts = Split(Once(exe, dir, "pages.txt", "out", lang, o, deadline, true), files.Count);
                if (parts != null) return parts;
            }
            string[] r = new string[files.Count];
            for (int i = 0; i < files.Count; i++) r[i] = Once(exe, dir, files[i], "out" + i, lang, o, deadline, false);
            return r;
        }

        // One file that may hold several pages (a multi-page TIFF): one part per page.
        public static string[] RunFile(string exe, string dir, string file, string lang, PdfOcrOptions o)
        {
            string all = Once(exe, dir, file, "out", lang, o, Deadline(o, 10), true);
            string[] parts = all.Split(new[] { Break }, StringSplitOptions.None);
            if (parts.Length == 1) parts = all.Split('\f');          // a Tesseract that ignores the separator setting
            List<string> keep = new List<string>(parts);
            if (keep.Count > 1 && keep[keep.Count - 1].Trim().Length == 0) keep.RemoveAt(keep.Count - 1);
            return keep.ToArray();
        }

        private static DateTime Deadline(PdfOcrOptions o, int pages)
        {
            int limit = o.TimeoutSeconds > 0 ? o.TimeoutSeconds : 60 + 30 * pages;
            return DateTime.UtcNow.AddSeconds(Math.Max(30, limit));
        }

        // Pages of a batch run: by our separator, or by the form feed of a Tesseract (4.0) that has
        // no separator setting; null when neither gives one part per page.
        private static string[] Split(string all, int count)
        {
            foreach (string[] parts0 in new[] { all.Split(new[] { Break }, StringSplitOptions.None), all.Split('\f') })
            {
                string[] parts = parts0;
                if (parts.Length == count + 1 && parts[count].Trim().Length == 0) Array.Resize(ref parts, count);
                if (parts.Length == count) return parts;
            }
            return null;
        }

        private static string Once(string exe, string dir, string input, string outBase, string lang, PdfOcrOptions o, DateTime deadline, bool batch)
        {
            StringBuilder args = new StringBuilder();
            args.Append(Q(input)).Append(' ').Append(Q(outBase)).Append(" -l ").Append(lang);
            string td = PdfOcr.Tessdata(exe, o.TessdataFolder);
            if (td != null) args.Append(" --tessdata-dir ").Append(Q(td.TrimEnd('\\', '/')));
            if (batch) args.Append(" -c page_separator=").Append(Break);
            ProcessStartInfo si = new ProcessStartInfo(exe, args.ToString());
            si.WorkingDirectory = dir;              // page names stay short and ASCII whatever the temp path is
            si.UseShellExecute = false;
            si.CreateNoWindow = true;
            si.RedirectStandardError = true;
            si.RedirectStandardOutput = true;
            si.StandardErrorEncoding = Encoding.UTF8;
            si.StandardOutputEncoding = Encoding.UTF8;
            StringBuilder err = new StringBuilder();
            using (Process p = new Process())
            {
                p.StartInfo = si;
                p.ErrorDataReceived += delegate(object s, DataReceivedEventArgs e) { if (e.Data != null) lock (err) err.Append(e.Data).Append('\n'); };
                p.OutputDataReceived += delegate(object s, DataReceivedEventArgs e) { };
                try { p.Start(); }
                catch (Exception e) { throw new PdfException("could not start tesseract (" + exe + "): " + e.Message); }
                p.BeginErrorReadLine();
                p.BeginOutputReadLine();
                int ms = (int)Math.Max(1000, (deadline - DateTime.UtcNow).TotalMilliseconds);
                if (!p.WaitForExit(ms))
                {
                    try { p.Kill(); } catch (Exception) { }
                    throw new PdfException("tesseract ran out of time and was stopped (raise TimeoutSeconds for very long documents)");
                }
                p.WaitForExit();
                string txt = Path.Combine(dir, outBase + ".txt");
                if (p.ExitCode != 0 || !File.Exists(txt))
                {
                    string e = err.ToString();
                    if (e.Contains("Failed loading language") || e.Contains("Error opening data file"))
                        throw new PdfException("tesseract has no language data for '" + lang + "' in " + (td ?? "its default folder")
                            + ". Copy the missing language files there (for example ara.traineddata, in the version that matches Tesseract), or point the tessdata folder at a folder that has them. Tesseract said: " + Tail(e));
                    throw new PdfException("tesseract failed (exit " + p.ExitCode + "): " + Tail(e));
                }
                return File.ReadAllText(txt, Encoding.UTF8);
            }
        }

        private static string Tail(string s)
        {
            s = (s ?? "").Trim();
            return s.Length > 600 ? "..." + s.Substring(s.Length - 600) : s;
        }

        private static string Q(string s) { return "\"" + s + "\""; }
    }

    // Typed right-to-left text (Arabic, Hebrew) back into reading order. PDF producers write such
    // lines in visual order, often as presentation-form letters: lines are rebuilt from glyph
    // positions, read right to left with runs of digits and Latin kept left to right, mirrored
    // brackets swapped, and presentation forms turned back into ordinary letters.
    internal static class RtlText
    {
        public static bool IsRtl(char c)
        {
            return (c >= '\u0590' && c <= '\u08FF') || (c >= '\uFB1D' && c <= '\uFDFF') || (c >= '\uFE70' && c <= '\uFEFF');
        }

        private static bool IsLtr(char c)
        {
            return !IsRtl(c) && (char.IsLetterOrDigit(c));
        }

        public static bool HasRtl(List<PdfGlyph> glyphs)
        {
            foreach (PdfGlyph g in glyphs)
                if (g.RenderMode != 3 && g.RenderMode != 7 && g.Text != null)
                    foreach (char c in g.Text) if (IsRtl(c) && char.IsLetter(c)) return true;
            return false;
        }

        private sealed class Line { public double Y, Size; public List<PdfGlyph> G = new List<PdfGlyph>(); }

        public static string Read(List<PdfGlyph> glyphs)
        {
            List<PdfGlyph> vis = new List<PdfGlyph>();
            foreach (PdfGlyph g in glyphs) if (g.RenderMode != 3 && g.RenderMode != 7 && !string.IsNullOrEmpty(g.Text)) vis.Add(g);
            vis.Sort((a, b) => b.Y.CompareTo(a.Y));
            List<Line> lines = new List<Line>();
            foreach (PdfGlyph g in vis)
            {
                double size = Math.Max(1, g.FontSize);
                Line hit = null;
                foreach (Line l in lines) if (Math.Abs(l.Y - g.Y) < 0.45 * Math.Max(size, l.Size)) { hit = l; break; }
                if (hit == null) { hit = new Line(); hit.Y = g.Y; hit.Size = size; lines.Add(hit); }
                hit.G.Add(g);
            }
            lines.Sort((a, b) => b.Y.CompareTo(a.Y));
            StringBuilder sb = new StringBuilder();
            foreach (Line l in lines)
            {
                string t = Logical(l);
                if (t.Length == 0) continue;
                if (sb.Length > 0) sb.Append("\r\n");
                sb.Append(t);
            }
            return sb.ToString();
        }

        private static string Logical(Line l)
        {
            l.G.Sort((a, b) => a.X.CompareTo(b.X));
            // visual tokens, left to right, with a space wherever the gap says one was meant
            List<string> tok = new List<string>();
            for (int i = 0; i < l.G.Count; i++)
            {
                PdfGlyph g = l.G[i];
                if (i > 0)
                {
                    PdfGlyph p = l.G[i - 1];
                    double gap = g.X - (p.X + p.Width);
                    bool spaced = p.Text.EndsWith(" ", StringComparison.Ordinal) || g.Text.StartsWith(" ", StringComparison.Ordinal);
                    if (!spaced && gap > 0.2 * Math.Max(1, Math.Max(g.FontSize, p.FontSize))) tok.Add(" ");
                }
                tok.Add(g.Text);
            }
            bool rtl = false;
            foreach (string t in tok) foreach (char c in t) if (IsRtl(c) && char.IsLetter(c)) rtl = true;
            if (!rtl) return Collapse(string.Concat(tok.ToArray()));

            tok.Reverse();
            // runs that read left to right (numbers, Latin words and what sits between them) go back
            int k = 0;
            while (k < tok.Count)
            {
                if (!HasLtr(tok[k])) { k++; continue; }
                int end = k, j = k + 1;
                while (j < tok.Count && !HasRtlLetter(tok[j]))
                {
                    if (HasLtr(tok[j])) end = j;
                    j++;
                }
                tok.Reverse(k, end - k + 1);
                k = end + 1;
            }
            StringBuilder sb = new StringBuilder();
            foreach (string t in tok)
            {
                string piece = t;
                if (!HasLtr(t) && piece.Length > 1 && HasRtlLetter(piece))
                {
                    // a glyph that stands for several letters (a ligature) keeps its own order
                }
                sb.Append(Mirror(piece));
            }
            return Collapse(Normalise(sb.ToString()));
        }

        private static bool HasLtr(string t) { foreach (char c in t) if (IsLtr(c)) return true; return false; }
        private static bool HasRtlLetter(string t) { foreach (char c in t) if (IsRtl(c) && char.IsLetter(c)) return true; return false; }

        private static string Mirror(string t)
        {
            if (t.Length != 1) return t;
            switch (t[0])
            {
                case '(': return ")"; case ')': return "(";
                case '[': return "]"; case ']': return "[";
                case '{': return "}"; case '}': return "{";
                case '<': return ">"; case '>': return "<";
                case '\u00AB': return "\u00BB"; case '\u00BB': return "\u00AB";
            }
            return t;
        }

        // Presentation forms (one shape per position in a word) back to the letters themselves.
        // FE80-FEF4 list each letter's shapes in order; the count says how many shapes it has.
        private static readonly string Letters = "\u0621\u0622\u0623\u0624\u0625\u0626\u0627\u0628\u0629\u062A\u062B\u062C\u062D\u062E\u062F\u0630\u0631\u0632\u0633\u0634\u0635\u0636\u0637\u0638\u0639\u063A\u0641\u0642\u0643\u0644\u0645\u0646\u0647\u0648\u0649\u064A";
        private static readonly int[] Shapes = { 1, 2, 2, 2, 2, 4, 2, 4, 2, 4, 4, 4, 4, 4, 2, 2, 2, 2, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 2, 2, 4 };
        private static readonly string[] LamAlef = { "\u0644\u0622", "\u0644\u0623", "\u0644\u0625", "\u0644\u0627" };
        private static Dictionary<char, string> _forms;

        private static string Normalise(string s)
        {
            if (_forms == null)
            {
                Dictionary<char, string> m = new Dictionary<char, string>();
                int code = 0xFE80;
                for (int i = 0; i < Letters.Length; i++)
                    for (int k = 0; k < Shapes[i]; k++) m[(char)code++] = Letters[i].ToString();
                for (int i = 0; i < 4; i++) { m[(char)(0xFEF5 + 2 * i)] = LamAlef[i]; m[(char)(0xFEF6 + 2 * i)] = LamAlef[i]; }
                _forms = m;
            }
            StringBuilder sb = new StringBuilder(s.Length);
            foreach (char c in s)
            {
                string r;
                if (_forms.TryGetValue(c, out r)) sb.Append(r);
                else if ((c >= '\uFB50' && c <= '\uFDFF') || (c >= '\uFE70' && c <= '\uFE7F'))
                {
                    string n = c.ToString().Normalize(NormalizationForm.FormKC);
                    sb.Append(n.Replace("\u0640", ""));          // drop the tatweel a spacing mark carries
                }
                else sb.Append(c);
            }
            return sb.ToString();
        }

        private static string Collapse(string s)
        {
            StringBuilder sb = new StringBuilder();
            bool sp = false;
            foreach (char c in s.Trim())
            {
                if (c == ' ') { if (!sp) sb.Append(' '); sp = true; }
                else { sb.Append(c); sp = false; }
            }
            return sb.ToString();
        }
    }

    // A grey image (0 black - 255 white) or, for a stencil mask, which pixels get painted.
    internal sealed class GreyImage
    {
        public int W, H;
        public byte[] Px;
        public bool Mask;           // Px holds 1 where black paint goes
    }

    // The images on one page, where they sit, and the page drawn from them alone.
    internal sealed class PdfScanPage
    {
        private sealed class Placed { public GreyImage Img; public PdfMatrix M; }

        private readonly List<Placed> _placed = new List<Placed>();
        private readonly List<PdfGlyph> _text = new List<PdfGlyph>();
        private PdfDictionary _res;
        public int TextGlyphs { get { return _text.Count; } }
        public readonly List<string> Problems = new List<string>();
        public double Coverage;
        private double[] _box;
        private int _rot;
        private double _area;
        private PdfFile _f;

        public List<GreyImage> Images
        {
            get { List<GreyImage> r = new List<GreyImage>(); foreach (Placed p in _placed) r.Add(p.Img); return r; }
        }

        public static PdfScanPage Collect(PdfPage page)
        {
            return Collect(page, null);
        }

        // text: glyphs (from PdfContentReader.Extract(page, true)) to draw over the images, or null
        public static PdfScanPage Collect(PdfPage page, List<PdfGlyph> text)
        {
            PdfScanPage s = new PdfScanPage();
            if (text != null)
                foreach (PdfGlyph g in text)
                    if (g.Font != null && g.RenderMode != 3 && g.RenderMode != 7) s._text.Add(g);
            s._res = page.SourceFile == null ? null : page.SourceFile.Resolve(page.Dictionary.Get("Resources")) as PdfDictionary;
            s._f = page.SourceFile;
            s._box = page.VisibleBox;
            s._rot = page.Rotation;
            s._area = Math.Abs((s._box[2] - s._box[0]) * (s._box[3] - s._box[1]));
            if (s._f == null) return s;
            byte[] content = PdfContentReader.ContentBytes(s._f, page.Dictionary.Get("Contents"));
            PdfDictionary res = s._f.Resolve(page.Dictionary.Get("Resources")) as PdfDictionary;
            s.Walk(content, res, PdfMatrix.Identity, 0);
            return s;
        }

        private void Walk(byte[] content, PdfDictionary res, PdfMatrix ctm, int depth)
        {
            if (depth > 8) return;
            PdfLexer lex = new PdfLexer(content);
            PdfParser parser = new PdfParser(content, null);
            List<PdfObject> stack = new List<PdfObject>();
            Stack<PdfMatrix> saved = new Stack<PdfMatrix>();
            while (true)
            {
                int before = lex.Position;
                Token t = lex.Next();
                if (t.Type == TokenType.Eof) break;
                if (t.Type != TokenType.Keyword)
                {
                    parser.Position = before;
                    PdfObject o;
                    try { o = parser.ParseObject(); } catch (Exception) { break; }
                    lex.Position = parser.Position;
                    stack.Add(o);
                    if (stack.Count > 64) stack.RemoveAt(0);
                    continue;
                }
                switch (t.Text)
                {
                    case "q": saved.Push(ctm); break;
                    case "Q": if (saved.Count > 0) ctm = saved.Pop(); break;
                    case "cm":
                        if (stack.Count >= 6)
                        {
                            double[] v = new double[6];
                            bool ok = true;
                            for (int i = 0; i < 6; i++) { PdfNumber n = stack[stack.Count - 6 + i] as PdfNumber; if (n == null) ok = false; else v[i] = n.Value; }
                            if (ok) ctm = PdfMatrix.Multiply(new PdfMatrix(v[0], v[1], v[2], v[3], v[4], v[5]), ctm);
                        }
                        break;
                    case "Do":
                        if (stack.Count >= 1 && stack[stack.Count - 1] is PdfName) Do(((PdfName)stack[stack.Count - 1]).Value, res, ctm, depth);
                        break;
                    case "BI":
                        Inline(lex, parser, res, ctm);
                        break;
                }
                stack.Clear();
            }
        }

        private void Do(string name, PdfDictionary res, PdfMatrix ctm, int depth)
        {
            PdfDictionary xo = res == null ? null : _f.Resolve(res.Get("XObject")) as PdfDictionary;
            if (xo == null) return;
            PdfStream s = _f.Resolve(xo.Get(name)) as PdfStream;
            if (s == null) return;
            PdfName sub = _f.Resolve(s.Dict.Get("Subtype")) as PdfName;
            if (sub == null) return;
            if (sub.Value == "Form")
            {
                PdfMatrix inner = ctm;
                PdfArray mx = _f.Resolve(s.Dict.Get("Matrix")) as PdfArray;
                if (mx != null && mx.Count >= 6)
                    inner = PdfMatrix.Multiply(new PdfMatrix(Num(mx[0]), Num(mx[1]), Num(mx[2]), Num(mx[3]), Num(mx[4]), Num(mx[5])), ctm);
                PdfDictionary fres = _f.Resolve(s.Dict.Get("Resources")) as PdfDictionary;
                byte[] body;
                try { body = PdfFilters.Decode(s, _f); } catch (Exception) { return; }
                Walk(body, fres ?? res, inner, depth + 1);
            }
            else if (sub.Value == "Image") Place(s, res, ctm);
        }

        private double Num(PdfObject o) { PdfNumber n = _f.Resolve(o) as PdfNumber; return n == null ? 0 : n.Value; }

        private void Place(PdfStream s, PdfDictionary res, PdfMatrix ctm)
        {
            double w = Math.Sqrt(ctm.A * ctm.A + ctm.B * ctm.B), h = Math.Sqrt(ctm.C * ctm.C + ctm.D * ctm.D);
            double cover = _area > 0 ? Math.Min(1, w * h / _area) : 0;
            if (cover < 0.0005) return;                    // specks: logos, bullets, rules
            string why;
            GreyImage g = ImageDecoder.Decode(_f, s, res, out why);
            if (g == null)
            {
                if (why != null && !Problems.Contains(why)) Problems.Add(why);
                Coverage = Math.Min(1, Coverage + cover);
                return;
            }
            Coverage = Math.Min(1, Coverage + cover);
            Placed p = new Placed();
            p.Img = g;
            p.M = ctm;
            _placed.Add(p);
        }

        private static readonly Dictionary<string, string> Abbrev = new Dictionary<string, string>
        {
            { "W", "Width" }, { "H", "Height" }, { "BPC", "BitsPerComponent" }, { "CS", "ColorSpace" },
            { "F", "Filter" }, { "DP", "DecodeParms" }, { "D", "Decode" }, { "IM", "ImageMask" }, { "I", "Interpolate" }
        };

        private void Inline(PdfLexer lex, PdfParser parser, PdfDictionary res, PdfMatrix ctm)
        {
            PdfStream img = ReadInline(lex, parser);
            if (img != null) Place(img, res, ctm);
        }

        // An inline image (BI ... ID data EI) as a stream with its keys spelt out; the lexer ends after EI.
        internal static PdfStream ReadInline(PdfLexer lex, PdfParser parser)
        {
            PdfDictionary d = new PdfDictionary();
            byte[] data = lex.Data;
            while (true)
            {
                int before = lex.Position;
                Token t = lex.Next();
                if (t.Type == TokenType.Eof) return null;
                if (t.Type == TokenType.Keyword && t.Text == "ID") break;
                if (t.Type != TokenType.Name) return null;
                string key = t.Text;
                parser.Position = lex.Position;
                PdfObject v;
                try { v = parser.ParseObject(); } catch (Exception) { return null; }
                lex.Position = parser.Position;
                string full;
                d.Set(Abbrev.TryGetValue(key, out full) ? full : key, v);
            }
            int start = lex.Position + 1;                  // one white-space byte follows ID
            int end = -1;
            int known = UnfilteredLength(d);
            if (known > 0 && start + known <= data.Length) end = start + known;
            int i = end > 0 ? end : start;
            while (i + 1 < data.Length)
            {
                if (data[i] == (byte)'E' && data[i + 1] == (byte)'I' && (i == 0 || PdfLexer.IsWhite(data[i - 1]))
                    && (i + 2 >= data.Length || PdfLexer.IsWhite(data[i + 2]) || data[i + 2] == (byte)'Q'))
                    break;
                i++;
            }
            if (end < 0) end = Math.Max(start, i - 1);
            byte[] body = new byte[Math.Max(0, end - start)];
            Buffer.BlockCopy(data, start, body, 0, body.Length);
            lex.Position = Math.Min(data.Length, i + 2);
            return new PdfStream(d, body);
        }

        private static int UnfilteredLength(PdfDictionary d)
        {
            if (d.Has("Filter")) return -1;
            PdfNumber w = d.Get("Width") as PdfNumber, h = d.Get("Height") as PdfNumber;
            if (w == null || h == null) return -1;
            PdfObject im = d.Get("ImageMask");
            bool mask = im is PdfBool && ((PdfBool)im).Value;
            int bpc = mask ? 1 : (d.Get("BitsPerComponent") is PdfNumber ? ((PdfNumber)d.Get("BitsPerComponent")).AsInt : 8);
            int comps = 1;
            PdfName cs = d.Get("ColorSpace") as PdfName;
            if (!mask && cs != null)
            {
                if (cs.Value == "RGB" || cs.Value == "DeviceRGB") comps = 3;
                else if (cs.Value == "CMYK" || cs.Value == "DeviceCMYK") comps = 4;
                else if (cs.Value != "G" && cs.Value != "DeviceGray") return -1;
            }
            else if (!mask) return -1;
            return ((w.AsInt * comps * bpc + 7) / 8) * h.AsInt;
        }

        // Resolution the page is drawn at: the main scan's own, so its pixels map 1:1 onto the
        // drawing. Horizontal and vertical are set apart, because a page size in points and a
        // scan's pixel counts rarely round to exactly the same resolution.
        public double ChooseDpi(int wanted)
        {
            double x, y;
            Scales(wanted, out x, out y);
            return Math.Max(x, y) * 72;
        }

        private void Scales(int wanted, out double sx, out double sy)
        {
            sx = sy = (wanted > 0 ? wanted : 300) / 72.0;
            if (wanted > 0) return;
            Placed main = null;
            double bestArea = 0;
            foreach (Placed p in _placed)
            {
                double w = Math.Sqrt(p.M.A * p.M.A + p.M.B * p.M.B), h = Math.Sqrt(p.M.C * p.M.C + p.M.D * p.M.D);
                if (w * h > bestArea) { bestArea = w * h; main = p; }
            }
            if (main == null) return;
            PdfMatrix m = main.M;
            double eps = 1e-6 * (Math.Abs(m.A) + Math.Abs(m.B) + Math.Abs(m.C) + Math.Abs(m.D));
            double px, py;                               // pixels per point along page x and page y
            if (Math.Abs(m.B) <= eps && Math.Abs(m.C) <= eps) { px = main.Img.W / Math.Abs(m.A); py = main.Img.H / Math.Abs(m.D); }
            else if (Math.Abs(m.A) <= eps && Math.Abs(m.D) <= eps) { px = main.Img.H / Math.Abs(m.C); py = main.Img.W / Math.Abs(m.B); }
            else
            {
                double w = Math.Sqrt(m.A * m.A + m.B * m.B), h = Math.Sqrt(m.C * m.C + m.D * m.D);
                px = py = Math.Max(main.Img.W / w, main.Img.H / h);
            }
            double lo = 150 / 72.0, hi = 400 / 72.0;
            if (px < lo || py < lo || px > hi || py > hi || Math.Abs(px / py - 1) > 0.02)
            {
                double u = Math.Max(lo, Math.Min(hi, Math.Max(px, py)));
                px = py = u;                             // out of range or not square: one clamped scale
            }
            sx = px; sy = py;
        }

        public GreyImage Draw(int wanted)
        {
            double sx, sy;
            Scales(wanted, out sx, out sy);
            double bw = _box[2] - _box[0], bh = _box[3] - _box[1];
            int W = Math.Max(1, (int)Math.Round(bw * sx)), H = Math.Max(1, (int)Math.Round(bh * sy));
            if ((long)W * H > 150000000L) throw new PdfException("page too large to draw for OCR (" + W + " x " + H + " pixels); set a lower Dpi");
            PdfMatrix toRaster = new PdfMatrix(sx, 0, 0, -sy, -_box[0] * sx, _box[3] * sy);
            int RW = W, RH = H;
            switch (_rot)
            {
                case 90: toRaster = PdfMatrix.Multiply(toRaster, new PdfMatrix(0, 1, -1, 0, H, 0)); RW = H; RH = W; break;
                case 180: toRaster = PdfMatrix.Multiply(toRaster, new PdfMatrix(-1, 0, 0, -1, W, H)); break;
                case 270: toRaster = PdfMatrix.Multiply(toRaster, new PdfMatrix(0, -1, 1, 0, 0, W)); RW = H; RH = W; break;
            }
            GreyImage page = new GreyImage();
            page.W = RW; page.H = RH;
            page.Px = new byte[RW * RH];
            for (int i = 0; i < page.Px.Length; i++) page.Px[i] = 255;
            foreach (Placed p in _placed) Paint(page, p.Img, PdfMatrix.Multiply(p.M, toRaster));
            foreach (PdfGlyph g in _text) DrawGlyph(page, g, toRaster);
            return page;
        }

        private void DrawGlyph(GreyImage page, PdfGlyph g, PdfMatrix toRaster)
        {
            PdfFontInfo fi = g.Font;
            if (fi.Program == null)
            {
                if (fi.IsType3) fi.Program = new Type3Program(fi.File, fi.Dict, fi.Type3Matrix, _res);
                else fi.Program = PdfFontProgram.Build(fi.File, fi.Dict);
            }
            PdfMatrix place = PdfMatrix.Multiply(g.Trm, toRaster);
            Type3Program t3 = fi.Program as Type3Program;
            if (t3 != null)
            {
                if (t3.Problem != null) { Note(fi, t3.Problem); return; }
                t3.Draw(page, g.Code, PdfMatrix.Multiply(t3.FontMatrix, place));
                return;
            }
            PdfFontProgram fp = (PdfFontProgram)fi.Program;
            if (!fp.Usable) { Note(fi, fp.Problem); return; }
            GlyphPath path = fp.Outline(g.Code);
            if (path == null) return;
            if (g.RenderMode == 1 || g.RenderMode == 5)
                GlyphRaster.Stroke(page, path, PdfMatrix.Multiply(new PdfMatrix(fp.UnitsToText, 0, 0, fp.UnitsToText, 0, 0), place), 30);
            else GlyphRaster.Fill(page, path, PdfMatrix.Multiply(new PdfMatrix(fp.UnitsToText, 0, 0, fp.UnitsToText, 0, 0), place));
        }

        private void Note(PdfFontInfo fi, string why)
        {
            string m = "text in font " + (fi.BaseFont ?? "?") + " not drawn: " + why;
            if (!Problems.Contains(m)) Problems.Add(m);
        }

        internal static void Paint(GreyImage page, GreyImage img, PdfMatrix t)
        {
            double det = t.A * t.D - t.B * t.C;
            if (Math.Abs(det) < 1e-12) return;
            // raster -> unit square
            double ia = t.D / det, ib = -t.B / det, ic = -t.C / det, id = t.A / det;
            double ie = -(t.E * ia + t.F * ic), iff = -(t.E * ib + t.F * id);
            double minX = double.MaxValue, minY = double.MaxValue, maxX = double.MinValue, maxY = double.MinValue;
            double[] us = { 0, 1, 0, 1 }, vs = { 0, 0, 1, 1 };
            for (int k = 0; k < 4; k++)
            {
                double x, y;
                t.Apply(us[k], vs[k], out x, out y);
                minX = Math.Min(minX, x); maxX = Math.Max(maxX, x); minY = Math.Min(minY, y); maxY = Math.Max(maxY, y);
            }
            int x0 = Math.Max(0, (int)Math.Floor(minX)), x1 = Math.Min(page.W, (int)Math.Ceiling(maxX));
            int y0 = Math.Max(0, (int)Math.Floor(minY)), y1 = Math.Min(page.H, (int)Math.Ceiling(maxY));
            if (x0 >= x1 || y0 >= y1) return;
            double pw = Math.Sqrt(t.A * t.A + t.B * t.B), ph = Math.Sqrt(t.C * t.C + t.D * t.D);
            // average several samples only when the image is clearly finer than the page drawing
            int ss = (int)Math.Ceiling(Math.Max(img.W / Math.Max(1e-9, pw), img.H / Math.Max(1e-9, ph)) - 0.1);
            ss = Math.Max(1, Math.Min(4, ss));
            int W = img.W, H = img.H;
            for (int y = y0; y < y1; y++)
            {
                int row = y * page.W;
                for (int x = x0; x < x1; x++)
                {
                    int sum = 0, n = 0, hits = 0;
                    for (int sy = 0; sy < ss; sy++)
                        for (int sx = 0; sx < ss; sx++)
                        {
                            double rx = x + (sx + 0.5) / ss, ry = y + (sy + 0.5) / ss;
                            double u = rx * ia + ry * ic + ie, v = rx * ib + ry * id + iff;
                            if (u < 0 || u >= 1 || v < 0 || v >= 1) continue;
                            int col = (int)(u * W), r = (int)((1 - v) * H);
                            if (col >= W) col = W - 1;
                            if (r >= H) r = H - 1;
                            if (r < 0) r = 0;
                            n++;
                            byte b = img.Px[r * W + col];
                            if (img.Mask) { if (b != 0) hits++; }
                            else sum += b;
                        }
                    if (n == 0) continue;
                    if (img.Mask)
                    {
                        if (hits == 0) continue;
                        int cur = page.Px[row + x];
                        page.Px[row + x] = (byte)((cur * (ss * ss - hits)) / (ss * ss));
                    }
                    else if (n == ss * ss) page.Px[row + x] = (byte)(sum / n);
                    else
                    {
                        int cur = page.Px[row + x];
                        page.Px[row + x] = (byte)((sum + cur * (ss * ss - n)) / (ss * ss));
                    }
                }
            }
        }

        public void Render(string pngPath, int dpi)
        {
            GreyImage g = Draw(dpi);
            Png.WriteGrey(pngPath, g, ChooseDpi(dpi));
        }
    }

    internal static class Png
    {
        private static uint[] _crc;

        public static void WriteGrey(string path, GreyImage g, double dpi)
        {
            using (FileStream fs = new FileStream(path, FileMode.Create, FileAccess.Write))
            {
                fs.Write(new byte[] { 137, 80, 78, 71, 13, 10, 26, 10 }, 0, 8);
                byte[] ihdr = new byte[13];
                Be(ihdr, 0, (uint)g.W); Be(ihdr, 4, (uint)g.H);
                ihdr[8] = 8; ihdr[9] = 0; ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;
                Chunk(fs, "IHDR", ihdr);
                byte[] phys = new byte[9];
                uint ppm = (uint)Math.Round(dpi / 0.0254);
                Be(phys, 0, ppm); Be(phys, 4, ppm); phys[8] = 1;
                Chunk(fs, "pHYs", phys);
                byte[] raw = new byte[(g.W + 1) * g.H];
                for (int y = 0; y < g.H; y++)
                {
                    raw[y * (g.W + 1)] = 0;
                    Buffer.BlockCopy(g.Px, y * g.W, raw, y * (g.W + 1) + 1, g.W);
                }
                Chunk(fs, "IDAT", Zlib(raw));
                Chunk(fs, "IEND", new byte[0]);
            }
        }

        // zlib wrapping (header, deflate, Adler-32) around the framework's deflate
        private static byte[] Zlib(byte[] data)
        {
            MemoryStream ms = new MemoryStream();
            ms.WriteByte(0x78); ms.WriteByte(0x9C);
            using (System.IO.Compression.DeflateStream z = new System.IO.Compression.DeflateStream(ms, System.IO.Compression.CompressionMode.Compress, true))
                z.Write(data, 0, data.Length);
            uint a = 1, b = 0;
            foreach (byte x in data) { a = (a + x) % 65521; b = (b + a) % 65521; }
            uint adler = (b << 16) | a;
            ms.WriteByte((byte)(adler >> 24)); ms.WriteByte((byte)(adler >> 16)); ms.WriteByte((byte)(adler >> 8)); ms.WriteByte((byte)adler);
            return ms.ToArray();
        }

        private static void Be(byte[] b, int o, uint v) { b[o] = (byte)(v >> 24); b[o + 1] = (byte)(v >> 16); b[o + 2] = (byte)(v >> 8); b[o + 3] = (byte)v; }

        private static void Chunk(Stream s, string type, byte[] data)
        {
            byte[] len = new byte[4];
            Be(len, 0, (uint)data.Length);
            s.Write(len, 0, 4);
            byte[] td = new byte[4 + data.Length];
            Encoding.ASCII.GetBytes(type, 0, 4, td, 0);
            Buffer.BlockCopy(data, 0, td, 4, data.Length);
            s.Write(td, 0, td.Length);
            byte[] c = new byte[4];
            Be(c, 0, Crc(td));
            s.Write(c, 0, 4);
        }

        private static uint Crc(byte[] b)
        {
            if (_crc == null)
            {
                uint[] t = new uint[256];
                for (uint n = 0; n < 256; n++)
                {
                    uint c = n;
                    for (int k = 0; k < 8; k++) c = (c & 1) != 0 ? 0xEDB88320u ^ (c >> 1) : c >> 1;
                    t[n] = c;
                }
                _crc = t;
            }
            uint r = 0xFFFFFFFFu;
            foreach (byte x in b) r = _crc[(r ^ x) & 0xFF] ^ (r >> 8);
            return r ^ 0xFFFFFFFFu;
        }
    }

    // PDF image XObject (or inline image) -> grey pixels.
    internal static class ImageDecoder
    {
        private sealed class Space
        {
            public string Kind;                 // gray rgb cmyk lab sep indexed
            public int N = 1;
            public Space Base;
            public int HiVal;
            public byte[] Lookup;
        }

        public static GreyImage Decode(PdfFile f, PdfStream s, PdfDictionary res, out string why)
        {
            why = null;
            PdfDictionary d = s.Dict;
            int w = Int(f, d.Get("Width")), h = Int(f, d.Get("Height"));
            if (w <= 0 || h <= 0 || (long)w * h > 200000000L) { why = "image with bad size " + w + "x" + h; return null; }
            PdfBool imBool = f.Resolve(d.Get("ImageMask")) as PdfBool;
            bool mask = imBool != null && imBool.Value;
            int bpc = mask ? 1 : Int(f, d.Get("BitsPerComponent"));

            List<string> filters = new List<string>();
            PdfObject fo = f.Resolve(d.Get("Filter"));
            if (fo is PdfName) filters.Add(((PdfName)fo).Value);
            else if (fo is PdfArray) foreach (PdfObject x in ((PdfArray)fo).Items) { PdfName n = f.Resolve(x) as PdfName; if (n != null) filters.Add(n.Value); }
            string last = filters.Count > 0 ? filters[filters.Count - 1] : null;
            if (last == "JBIG2Decode") { why = "JBIG2-compressed scan, which this library cannot decode yet"; return null; }
            if (last == "JPXDecode") { why = "JPEG 2000 scan, which this library cannot decode yet"; return null; }
            bool dct = last == "DCTDecode" || last == "DCT";
            bool fax = last == "CCITTFaxDecode" || last == "CCF";

            byte[] data;
            try { data = PdfFilters.Decode(s, f); }
            catch (Exception e) { why = "image data unreadable: " + e.Message; return null; }

            if (dct) return Jpeg(f, d, data, out why);

            if (fax)
            {
                PdfObject dpo = f.Resolve(d.Get("DecodeParms"));
                if (dpo is PdfArray) { PdfArray a = (PdfArray)dpo; dpo = a.Count > 0 ? f.Resolve(a[a.Count - 1]) : null; }
                PdfDictionary dp = dpo as PdfDictionary;
                int k = dp == null ? 0 : IntOr(f, dp.Get("K"), 0);
                int cols = dp == null ? 1728 : IntOr(f, dp.Get("Columns"), 1728);
                int rows = dp == null ? 0 : IntOr(f, dp.Get("Rows"), 0);
                bool align = dp != null && Bool(f, dp.Get("EncodedByteAlign"));
                bool b1 = dp != null && Bool(f, dp.Get("BlackIs1"));
                try { data = PdfCcitt.Decode(data, k, cols, rows > 0 ? rows : h, align, b1); }
                catch (Exception e) { why = "fax image unreadable: " + e.Message; return null; }
                w = cols;
                bpc = 1;
            }
            if (bpc != 1 && bpc != 2 && bpc != 4 && bpc != 8 && bpc != 16) { why = "image with " + bpc + " bits per component"; return null; }

            double[] decode = Nums(f, d.Get("Decode"));
            if (mask)
            {
                bool paintOnOne = decode != null && decode.Length >= 2 && decode[0] > decode[1];
                GreyImage m = new GreyImage();
                m.W = w; m.H = h; m.Mask = true; m.Px = new byte[w * h];
                int stride = (w + 7) / 8;
                for (int y = 0; y < h; y++)
                    for (int x = 0; x < w; x++)
                    {
                        int idx = y * stride + (x >> 3);
                        int bit = idx < data.Length ? (data[idx] >> (7 - (x & 7))) & 1 : 1;
                        m.Px[y * w + x] = (byte)((bit == 1) == paintOnOne ? 1 : 0);
                    }
                return m;
            }

            Space cs = fax && d.Get("ColorSpace") == null ? Gray() : Resolve(f, d.Get("ColorSpace"), res, 0);
            if (cs == null) { why = "image in an unsupported colour space"; return null; }
            return Samples(data, w, h, bpc, cs, decode);
        }

        private static Space Gray() { Space s = new Space(); s.Kind = "gray"; s.N = 1; return s; }

        private static Space Resolve(PdfFile f, PdfObject o, PdfDictionary res, int depth)
        {
            if (depth > 6) return null;
            o = f.Resolve(o);
            Space s = new Space();
            PdfName n = o as PdfName;
            if (n != null)
            {
                switch (n.Value)
                {
                    case "DeviceGray": case "G": case "CalGray": s.Kind = "gray"; s.N = 1; return s;
                    case "DeviceRGB": case "RGB": case "CalRGB": s.Kind = "rgb"; s.N = 3; return s;
                    case "DeviceCMYK": case "CMYK": s.Kind = "cmyk"; s.N = 4; return s;
                }
                PdfDictionary csd = res == null ? null : f.Resolve(res.Get("ColorSpace")) as PdfDictionary;
                if (csd != null && csd.Has(n.Value)) return Resolve(f, csd.Get(n.Value), res, depth + 1);
                return null;
            }
            PdfArray a = o as PdfArray;
            if (a == null || a.Count == 0) return null;
            PdfName head = f.Resolve(a[0]) as PdfName;
            if (head == null) return null;
            switch (head.Value)
            {
                case "CalGray": s.Kind = "gray"; s.N = 1; return s;
                case "CalRGB": s.Kind = "rgb"; s.N = 3; return s;
                case "Lab": s.Kind = "lab"; s.N = 3; return s;
                case "ICCBased":
                {
                    PdfStream st = a.Count > 1 ? f.Resolve(a[1]) as PdfStream : null;
                    int nn = st == null ? 3 : IntOr(f, st.Dict.Get("N"), 3);
                    s.Kind = nn == 1 ? "gray" : nn == 4 ? "cmyk" : "rgb";
                    s.N = nn == 1 || nn == 4 ? nn : 3;
                    return s;
                }
                case "Indexed": case "I":
                {
                    if (a.Count < 4) return null;
                    s.Kind = "indexed"; s.N = 1;
                    s.Base = Resolve(f, a[1], res, depth + 1);
                    if (s.Base == null || s.Base.Kind == "indexed") return null;
                    s.HiVal = Int(f, a[2]);
                    PdfObject lk = f.Resolve(a[3]);
                    if (lk is PdfString) s.Lookup = ((PdfString)lk).Bytes;
                    else if (lk is PdfStream) { try { s.Lookup = PdfFilters.Decode((PdfStream)lk, f); } catch (Exception) { return null; } }
                    else return null;
                    return s;
                }
                case "Separation": s.Kind = "sep"; s.N = 1; return s;
                case "DeviceN":
                {
                    PdfArray names = a.Count > 1 ? f.Resolve(a[1]) as PdfArray : null;
                    s.Kind = "sep"; s.N = names == null ? 1 : Math.Max(1, names.Count);
                    return s;
                }
            }
            return null;
        }

        private static GreyImage Samples(byte[] data, int w, int h, int bpc, Space cs, double[] decode)
        {
            int n = cs.N;
            int stride = (w * n * bpc + 7) / 8;
            double max = (1 << bpc) - 1;
            double[] lo = new double[n], hi = new double[n];
            for (int c = 0; c < n; c++)
            {
                if (cs.Kind == "indexed") { lo[c] = 0; hi[c] = max; }
                else if (cs.Kind == "lab") { lo[c] = c == 0 ? 0 : -100; hi[c] = c == 0 ? 100 : 100; }
                else { lo[c] = 0; hi[c] = 1; }
                if (decode != null && decode.Length >= 2 * n) { lo[c] = decode[2 * c]; hi[c] = decode[2 * c + 1]; }
            }
            GreyImage g = new GreyImage();
            g.W = w; g.H = h; g.Px = new byte[w * h];
            double[] v = new double[n];
            bool fast = bpc == 8 && cs.Kind == "gray" && lo[0] == 0 && hi[0] == 1;
            for (int y = 0; y < h; y++)
            {
                int rowStart = y * stride;
                for (int x = 0; x < w; x++)
                {
                    if (fast)
                    {
                        int idx = rowStart + x;
                        g.Px[y * w + x] = idx < data.Length ? data[idx] : (byte)255;
                        continue;
                    }
                    for (int c = 0; c < n; c++)
                    {
                        long bitPos = (long)(x * n + c) * bpc;
                        int raw = Read(data, rowStart, bitPos, bpc);
                        v[c] = lo[c] + raw * (hi[c] - lo[c]) / max;
                    }
                    g.Px[y * w + x] = ToGrey(cs, v);
                }
            }
            return g;
        }

        private static int Read(byte[] d, int rowStart, long bitPos, int bpc)
        {
            long byteIdx = rowStart + (bitPos >> 3);
            if (byteIdx >= d.Length) return 0;
            if (bpc == 8) return d[byteIdx];
            if (bpc == 16) return byteIdx + 1 < d.Length ? (d[byteIdx] << 8) | d[byteIdx + 1] : d[byteIdx] << 8;
            int shift = 8 - (int)(bitPos & 7) - bpc;
            return (d[byteIdx] >> shift) & ((1 << bpc) - 1);
        }

        private static byte ToGrey(Space cs, double[] v)
        {
            double g;
            switch (cs.Kind)
            {
                case "gray": g = v[0]; break;
                case "rgb": g = 0.299 * v[0] + 0.587 * v[1] + 0.114 * v[2]; break;
                case "cmyk": g = 1 - Math.Min(1, 0.3 * v[0] + 0.59 * v[1] + 0.11 * v[2] + v[3]); break;
                case "lab": g = v[0] / 100; break;
                case "sep":
                {
                    double t = 0;
                    for (int i = 0; i < cs.N; i++) t += v[i];
                    g = 1 - Math.Min(1, t / cs.N);
                    break;
                }
                case "indexed":
                {
                    int idx = (int)Math.Round(v[0]);
                    if (idx < 0) idx = 0;
                    if (idx > cs.HiVal) idx = cs.HiVal;
                    Space b = cs.Base;
                    double[] bv = new double[b.N];
                    for (int c = 0; c < b.N; c++)
                    {
                        int at = idx * b.N + c;
                        double raw = at < cs.Lookup.Length ? cs.Lookup[at] / 255.0 : 0;
                        bv[c] = b.Kind == "lab" ? (c == 0 ? raw * 100 : raw * 200 - 100) : raw;
                    }
                    return ToGrey(b, bv);
                }
                default: g = v[0]; break;
            }
            if (g < 0) g = 0;
            if (g > 1) g = 1;
            return (byte)Math.Round(g * 255);
        }

        // A photo or picture file, turned upright as its camera recorded, in grey; dpi as stored
        // (300 when the file says less than 70, which means it does not really know).
        public static GreyImage Photo(byte[] data, out double dpi)
        {
            using (MemoryStream ms = new MemoryStream(data))
            using (Image src = Image.FromStream(ms, false, false))
            {
                int orientation = JpegOrientation(data);
                dpi = src.HorizontalResolution >= 70 ? src.HorizontalResolution : 300;
                using (Bitmap bmp = new Bitmap(src.Width, src.Height, PixelFormat.Format24bppRgb))
                {
                    using (Graphics gr = Graphics.FromImage(bmp))
                    {
                        gr.Clear(Color.White);
                        gr.DrawImage(src, 0, 0, src.Width, src.Height);
                    }
                    return Upright(Grey(bmp), orientation);
                }
            }
        }

        // The EXIF orientation tag of a JPEG, read from the bytes (graphics libraries disagree on it).
        internal static int JpegOrientation(byte[] d)
        {
            if (d.Length < 4 || d[0] != 0xFF || d[1] != 0xD8) return 1;
            int i = 2;
            while (i + 4 <= d.Length && d[i] == 0xFF)
            {
                int marker = d[i + 1], len = (d[i + 2] << 8) | d[i + 3];
                if (marker == 0xDA || len < 2) break;
                int seg = i + 4;
                if (marker == 0xE1 && seg + 14 <= d.Length && d[seg] == 'E' && d[seg + 1] == 'x' && d[seg + 2] == 'i' && d[seg + 3] == 'f')
                {
                    int t = seg + 6;
                    bool le = d[t] == 'I';
                    Func<int, int> u16 = o => o + 1 < d.Length ? (le ? d[o] | (d[o + 1] << 8) : (d[o] << 8) | d[o + 1]) : 0;
                    Func<int, int> u32 = o => o + 3 < d.Length ? (le ? d[o] | (d[o + 1] << 8) | (d[o + 2] << 16) | (d[o + 3] << 24) : (d[o] << 24) | (d[o + 1] << 16) | (d[o + 2] << 8) | d[o + 3]) : 0;
                    int ifd = t + u32(t + 4);
                    int n = u16(ifd);
                    for (int k = 0; k < n && k < 512; k++)
                    {
                        int e = ifd + 2 + 12 * k;
                        if (e + 12 > d.Length) break;
                        if (u16(e) == 0x0112) { int o = u16(e + 8); return o >= 1 && o <= 8 ? o : 1; }
                    }
                    return 1;
                }
                i += 2 + len;
            }
            return 1;
        }

        // EXIF orientation: how the stored picture must be turned or mirrored to be seen upright.
        internal static GreyImage Upright(GreyImage g, int orientation)
        {
            if (orientation <= 1 || orientation > 8) return g;
            int W0 = g.W, H0 = g.H;
            bool swap = orientation >= 5;
            GreyImage r = new GreyImage();
            r.W = swap ? H0 : W0; r.H = swap ? W0 : H0; r.Px = new byte[g.Px.Length];
            for (int y = 0; y < r.H; y++)
                for (int x = 0; x < r.W; x++)
                {
                    int sx, sy;
                    switch (orientation)
                    {
                        case 2: sx = W0 - 1 - x; sy = y; break;
                        case 3: sx = W0 - 1 - x; sy = H0 - 1 - y; break;
                        case 4: sx = x; sy = H0 - 1 - y; break;
                        case 5: sx = y; sy = x; break;
                        case 6: sx = y; sy = H0 - 1 - x; break;
                        case 7: sx = W0 - 1 - y; sy = H0 - 1 - x; break;
                        default: sx = W0 - 1 - y; sy = x; break;          // 8
                    }
                    r.Px[y * r.W + x] = g.Px[sy * W0 + sx];
                }
            return r;
        }

        private static GreyImage Grey(Bitmap bmp)
        {
            GreyImage g = new GreyImage();
            g.W = bmp.Width; g.H = bmp.Height; g.Px = new byte[g.W * g.H];
            BitmapData bd = bmp.LockBits(new Rectangle(0, 0, g.W, g.H), ImageLockMode.ReadOnly, PixelFormat.Format24bppRgb);
            try
            {
                byte[] row = new byte[Math.Abs(bd.Stride)];
                for (int y = 0; y < g.H; y++)
                {
                    Marshal.Copy(new IntPtr(bd.Scan0.ToInt64() + (long)y * bd.Stride), row, 0, row.Length);
                    for (int x = 0; x < g.W; x++)
                        g.Px[y * g.W + x] = (byte)((row[3 * x + 2] * 299 + row[3 * x + 1] * 587 + row[3 * x] * 114 + 500) / 1000);
                }
            }
            finally { bmp.UnlockBits(bd); }
            return g;
        }

        private static GreyImage Jpeg(PdfFile f, PdfDictionary d, byte[] data, out string why)
        {
            why = null;
            try
            {
                using (MemoryStream ms = new MemoryStream(data))
                using (Image src = Image.FromStream(ms, false, false))
                using (Bitmap bmp = new Bitmap(src.Width, src.Height, PixelFormat.Format24bppRgb))
                {
                    using (Graphics gr = Graphics.FromImage(bmp))
                    {
                        gr.Clear(Color.White);
                        gr.DrawImage(src, 0, 0, src.Width, src.Height);
                    }
                    GreyImage g = new GreyImage();
                    g.W = bmp.Width; g.H = bmp.Height; g.Px = new byte[g.W * g.H];
                    BitmapData bd = bmp.LockBits(new Rectangle(0, 0, g.W, g.H), ImageLockMode.ReadOnly, PixelFormat.Format24bppRgb);
                    try
                    {
                        byte[] row = new byte[Math.Abs(bd.Stride)];
                        for (int y = 0; y < g.H; y++)
                        {
                            Marshal.Copy(new IntPtr(bd.Scan0.ToInt64() + (long)y * bd.Stride), row, 0, row.Length);
                            for (int x = 0; x < g.W; x++)
                                g.Px[y * g.W + x] = (byte)((row[3 * x + 2] * 299 + row[3 * x + 1] * 587 + row[3 * x] * 114 + 500) / 1000);
                        }
                    }
                    finally { bmp.UnlockBits(bd); }
                    double[] dec = Nums(f, d.Get("Decode"));
                    if (dec != null && dec.Length >= 2 && dec[0] > dec[1])
                        for (int i = 0; i < g.Px.Length; i++) g.Px[i] = (byte)(255 - g.Px[i]);
                    return g;
                }
            }
            catch (Exception e)
            {
                why = "JPEG scan unreadable: " + e.Message;
                return null;
            }
        }

        private static int Int(PdfFile f, PdfObject o) { PdfNumber n = f.Resolve(o) as PdfNumber; return n == null ? 0 : n.AsInt; }
        private static int IntOr(PdfFile f, PdfObject o, int def) { PdfNumber n = f.Resolve(o) as PdfNumber; return n == null ? def : n.AsInt; }
        private static bool Bool(PdfFile f, PdfObject o) { PdfBool b = f.Resolve(o) as PdfBool; return b != null && b.Value; }

        private static double[] Nums(PdfFile f, PdfObject o)
        {
            PdfArray a = f.Resolve(o) as PdfArray;
            if (a == null) return null;
            double[] r = new double[a.Count];
            for (int i = 0; i < a.Count; i++) { PdfNumber n = f.Resolve(a[i]) as PdfNumber; r[i] = n == null ? 0 : n.Value; }
            return r;
        }
    }
}
