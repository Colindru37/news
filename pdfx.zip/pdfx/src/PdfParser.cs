using System;
using System.Text;

namespace Pdfx.Internal
{
    public sealed class PdfParser
    {
        private readonly PdfLexer _lex;
        private readonly PdfFile _owner;
        private int _curNum;
        private int _curGen;

        public bool SuppressDecryption;

        public PdfParser(byte[] data, PdfFile owner)
        {
            _lex = new PdfLexer(data);
            _owner = owner;
        }

        public int Position
        {
            get { return _lex.Position; }
            set { _lex.Position = value; }
        }

        public byte[] Data { get { return _lex.Data; } }

        public PdfObject ParseObject()
        {
            return ParseFromToken(_lex.Next());
        }

        public PdfObject ParseIndirectAt(int offset, out int number, out int generation)
        {
            number = 0;
            generation = 0;
            if (offset < 0 || offset >= _lex.Data.Length)
                throw new PdfException("object offset out of range: " + offset);

            _lex.Position = offset;
            Token a = _lex.Next();
            Token b = _lex.Next();
            Token c = _lex.Next();
            if (a.Type != TokenType.Number || b.Type != TokenType.Number
                || c.Type != TokenType.Keyword || c.Text != "obj")
                throw new PdfException("expected 'N G obj' at offset " + offset);

            number = (int)a.Number;
            generation = (int)b.Number;
            _curNum = number;
            _curGen = generation;
            return ParseObject();
        }

        private PdfObject ParseFromToken(Token t)
        {
            switch (t.Type)
            {
                case TokenType.Eof:
                    return PdfNull.Instance;

                case TokenType.Number:
                    if (t.IsInteger)
                    {
                        int save = _lex.Position;
                        Token t2 = _lex.Next();
                        if (t2.Type == TokenType.Number && t2.IsInteger)
                        {
                            Token t3 = _lex.Next();
                            if (t3.Type == TokenType.Keyword && t3.Text == "R")
                                return new PdfRef((int)t.Number, (int)t2.Number);
                        }
                        _lex.Position = save;
                    }
                    return new PdfNumber(t.Number, t.IsInteger);

                case TokenType.Name:
                    return new PdfName(t.Text);

                case TokenType.String:
                {
                    byte[] bytes = t.Bytes;
                    if (_owner != null && _owner.Decryptor != null && !SuppressDecryption)
                        bytes = _owner.Decryptor.DecryptString(bytes, _curNum, _curGen);
                    return new PdfString(bytes, t.WasHex);
                }

                case TokenType.ArrayStart:
                {
                    PdfArray arr = new PdfArray();
                    while (true)
                    {
                        int save = _lex.Position;
                        Token e = _lex.Next();
                        if (e.Type == TokenType.ArrayEnd || e.Type == TokenType.Eof) break;
                        if (e.Type == TokenType.DictEnd) break;
                        _lex.Position = save;
                        arr.Items.Add(ParseObject());
                        if (_lex.Position <= save) { _lex.Position = save + 1; }
                    }
                    return arr;
                }

                case TokenType.DictStart:
                    return ParseDictionaryOrStream();

                case TokenType.Keyword:
                    if (t.Text == "true") return PdfBool.True;
                    if (t.Text == "false") return PdfBool.False;
                    return PdfNull.Instance;
            }
            return PdfNull.Instance;
        }

        private PdfObject ParseDictionaryOrStream()
        {
            PdfDictionary dict = new PdfDictionary();
            while (true)
            {
                Token k = _lex.Next();
                if (k.Type == TokenType.DictEnd || k.Type == TokenType.Eof) break;
                if (k.Type != TokenType.Name) continue;
                PdfObject v = ParseObject();
                dict.Set(k.Text, v);
            }

            int save = _lex.Position;
            Token s = _lex.Next();
            if (s.Type == TokenType.Keyword && s.Text == "stream")
                return ReadStream(dict);
            _lex.Position = save;
            return dict;
        }

        private PdfObject ReadStream(PdfDictionary dict)
        {
            byte[] data = _lex.Data;
            int p = _lex.Position;

            if (p < data.Length && data[p] == 13)
            {
                p++;
                if (p < data.Length && data[p] == 10) p++;
            }
            else if (p < data.Length && data[p] == 10) p++;

            int start = p;

            int len = -1;
            PdfObject lenObj = dict.Get("Length");
            if (lenObj is PdfRef && _owner != null) lenObj = _owner.Resolve(lenObj);
            PdfNumber ln = lenObj as PdfNumber;
            if (ln != null) len = ln.AsInt;

            bool ok = false;
            if (len >= 0 && start + len <= data.Length)
            {
                int q = start + len;
                while (q < data.Length && PdfLexer.IsWhite(data[q])) q++;
                if (Match(data, q, "endstream")) ok = true;
            }

            if (!ok)
            {
                int idx = IndexOf(data, "endstream", start);
                int end = idx < 0 ? data.Length : idx;
                if (end > start && data[end - 1] == 10) end--;
                if (end > start && data[end - 1] == 13) end--;
                len = end - start;
            }

            if (len < 0) len = 0;
            if (start + len > data.Length) len = Math.Max(0, data.Length - start);

            byte[] raw = new byte[len];
            Buffer.BlockCopy(data, start, raw, 0, len);

            int after = IndexOf(data, "endstream", start + len);
            _lex.Position = after < 0 ? data.Length : after + 9;

            if (_owner != null && _owner.Decryptor != null && !SuppressDecryption)
            {
                PdfName ty = dict.Get("Type") as PdfName;
                if (ty == null || ty.Value != "XRef")
                    raw = _owner.Decryptor.DecryptStream(raw, _curNum, _curGen);
            }

            return new PdfStream(dict, raw);
        }

        public static bool Match(byte[] data, int pos, string text)
        {
            if (pos < 0 || pos + text.Length > data.Length) return false;
            for (int i = 0; i < text.Length; i++)
                if (data[pos + i] != (byte)text[i]) return false;
            return true;
        }

        public static int IndexOf(byte[] data, string text, int from)
        {
            if (from < 0) from = 0;
            int last = data.Length - text.Length;
            for (int i = from; i <= last; i++)
                if (Match(data, i, text)) return i;
            return -1;
        }

        public static int LastIndexOf(byte[] data, string text, int from, int limit)
        {
            int start = Math.Min(from, data.Length - text.Length);
            for (int i = start; i >= limit && i >= 0; i--)
                if (Match(data, i, text)) return i;
            return -1;
        }
    }
}
