using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Text;

namespace Pdfx.Internal
{
    internal static class PdfaGlyphs
    {
        private static Dictionary<string, int> _names;
        private static Dictionary<string, string[]> _encodings;
        private static readonly object Gate = new object();

        private static void Load()
        {
            lock (Gate)
            {
                if (_names != null) return;
                Dictionary<string, int> n = new Dictionary<string, int>(StringComparer.Ordinal);
                Fill(n, PdfaTables.Dingbats);
                Fill(n, PdfaTables.Glyphs);
                // Symbol's bracket and integral pieces: the glyph list points them into
                // Adobe's private range; Unicode has had real code points since 3.2.
                Fill(n, "parenlefttp 239b parenleftex 239c parenleftbt 239d parenrighttp 239e parenrightex 239f "
                    + "parenrightbt 23a0 bracketlefttp 23a1 bracketleftex 23a2 bracketleftbt 23a3 bracketrighttp 23a4 "
                    + "bracketrightex 23a5 bracketrightbt 23a6 bracelefttp 23a7 braceleftmid 23a8 braceleftbt 23a9 "
                    + "braceex 23aa bracerighttp 23ab bracerightmid 23ac bracerightbt 23ad integraltp 2320 "
                    + "integralbt 2321 integralex 23ae arrowvertex 23d0 arrowhorizex 23af radicalex 203e "
                    + "copyrightsans a9 copyrightserif a9 registersans ae registerserif ae trademarksans 2122 trademarkserif 2122");
                Dictionary<string, string[]> e = new Dictionary<string, string[]>(StringComparer.Ordinal);
                e["StandardEncoding"] = Split(PdfaTables.Standard);
                e["WinAnsiEncoding"] = Split(PdfaTables.WinAnsi);
                e["MacRomanEncoding"] = Split(PdfaTables.MacRoman);
                e["Symbol"] = Split(PdfaTables.Symbol);
                e["ZapfDingbats"] = Split(PdfaTables.ZapfDingbats);
                _encodings = e;
                _names = n;
            }
        }

        private static void Fill(Dictionary<string, int> into, string table)
        {
            string[] p = table.Split(' ');
            for (int i = 0; i + 1 < p.Length; i += 2)
                into[p[i]] = Convert.ToInt32(p[i + 1], 16);
        }

        private static string[] Split(string table)
        {
            string[] p = table.Split(' ');
            string[] r = new string[256];
            for (int i = 0; i < 256 && i < p.Length; i++) r[i] = p[i] == "." ? null : p[i];
            return r;
        }

        public static string[] Encoding(string name)
        {
            Load();
            string[] e;
            return _encodings.TryGetValue(name, out e) ? (string[])e.Clone() : null;
        }

        // Adobe Glyph List lookup, plus the uniXXXX / uXXXX[XX] forms. -1 if unknown.
        public static int Unicode(string glyph)
        {
            if (string.IsNullOrEmpty(glyph)) return -1;
            Load();
            int u;
            if (_names.TryGetValue(glyph, out u)) return u;
            string g = glyph;
            int dot = g.IndexOf('.');
            if (dot > 0) { g = g.Substring(0, dot); if (_names.TryGetValue(g, out u)) return u; }
            if (g.StartsWith("uni", StringComparison.Ordinal) && g.Length == 7 && TryHex(g.Substring(3), out u)) return u;
            if (g.StartsWith("u", StringComparison.Ordinal) && g.Length >= 5 && g.Length <= 7 && TryHex(g.Substring(1), out u)) return u;
            return -1;
        }

        private static bool TryHex(string s, out int v)
        {
            return int.TryParse(s, System.Globalization.NumberStyles.HexNumber,
                System.Globalization.CultureInfo.InvariantCulture, out v);
        }
    }

    internal sealed class PdfaFontFixer
    {
        private readonly PdfOutput _o;
        private readonly PdfStandardsConverterOptions _opt;
        private readonly IList<string> _warn;
        private readonly Dictionary<string, PdfaTrueType> _loaded = new Dictionary<string, PdfaTrueType>();

        public PdfaFontFixer(PdfOutput o, PdfStandardsConverterOptions opt, IList<string> warnings)
        {
            _o = o; _opt = opt; _warn = warnings;
        }

        private PdfObject R(PdfObject x)
        {
            int guard = 0;
            while (x is PdfRef && guard++ < 32) x = _o.GetObject(((PdfRef)x).Number);
            return x;
        }

        private static string Name(PdfObject o) { PdfName n = o as PdfName; return n == null ? null : n.Value; }

        public static bool IsEmbedded(PdfDictionary descriptor)
        {
            return descriptor != null && (descriptor.Has("FontFile") || descriptor.Has("FontFile2") || descriptor.Has("FontFile3"));
        }

        // Replaces the contents of a simple, non-embedded font dictionary in place with an
        // embedded, subsetted, symbolic TrueType font that draws the same glyphs.
        public void EmbedSimple(PdfDictionary font, HashSet<int> used)
        {
            string baseFont = Name(font.Get("BaseFont")) ?? "Helvetica";
            PdfDictionary desc = R(font.Get("FontDescriptor")) as PdfDictionary;
            int flags = 0;
            if (desc != null) { PdfNumber f = R(desc.Get("Flags")) as PdfNumber; if (f != null) flags = f.AsInt; }

            string family; bool bold, italic;
            ParseName(baseFont, desc, flags, out family, out bold, out italic);
            string key = PdfaFontLocator.Norm(family);
            bool isSymbol = key == "symbol" || key == "symbolmt";
            bool isDings = key == "zapfdingbats" || key == "dingbats" || key == "itczapfdingbats";

            string[] names = Glyphs(font, isSymbol, isDings, flags);
            Dictionary<int, int> unicode = ReadToUnicode(font);

            bool drawn = used != null && used.Count > 0;
            if (!drawn)
            {
                used = new HashSet<int>();
                for (int c = 32; c < 127; c++) if (names[c] != null) used.Add(c);
            }

            Dictionary<int, int> codeUni = new Dictionary<int, int>();
            foreach (int c in used)
            {
                if (c < 0 || c > 255) continue;
                int u = PdfaGlyphs.Unicode(names[c]);
                if (u < 0) unicode.TryGetValue(c, out u);
                if (u <= 0 && names[c] == null && c >= 32 && c < 127) u = c;
                codeUni[c] = u;
            }

            List<string> candidates = Candidates(family, key, desc, flags, isSymbol, isDings);
            PdfaTrueType best = null;
            Dictionary<int, int> bestMap = null;
            List<int> bestMissing = null;
            foreach (string fam in candidates)
            {
                PdfaFontLocator.Entry e = fam.StartsWith("ps:", StringComparison.Ordinal)
                    ? PdfaFontLocator.FindPostScript(_opt.FontDirectories, fam.Substring(3))
                    : PdfaFontLocator.Find(_opt.FontDirectories, fam, bold, italic);
                if (e == null) continue;
                PdfaTrueType tt = Load(e);
                if (tt == null) continue;
                if ((tt.FsType & 0x000F) == 0x0002) continue;
                Dictionary<int, int> map = new Dictionary<int, int>();
                List<int> missing = new List<int>();
                foreach (KeyValuePair<int, int> kv in codeUni)
                {
                    int gid = 0;
                    if (tt.IsSymbolEncoded) gid = tt.GlyphForSymbolCode(kv.Key);
                    else if (kv.Value > 0) gid = tt.GlyphForUnicode(kv.Value);
                    if (gid == 0) missing.Add(kv.Key); else map[kv.Key] = gid;
                }
                if (best == null || missing.Count < bestMissing.Count)
                {
                    best = tt; bestMap = map; bestMissing = missing;
                }
                if (missing.Count == 0) break;
            }

            if (best == null)
                throw new PdfException("font " + baseFont + " is not embedded and no installed TrueType font can replace it");
            if (bestMissing.Count > 0)
            {
                StringBuilder sb = new StringBuilder();
                foreach (int c in bestMissing)
                {
                    if (sb.Length > 0) sb.Append(", ");
                    sb.Append(names[c] ?? ("code " + c));
                }
                throw new PdfException("font " + baseFont + " is not embedded and the best replacement ("
                    + best.Family + ") has no glyph for: " + sb);
            }

            if (drawn && PdfaFontLocator.Norm(best.Family) != PdfaFontLocator.Norm(family)
                && !MetricCompatible(key, best.Family))
                _warn.Add("font " + baseFont + " replaced by " + best.Family + " (different metrics, text may shift)");

            Rebuild(font, best, bestMap, codeUni, baseFont);
        }

        // A symbolic TrueType font may not carry /Encoding in PDF/A-2/3; viewers ignore it
        // anyway (codes go through the (3,0) cmap). Its glyph names are often the only
        // text mapping though, so they are kept as a ToUnicode CMap before it goes.
        public void DropSymbolicEncoding(PdfDictionary font)
        {
            if (!font.Has("Encoding")) return;
            if (!font.Has("ToUnicode"))
            {
                string[] names = Glyphs(font, false, false, 4);
                Dictionary<int, int> map = new Dictionary<int, int>();
                PdfNumber fc = R(font.Get("FirstChar")) as PdfNumber, lc = R(font.Get("LastChar")) as PdfNumber;
                int first = fc == null ? 0 : fc.AsInt, last = lc == null ? 255 : lc.AsInt;
                for (int c = Math.Max(0, first); c <= Math.Min(255, last); c++)
                {
                    int u = PdfaGlyphs.Unicode(names[c]);
                    if (u > 0) map[c] = u;
                }
                if (map.Count > 0) font.Set("ToUnicode", new PdfRef(_o.AddObject(ToUnicodeStream(map, false)), 0));
            }
            font.Remove("Encoding");
        }

        private void Rebuild(PdfDictionary font, PdfaTrueType tt, Dictionary<int, int> map,
                             Dictionary<int, int> codeUni, string originalName)
        {
            List<int> codes = new List<int>(map.Keys);
            codes.Sort();
            int first = codes[0], last = codes[codes.Count - 1];
            byte[] program = tt.Subset(map.Values, map);
            string ps = tt.PostScriptName.Replace(" ", "");
            string tag = SubsetTag(originalName, codes);

            PdfArray widths = new PdfArray();
            for (int c = first; c <= last; c++)
            {
                int gid;
                double w = map.TryGetValue(c, out gid) ? tt.AdvanceOf(gid) : 0;
                widths.Items.Add(new PdfNumber(Math.Round(w), true));
            }

            PdfDictionary ff = new PdfDictionary();
            ff.Set("Filter", new PdfName("FlateDecode"));
            ff.Set("Length1", new PdfNumber(program.Length, true));
            int ffNum = _o.AddObject(new PdfStream(ff, Deflate(program)));

            PdfDictionary d = new PdfDictionary();
            d.Set("Type", new PdfName("FontDescriptor"));
            d.Set("FontName", new PdfName(tag + "+" + ps));
            int flags = 4;
            if (tt.FixedPitch) flags |= 1;
            if (tt.Serif) flags |= 2;
            if (tt.Italic) flags |= 64;
            d.Set("Flags", new PdfNumber(flags, true));
            PdfArray bbox = new PdfArray();
            bbox.Items.Add(new PdfNumber(Math.Round(tt.Scale(tt.XMin)), true));
            bbox.Items.Add(new PdfNumber(Math.Round(tt.Scale(tt.YMin)), true));
            bbox.Items.Add(new PdfNumber(Math.Round(tt.Scale(tt.XMax)), true));
            bbox.Items.Add(new PdfNumber(Math.Round(tt.Scale(tt.YMax)), true));
            d.Set("FontBBox", bbox);
            d.Set("ItalicAngle", new PdfNumber(tt.ItalicAngle, false));
            d.Set("Ascent", new PdfNumber(Math.Round(tt.Scale(tt.Ascent)), true));
            d.Set("Descent", new PdfNumber(Math.Round(tt.Scale(tt.Descent)), true));
            d.Set("CapHeight", new PdfNumber(Math.Round(tt.Scale(tt.CapHeight)), true));
            d.Set("StemV", new PdfNumber(tt.Bold ? 120 : 80, true));
            d.Set("FontFile2", new PdfRef(ffNum, 0));
            int dNum = _o.AddObject(d);

            int tuNum = _o.AddObject(ToUnicodeStream(codeUni, false));

            font.Map.Clear();
            font.Set("Type", new PdfName("Font"));
            font.Set("Subtype", new PdfName("TrueType"));
            font.Set("BaseFont", new PdfName(tag + "+" + ps));
            font.Set("FirstChar", new PdfNumber(first, true));
            font.Set("LastChar", new PdfNumber(last, true));
            font.Set("Widths", widths);
            font.Set("FontDescriptor", new PdfRef(dNum, 0));
            font.Set("ToUnicode", new PdfRef(tuNum, 0));
        }

        // code -> glyph name for any simple font, the way a viewer resolves it.
        internal string[] GlyphNames(PdfDictionary font)
        {
            string baseFont = Name(font.Get("BaseFont")) ?? "";
            string family; bool b, i;
            ParseName(baseFont, null, 0, out family, out b, out i);
            string key = PdfaFontLocator.Norm(family);
            bool sym = key == "symbol" || key == "symbolmt";
            bool dings = key == "zapfdingbats" || key == "dingbats" || key == "itczapfdingbats";
            if (Name(font.Get("Subtype")) == "Type3")
            {
                string[] none = new string[256];
                PdfDictionary ed = R(font.Get("Encoding")) as PdfDictionary;
                PdfArray diff = ed == null ? null : R(ed.Get("Differences")) as PdfArray;
                if (diff == null) return none;
                int code = 0;
                for (int k = 0; k < diff.Count; k++)
                {
                    PdfObject it = R(diff[k]);
                    if (it is PdfNumber) { code = ((PdfNumber)it).AsInt; continue; }
                    string g = Name(it);
                    if (g != null && code >= 0 && code < 256) none[code++] = g;
                }
                return none;
            }
            return Glyphs(font, sym, dings, 0);
        }

        // Adds code -> Unicode entries to a font's ToUnicode CMap, keeping every mapping it
        // already has (ligatures included) by inserting a block before endcmap.
        internal void AddToUnicode(PdfDictionary font, IDictionary<int, int> add, bool twoByte)
        {
            PdfStream s = R(font.Get("ToUnicode")) as PdfStream;
            byte[] old = null;
            if (s != null) { try { old = PdfaDecode.Decode(s, _o); } catch { old = null; } }
            string text = old == null ? null : Encoding.GetEncoding(28591).GetString(old);
            int at = text == null ? -1 : text.LastIndexOf("endcmap", StringComparison.Ordinal);
            if (at < 0)
            {
                Dictionary<int, int> all = new Dictionary<int, int>(ReadToUnicode(font));
                foreach (KeyValuePair<int, int> kv in add) all[kv.Key] = kv.Value;
                font.Set("ToUnicode", new PdfRef(_o.AddObject(ToUnicodeStream(all, twoByte)), 0));
                return;
            }
            Dictionary<int, byte[]> raw = ReadToUnicodeRaw(font);
            bool replaces = false;
            foreach (int c in add.Keys) if (raw.ContainsKey(c)) replaces = true;
            if (replaces)
            {
                // Two entries for one code is undefined; readers pick either. Drop every bfchar and
                // bfrange section and write the merged map back, keeping the header and codespace.
                foreach (KeyValuePair<int, int> kv in add) raw[kv.Key] = Utf16(kv.Value);
                text = StripSections(StripSections(text.Substring(0, at), "bfchar"), "bfrange") + text.Substring(at);
                at = text.LastIndexOf("endcmap", StringComparison.Ordinal);
                StringBuilder all = new StringBuilder();
                List<int> keys = new List<int>(raw.Keys);
                keys.Sort();
                for (int i = 0; i < keys.Count; i += 100)
                {
                    int n = Math.Min(100, keys.Count - i);
                    all.Append(n).Append(" beginbfchar\n");
                    for (int k = i; k < i + n; k++)
                    {
                        all.Append('<').Append(keys[k].ToString(twoByte ? "X4" : "X2")).Append("> <");
                        foreach (byte b in raw[keys[k]]) all.Append(b.ToString("X2"));
                        all.Append(">\n");
                    }
                    all.Append("endbfchar\n");
                }
                text = text.Substring(0, at) + all + text.Substring(at);
                PdfDictionary nd = new PdfDictionary();
                nd.Set("Filter", new PdfName("FlateDecode"));
                font.Set("ToUnicode", new PdfRef(_o.AddObject(new PdfStream(nd, Deflate(Encoding.GetEncoding(28591).GetBytes(text)))), 0));
                return;
            }
            StringBuilder sb = new StringBuilder();
            List<int> codes = new List<int>(add.Keys);
            codes.Sort();
            for (int i = 0; i < codes.Count; i += 100)
            {
                int n = Math.Min(100, codes.Count - i);
                sb.Append(n).Append(" beginbfchar\n");
                for (int k = i; k < i + n; k++)
                {
                    sb.Append('<').Append(codes[k].ToString(twoByte ? "X4" : "X2")).Append("> <");
                    foreach (char ch in char.ConvertFromUtf32(add[codes[k]])) sb.Append(((int)ch).ToString("X4"));
                    sb.Append(">\n");
                }
                sb.Append("endbfchar\n");
            }
            string merged = text.Substring(0, at) + sb + text.Substring(at);
            PdfDictionary d = new PdfDictionary();
            d.Set("Filter", new PdfName("FlateDecode"));
            font.Set("ToUnicode", new PdfRef(_o.AddObject(new PdfStream(d, Deflate(Encoding.GetEncoding(28591).GetBytes(merged)))), 0));
        }

        private static byte[] Utf16(int u)
        {
            string t = char.ConvertFromUtf32(u);
            byte[] r = new byte[2 * t.Length];
            for (int i = 0; i < t.Length; i++) { r[2 * i] = (byte)(t[i] >> 8); r[2 * i + 1] = (byte)t[i]; }
            return r;
        }

        // Removes every "N beginbf<kind> ... endbf<kind>" block, count included.
        private static string StripSections(string text, string kind)
        {
            StringBuilder sb = new StringBuilder();
            int pos = 0;
            while (true)
            {
                int b = text.IndexOf("begin" + kind, pos, StringComparison.Ordinal);
                if (b < 0) break;
                int e = text.IndexOf("end" + kind, b, StringComparison.Ordinal);
                if (e < 0) break;
                int start = b;
                while (start > pos && char.IsWhiteSpace(text[start - 1])) start--;
                while (start > pos && char.IsDigit(text[start - 1])) start--;
                sb.Append(text, pos, start - pos);
                pos = e + ("end" + kind).Length;
            }
            sb.Append(text, pos, text.Length - pos);
            return sb.ToString();
        }

        public static PdfStream ToUnicodeStream(IDictionary<int, int> codeUni, bool twoByte)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("/CIDInit /ProcSet findresource begin\n12 dict begin\nbegincmap\n");
            sb.Append("/CIDSystemInfo << /Registry (Adobe) /Ordering (UCS) /Supplement 0 >> def\n");
            sb.Append("/CMapName /Adobe-Identity-UCS def\n/CMapType 2 def\n");
            sb.Append("1 begincodespacerange\n").Append(twoByte ? "<0000> <FFFF>" : "<00> <FF>").Append("\nendcodespacerange\n");
            List<int> codes = new List<int>();
            foreach (KeyValuePair<int, int> kv in codeUni) if (kv.Value > 0 && kv.Value != 0xFEFF && kv.Value != 0xFFFE) codes.Add(kv.Key);
            codes.Sort();
            for (int i = 0; i < codes.Count; i += 100)
            {
                int n = Math.Min(100, codes.Count - i);
                sb.Append(n).Append(" beginbfchar\n");
                for (int k = i; k < i + n; k++)
                {
                    int c = codes[k];
                    sb.Append('<').Append(c.ToString(twoByte ? "X4" : "X2")).Append("> <");
                    string s = char.ConvertFromUtf32(codeUni[c]);
                    foreach (char ch in s) sb.Append(((int)ch).ToString("X4"));
                    sb.Append(">\n");
                }
                sb.Append("endbfchar\n");
            }
            sb.Append("endcmap\nCMapName currentdict /CMap defineresource pop\nend\nend\n");
            PdfDictionary d = new PdfDictionary();
            d.Set("Filter", new PdfName("FlateDecode"));
            return new PdfStream(d, Deflate(Encoding.ASCII.GetBytes(sb.ToString())));
        }

        private static string SubsetTag(string name, List<int> codes)
        {
            uint h = 2166136261;
            foreach (char c in name) h = (h ^ c) * 16777619;
            foreach (int c in codes) h = (h ^ (uint)c) * 16777619;
            char[] t = new char[6];
            for (int i = 0; i < 6; i++) { t[i] = (char)('A' + (int)(h % 26)); h /= 26; }
            return new string(t);
        }

        private PdfaTrueType Load(PdfaFontLocator.Entry e)
        {
            string k = e.Path + "#" + e.Index;
            PdfaTrueType t;
            if (_loaded.TryGetValue(k, out t)) return t;
            try { t = PdfaTrueType.Parse(File.ReadAllBytes(e.Path), e.Index); t.Path = e.Path; }
            catch { t = null; }
            _loaded[k] = t;
            return t;
        }

        // code -> glyph name, following the font's /Encoding or the base font's built-in one.
        private string[] Glyphs(PdfDictionary font, bool isSymbol, bool isDings, int flags)
        {
            string[] names;
            if (isSymbol) names = PdfaGlyphs.Encoding("Symbol");
            else if (isDings) names = PdfaGlyphs.Encoding("ZapfDingbats");
            else names = PdfaGlyphs.Encoding("StandardEncoding");

            PdfObject enc = R(font.Get("Encoding"));
            string en = Name(enc);
            if (en != null)
            {
                string[] e = PdfaGlyphs.Encoding(en);
                if (e != null) names = e;
            }
            PdfDictionary ed = enc as PdfDictionary;
            if (ed != null)
            {
                string be = Name(R(ed.Get("BaseEncoding")));
                if (be != null) { string[] e = PdfaGlyphs.Encoding(be); if (e != null) names = e; }
                PdfArray diff = R(ed.Get("Differences")) as PdfArray;
                if (diff != null)
                {
                    int code = 0;
                    for (int i = 0; i < diff.Count; i++)
                    {
                        PdfObject it = R(diff[i]);
                        PdfNumber n = it as PdfNumber;
                        if (n != null) { code = n.AsInt; continue; }
                        string g = Name(it);
                        if (g != null && code >= 0 && code < 256) names[code++] = g;
                    }
                }
            }
            return names;
        }

        internal Dictionary<int, int> ReadToUnicode(PdfDictionary font)
        {
            Dictionary<int, int> r = new Dictionary<int, int>();
            foreach (KeyValuePair<int, byte[]> kv in ReadToUnicodeRaw(font)) r[kv.Key] = FirstChar(kv.Value);
            return r;
        }

        // code -> the full UTF-16BE target, so a rewrite keeps ligatures and multi-unit targets.
        private Dictionary<int, byte[]> ReadToUnicodeRaw(PdfDictionary font)
        {
            Dictionary<int, byte[]> r = new Dictionary<int, byte[]>();
            PdfStream s = R(font.Get("ToUnicode")) as PdfStream;
            if (s == null) return r;
            byte[] data;
            try { data = PdfaDecode.Decode(s, _o); } catch { return r; }
            PdfaLexer lx = new PdfaLexer(data);
            List<PdfaToken> buf = new List<PdfaToken>();
            string mode = null;
            while (true)
            {
                PdfaToken t = lx.Next();
                if (t.Kind == PdfaTok.Eof) break;
                if (t.Kind == PdfaTok.Operator)
                {
                    if (t.Text == "beginbfchar" || t.Text == "beginbfrange") mode = t.Text;
                    else if (t.Text == "endbfchar" || t.Text == "endbfrange") mode = null;
                    buf.Clear();
                    continue;
                }
                if (mode == null) continue;
                buf.Add(t);
                if (mode == "beginbfchar" && buf.Count == 2)
                {
                    if (buf[0].Kind == PdfaTok.String && buf[1].Kind == PdfaTok.String)
                        r[Int(buf[0].Bytes)] = buf[1].Bytes;
                    buf.Clear();
                }
                else if (mode == "beginbfrange" && buf.Count >= 3 && buf[buf.Count - 1].Kind != PdfaTok.ArrayStart)
                {
                    if (buf[2].Kind == PdfaTok.String)
                    {
                        int lo = Int(buf[0].Bytes), hi = Int(buf[1].Bytes);
                        for (int c = lo; c <= hi && c - lo < 65536; c++) r[c] = Offset(buf[2].Bytes, c - lo);
                        buf.Clear();
                    }
                    else if (buf[2].Kind == PdfaTok.ArrayStart)
                    {
                        if (buf[buf.Count - 1].Kind == PdfaTok.ArrayEnd)
                        {
                            int lo = Int(buf[0].Bytes);
                            for (int k = 3; k < buf.Count - 1; k++) if (buf[k].Kind == PdfaTok.String) r[lo + k - 3] = buf[k].Bytes;
                            buf.Clear();
                        }
                    }
                    else buf.Clear();
                }
            }
            return r;
        }

        private static int Int(byte[] b) { int v = 0; foreach (byte x in b) v = v << 8 | x; return v; }

        // A bfrange target advances by its last UTF-16 unit (a surrogate pair stays a pair).
        private static byte[] Offset(byte[] t, int by)
        {
            byte[] r = (byte[])t.Clone();
            if (by == 0 || r.Length < 2) return r;
            int u = (r[r.Length - 2] << 8 | r[r.Length - 1]) + by;
            r[r.Length - 2] = (byte)(u >> 8);
            r[r.Length - 1] = (byte)u;
            return r;
        }

        private static int FirstChar(byte[] utf16)
        {
            if (utf16.Length < 2) return utf16.Length == 1 ? utf16[0] : -1;
            int hi = utf16[0] << 8 | utf16[1];
            if (hi >= 0xD800 && hi < 0xDC00 && utf16.Length >= 4)
                return 0x10000 + ((hi - 0xD800) << 10) + ((utf16[2] << 8 | utf16[3]) - 0xDC00);
            return hi;
        }

        private static readonly string[] Sans = { "Arial", "Liberation Sans", "Arimo", "Helvetica", "DejaVu Sans" };
        private static readonly string[] Serif = { "Times New Roman", "Liberation Serif", "Tinos", "DejaVu Serif" };
        private static readonly string[] Mono = { "Courier New", "Liberation Mono", "Cousine", "DejaVu Sans Mono" };
        private static readonly string[] SymbolFonts = { "Symbol", "Segoe UI Symbol", "DejaVu Sans", "Noto Sans Symbols", "Arial" };
        private static readonly string[] DingFonts = { "Segoe UI Symbol", "DejaVu Sans", "Noto Sans Symbols 2", "Noto Sans Symbols" };

        private static string Generic(string key)
        {
            if (key.StartsWith("helvetica") || key.StartsWith("arial")) return "sans";
            if (key.StartsWith("times")) return "serif";
            if (key.StartsWith("courier")) return "mono";
            return null;
        }

        private static bool MetricCompatible(string key, string family)
        {
            string g = Generic(key);
            string f = PdfaFontLocator.Norm(family);
            if (g == "sans") return f == "arial" || f == "liberationsans" || f == "arimo" || f == "helvetica";
            if (g == "serif") return f == "timesnewroman" || f == "liberationserif" || f == "tinos";
            if (g == "mono") return f == "couriernew" || f == "liberationmono" || f == "cousine";
            return false;
        }

        private static List<string> Candidates(string family, string key, PdfDictionary desc, int flags, bool isSymbol, bool isDings)
        {
            List<string> r = new List<string>();
            if (isSymbol) { r.AddRange(SymbolFonts); return r; }
            if (isDings) { r.AddRange(DingFonts); return r; }
            string g = Generic(key);
            if (g == "sans") r.AddRange(Sans);
            else if (g == "serif") r.AddRange(Serif);
            else if (g == "mono") r.AddRange(Mono);
            else
            {
                r.Add(family);
                string ps = family.Replace(" ", "");
                r.Add("ps:" + ps);
                if ((flags & 1) != 0) r.AddRange(Mono);
                else if ((flags & 2) != 0) r.AddRange(Serif);
                else r.AddRange(Sans);
            }
            return r;
        }

        private static readonly string[] StyleWords = { "bolditalic", "boldoblique", "bold", "italic", "oblique", "regular", "roman", "book", "normal", "semibold", "demibold", "black", "heavy" };

        internal static void ParseName(string baseFont, PdfDictionary desc, int flags, out string family, out bool bold, out bool italic)
        {
            string n = baseFont;
            int plus = n.IndexOf('+');
            if (plus == 6) n = n.Substring(7);
            string style = "";
            int comma = n.IndexOf(',');
            if (comma >= 0) { style = n.Substring(comma + 1); n = n.Substring(0, comma); }
            else
            {
                int dash = n.LastIndexOf('-');
                if (dash > 0) { style = n.Substring(dash + 1); n = n.Substring(0, dash); }
            }
            string ls = style.ToLowerInvariant();
            if (ls.EndsWith("mt")) ls = ls.Substring(0, ls.Length - 2);
            bold = ls.Contains("bold") || ls.Contains("black") || ls.Contains("heavy") || (flags & 0x40000) != 0;
            italic = ls.Contains("italic") || ls.Contains("oblique") || (flags & 64) != 0;
            if (desc != null)
            {
                PdfNumber w = desc.Get("FontWeight") as PdfNumber;
                if (w != null && w.Value >= 600) bold = true;
                PdfNumber a = desc.Get("ItalicAngle") as PdfNumber;
                if (a != null && Math.Abs(a.Value) > 0.5) italic = true;
            }
            if (n.EndsWith("PSMT")) n = n.Substring(0, n.Length - 4);
            else if (n.EndsWith("MT")) n = n.Substring(0, n.Length - 2);
            else if (n.EndsWith("PS")) n = n.Substring(0, n.Length - 2);
            string known = PdfaFontLocator.Norm(n);
            if (known == "timesnewroman" || known == "times") family = "Times New Roman";
            else if (style.Length > 0 && Array.IndexOf(StyleWords, ls) < 0 && comma < 0)
                family = n + " " + style;
            else family = SplitCamel(n);
        }

        private static string SplitCamel(string s)
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < s.Length; i++)
            {
                if (i > 0 && char.IsUpper(s[i]) && char.IsLower(s[i - 1])) sb.Append(' ');
                sb.Append(s[i]);
            }
            return sb.ToString();
        }

        public static byte[] Deflate(byte[] data)
        {
            MemoryStream ms = new MemoryStream();
            ms.WriteByte(0x78); ms.WriteByte(0x9C);
            using (DeflateStream z = new DeflateStream(ms, CompressionMode.Compress, true))
                z.Write(data, 0, data.Length);
            uint a = 1, b = 0;
            foreach (byte x in data) { a = (a + x) % 65521; b = (b + a) % 65521; }
            uint ad = (b << 16) | a;
            ms.WriteByte((byte)(ad >> 24)); ms.WriteByte((byte)(ad >> 16)); ms.WriteByte((byte)(ad >> 8)); ms.WriteByte((byte)ad);
            return ms.ToArray();
        }
    }
}
