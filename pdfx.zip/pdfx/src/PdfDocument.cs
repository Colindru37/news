using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Pdfx.Internal;

namespace Pdfx
{
    public sealed partial class PdfDocument : IDisposable
    {

        private readonly List<PdfPage> _pages = new List<PdfPage>();

        // Files this document OPENED and must therefore close.
        private readonly List<PdfFile> _owned = new List<PdfFile>();

        // Files this document BORROWED pages from. They must stay readable until
        // this document is written, but they belong to whoever opened them and
        // must NOT be disposed here. Conflating the two closed a shared source as
        // soon as the first output document was disposed, so every later output
        // silently came out with the right page count and no content.
        private readonly List<PdfFile> _borrowed = new List<PdfFile>();

        private readonly PdfDictionary _info = new PdfDictionary();
        private readonly List<PdfBookmark> _bookmarks = new List<PdfBookmark>();
        private readonly List<PdfAttachment> _attachments = new List<PdfAttachment>();
        private readonly HashSet<PdfDocument> _bookmarksFrom = new HashSet<PdfDocument>();
        private PdfDictionary _root;

        // Catalog entries carried over from the opened file. Structure tags, PDF/A metadata and
        // output intents are not: a changed document must not keep claiming what it no longer is.
        private static readonly string[] Kept = { "Lang", "ViewerPreferences", "PageMode", "PageLayout", "OCProperties" };

        public bool WasRepaired { get; private set; }

        internal PdfDictionary AcroForm;
        internal PdfFile PrimaryFile;
        public PdfFile SourceFile { get { return PrimaryFile; } }

        private PdfDocument() { }

        public static PdfDocument Create()
        {
            return new PdfDocument();
        }

        public static PdfDocument Open(string path)
        {
            return Open(path, null);
        }

        public static PdfDocument Open(byte[] bytes)
        {
            return Open(bytes, null);
        }

        // A JPEG or PNG opens too, as a one-page document.
        public static PdfDocument Open(string path, string password)
        {
            return Open(PdfComposer.ReadInput(path), password);
        }

        public static PdfDocument Open(byte[] bytes, string password)
        {
            if (bytes == null) throw new ArgumentNullException("bytes");
            if (PdfImages.IsImage(bytes)) bytes = PdfImages.ToPdf(new[] { bytes });
            else PdfImages.RefuseText(bytes);
            return FromFile(Unlocked(PdfFile.Open(bytes), password), true);
        }

        private static PdfFile Unlocked(PdfFile f, string password)
        {
            if (f.IsEncrypted && f.Decryptor == null && password != null) f.Unlock(password);
            return f;
        }

        private static PdfDocument FromFile(PdfFile f, bool own)
        {
            PdfDocument d = new PdfDocument();
            if (own) d._owned.Add(f);
            d.WasRepaired = f.WasRepaired;

            if (f.IsEncrypted && f.Decryptor == null)
                throw new Internal.PdfException("cannot open the document: "
                    + (f.DecryptionProblem ?? "it is encrypted and could not be unlocked"));

            PdfDictionary root = f.Resolve(f.Trailer.Get("Root")) as PdfDictionary;
            if (root == null) throw new Internal.PdfException("not a PDF file, or damaged beyond repair (no document catalog)");

            d.PrimaryFile = f;
            d.AcroForm = f.Resolve(root.Get("AcroForm")) as PdfDictionary;

            PdfObject pagesRef = root.Get("Pages");
            Collect(f, pagesRef, new PdfDictionary(), d._pages, new HashSet<int>(), 0);
            d._root = root;

            Dictionary<int, PdfPage> byNumber = new Dictionary<int, PdfPage>();
            foreach (PdfPage p in d._pages) if (p.SourceNumber > 0 && !byNumber.ContainsKey(p.SourceNumber)) byNumber[p.SourceNumber] = p;
            try { d._bookmarks.AddRange(PdfOutlines.Read(d, f, root, byNumber)); } catch (Exception) { }
            try { d._attachments.AddRange(PdfAttachmentIo.Read(f, root)); } catch (Exception) { }

            PdfDictionary info = f.Resolve(f.Trailer.Get("Info")) as PdfDictionary;
            if (info != null)
            {
                foreach (KeyValuePair<string, PdfObject> kv in info.Map)
                {
                    PdfString s = f.Resolve(kv.Value) as PdfString;
                    if (s != null) d._info.Set(kv.Key, new PdfString(s.Bytes, s.WasHex));
                }
            }
            return d;
        }

        private static void Collect(PdfFile f, PdfObject nodeRef, PdfDictionary inherited,
                                    List<PdfPage> into, HashSet<int> guard, int depth)
        {
            PdfPageTree.Collect(f, nodeRef, inherited, into, guard, depth);
        }

        public int PageCount { get { return _pages.Count; } }

        public PdfPage GetPage(int index)
        {
            if (index < 0 || index >= _pages.Count)
                throw new Internal.PdfException("page index out of range: " + index
                    + " (document has " + _pages.Count + " pages)");
            return _pages[index];
        }

        public void RemovePage(int index)
        {
            GetPage(index);
            _pages.RemoveAt(index);
        }

        public void MovePage(int from, int to)
        {
            PdfPage p = GetPage(from);
            if (to < 0 || to >= _pages.Count)
                throw new Internal.PdfException("target index out of range: " + to);
            _pages.RemoveAt(from);
            _pages.Insert(to, p);
        }

        public void AppendPagesFrom(PdfDocument other)
        {
            if (other == null) throw new ArgumentNullException("other");
            for (int i = 0; i < other._pages.Count; i++) _pages.Add(other._pages[i]);
            CarryBookmarks(other);
            // Attachments travel with a whole document; the same file merged twice adds them once.
            foreach (PdfAttachment a in other._attachments)
            {
                bool dup = false;
                foreach (PdfAttachment b in _attachments)
                    if (ReferenceEquals(a, b) || (a.Source != null && a.Source == b.Source && Equals(a.SourceSpec, b.SourceSpec))) dup = true;
                if (!dup) _attachments.Add(a);
            }
            KeepAlive(other);
        }

        // A source's bookmarks come along once; those whose pages are not here are dropped on save.
        private void CarryBookmarks(PdfDocument other)
        {
            if (other == this || !_bookmarksFrom.Add(other)) return;
            foreach (PdfBookmark b in other._bookmarks) _bookmarks.Add(b.CloneInto(this));
        }

        internal int IndexOfPage(PdfPage p) { return _pages.IndexOf(p); }

        // Top-level bookmarks, each with its Children.
        public IList<PdfBookmark> Bookmarks { get { return _bookmarks; } }

        public PdfBookmark AddBookmark(string title, int pageIndex)
        {
            PdfBookmark b = new PdfBookmark(this, title, GetPage(pageIndex));
            _bookmarks.Add(b);
            return b;
        }

        // Files embedded in the document. Remove from this list to drop one.
        public IList<PdfAttachment> Attachments { get { return _attachments; } }

        public PdfAttachment AddAttachment(string path)
        {
            byte[] data = PdfComposer.ReadInput(path);
            return AddAttachment(Path.GetFileName(PdfComposer.CleanPath(path)), data);
        }

        public PdfAttachment AddAttachment(string fileName, byte[] data)
        {
            if (string.IsNullOrEmpty(fileName)) throw new ArgumentException("the attachment needs a file name", "fileName");
            if (data == null) throw new ArgumentNullException("data");
            PdfAttachment a = PdfAttachment.FromData(fileName, (byte[])data.Clone());
            _attachments.Add(a);
            return a;
        }

        public void InsertPageFrom(PdfDocument other, int otherIndex, int at)
        {
            if (other == null) throw new ArgumentNullException("other");
            PdfPage p = other.GetPage(otherIndex);
            if (at < 0 || at > _pages.Count)
                throw new Internal.PdfException("insert index out of range: " + at);
            _pages.Insert(at, p);
            CarryBookmarks(other);
            KeepAlive(other);
        }

        // Inclusive, 0-based. The source is left untouched; the returned document
        // borrows its pages, so the source must stay open until it is written.
        public PdfDocument ExtractPages(int first, int last)
        {
            if (first < 0 || first >= _pages.Count)
                throw new Internal.PdfException("first page out of range: " + first);
            if (last < first || last >= _pages.Count)
                throw new Internal.PdfException("last page out of range: " + last);

            PdfDocument d = Create();
            int at = 0;
            for (int p = first; p <= last; p++)
                d.InsertPageFrom(this, p, at++);
            return d;
        }

        // Borrowing pages does not transfer ownership of the source file.
        private void KeepAlive(PdfDocument other)
        {
            for (int i = 0; i < other._owned.Count; i++)
                Borrow(other._owned[i]);
            for (int i = 0; i < other._borrowed.Count; i++)
                Borrow(other._borrowed[i]);
        }

        private void Borrow(PdfFile f)
        {
            if (f == null) return;
            if (_owned.Contains(f)) return;
            if (!_borrowed.Contains(f)) _borrowed.Add(f);
        }

        public PdfPage AddBlankPage(double width, double height)
        {
            PdfDictionary d = new PdfDictionary();
            d.Set("Type", new PdfName("Page"));
            PdfArray box = new PdfArray();
            box.Items.Add(new PdfNumber(0, true));
            box.Items.Add(new PdfNumber(0, true));
            box.Items.Add(new PdfNumber(width, false));
            box.Items.Add(new PdfNumber(height, false));
            d.Set("MediaBox", box);
            d.Set("Resources", new PdfDictionary());
            PdfPage p = new PdfPage(null, d);
            _pages.Add(p);
            return p;
        }

        public string Title { get { return Meta("Title"); } set { SetMeta("Title", value); } }
        public string Author { get { return Meta("Author"); } set { SetMeta("Author", value); } }
        public string Subject { get { return Meta("Subject"); } set { SetMeta("Subject", value); } }
        public string Keywords { get { return Meta("Keywords"); } set { SetMeta("Keywords", value); } }
        public string Creator { get { return Meta("Creator"); } set { SetMeta("Creator", value); } }
        public string Producer { get { return Meta("Producer"); } set { SetMeta("Producer", value); } }

        private string Meta(string key)
        {
            PdfString s = _info.Get(key) as PdfString;
            return s == null ? null : s.AsText();
        }

        private void SetMeta(string key, string value)
        {
            if (value == null) { _info.Remove(key); return; }
            _info.Set(key, new PdfString(TextBytes(value), false));
        }

        internal static byte[] TextBytes(string value)
        {
            bool ascii = true;
            for (int i = 0; i < value.Length; i++) if (value[i] > 126) { ascii = false; break; }
            if (ascii)
            {
                byte[] b = new byte[value.Length];
                for (int i = 0; i < value.Length; i++) b[i] = (byte)value[i];
                return b;
            }
            byte[] u = Encoding.BigEndianUnicode.GetBytes(value);
            byte[] r = new byte[u.Length + 2];
            r[0] = 0xFE; r[1] = 0xFF;
            Buffer.BlockCopy(u, 0, r, 2, u.Length);
            return r;
        }

        public string ToText()
        {
            return PdfConvert.ToText(this, new PdfConvertOptions());
        }

        public string ToText(PdfConvertOptions options)
        {
            if (options == null) throw new ArgumentNullException("options");
            return PdfConvert.ToText(this, options);
        }

        public string ToMarkdown()
        {
            return PdfConvert.ToMarkdown(this, new PdfConvertOptions());
        }

        public string ToMarkdown(PdfConvertOptions options)
        {
            if (options == null) throw new ArgumentNullException("options");
            return PdfConvert.ToMarkdown(this, options);
        }

        public string ToHtml()
        {
            return PdfConvert.ToHtml(this, new PdfConvertOptions());
        }

        public string ToHtml(PdfConvertOptions options)
        {
            if (options == null) throw new ArgumentNullException("options");
            return PdfConvert.ToHtml(this, options);
        }

        public string ExtractText()
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < _pages.Count; i++)
            {
                if (i > 0) sb.Append(Environment.NewLine);
                sb.Append(PdfText.Extract(_pages[i]));
            }
            return sb.ToString();
        }

        public byte[] ToBytes()
        {
            return Build(null);
        }

        private byte[] Build(PdfEncryptor enc)
        {
            PdfOutput o = new PdfOutput();
            o.Encryptor = enc;
            int pagesNum = o.Reserve();
            int catalogNum = o.Reserve();

            PdfArray kids = new PdfArray();
            Dictionary<PdfPage, int> pageRefs = new Dictionary<PdfPage, int>();
            for (int i = 0; i < _pages.Count; i++)
            {
                PdfPage p = _pages[i];
                int n = o.Reserve();
                PdfDictionary copy;
                if (p.FitTo != null && NeedsWrap(p))
                    copy = PdfResizer.Wrap(o, p, p.FitTo[0], p.FitTo[1], n);
                else
                    copy = p.Source != null
                        ? (PdfDictionary)o.Import(p.Source, p.Dict)
                        : (PdfDictionary)o.CopyDirect(p.Dict);
                copy.Set("Type", new PdfName("Page"));
                copy.Set("Parent", new PdfRef(pagesNum, 0));
                o.SetObject(n, copy);
                kids.Items.Add(new PdfRef(n, 0));
                if (!pageRefs.ContainsKey(p)) pageRefs[p] = n;
            }

            PdfDictionary pages = new PdfDictionary();
            pages.Set("Type", new PdfName("Pages"));
            pages.Set("Kids", kids);
            pages.Set("Count", new PdfNumber(kids.Count, true));
            o.SetObject(pagesNum, pages);

            PdfDictionary cat = new PdfDictionary();
            cat.Set("Type", new PdfName("Catalog"));
            cat.Set("Pages", new PdfRef(pagesNum, 0));
            if (AcroForm != null && PrimaryFile != null)
                cat.Set("AcroForm", o.Import(PrimaryFile, AcroForm));
            if (_root != null && PrimaryFile != null)
                foreach (string k in Kept)
                    if (_root.Has(k)) cat.Set(k, o.Import(PrimaryFile, _root.Get(k)));
            PdfOutlines.Write(o, cat, _bookmarks, pageRefs);
            PdfAttachmentIo.Write(o, cat, _attachments);
            o.SetObject(catalogNum, cat);
            o.Trailer.Set("Root", new PdfRef(catalogNum, 0));

            if (_info.Map.Count > 0)
            {
                PdfDictionary info = new PdfDictionary();
                foreach (KeyValuePair<string, PdfObject> kv in _info.Map) info.Set(kv.Key, kv.Value);
                int n = o.AddObject(info);
                o.Trailer.Set("Info", new PdfRef(n, 0));
            }

            return o.ToBytes();
        }

        // A page already of the wanted size, unrotated and uncropped, is copied as it is.
        private static bool NeedsWrap(PdfPage p)
        {
            double[] m = p.MediaBox, v = p.VisibleBox;
            bool sameBox = Math.Abs(m[0] - v[0]) < 0.01 && Math.Abs(m[1] - v[1]) < 0.01 && Math.Abs(m[2] - v[2]) < 0.01 && Math.Abs(m[3] - v[3]) < 0.01;
            bool sameSize = Math.Abs(p.Width - p.FitTo[0]) < 0.5 && Math.Abs(p.Height - p.FitTo[1]) < 0.5;
            return !(sameBox && sameSize && p.Rotation == 0 && Math.Abs(m[0]) < 0.01 && Math.Abs(m[1]) < 0.01);
        }

        public void Save(string path)
        {
            PdfComposer.WriteOutput(path, ToBytes());
        }

        public void Save(Stream target)
        {
            byte[] b = ToBytes();
            target.Write(b, 0, b.Length);
        }

        public void Dispose()
        {
            // Only files this document opened. Borrowed sources stay open for
            // their owner - see _borrowed.
            for (int i = 0; i < _owned.Count; i++) _owned[i].Dispose();
            _owned.Clear();
            _borrowed.Clear();
            _pages.Clear();
        }
    }
}
