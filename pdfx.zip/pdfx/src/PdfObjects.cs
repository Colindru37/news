using System;
using System.Collections.Generic;
using System.Text;

namespace Pdfx.Internal
{
    public abstract class PdfObject { }

    public sealed class PdfNull : PdfObject
    {
        public static readonly PdfNull Instance = new PdfNull();
        private PdfNull() { }
        public override string ToString() { return "null"; }
    }

    public sealed class PdfBool : PdfObject
    {
        public readonly bool Value;
        public PdfBool(bool value) { Value = value; }
        public static readonly PdfBool True = new PdfBool(true);
        public static readonly PdfBool False = new PdfBool(false);
    }

    public sealed class PdfNumber : PdfObject
    {
        public readonly double Value;
        public readonly bool IsInteger;
        public PdfNumber(double value, bool isInteger) { Value = value; IsInteger = isInteger; }
        public int AsInt { get { return (int)Math.Round(Value); } }
        public long AsLong { get { return (long)Math.Round(Value); } }
        public override string ToString() { return Value.ToString(System.Globalization.CultureInfo.InvariantCulture); }
    }

    public sealed class PdfString : PdfObject
    {
        public readonly byte[] Bytes;
        public readonly bool WasHex;
        public PdfString(byte[] bytes, bool wasHex) { Bytes = bytes; WasHex = wasHex; }

        public string AsText()
        {
            if (Bytes.Length >= 2 && Bytes[0] == 0xFE && Bytes[1] == 0xFF)
                return Encoding.BigEndianUnicode.GetString(Bytes, 2, Bytes.Length - 2);
            var sb = new StringBuilder(Bytes.Length);
            for (int i = 0; i < Bytes.Length; i++) sb.Append((char)Bytes[i]);
            return sb.ToString();
        }
    }

    public sealed class PdfName : PdfObject
    {
        public readonly string Value;
        public PdfName(string value) { Value = value; }
        public override bool Equals(object obj)
        {
            PdfName o = obj as PdfName;
            return o != null && o.Value == Value;
        }
        public override int GetHashCode() { return Value == null ? 0 : Value.GetHashCode(); }
        public override string ToString() { return "/" + Value; }
    }

    public sealed class PdfArray : PdfObject
    {
        public readonly List<PdfObject> Items = new List<PdfObject>();
        public int Count { get { return Items.Count; } }
        public PdfObject this[int i]
        {
            get { return i >= 0 && i < Items.Count ? Items[i] : (PdfObject)PdfNull.Instance; }
        }
    }

    public sealed class PdfDictionary : PdfObject
    {
        public readonly Dictionary<string, PdfObject> Map = new Dictionary<string, PdfObject>(StringComparer.Ordinal);
        public PdfObject Get(string key)
        {
            PdfObject v;
            return Map.TryGetValue(key, out v) ? v : null;
        }
        public bool Has(string key) { return Map.ContainsKey(key); }
        public void Set(string key, PdfObject value) { Map[key] = value; }
        public void Remove(string key) { Map.Remove(key); }
    }

    public sealed class PdfStream : PdfObject
    {
        public readonly PdfDictionary Dict;
        public byte[] RawData;
        public PdfStream(PdfDictionary dict, byte[] raw) { Dict = dict; RawData = raw; }
    }

    public sealed class PdfRef : PdfObject
    {
        public readonly int Number;
        public readonly int Generation;
        public PdfRef(int number, int generation) { Number = number; Generation = generation; }
        public override bool Equals(object obj)
        {
            PdfRef o = obj as PdfRef;
            return o != null && o.Number == Number && o.Generation == Generation;
        }
        public override int GetHashCode() { return Number * 31 + Generation; }
        public override string ToString() { return Number + " " + Generation + " R"; }
    }

    // Everything the library throws for a bad or unreadable document. Derives from
    // Pdfx.PdfException so callers can catch it with only "using Pdfx;".
    public class PdfException : Pdfx.PdfException
    {
        public PdfException(string message) : base(message) { }
    }

    public interface IPdfDecryptor
    {
        byte[] DecryptString(byte[] data, int objNumber, int generation);
        byte[] DecryptStream(byte[] data, int objNumber, int generation);
    }
}

namespace Pdfx
{
    // Catch this. The library always throws the Pdfx.Internal subclass, so code written
    // against either name keeps working.
    public abstract class PdfException : Exception
    {
        protected PdfException(string message) : base(message) { }
    }
}
