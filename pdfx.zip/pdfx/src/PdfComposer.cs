using System;
using System.Collections.Generic;
using System.IO;
using Pdfx.Internal;

namespace Pdfx
{
    public static partial class PdfComposer
    {
        public static void Merge(string[] inputs, string output)
        {
            MergeCore(inputs, output, false);
        }

        private static void MergeCore(string[] inputs, string output, bool bookmarkEachFile)
        {
            if (inputs == null || inputs.Length == 0)
                throw new Internal.PdfException("Merge needs at least one input file");

            List<PdfDocument> opened = new List<PdfDocument>();
            try
            {
                PdfDocument target = PdfDocument.Create();
                for (int i = 0; i < inputs.Length; i++)
                {
                    if (inputs[i] == null) throw new ArgumentException("input " + (i + 1) + " is null", "inputs");
                    PdfDocument d;
                    // With twenty inputs, "needs a password" is useless without saying which.
                    try { d = PdfDocument.Open(inputs[i]); }
                    catch (Internal.PdfException e)
                    {
                        throw new Internal.PdfException("input " + (i + 1) + " (" + Path.GetFileName(inputs[i]) + "): " + e.Message);
                    }
                    opened.Add(d);
                    int firstPage = target.PageCount, before = target.Bookmarks.Count;
                    target.AppendPagesFrom(d);
                    if (bookmarkEachFile && d.PageCount > 0)
                    {
                        List<PdfBookmark> own = new List<PdfBookmark>();
                        while (target.Bookmarks.Count > before) { own.Add(target.Bookmarks[before]); target.Bookmarks.RemoveAt(before); }
                        PdfBookmark file = target.AddBookmark(Path.GetFileNameWithoutExtension(CleanPath(inputs[i])), firstPage);
                        foreach (PdfBookmark b in own) file.Children.Add(b);
                    }
                }
                if (target.PageCount == 0)
                    throw new Internal.PdfException("Merge produced no pages: every input was empty");
                target.Save(output);
            }
            finally
            {
                for (int i = 0; i < opened.Count; i++) opened[i].Dispose();
            }
        }

        public static void Extract(string input, int[] pageIndexes, string output)
        {
            if (pageIndexes == null || pageIndexes.Length == 0)
                throw new Internal.PdfException("Extract needs at least one page index");

            using (PdfDocument src = PdfDocument.Open(input))
            {
                PdfDocument target = PdfDocument.Create();
                for (int i = 0; i < pageIndexes.Length; i++)
                {
                    int idx = pageIndexes[i];
                    if (idx < 0 || idx >= src.PageCount)
                        throw new Internal.PdfException("page index out of range: " + idx
                            + " (document has " + src.PageCount + " pages)");
                    target.InsertPageFrom(src, idx, target.PageCount);
                }
                target.Save(output);
            }
        }

        public static string[] SplitToPages(string input, string outputFolder, string prefix)
        {
            outputFolder = OutputFolder(outputFolder);

            using (PdfDocument src = PdfDocument.Open(input))
            {
                string[] made = new string[src.PageCount];
                for (int i = 0; i < src.PageCount; i++)
                {
                    PdfDocument one = PdfDocument.Create();
                    one.InsertPageFrom(src, i, 0);
                    string path = Path.Combine(outputFolder, prefix + (i + 1).ToString("D4") + ".pdf");
                    one.Save(path);
                    made[i] = path;
                }
                return made;
            }
        }

        public static void RotatePages(string input, int[] pageIndexes, int degrees, string output)
        {
            if (degrees % 90 != 0)
                throw new ArgumentException("pages turn in steps of 90 degrees; " + degrees + " is not one", "degrees");
            using (PdfDocument doc = PdfDocument.Open(input))
            {
                if (pageIndexes == null || pageIndexes.Length == 0)
                {
                    for (int i = 0; i < doc.PageCount; i++)
                        doc.GetPage(i).Rotation = doc.GetPage(i).Rotation + degrees;
                }
                else
                {
                    // A page listed twice turns once, not twice as far.
                    foreach (int index in new HashSet<int>(pageIndexes))
                    {
                        PdfPage p = doc.GetPage(index);
                        p.Rotation = p.Rotation + degrees;
                    }
                }
                doc.Save(output);
            }
        }

        public static void DeletePages(string input, int[] pageIndexes, string output)
        {
            using (PdfDocument doc = PdfDocument.Open(input))
            {
                // A page listed twice is deleted once: removing index 0 twice would take page 2 too.
                List<int> sorted = new List<int>(new HashSet<int>(pageIndexes ?? new int[0]));
                sorted.Sort();
                for (int i = sorted.Count - 1; i >= 0; i--) doc.RemovePage(sorted[i]);
                if (doc.PageCount == 0)
                    throw new Internal.PdfException("refusing to save a document with no pages left");
                doc.Save(output);
            }
        }
    }
}
