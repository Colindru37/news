using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using Pdfx.Internal;

namespace Pdfx
{
    public sealed class PdfStandardsConverterOptions
    {
        public bool PreserveAllowedMetadata;
        public string Language = "en-US";
        public List<string> FontDirectories = new List<string>();
        public bool AllowSignatureRemoval;
    }

    // PDF -> PDF/A (ISO 19005 parts 1-3, conformance levels A, B and U).
    public sealed class PdfStandardsConverter
    {
        private readonly byte[] _source;
        private readonly string _password;
        private readonly PdfStandardsConverterOptions _options = new PdfStandardsConverterOptions();
        private readonly List<string> _warnings = new List<string>();

        public PdfStandardsConverter(string path) : this(path, null) { }

        public PdfStandardsConverter(string path, string password)
        {
            _source = Images(PdfComposer.ReadInput(path));
            _password = password;
        }

        public PdfStandardsConverter(byte[] bytes) : this(bytes, null) { }

        public PdfStandardsConverter(byte[] bytes, string password)
        {
            if (bytes == null) throw new ArgumentNullException("bytes");
            _source = Images(bytes);
            _password = password;
        }

        public PdfStandardsConverter(Stream input) : this(input, null) { }

        public PdfStandardsConverter(Stream input, string password)
        {
            if (input == null) throw new ArgumentNullException("input");
            MemoryStream ms = new MemoryStream();
            input.CopyTo(ms);
            _source = Images(ms.ToArray());
            _password = password;
        }

        public PdfStandardsConverterOptions Options { get { return _options; } }

        // What the last conversion changed that a reader could notice. Cleared on each call.
        public IList<string> Warnings { get { return _warnings; } }

        public void ToPdfA1B(string path) { Save(path, 1, 'B'); }
        public void ToPdfA1B(Stream target) { Save(target, 1, 'B'); }
        public void ToPdfA2B(string path) { Save(path, 2, 'B'); }
        public void ToPdfA2B(Stream target) { Save(target, 2, 'B'); }
        public void ToPdfA3B(string path) { Save(path, 3, 'B'); }
        public void ToPdfA3B(Stream target) { Save(target, 3, 'B'); }
        public void ToPdfA2U(string path) { Save(path, 2, 'U'); }
        public void ToPdfA2U(Stream target) { Save(target, 2, 'U'); }
        public void ToPdfA3U(string path) { Save(path, 3, 'U'); }
        public void ToPdfA3U(Stream target) { Save(target, 3, 'U'); }
        public void ToPdfA1A(string path) { Save(path, 1, 'A'); }
        public void ToPdfA1A(Stream target) { Save(target, 1, 'A'); }
        public void ToPdfA2A(string path) { Save(path, 2, 'A'); }
        public void ToPdfA2A(Stream target) { Save(target, 2, 'A'); }
        public void ToPdfA3A(string path) { Save(path, 3, 'A'); }
        public void ToPdfA3A(Stream target) { Save(target, 3, 'A'); }

        public byte[] Convert(int part, char conformance)
        {
            if (part < 1 || part > 3) throw new ArgumentOutOfRangeException("part");
            conformance = char.ToUpperInvariant(conformance);
            if (conformance != 'A' && conformance != 'B' && conformance != 'U')
                throw new ArgumentOutOfRangeException("conformance");
            if (part == 1 && conformance == 'U') throw new Internal.PdfException("PDF/A-1 has no U level");
            _warnings.Clear();
            return new PdfaJob(part, conformance, _options, _warnings).Run(_source, _password);
        }

        // A JPEG or PNG converts too: it becomes a one-page PDF first.
        private static byte[] Images(byte[] b)
        {
            if (PdfImages.IsImage(b)) return PdfImages.ToPdf(new[] { b });
            PdfImages.RefuseText(b);
            return b;
        }

        // One call for the common case. level is any usual spelling: "2B", "PDF/A-2b", "pdfa2b".
        public static void ConvertFile(string input, string output, string level)
        {
            ConvertFile(input, output, level, null);
        }

        public static void ConvertFile(string input, string output, string level, string password)
        {
            if (input == null) throw new ArgumentNullException("input");
            if (output == null) throw new ArgumentNullException("output");
            int part;
            char conformance;
            ParseLevel(level, out part, out conformance);
            new PdfStandardsConverter(input, password).Save(output, part, conformance);
        }

        // The level a file claims in its XMP metadata ("2B", "1A", ...), or null when it claims
        // none. A claim, not a validation: only a validator can say whether it is true.
        public static string GetDeclaredLevel(string path)
        {
            if (path == null) throw new ArgumentNullException("path");
            using (PdfFile f = PdfFile.Open(path))
            {
                PdfDictionary root = f.Resolve(f.Trailer.Get("Root")) as PdfDictionary;
                PdfStream md = root == null ? null : f.Resolve(root.Get("Metadata")) as PdfStream;
                if (md == null) return null;
                string xmp;
                try { xmp = System.Text.Encoding.UTF8.GetString(PdfFilters.Decode(md, f)); }
                catch (Exception) { return null; }
                string part = XmpValue(xmp, "part");
                if (part == null) return null;
                string conf = XmpValue(xmp, "conformance");
                return part + (conf == null ? "" : conf.ToUpperInvariant());
            }
        }

        private static string XmpValue(string xmp, string key)
        {
            System.Text.RegularExpressions.Match m = System.Text.RegularExpressions.Regex.Match(xmp,
                "pdfaid:" + key + "\\s*(?:=\\s*[\"']\\s*([0-9A-Za-z])|>\\s*([0-9A-Za-z])\\s*<)");
            if (!m.Success) return null;
            return m.Groups[1].Success ? m.Groups[1].Value : m.Groups[2].Value;
        }

        private static void ParseLevel(string level, out int part, out char conformance)
        {
            string t = level == null ? "" : level.Trim().ToUpperInvariant();
            if (t.StartsWith("PDF", StringComparison.Ordinal)) t = t.Substring(3);
            t = t.Replace("/", "").Replace("-", "").Replace(" ", "").Replace("_", "");
            if (t.StartsWith("A", StringComparison.Ordinal) && t.Length == 3) t = t.Substring(1);
            if (t.Length != 2 || t[0] < '1' || t[0] > '3' || (t[1] != 'A' && t[1] != 'B' && t[1] != 'U') || t == "1U")
                throw new ArgumentException("unknown PDF/A level '" + level + "'; use one of 1A, 1B, 2A, 2B, 2U, 3A, 3B, 3U", "level");
            part = t[0] - '0';
            conformance = t[1];
        }

        private void Save(string path, int part, char conformance)
        {
            if (path == null) throw new ArgumentNullException("path");
            byte[] b = Convert(part, conformance);
            PdfComposer.WriteOutput(path, b);
        }

        private void Save(Stream target, int part, char conformance)
        {
            if (target == null) throw new ArgumentNullException("target");
            byte[] b = Convert(part, conformance);
            target.Write(b, 0, b.Length);
        }
    }
}

namespace Pdfx.Internal
{
    internal sealed partial class PdfaJob
    {
        private readonly int _part;
        private readonly char _conf;
        private readonly PdfStandardsConverterOptions _opt;
        private readonly IList<string> _warn;
        private PdfFile _f;
        private PdfOutput _o;
        private PdfDictionary _cat;
        private PdfaContentScanner _scan;
        private readonly HashSet<PdfObject> _seen = new HashSet<PdfObject>();
        private readonly List<PdfDictionary> _resources = new List<PdfDictionary>();
        private readonly HashSet<PdfDictionary> _resSeen = new HashSet<PdfDictionary>();
        private readonly List<PdfDictionary> _fonts = new List<PdfDictionary>();
        private readonly HashSet<PdfDictionary> _fontSeen = new HashSet<PdfDictionary>();
        private readonly List<PdfDictionary> _pages = new List<PdfDictionary>();
        private readonly Dictionary<PdfDictionary, PdfDictionary> _pageRes = new Dictionary<PdfDictionary, PdfDictionary>();
        private bool _cmyk;
        private readonly HashSet<string> _once = new HashSet<string>();

        public PdfaJob(int part, char conf, PdfStandardsConverterOptions opt, IList<string> warnings)
        {
            _part = part; _conf = conf; _opt = opt; _warn = warnings;
        }

        private void WarnOnce(string w) { if (_once.Add(w)) _warn.Add(w); }

        private PdfObject R(PdfObject x)
        {
            int guard = 0;
            while (x is PdfRef && guard++ < 32) x = _o.GetObject(((PdfRef)x).Number);
            return x;
        }

        private static string Name(PdfObject o) { PdfName n = o as PdfName; return n == null ? null : n.Value; }

        private static PdfNumber Num(double v) { return new PdfNumber(v, v == Math.Floor(v)); }

        public byte[] Run(byte[] source, string password)
        {
            _f = PdfFile.Open(source);
            if (_f.IsEncrypted && _f.Decryptor == null)
            {
                if (password != null) _f.Unlock(password);
                if (_f.Decryptor == null)
                    throw new PdfException("cannot convert: the document is encrypted and "
                        + (password == null ? "no password was given" : "the password is wrong"));
            }
            PdfObject rootRef = _f.Trailer.Get("Root");
            if (!(_f.Resolve(rootRef) is PdfDictionary)) throw new PdfException("not a PDF file, or damaged beyond repair (no document catalog)");

            _o = new PdfOutput();
            PdfObject root = _o.Import(_f, rootRef);
            _cat = R(root) as PdfDictionary;
            PdfDictionary srcInfo = _f.Resolve(_f.Trailer.Get("Info")) as PdfDictionary;
            _scan = new PdfaContentScanner(_o);

            CollectPages(R(_cat.Get("Pages")), null, new HashSet<PdfObject>(), 0);
            if (_pages.Count == 0) throw new PdfException("document has no pages");
            HandleSignatures();

            FixCatalog();
            int existing = _o.Count;
            for (int i = 1; i <= existing; i++) Walk(_o.GetObject(i), null, 0);
            Walk(_cat, null, 0);

            foreach (PdfDictionary page in _pages) FixPage(page);
            foreach (PdfDictionary page in _pages) ScanPage(page);
            if (_scan.UsesCmyk) _cmyk = true;

            PdfaFontFixer fixer = new PdfaFontFixer(_o, _opt, _warn);
            foreach (PdfDictionary font in _fonts) FixFont(fixer, font);
            if (_conf != 'B') EnsureUnicode(fixer);
            if (_part == 1) { FixContentLimits(); FlattenAlpha(); }
            if (_conf == 'A') Structure();

            AddOutputIntent();
            if (_cmyk) AddDefaultCmyk();

            PdfDictionary info = BuildInfo(srcInfo);
            int infoNum = _o.AddObject(info);
            AddMetadata(info);

            _o.Trailer.Set("Root", root is PdfRef ? root : new PdfRef(_o.AddObject(_cat), 0));
            _o.Trailer.Set("Info", new PdfRef(infoNum, 0));
            byte[] id = FileId(source);
            PdfArray ids = new PdfArray();
            ids.Items.Add(new PdfString(id, true));
            ids.Items.Add(new PdfString(id, true));
            _o.Trailer.Set("ID", ids);
            return _o.ToBytes();
        }

        // ---- pages -------------------------------------------------------------------

        private void CollectPages(PdfObject node, PdfDictionary inheritedRes, HashSet<PdfObject> guard, int depth)
        {
            PdfDictionary d = node as PdfDictionary;
            if (d == null || depth > 64 || !guard.Add(d)) return;
            PdfDictionary res = R(d.Get("Resources")) as PdfDictionary ?? inheritedRes;
            PdfArray kids = R(d.Get("Kids")) as PdfArray;
            if (Name(d.Get("Type")) != "Page" && kids != null)
            {
                for (int i = 0; i < kids.Count; i++) CollectPages(R(kids[i]), res, guard, depth + 1);
                return;
            }
            if (res == null) res = new PdfDictionary();
            if (!d.Has("Resources")) d.Set("Resources", res);
            _pages.Add(d);
            _pageRes[d] = res;
        }

        private void FixPage(PdfDictionary page)
        {
            page.Remove("AA");
            page.Remove("PresSteps");
            if (_part == 1) page.Remove("Group");
            PdfArray annots = R(page.Get("Annots")) as PdfArray;
            if (annots == null) return;
            PdfArray kept = new PdfArray();
            for (int i = 0; i < annots.Count; i++)
            {
                PdfDictionary a = R(annots[i]) as PdfDictionary;
                if (a == null) continue;
                if (!FixAnnotation(a)) continue;
                kept.Items.Add(annots[i]);
            }
            page.Set("Annots", kept);
        }

        private static readonly string[] Annots1 = { "Text", "Link", "FreeText", "Line", "Square", "Circle", "Highlight",
            "Underline", "Squiggly", "StrikeOut", "Stamp", "Ink", "Popup", "Widget", "PrinterMark", "TrapNet" };
        private static readonly string[] Annots2 = { "Text", "Link", "FreeText", "Line", "Square", "Circle", "Polygon",
            "PolyLine", "Highlight", "Underline", "Squiggly", "StrikeOut", "Stamp", "Caret", "Ink", "Popup", "Widget",
            "PrinterMark", "TrapNet", "Watermark", "Redact" };

        private bool FixAnnotation(PdfDictionary a)
        {
            string sub = Name(a.Get("Subtype")) ?? "";
            bool allowed = _part == 1 ? Array.IndexOf(Annots1, sub) >= 0
                : Array.IndexOf(Annots2, sub) >= 0 || (_part == 3 && sub == "FileAttachment");
            if (!allowed)
            {
                WarnOnce("removed " + sub + " annotations (not allowed in PDF/A-" + _part + ")");
                return false;
            }
            PdfNumber f = R(a.Get("F")) as PdfNumber;
            int flags = f == null ? 0 : f.AsInt;
            flags = (flags | 4) & ~(1 | 2 | 32 | 256);
            a.Set("F", new PdfNumber(flags, true));
            if (_part == 1) a.Remove("CA");
            a.Remove("AA");

            if (sub == "Popup") { a.Remove("AP"); return true; }
            PdfDictionary ap = R(a.Get("AP")) as PdfDictionary;
            if (ap != null)
            {
                ap.Remove("D");
                ap.Remove("R");
            }
            if (sub == "Link" && ap == null) return true;
            PdfObject n = ap == null ? null : R(ap.Get("N"));
            if (n == null || n is PdfNull)
            {
                double[] r = Rect(a);
                PdfDictionary fd = new PdfDictionary();
                fd.Set("Type", new PdfName("XObject"));
                fd.Set("Subtype", new PdfName("Form"));
                PdfArray bbox = new PdfArray();
                bbox.Items.Add(Num(0)); bbox.Items.Add(Num(0));
                bbox.Items.Add(Num(Math.Abs(r[2] - r[0]))); bbox.Items.Add(Num(Math.Abs(r[3] - r[1])));
                fd.Set("BBox", bbox);
                int num = _o.AddObject(new PdfStream(fd, new byte[0]));
                PdfDictionary nap = new PdfDictionary();
                nap.Set("N", new PdfRef(num, 0));
                a.Set("AP", nap);
                if (sub != "Widget") WarnOnce("gave " + sub + " annotations an empty appearance (they had none)");
            }
            else if (sub == "Widget" && FieldType(a) == "Btn" && n is PdfStream)
            {
                PdfDictionary st = new PdfDictionary();
                string state = Name(a.Get("AS")) ?? "Off";
                st.Set(state, ap.Get("N"));
                ap.Set("N", st);
                a.Set("AS", new PdfName(state));
            }
            return true;
        }

        private string FieldType(PdfDictionary a)
        {
            PdfDictionary d = a;
            for (int i = 0; i < 32 && d != null; i++)
            {
                string ft = Name(R(d.Get("FT")));
                if (ft != null) return ft;
                d = R(d.Get("Parent")) as PdfDictionary;
            }
            return null;
        }

        private double[] Rect(PdfDictionary a)
        {
            double[] r = { 0, 0, 0, 0 };
            PdfArray arr = R(a.Get("Rect")) as PdfArray;
            if (arr != null && arr.Count == 4)
                for (int i = 0; i < 4; i++) { PdfNumber n = R(arr[i]) as PdfNumber; if (n != null) r[i] = n.Value; }
            return r;
        }

        private void ScanPage(PdfDictionary page)
        {
            PdfDictionary res = _pageRes[page];
            _scan.Scan(PageContent(page), res, 0);
            PdfArray annots = R(page.Get("Annots")) as PdfArray;
            if (annots == null) return;
            for (int i = 0; i < annots.Count; i++)
            {
                PdfDictionary a = R(annots[i]) as PdfDictionary;
                PdfDictionary ap = a == null ? null : R(a.Get("AP")) as PdfDictionary;
                if (ap == null) continue;
                foreach (KeyValuePair<string, PdfObject> kv in ap.Map)
                {
                    PdfObject v = R(kv.Value);
                    PdfStream s = v as PdfStream;
                    if (s != null) { _scan.ScanFormOnce(s, res, 1); continue; }
                    PdfDictionary states = v as PdfDictionary;
                    if (states != null)
                        foreach (KeyValuePair<string, PdfObject> st in states.Map)
                            _scan.ScanFormOnce(R(st.Value) as PdfStream, res, 1);
                }
            }
        }

        private byte[] PageContent(PdfDictionary page)
        {
            PdfObject c = R(page.Get("Contents"));
            MemoryStream ms = new MemoryStream();
            PdfStream s = c as PdfStream;
            if (s != null) { byte[] b = _scan.Decode(s); if (b != null) ms.Write(b, 0, b.Length); }
            PdfArray arr = c as PdfArray;
            if (arr != null)
                for (int i = 0; i < arr.Count; i++)
                {
                    PdfStream p = R(arr[i]) as PdfStream;
                    byte[] b = p == null ? null : _scan.Decode(p);
                    if (b == null) continue;
                    ms.Write(b, 0, b.Length);
                    ms.WriteByte(10);
                }
            return ms.ToArray();
        }

        // ---- the object walk ---------------------------------------------------------

        private void Walk(PdfObject o, string parentKey, int depth)
        {
            if (o == null || depth > 64) return;
            if (o is PdfDictionary || o is PdfArray || o is PdfStream)
                if (!_seen.Add(o)) return;

            PdfArray arr = o as PdfArray;
            if (arr != null)
            {
                for (int i = 0; i < arr.Count; i++)
                {
                    PdfName nm = arr[i] as PdfName;
                    if (nm != null && nm.Value == "DeviceCMYK") _cmyk = true;
                    if (!(arr[i] is PdfRef)) Walk(arr[i], parentKey, depth + 1);
                }
                return;
            }

            PdfStream s = o as PdfStream;
            PdfDictionary d = s != null ? s.Dict : o as PdfDictionary;
            if (d == null) return;

            if (s != null) FixStream(s);
            else FixDictionary(d);

            List<string> keys = new List<string>(d.Map.Keys);
            foreach (string k in keys)
            {
                PdfObject v = d.Get(k);
                if (v == null) continue;
                PdfName nm = v as PdfName;
                if (nm != null && nm.Value == "DeviceCMYK" && k != "Alternate") _cmyk = true;
                if (k == "Resources")
                {
                    PdfDictionary res = R(v) as PdfDictionary;
                    if (res != null) FixResources(res);
                }
                if (!(v is PdfRef)) Walk(v, k, depth + 1);
            }
        }

        private void FixDictionary(PdfDictionary d)
        {
            d.Remove("AA");
            if (d != _cat) d.Remove("Metadata");
            FixActionKey(d, "A");
            FixActionKey(d, "Next");
            string type = Name(d.Get("Type"));
            if (type == "Filespec" || (d.Has("EF") && d.Has("F"))) FixFilespec(d);
            if (d.Has("DR"))
            {
                PdfDictionary dr = R(d.Get("DR")) as PdfDictionary;
                if (dr != null) FixResources(dr);
            }
        }

        private static readonly string[] AllowedActions = { "GoTo", "GoToR", "GoToE", "Thread", "URI", "SubmitForm", "Named" };
        private static readonly string[] AllowedNamed = { "NextPage", "PrevPage", "FirstPage", "LastPage" };

        private bool ActionAllowed(PdfDictionary act)
        {
            string s = Name(R(act.Get("S")));
            if (s == null) return true;
            if (Array.IndexOf(AllowedActions, s) < 0) return false;
            if (s == "GoToE" && _part == 1) return false;
            if (s == "Named" && Array.IndexOf(AllowedNamed, Name(R(act.Get("N"))) ?? "") < 0) return false;
            return true;
        }

        private void FixActionKey(PdfDictionary d, string key)
        {
            PdfObject v = R(d.Get(key));
            PdfDictionary act = v as PdfDictionary;
            if (act != null && act.Has("S") && !ActionAllowed(act))
            {
                d.Remove(key);
                WarnOnce("removed " + Name(R(act.Get("S"))) + " actions (not allowed in PDF/A)");
            }
            PdfArray arr = v as PdfArray;
            if (arr != null && key == "Next")
            {
                for (int i = arr.Count - 1; i >= 0; i--)
                {
                    PdfDictionary a = R(arr[i]) as PdfDictionary;
                    if (a != null && !ActionAllowed(a)) arr.Items.RemoveAt(i);
                }
            }
        }

        private void FixStream(PdfStream s)
        {
            PdfDictionary d = s.Dict;
            d.Remove("F");
            d.Remove("FFilter");
            d.Remove("FDecodeParms");
            d.Remove("DL");
            d.Remove("Metadata");
            Refilter(s);

            string type = Name(d.Get("Type"));
            string sub = Name(d.Get("Subtype"));
            FixIccForPart1(s);
            if (sub == "Image") FixImage(s);
            else if (sub == "Form") FixForm(s);
            else if (sub == "PS" || (type == "XObject" && sub == "PS"))
                throw new PdfException("document contains a PostScript XObject, which no PDF/A level allows");
        }

        // LZW is forbidden in every part, and so is an external or crypt filter left over
        // from a decrypted file. Decode and re-store as Flate.
        private void Refilter(PdfStream s)
        {
            PdfObject f = R(s.Dict.Get("Filter"));
            List<string> names = new List<string>();
            if (f is PdfName) names.Add(((PdfName)f).Value);
            PdfArray fa = f as PdfArray;
            if (fa != null) for (int i = 0; i < fa.Count; i++) { string n = Name(R(fa[i])); if (n != null) names.Add(n); }
            bool bad = false;
            foreach (string n in names) if (n == "LZWDecode" || n == "LZW" || n == "Crypt") bad = true;
            if (!bad) return;
            if (names.Contains("Crypt") && names.Count == 1) { s.Dict.Remove("Filter"); s.Dict.Remove("DecodeParms"); return; }
            int keepFrom = names.Count;
            for (int i = 0; i < names.Count; i++)
                if (names[i] != "LZWDecode" && names[i] != "LZW" && names[i] != "FlateDecode" && names[i] != "Fl"
                    && names[i] != "ASCII85Decode" && names[i] != "A85" && names[i] != "ASCIIHexDecode" && names[i] != "AHx"
                    && names[i] != "RunLengthDecode" && names[i] != "RL" && names[i] != "Crypt")
                { keepFrom = i; break; }
            if (keepFrom != names.Count)
                throw new PdfException("an LZW stream is followed by a " + names[keepFrom] + " filter; cannot re-encode it");
            byte[] plain = PdfaDecode.Decode(s, _o);
            s.RawData = PdfaFontFixer.Deflate(plain);
            s.Dict.Set("Filter", new PdfName("FlateDecode"));
            s.Dict.Remove("DecodeParms");
        }

        private void FixImage(PdfStream s)
        {
            PdfDictionary d = s.Dict;
            d.Remove("Interpolate");
            d.Remove("Alternates");
            d.Remove("OPI");
            string intent = Name(d.Get("Intent"));
            if (intent != null && intent != "AbsoluteColorimetric" && intent != "RelativeColorimetric"
                && intent != "Saturation" && intent != "Perceptual") d.Remove("Intent");
            if (_part == 1)
            {
                if (d.Has("SMask"))
                {
                    PdfStream sm = R(d.Get("SMask")) as PdfStream;
                    PdfStream hard = sm == null ? null : HardMask(sm);
                    d.Remove("SMask");
                    if (hard != null)
                    {
                        d.Set("Mask", new PdfRef(_o.AddObject(hard), 0));
                        WarnOnce("turned soft image transparency into hard-edged masks (PDF/A-1 does not allow soft masks)");
                    }
                    else WarnOnce("removed image transparency (PDF/A-1 does not allow transparency)");
                }
                if (d.Has("SMaskInData"))
                {
                    d.Remove("SMaskInData");
                    WarnOnce("removed image transparency (PDF/A-1 does not allow transparency)");
                }
                PdfObject f = R(d.Get("Filter"));
                if (Name(f) == "JPXDecode" || (f is PdfArray && ((PdfArray)f).Items.Exists(x => Name(R(x)) == "JPXDecode")))
                    throw new PdfException("document contains a JPEG 2000 image, which PDF/A-1 does not allow; convert to PDF/A-2 instead");
            }
        }

        // Thresholds a soft mask at 50% into a 1-bit explicit mask, which PDF/A-1 allows.
        // Fully transparent and fully opaque areas come out exactly as before. Returns
        // null when the mask cannot be decoded here (JPEG/JPEG 2000 compressed).
        private PdfStream HardMask(PdfStream sm)
        {
            PdfObject f = R(sm.Dict.Get("Filter"));
            List<string> fl = new List<string>();
            if (f is PdfName) fl.Add(((PdfName)f).Value);
            if (f is PdfArray) foreach (PdfObject x in ((PdfArray)f).Items) { string n = Name(R(x)); if (n != null) fl.Add(n); }
            foreach (string n in fl)
                if (n == "DCTDecode" || n == "DCT" || n == "JPXDecode" || n == "JBIG2Decode" || n == "CCITTFaxDecode" || n == "CCF") return null;
            PdfNumber wn = R(sm.Dict.Get("Width")) as PdfNumber, hn = R(sm.Dict.Get("Height")) as PdfNumber;
            PdfNumber bn = R(sm.Dict.Get("BitsPerComponent")) as PdfNumber;
            if (wn == null || hn == null) return null;
            int w = wn.AsInt, h = hn.AsInt, bpc = bn == null ? 8 : bn.AsInt;
            if (w <= 0 || h <= 0 || (bpc != 1 && bpc != 2 && bpc != 4 && bpc != 8 && bpc != 16)) return null;
            byte[] a;
            try { a = PdfaDecode.Decode(sm, _o); } catch { return null; }
            bool invert = false;
            PdfArray dec = R(sm.Dict.Get("Decode")) as PdfArray;
            if (dec != null && dec.Count >= 2)
            {
                PdfNumber d0 = R(dec[0]) as PdfNumber, d1 = R(dec[1]) as PdfNumber;
                if (d0 != null && d1 != null && d0.Value > d1.Value) invert = true;
            }
            int max = (1 << Math.Min(bpc, 15)) - 1;
            if (bpc == 16) max = 65535;
            int inRow = (w * bpc + 7) / 8;
            if (a.Length < inRow * h) return null;
            int outRow = (w + 7) / 8;
            byte[] bits = new byte[outRow * h];
            for (int y = 0; y < h; y++)
                for (int x = 0; x < w; x++)
                {
                    int v;
                    int bit = x * bpc;
                    if (bpc == 8) v = a[y * inRow + x];
                    else if (bpc == 16) v = a[y * inRow + 2 * x] << 8 | a[y * inRow + 2 * x + 1];
                    else v = (a[y * inRow + bit / 8] >> (8 - bpc - bit % 8)) & max;
                    double alpha = v / (double)max;
                    if (invert) alpha = 1 - alpha;
                    if (alpha < 0.5) bits[y * outRow + x / 8] |= (byte)(0x80 >> (x % 8));
                }
            PdfDictionary md = new PdfDictionary();
            md.Set("Type", new PdfName("XObject"));
            md.Set("Subtype", new PdfName("Image"));
            md.Set("Width", new PdfNumber(w, true));
            md.Set("Height", new PdfNumber(h, true));
            md.Set("ImageMask", PdfBool.True);
            md.Set("BitsPerComponent", new PdfNumber(1, true));
            md.Set("Filter", new PdfName("FlateDecode"));
            return new PdfStream(md, PdfaFontFixer.Deflate(bits));
        }

        private void FixForm(PdfStream s)
        {
            PdfDictionary d = s.Dict;
            d.Remove("OPI");
            d.Remove("PS");
            d.Remove("Ref");
            if (Name(d.Get("Subtype2")) == "PS") d.Remove("Subtype2");
            if (_part == 1) d.Remove("Group");
        }

        private void FixResources(PdfDictionary res)
        {
            if (!_resSeen.Add(res)) return;
            _resources.Add(res);
            PdfDictionary gs = R(res.Get("ExtGState")) as PdfDictionary;
            if (gs != null)
                foreach (KeyValuePair<string, PdfObject> kv in gs.Map)
                {
                    PdfDictionary g = R(kv.Value) as PdfDictionary;
                    if (g != null) FixExtGState(g);
                }
            PdfDictionary fonts = R(res.Get("Font")) as PdfDictionary;
            if (fonts != null)
                foreach (KeyValuePair<string, PdfObject> kv in fonts.Map)
                {
                    PdfDictionary font = R(kv.Value) as PdfDictionary;
                    if (font != null && _fontSeen.Add(font)) _fonts.Add(font);
                }
        }

        private void FixExtGState(PdfDictionary g)
        {
            g.Remove("TR");
            if (g.Has("TR2") && Name(R(g.Get("TR2"))) != "Default") g.Set("TR2", new PdfName("Default"));
            g.Remove("HTP");
            g.Remove("HT");
            if (_part == 1)
            {
                if (!_alpha.ContainsKey(g))
                {
                    PdfNumber fa = R(g.Get("ca")) as PdfNumber, sa = R(g.Get("CA")) as PdfNumber;
                    _alpha[g] = new[] { fa == null ? 1.0 : fa.Value, sa == null ? 1.0 : sa.Value };
                }
                bool changed = false;
                PdfObject sm = R(g.Get("SMask"));
                if (sm != null && Name(sm) != "None") { g.Set("SMask", new PdfName("None")); changed = true; }
                foreach (string k in new[] { "CA", "ca" })
                {
                    PdfNumber n = R(g.Get(k)) as PdfNumber;
                    if (n != null && n.Value != 1.0) g.Set(k, new PdfNumber(1, true));
                }
                string bm = Name(R(g.Get("BM")));
                PdfArray bma = R(g.Get("BM")) as PdfArray;
                if ((bm != null && bm != "Normal" && bm != "Compatible") || bma != null)
                {
                    g.Set("BM", new PdfName("Normal"));
                    changed = true;
                }
                if (changed) WarnOnce("removed soft masks and blend modes (PDF/A-1 does not allow them)");
            }
        }

        // ---- catalog -----------------------------------------------------------------

        private void FixCatalog()
        {
            PdfDictionary c = _cat;
            c.Remove("AA");
            c.Remove("Requirements");
            c.Remove("NeedsRendering");
            c.Remove("Perms");
            c.Remove("Version");
            c.Remove("Metadata");
            c.Remove("OutputIntents");
            PdfObject oa = R(c.Get("OpenAction"));
            PdfDictionary oad = oa as PdfDictionary;
            if (oad != null && !ActionAllowed(oad))
            {
                c.Remove("OpenAction");
                WarnOnce("removed the document open action (" + Name(R(oad.Get("S"))) + ")");
            }

            PdfDictionary names = R(c.Get("Names")) as PdfDictionary;
            if (names != null)
            {
                if (names.Has("JavaScript")) { names.Remove("JavaScript"); WarnOnce("removed document JavaScript"); }
                names.Remove("AlternatePresentations");
                if (_part < 3 && names.Has("EmbeddedFiles"))
                {
                    names.Remove("EmbeddedFiles");
                    WarnOnce("removed attached files (PDF/A-" + _part + " does not allow them; PDF/A-3 does)");
                }
            }

            PdfDictionary form = R(c.Get("AcroForm")) as PdfDictionary;
            if (form != null)
            {
                if (form.Has("XFA")) { form.Remove("XFA"); WarnOnce("removed XFA form data"); }
                form.Remove("NeedAppearances");
            }

            if (_part == 1) c.Remove("OCProperties");
            else
            {
                PdfDictionary oc = R(c.Get("OCProperties")) as PdfDictionary;
                if (oc != null)
                {
                    PdfArray ocgs = R(oc.Get("OCGs")) as PdfArray;
                    FixOcConfig(R(oc.Get("D")) as PdfDictionary, "Default", ocgs);
                    PdfArray cfgs = R(oc.Get("Configs")) as PdfArray;
                    if (cfgs != null)
                        for (int i = 0; i < cfgs.Count; i++) FixOcConfig(R(cfgs[i]) as PdfDictionary, "Config " + (i + 1), ocgs);
                }
            }

            if (_part == 3) CollectAttachments();
        }

        // A config's /Order, when present, must list every optional content group.
        private void FixOcConfig(PdfDictionary cfg, string name, PdfArray ocgs)
        {
            if (cfg == null) return;
            cfg.Remove("AS");
            if (!(cfg.Get("Name") is PdfString)) cfg.Set("Name", new PdfString(Encoding.ASCII.GetBytes(name), false));
            PdfArray order = R(cfg.Get("Order")) as PdfArray;
            if (order == null || ocgs == null) return;
            HashSet<int> listed = new HashSet<int>();
            CollectRefs(order, listed, 0);
            for (int i = 0; i < ocgs.Count; i++)
            {
                PdfRef r = ocgs[i] as PdfRef;
                if (r != null && listed.Add(r.Number)) order.Items.Add(r);
            }
        }

        private void CollectRefs(PdfArray a, HashSet<int> into, int depth)
        {
            if (depth > 16) return;
            for (int i = 0; i < a.Count; i++)
            {
                PdfRef r = a[i] as PdfRef;
                if (r != null) into.Add(r.Number);
                PdfArray sub = R(a[i]) as PdfArray;
                if (sub != null) CollectRefs(sub, into, depth + 1);
            }
        }

        private readonly List<PdfObject> _attachments = new List<PdfObject>();

        private void CollectAttachments()
        {
            PdfDictionary names = R(_cat.Get("Names")) as PdfDictionary;
            PdfDictionary ef = names == null ? null : R(names.Get("EmbeddedFiles")) as PdfDictionary;
            if (ef == null) return;
            CollectTree(ef, 0);
            if (_attachments.Count == 0) return;
            PdfArray af = R(_cat.Get("AF")) as PdfArray ?? new PdfArray();
            foreach (PdfObject a in _attachments) if (!af.Items.Contains(a)) af.Items.Add(a);
            _cat.Set("AF", af);
        }

        private void CollectTree(PdfDictionary node, int depth)
        {
            if (node == null || depth > 32) return;
            PdfArray n = R(node.Get("Names")) as PdfArray;
            if (n != null)
                for (int i = 1; i < n.Count; i += 2)
                {
                    PdfDictionary spec = R(n[i]) as PdfDictionary;
                    if (spec == null) continue;
                    // AF must point at the very same object as the name tree, so a direct
                    // dictionary is promoted to an indirect one shared by both.
                    if (!(n[i] is PdfRef)) n.Items[i] = new PdfRef(_o.AddObject(spec), 0);
                    _attachments.Add(n.Items[i]);
                }
            PdfArray kids = R(node.Get("Kids")) as PdfArray;
            if (kids != null) for (int i = 0; i < kids.Count; i++) CollectTree(R(kids[i]) as PdfDictionary, depth + 1);
        }

        private void FixFilespec(PdfDictionary fs)
        {
            if (_part < 3) return;
            fs.Set("Type", new PdfName("Filespec"));
            PdfString f = R(fs.Get("F")) as PdfString;
            PdfString uf = R(fs.Get("UF")) as PdfString;
            if (f == null && uf != null) fs.Set("F", uf);
            if (uf == null && f != null) fs.Set("UF", f);
            if (fs.Get("F") == null) { PdfString x = new PdfString(Encoding.ASCII.GetBytes("attachment"), false); fs.Set("F", x); fs.Set("UF", x); }
            if (!fs.Has("AFRelationship")) fs.Set("AFRelationship", new PdfName("Unspecified"));
            if (!fs.Has("Desc")) fs.Set("Desc", fs.Get("UF"));
            PdfDictionary efd = R(fs.Get("EF")) as PdfDictionary;
            if (efd == null) return;
            string fname = ((PdfString)R(fs.Get("UF"))).AsText();
            foreach (KeyValuePair<string, PdfObject> kv in efd.Map)
            {
                PdfStream st = R(kv.Value) as PdfStream;
                if (st == null) continue;
                if (!(st.Dict.Get("Subtype") is PdfName)) st.Dict.Set("Subtype", new PdfName(Mime(fname)));
                PdfDictionary p = R(st.Dict.Get("Params")) as PdfDictionary;
                if (p == null) { p = new PdfDictionary(); st.Dict.Set("Params", p); }
                if (!(R(p.Get("ModDate")) is PdfString)) p.Set("ModDate", PdfDate(DateTimeOffset.Now));
            }
        }

        private static string Mime(string name)
        {
            string e = Path.GetExtension(name ?? "").ToLowerInvariant();
            switch (e)
            {
                case ".pdf": return "application/pdf";
                case ".xml": return "application/xml";
                case ".txt": return "text/plain";
                case ".csv": return "text/csv";
                case ".json": return "application/json";
                case ".png": return "image/png";
                case ".jpg": case ".jpeg": return "image/jpeg";
                case ".xlsx": return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                case ".docx": return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
                default: return "application/octet-stream";
            }
        }

        // ---- signatures --------------------------------------------------------------

        private void HandleSignatures()
        {
            PdfDictionary form = R(_cat.Get("AcroForm")) as PdfDictionary;
            PdfArray fields = form == null ? null : R(form.Get("Fields")) as PdfArray;
            if (fields == null) return;
            List<PdfDictionary> signed = new List<PdfDictionary>();
            FindSigned(fields, signed, 0);
            if (signed.Count == 0) return;
            if (!_opt.AllowSignatureRemoval)
                throw new PdfException("the document is digitally signed; converting it rewrites the file and would invalidate "
                    + "the signature. Set Options.AllowSignatureRemoval to convert anyway");
            foreach (PdfDictionary f in signed) f.Remove("V");
            form.Remove("SigFlags");
            _warn.Add("removed " + signed.Count + " digital signature(s): conversion invalidates them");
        }

        private void FindSigned(PdfArray fields, List<PdfDictionary> into, int depth)
        {
            if (depth > 32) return;
            for (int i = 0; i < fields.Count; i++)
            {
                PdfDictionary f = R(fields[i]) as PdfDictionary;
                if (f == null) continue;
                if (Name(R(f.Get("FT"))) == "Sig" && f.Has("V")) into.Add(f);
                PdfArray kids = R(f.Get("Kids")) as PdfArray;
                if (kids != null) FindSigned(kids, into, depth + 1);
            }
        }

        // ---- fonts -------------------------------------------------------------------

        private void FixFont(PdfaFontFixer fixer, PdfDictionary font)
        {
            string sub = Name(font.Get("Subtype"));
            if (sub == "Type3")
            {
                PdfDictionary res = R(font.Get("Resources")) as PdfDictionary;
                if (res != null) FixResources(res);
                return;
            }
            if (sub == "Type0")
            {
                PdfArray desc = R(font.Get("DescendantFonts")) as PdfArray;
                PdfDictionary cid = desc == null ? null : R(desc[0]) as PdfDictionary;
                PdfDictionary fd = cid == null ? null : R(cid.Get("FontDescriptor")) as PdfDictionary;
                if (!PdfaFontFixer.IsEmbedded(fd))
                    throw new PdfException("composite font " + Name(font.Get("BaseFont")) + " is not embedded; "
                        + "replacing a CID font without its original is not supported");
                if (fd != null) FixEmbeddedDescriptor(fd, true);
                if (cid != null && Name(cid.Get("Subtype")) == "CIDFontType2" && !cid.Has("CIDToGIDMap"))
                    cid.Set("CIDToGIDMap", new PdfName("Identity"));
                if (_part == 1 && cid != null) FixCidForPart1(font, cid, fd);
                return;
            }
            PdfDictionary d = R(font.Get("FontDescriptor")) as PdfDictionary;
            if (PdfaFontFixer.IsEmbedded(d))
            {
                FixEmbeddedDescriptor(d, false);
                PdfNumber fl = R(d.Get("Flags")) as PdfNumber;
                if (sub == "TrueType" && fl != null && (fl.AsInt & 4) != 0) fixer.DropSymbolicEncoding(font);
                if (_part == 1) FixEmbeddedSimpleForPart1(font, d, sub);
                return;
            }
            HashSet<int> used;
            _scan.Codes.TryGetValue(font, out used);
            fixer.EmbedSimple(font, used);
        }

        private void FixEmbeddedDescriptor(PdfDictionary fd, bool cid)
        {
            if (_part > 1)
            {
                fd.Remove("CharSet");
                fd.Remove("CIDSet");
            }
        }

        // ---- colour ------------------------------------------------------------------

        private void AddOutputIntent()
        {
            PdfDictionary pd = new PdfDictionary();
            pd.Set("N", new PdfNumber(3, true));
            pd.Set("Filter", new PdfName("FlateDecode"));
            int prof = _o.AddObject(new PdfStream(pd, PdfaFontFixer.Deflate(PdfaIcc.Srgb())));
            PdfDictionary oi = new PdfDictionary();
            oi.Set("Type", new PdfName("OutputIntent"));
            oi.Set("S", new PdfName("GTS_PDFA1"));
            oi.Set("OutputConditionIdentifier", Text("sRGB IEC61966-2.1"));
            oi.Set("RegistryName", Text("http://www.color.org"));
            oi.Set("Info", Text("sRGB IEC61966-2.1"));
            oi.Set("DestOutputProfile", new PdfRef(prof, 0));
            PdfArray arr = new PdfArray();
            arr.Items.Add(new PdfRef(_o.AddObject(oi), 0));
            _cat.Set("OutputIntents", arr);
        }

        private void AddDefaultCmyk()
        {
            PdfDictionary pd = new PdfDictionary();
            pd.Set("N", new PdfNumber(4, true));
            pd.Set("Filter", new PdfName("FlateDecode"));
            int prof = _o.AddObject(new PdfStream(pd, PdfaFontFixer.Deflate(PdfaIcc.Cmyk())));
            PdfArray cs = new PdfArray();
            cs.Items.Add(new PdfName("ICCBased"));
            cs.Items.Add(new PdfRef(prof, 0));
            int csNum = _o.AddObject(cs);
            foreach (PdfDictionary page in _pages) FixResources(_pageRes[page]);
            foreach (PdfDictionary res in _resources)
            {
                PdfDictionary c = R(res.Get("ColorSpace")) as PdfDictionary;
                if (c == null) { c = new PdfDictionary(); res.Set("ColorSpace", c); }
                c.Set("DefaultCMYK", new PdfRef(csNum, 0));
            }
            WarnOnce("CMYK colours are now tagged with a generic CMYK profile; printed colour may differ slightly");
        }

        // ---- metadata ----------------------------------------------------------------

        private static readonly string[] InfoKeys = { "Title", "Author", "Subject", "Keywords", "Creator", "Producer" };

        private PdfDictionary BuildInfo(PdfDictionary src)
        {
            PdfDictionary info = new PdfDictionary();
            if (src != null)
                foreach (string k in InfoKeys)
                {
                    PdfString s = _f.Resolve(src.Get(k)) as PdfString;
                    if (s != null && s.AsText().Trim().Length > 0) info.Set(k, Text(s.AsText()));
                }
            if (_opt.PreserveAllowedMetadata) FillFromSourceXmp(info);
            DateTimeOffset created = DateTimeOffset.Now;
            if (src != null)
            {
                PdfString cd = _f.Resolve(src.Get("CreationDate")) as PdfString;
                DateTimeOffset parsed;
                if (cd != null && TryParseDate(cd.AsText(), out parsed)) created = parsed;
            }
            info.Set("CreationDate", PdfDate(created));
            info.Set("ModDate", PdfDate(DateTimeOffset.Now));
            if (!info.Has("Producer")) info.Set("Producer", Text("Pdfx"));
            return info;
        }

        private void FillFromSourceXmp(PdfDictionary info)
        {
            PdfDictionary srcCat = _f.Resolve(_f.Trailer.Get("Root")) as PdfDictionary;
            PdfStream md = srcCat == null ? null : _f.Resolve(srcCat.Get("Metadata")) as PdfStream;
            if (md == null) return;
            string xml;
            try { xml = Encoding.UTF8.GetString(PdfFilters.Decode(md, _f)); } catch { return; }
            Fill(info, "Title", xml, "dc:title");
            Fill(info, "Author", xml, "dc:creator");
            Fill(info, "Subject", xml, "dc:description");
            Fill(info, "Keywords", xml, "pdf:Keywords");
            Fill(info, "Creator", xml, "xmp:CreatorTool");
        }

        private static void Fill(PdfDictionary info, string key, string xml, string tag)
        {
            if (info.Has(key)) return;
            Match m = Regex.Match(xml, "<" + tag + "[^>]*>(.*?)</" + tag + ">", RegexOptions.Singleline);
            if (!m.Success) return;
            string inner = m.Groups[1].Value;
            Match li = Regex.Match(inner, "<rdf:li[^>]*>(.*?)</rdf:li>", RegexOptions.Singleline);
            string v = li.Success ? li.Groups[1].Value : inner;
            v = Regex.Replace(v, "<[^>]+>", "").Trim();
            v = v.Replace("&lt;", "<").Replace("&gt;", ">").Replace("&quot;", "\"").Replace("&apos;", "'").Replace("&amp;", "&");
            if (v.Length > 0) info.Set(key, Text(v));
        }

        private void AddMetadata(PdfDictionary info)
        {
            StringBuilder x = new StringBuilder();
            x.Append("<?xpacket begin=\"\uFEFF\" id=\"W5M0MpCehiHzreSzNTczkc9d\"?>\n");
            x.Append("<x:xmpmeta xmlns:x=\"adobe:ns:meta/\">\n");
            x.Append("<rdf:RDF xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\">\n");
            x.Append("<rdf:Description rdf:about=\"\" xmlns:pdfaid=\"http://www.aiim.org/pdfa/ns/id/\">\n");
            x.Append("<pdfaid:part>").Append(_part).Append("</pdfaid:part>\n");
            x.Append("<pdfaid:conformance>").Append(_conf).Append("</pdfaid:conformance>\n");
            x.Append("</rdf:Description>\n");

            x.Append("<rdf:Description rdf:about=\"\" xmlns:dc=\"http://purl.org/dc/elements/1.1/\">\n");
            x.Append("<dc:format>application/pdf</dc:format>\n");
            string title = InfoText(info, "Title");
            if (title != null) x.Append("<dc:title><rdf:Alt><rdf:li xml:lang=\"x-default\">").Append(Esc(title)).Append("</rdf:li></rdf:Alt></dc:title>\n");
            string author = InfoText(info, "Author");
            if (author != null) x.Append("<dc:creator><rdf:Seq><rdf:li>").Append(Esc(author)).Append("</rdf:li></rdf:Seq></dc:creator>\n");
            string subject = InfoText(info, "Subject");
            if (subject != null) x.Append("<dc:description><rdf:Alt><rdf:li xml:lang=\"x-default\">").Append(Esc(subject)).Append("</rdf:li></rdf:Alt></dc:description>\n");
            x.Append("</rdf:Description>\n");

            x.Append("<rdf:Description rdf:about=\"\" xmlns:pdf=\"http://ns.adobe.com/pdf/1.3/\">\n");
            string producer = InfoText(info, "Producer");
            if (producer != null) x.Append("<pdf:Producer>").Append(Esc(producer)).Append("</pdf:Producer>\n");
            string keywords = InfoText(info, "Keywords");
            if (keywords != null) x.Append("<pdf:Keywords>").Append(Esc(keywords)).Append("</pdf:Keywords>\n");
            x.Append("</rdf:Description>\n");

            x.Append("<rdf:Description rdf:about=\"\" xmlns:xmp=\"http://ns.adobe.com/xap/1.0/\">\n");
            string creator = InfoText(info, "Creator");
            if (creator != null) x.Append("<xmp:CreatorTool>").Append(Esc(creator)).Append("</xmp:CreatorTool>\n");
            x.Append("<xmp:CreateDate>").Append(XmpDate(InfoText(info, "CreationDate"))).Append("</xmp:CreateDate>\n");
            string mod = XmpDate(InfoText(info, "ModDate"));
            x.Append("<xmp:ModifyDate>").Append(mod).Append("</xmp:ModifyDate>\n");
            x.Append("<xmp:MetadataDate>").Append(mod).Append("</xmp:MetadataDate>\n");
            x.Append("</rdf:Description>\n");

            x.Append("</rdf:RDF>\n</x:xmpmeta>\n<?xpacket end=\"w\"?>");

            PdfDictionary md = new PdfDictionary();
            md.Set("Type", new PdfName("Metadata"));
            md.Set("Subtype", new PdfName("XML"));
            int num = _o.AddObject(new PdfStream(md, Encoding.UTF8.GetBytes(x.ToString())));
            _cat.Set("Metadata", new PdfRef(num, 0));
        }

        private static string InfoText(PdfDictionary info, string key)
        {
            PdfString s = info.Get(key) as PdfString;
            return s == null ? null : s.AsText();
        }

        private static string Esc(string s)
        {
            StringBuilder sb = new StringBuilder(s.Length);
            foreach (char c in s)
            {
                if (c == '&') sb.Append("&amp;");
                else if (c == '<') sb.Append("&lt;");
                else if (c == '>') sb.Append("&gt;");
                else if (c < 0x20 && c != 9 && c != 10 && c != 13) continue;
                else sb.Append(c);
            }
            return sb.ToString();
        }

        internal static PdfString Text(string value)
        {
            bool ascii = true;
            foreach (char c in value) if (c > 126 || (c < 32 && c != 9 && c != 10 && c != 13)) { ascii = false; break; }
            if (ascii) return new PdfString(Encoding.ASCII.GetBytes(value), false);
            byte[] u = Encoding.BigEndianUnicode.GetBytes(value);
            byte[] r = new byte[u.Length + 2];
            r[0] = 0xFE; r[1] = 0xFF;
            Buffer.BlockCopy(u, 0, r, 2, u.Length);
            return new PdfString(r, false);
        }

        internal static PdfString PdfDate(DateTimeOffset t)
        {
            TimeSpan off = t.Offset;
            string sign = off < TimeSpan.Zero ? "-" : "+";
            off = off.Duration();
            string s = "D:" + t.ToString("yyyyMMddHHmmss", CultureInfo.InvariantCulture)
                + sign + off.Hours.ToString("00") + "'" + off.Minutes.ToString("00") + "'";
            return new PdfString(Encoding.ASCII.GetBytes(s), false);
        }

        private static string XmpDate(string pdfDate)
        {
            DateTimeOffset t;
            if (pdfDate == null || !TryParseDate(pdfDate, out t)) t = DateTimeOffset.Now;
            return t.ToString("yyyy-MM-dd'T'HH:mm:sszzz", CultureInfo.InvariantCulture);
        }

        internal static bool TryParseDate(string s, out DateTimeOffset result)
        {
            result = DateTimeOffset.MinValue;
            if (s == null) return false;
            s = s.Trim();
            if (s.StartsWith("D:")) s = s.Substring(2);
            if (s.Length < 4) return false;
            int[] parts = { 0, 1, 1, 0, 0, 0 };
            int[] lens = { 4, 2, 2, 2, 2, 2 };
            int p = 0;
            for (int i = 0; i < 6; i++)
            {
                if (p + lens[i] > s.Length || !IsDigits(s, p, lens[i])) break;
                parts[i] = int.Parse(s.Substring(p, lens[i]), CultureInfo.InvariantCulture);
                p += lens[i];
            }
            TimeSpan off = TimeSpan.Zero;
            if (p < s.Length && (s[p] == '+' || s[p] == '-'))
            {
                int sign = s[p] == '-' ? -1 : 1;
                p++;
                int hh = 0, mm = 0;
                if (p + 2 <= s.Length && IsDigits(s, p, 2)) { hh = int.Parse(s.Substring(p, 2), CultureInfo.InvariantCulture); p += 2; }
                if (p < s.Length && s[p] == '\'') p++;
                if (p + 2 <= s.Length && IsDigits(s, p, 2)) mm = int.Parse(s.Substring(p, 2), CultureInfo.InvariantCulture);
                off = new TimeSpan(sign * hh, sign * mm, 0);
            }
            try
            {
                if (parts[1] < 1 || parts[1] > 12) parts[1] = 1;
                if (parts[2] < 1 || parts[2] > DateTime.DaysInMonth(parts[0], parts[1])) parts[2] = 1;
                result = new DateTimeOffset(parts[0], parts[1], parts[2], Math.Min(parts[3], 23), Math.Min(parts[4], 59), Math.Min(parts[5], 59), off);
                return true;
            }
            catch { return false; }
        }

        private static bool IsDigits(string s, int p, int n)
        {
            for (int i = p; i < p + n; i++) if (s[i] < '0' || s[i] > '9') return false;
            return true;
        }

        private static byte[] FileId(byte[] source)
        {
            byte[] id = new byte[16];
            ulong h1 = 14695981039346656037UL, h2 = 1099511628211UL ^ (ulong)DateTime.UtcNow.Ticks;
            foreach (byte b in source) { h1 = (h1 ^ b) * 1099511628211UL; }
            for (int i = 0; i < 8; i++) { id[i] = (byte)(h1 >> (8 * i)); id[8 + i] = (byte)(h2 >> (8 * i)); h2 = h2 * 6364136223846793005UL + 1442695040888963407UL; }
            return id;
        }
    }
}
