using System;
using System.Collections.Generic;
using System.IO;

namespace Pdfx.Internal
{
    // TIFF as scanners and fax servers write it: baseline strips, bilevel / grey / palette /
    // RGB / CMYK, uncompressed, PackBits, LZW, Deflate, and CCITT G3/G4. CCITT strips are not
    // decoded: PDF reads that encoding itself, so each strip becomes a CCITTFaxDecode image and
    // the page stacks them. Anything else (tiles, JPEG-in-TIFF, YCbCr, BigTIFF) returns null and
    // the caller falls back to the system codec.
    internal static class PdfTiff
    {
        internal sealed class Strip
        {
            public PdfStream Image;
            public int Rows;
        }

        internal sealed class Page
        {
            public int Width, Height;
            public double Dpi;
            public PdfStream Image;             // one image for the page ...
            public List<Strip> Strips;          // ... or a stack of CCITT strips, top first
        }

        public static List<Page> Read(byte[] d)
        {
            if (d.Length < 8) return null;
            bool le = d[0] == 'I' && d[1] == 'I';
            if (!(le || (d[0] == 'M' && d[1] == 'M'))) return null;
            Reader r = new Reader(d, le);
            if (r.U16(2) != 42) return null;                     // 43 is BigTIFF: not here
            List<Page> pages = new List<Page>();
            HashSet<long> seen = new HashSet<long>();
            long ifd = r.U32(4);
            while (ifd > 0 && ifd + 2 <= d.Length && seen.Add(ifd) && pages.Count < 2000)
            {
                Dictionary<int, long[]> tags;
                Dictionary<int, double> rationals;
                long next = r.Ifd(ifd, out tags, out rationals);
                // Reduced-resolution thumbnails (NewSubfileType bit 0) are not pages.
                long[] sub;
                if (!(tags.TryGetValue(254, out sub) && (sub[0] & 1) != 0))
                {
                    Page p = Decode(r, tags, rationals);
                    if (p == null) return null;
                    pages.Add(p);
                }
                ifd = next;
            }
            return pages.Count == 0 ? null : pages;
        }

        private static long One(Dictionary<int, long[]> t, int tag, long fallback)
        {
            long[] v;
            return t.TryGetValue(tag, out v) && v.Length > 0 ? v[0] : fallback;
        }

        private static Page Decode(Reader r, Dictionary<int, long[]> t, Dictionary<int, double> rat)
        {
            int w = (int)One(t, 256, 0), h = (int)One(t, 257, 0);
            int bps = (int)One(t, 258, 1), spp = (int)One(t, 277, 1);
            int compression = (int)One(t, 259, 1), photometric = (int)One(t, 262, -1);
            int fillOrder = (int)One(t, 266, 1), planar = (int)One(t, 284, 1), predictor = (int)One(t, 317, 1);
            int orientation = (int)One(t, 274, 1);
            long[] offsets, counts;
            if (w <= 0 || h <= 0 || (long)w * h > 200000000L) return null;
            if (t.ContainsKey(322) || t.ContainsKey(324)) return null;        // tiled
            if (!t.TryGetValue(273, out offsets) || !t.TryGetValue(279, out counts) || offsets.Length != counts.Length || offsets.Length == 0) return null;
            if (planar != 1 || orientation != 1) return null;
            long[] bpsAll;
            if (t.TryGetValue(258, out bpsAll)) foreach (long b in bpsAll) if (b != bps) return null;
            if (bps != 1 && bps != 2 && bps != 4 && bps != 8 && bps != 16) return null;
            int rowsPerStrip = (int)Math.Min(One(t, 278, h), h);
            if (rowsPerStrip <= 0) rowsPerStrip = h;
            int stripCount = (h + rowsPerStrip - 1) / rowsPerStrip;
            if (stripCount != offsets.Length) return null;

            Page page = new Page();
            page.Width = w; page.Height = h;
            double xres, yres;
            long unit = One(t, 296, 2);
            if (rat.TryGetValue(282, out xres) && xres > 0 && unit != 1)
            {
                if (rat.TryGetValue(283, out yres) && yres > 0 && Math.Abs(xres - yres) / xres > 0.02) xres = 0;
                if (xres > 0) page.Dpi = unit == 3 ? xres * 2.54 : xres;
            }

            if (compression == 2 || compression == 3 || compression == 4)
            {
                if (bps != 1 || spp != 1) return null;
                long t4 = One(t, 292, 0), t6 = One(t, 293, 0);
                if (compression == 4 && (t6 & 2) != 0) return null;                 // uncompressed mode
                if (compression == 3 && (t4 & 2) != 0) return null;
                page.Strips = new List<Strip>();
                for (int s = 0; s < stripCount; s++)
                {
                    byte[] data = r.Bytes(offsets[s], counts[s]);
                    if (data == null) return null;
                    if (fillOrder == 2) ReverseBits(data);
                    int rows = s == stripCount - 1 ? h - rowsPerStrip * s : rowsPerStrip;
                    PdfDictionary x = Dict(w, rows, "DeviceGray", 1);
                    x.Set("Filter", new PdfName("CCITTFaxDecode"));
                    PdfDictionary pm = new PdfDictionary();
                    pm.Set("K", new PdfNumber(compression == 4 ? -1 : compression == 3 && (t4 & 1) != 0 ? 1 : 0, true));
                    pm.Set("Columns", new PdfNumber(w, true));
                    pm.Set("Rows", new PdfNumber(rows, true));
                    pm.Set("EndOfBlock", PdfBool.False);
                    if (compression == 2 || (compression == 3 && (t4 & 4) != 0)) pm.Set("EncodedByteAlign", PdfBool.True);
                    x.Set("DecodeParms", pm);
                    // CCITT codes white and black runs; a BlackIsZero file means them the other way round.
                    if (photometric == 1) x.Set("Decode", Inverted());
                    Strip st = new Strip();
                    st.Image = new PdfStream(x, data);
                    st.Rows = rows;
                    page.Strips.Add(st);
                }
                return page;
            }

            if (compression != 1 && compression != 5 && compression != 8 && compression != 32946 && compression != 32773) return null;
            if (photometric != 0 && photometric != 1 && photometric != 2 && photometric != 3 && photometric != 5) return null;
            int rowBytes = (int)(((long)w * bps * spp + 7) / 8);
            byte[] samples = new byte[(long)rowBytes * h];
            int at = 0;
            for (int s = 0; s < stripCount; s++)
            {
                byte[] raw = r.Bytes(offsets[s], counts[s]);
                if (raw == null) return null;
                int rows = s == stripCount - 1 ? h - rowsPerStrip * s : rowsPerStrip;
                byte[] dec;
                switch (compression)
                {
                    case 1: dec = raw; break;
                    case 5: dec = PdfFilters.LzwDecode(raw, 1); break;
                    case 32773: dec = PackBits(raw, rowBytes * rows); break;
                    default: dec = PdfFilters.FlateDecode(raw); break;
                }
                if (dec == null) return null;
                if (predictor == 2 && bps >= 8) dec = PdfFilters.ApplyPredictor(dec, 2, spp, bps, w);
                else if (predictor != 1) return null;
                int need = rowBytes * rows;
                if (dec.Length < need) return null;                                  // truncated strip
                Buffer.BlockCopy(dec, 0, samples, at, need);
                at += need;
            }
            if (fillOrder == 2 && bps < 8) ReverseBits(samples);

            PdfDictionary dict;
            byte[] outBytes;
            if (photometric == 3)
            {
                long[] map;
                if (!t.TryGetValue(320, out map) || bps > 8 || spp != 1 || map.Length < 3 * (1 << bps)) return null;
                int n = 1 << bps;
                outBytes = new byte[w * h * 3];
                for (int y = 0; y < h; y++)
                    for (int x = 0; x < w; x++)
                    {
                        int i = Sample(samples, y * rowBytes, x, bps);
                        int o = (y * w + x) * 3;
                        outBytes[o] = (byte)(map[i] >> 8); outBytes[o + 1] = (byte)(map[n + i] >> 8); outBytes[o + 2] = (byte)(map[2 * n + i] >> 8);
                    }
                dict = Dict(w, h, "DeviceRGB", 8);
            }
            else if (spp == 1 && (photometric == 0 || photometric == 1))
            {
                if (bps == 16) { outBytes = HighBytes(samples, w * h, r.Little); dict = Dict(w, h, "DeviceGray", 8); }
                else { outBytes = samples; dict = Dict(w, h, "DeviceGray", bps); }
                if (photometric == 0) dict.Set("Decode", Inverted());
            }
            else if ((photometric == 2 && spp >= 3) || (photometric == 5 && spp >= 4))
            {
                int keep = photometric == 2 ? 3 : 4;
                if (bps != 8 && bps != 16) return null;
                long[] extra;
                int alphaKind = t.TryGetValue(338, out extra) && extra.Length > 0 ? (int)extra[0] : 0;
                outBytes = Channels(samples, w * h, spp, keep, bps, r.Little, photometric == 2 && spp > keep ? alphaKind : 0);
                dict = Dict(w, h, photometric == 2 ? "DeviceRGB" : "DeviceCMYK", 8);
            }
            else return null;

            dict.Set("Filter", new PdfName("FlateDecode"));
            page.Image = new PdfStream(dict, PdfaFontFixer.Deflate(outBytes));
            return page;
        }

        private static PdfDictionary Dict(int w, int h, string cs, int bpc)
        {
            PdfDictionary x = new PdfDictionary();
            x.Set("Type", new PdfName("XObject"));
            x.Set("Subtype", new PdfName("Image"));
            x.Set("Width", new PdfNumber(w, true));
            x.Set("Height", new PdfNumber(h, true));
            x.Set("ColorSpace", new PdfName(cs));
            x.Set("BitsPerComponent", new PdfNumber(bpc, true));
            return x;
        }

        private static PdfArray Inverted()
        {
            PdfArray a = new PdfArray();
            a.Items.Add(new PdfNumber(1, true));
            a.Items.Add(new PdfNumber(0, true));
            return a;
        }

        private static int Sample(byte[] d, int rowStart, int x, int bps)
        {
            if (bps == 8) return d[rowStart + x];
            int bit = x * bps;
            return (d[rowStart + (bit >> 3)] >> (8 - bps - (bit & 7))) & ((1 << bps) - 1);
        }

        private static byte[] HighBytes(byte[] s, int n, bool little)
        {
            byte[] o = new byte[n];
            for (int i = 0; i < n; i++) o[i] = s[2 * i + (little ? 1 : 0)];
            return o;
        }

        // Keeps the first `keep` channels of each pixel as 8-bit; an alpha channel is laid on
        // white (kind 2 = plain alpha, 1 = already multiplied in).
        private static byte[] Channels(byte[] s, int pixels, int spp, int keep, int bps, bool little, int alphaKind)
        {
            byte[] o = new byte[pixels * keep];
            int step = bps / 8;
            for (int p = 0; p < pixels; p++)
            {
                int src = p * spp * step;
                int a = 255;
                if (alphaKind != 0 && spp > keep) a = s[src + keep * step + (little && step == 2 ? 1 : 0)];
                for (int c = 0; c < keep; c++)
                {
                    int v = s[src + c * step + (little && step == 2 ? 1 : 0)];
                    if (a != 255) v = alphaKind == 1 ? Math.Min(255, v + 255 - a) : (v * a + 255 * (255 - a)) / 255;
                    o[p * keep + c] = (byte)v;
                }
            }
            return o;
        }

        private static byte[] PackBits(byte[] d, int expected)
        {
            MemoryStream ms = new MemoryStream(expected);
            int i = 0;
            while (i < d.Length && ms.Length < expected)
            {
                int n = (sbyte)d[i++];
                if (n >= 0)
                {
                    int len = Math.Min(n + 1, d.Length - i);
                    ms.Write(d, i, len);
                    i += len;
                }
                else if (n != -128)
                {
                    if (i >= d.Length) break;
                    byte b = d[i++];
                    for (int k = 0; k < 1 - n; k++) ms.WriteByte(b);
                }
            }
            return ms.ToArray();
        }

        private static void ReverseBits(byte[] d)
        {
            for (int i = 0; i < d.Length; i++)
            {
                int b = d[i];
                b = ((b & 0xF0) >> 4) | ((b & 0x0F) << 4);
                b = ((b & 0xCC) >> 2) | ((b & 0x33) << 2);
                b = ((b & 0xAA) >> 1) | ((b & 0x55) << 1);
                d[i] = (byte)b;
            }
        }

        private sealed class Reader
        {
            private readonly byte[] _d;
            public readonly bool Little;
            public Reader(byte[] d, bool little) { _d = d; Little = little; }

            public int U16(long at)
            {
                if (at < 0 || at + 2 > _d.Length) return 0;
                return Little ? _d[at] | _d[at + 1] << 8 : _d[at] << 8 | _d[at + 1];
            }

            public long U32(long at)
            {
                if (at < 0 || at + 4 > _d.Length) return 0;
                uint a = _d[at], b = _d[at + 1], c = _d[at + 2], e = _d[at + 3];
                return Little ? (long)(a | b << 8 | c << 16 | e << 24) : (long)(a << 24 | b << 16 | c << 8 | e);
            }

            public byte[] Bytes(long at, long n)
            {
                if (at < 0 || n < 0 || at + n > _d.Length) return null;
                byte[] b = new byte[n];
                Buffer.BlockCopy(_d, (int)at, b, 0, (int)n);
                return b;
            }

            // One directory: integer tags as arrays, rationals as doubles. Returns the next IFD offset.
            public long Ifd(long at, out Dictionary<int, long[]> tags, out Dictionary<int, double> rationals)
            {
                tags = new Dictionary<int, long[]>();
                rationals = new Dictionary<int, double>();
                int n = U16(at);
                for (int i = 0; i < n; i++)
                {
                    long e = at + 2 + 12L * i;
                    if (e + 12 > _d.Length) break;
                    int tag = U16(e), type = U16(e + 2);
                    long count = U32(e + 4);
                    int size = type == 1 || type == 2 || type == 6 || type == 7 ? 1 : type == 3 || type == 8 ? 2 : type == 4 || type == 9 || type == 11 ? 4 : type == 5 || type == 10 || type == 12 ? 8 : 0;
                    if (size == 0 || count < 0 || count > 1000000) continue;
                    long where = count * size <= 4 ? e + 8 : U32(e + 8);
                    if (where < 0 || where + count * size > _d.Length) continue;
                    if (type == 5 || type == 10)
                    {
                        long num = U32(where), den = U32(where + 4);
                        if (den != 0) rationals[tag] = (double)num / den;
                        continue;
                    }
                    if (size == 8) continue;
                    long[] v = new long[count];
                    for (long k = 0; k < count; k++)
                        v[k] = size == 1 ? _d[where + k] : size == 2 ? U16(where + 2 * k) : U32(where + 4 * k);
                    tags[tag] = v;
                }
                return U32(at + 2 + 12L * n);
            }
        }
    }
}
