using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

namespace Pdfx.Internal
{
    // Image files -> PDF pages. JPEG is embedded as it is (DCTDecode); PNG is decoded to 8-bit
    // samples and re-compressed, with transparency as a soft mask.
    internal static class PdfImages
    {
        private const double A4W = 595.276, A4H = 841.89, Margin = 36;

        // "jpeg", "png", or null when the bytes are not an image we read. Throws for an image
        // type we recognise but do not support, so the caller gets a useful message instead
        // of "not a PDF".
        public static string Kind(byte[] b)
        {
            if (b == null || b.Length < 8) return null;
            if (b[0] == 0xFF && b[1] == 0xD8 && b[2] == 0xFF) return "jpeg";
            if (b[0] == 0x89 && b[1] == 'P' && b[2] == 'N' && b[3] == 'G') return "png";
            // TIFF (multi-page scanner output), GIF and BMP are decoded by Windows' own codecs.
            if ((b[0] == 'I' && b[1] == 'I' && b[2] == 42) || (b[0] == 'M' && b[1] == 'M' && b[3] == 42)) return "gdi";
            if (b[0] == 'G' && b[1] == 'I' && b[2] == 'F') return "gdi";
            if (b[0] == 'B' && b[1] == 'M' && b.Length > 14) return "gdi";
            string what = null;
            if (b.Length > 12 && b[0] == 'R' && b[1] == 'I' && b[2] == 'F' && b[3] == 'F' && b[8] == 'W' && b[9] == 'E' && b[10] == 'B' && b[11] == 'P') what = "WebP";
            else if (b.Length > 12 && b[4] == 'f' && b[5] == 't' && b[6] == 'y' && b[7] == 'p')
            {
                string brand = Encoding.ASCII.GetString(b, 8, 4);
                if (brand.StartsWith("hei", StringComparison.Ordinal) || brand.StartsWith("hev", StringComparison.Ordinal)
                    || brand == "mif1" || brand == "msf1") what = "HEIC";
                else if (brand.StartsWith("avi", StringComparison.Ordinal)) what = "AVIF";
            }
            if (what != null)
                throw new PdfException(what + " images are not supported; save the image as JPEG, PNG or TIFF first");
            return null;
        }

        public static bool IsImage(byte[] b) { return Kind(b) != null; }

        // A text file handed to a PDF entry point: say what to call instead. Only when there is
        // no PDF header and no object at all, so a damaged but repairable PDF still gets its chance.
        public static void RefuseText(byte[] b)
        {
            int n = Math.Min(b.Length, 1024);
            for (int i = 0; i + 4 < n; i++) if (b[i] == '%' && b[i + 1] == 'P' && b[i + 2] == 'D' && b[i + 3] == 'F') return;
            if (PdfParser.IndexOf(b, "endobj", 0) >= 0) return;
            if (Pdfx.PdfComposer.LooksBinary(b))
                throw new PdfException("not a PDF, JPEG or PNG file");
            throw new PdfException("not a PDF file: it looks like text; use PdfComposer.TextFileToPdf to turn text into a PDF");
        }

        // A PDF holding one page per image.
        public static byte[] ToPdf(IList<byte[]> images)
        {
            PdfDocument d = PdfDocument.Create();
            foreach (byte[] img in images) AddPage(d, img);
            return d.ToBytes();
        }

        // One page per picture: a JPEG or PNG gives one, a TIFF one per frame.
        public static void AddPage(PdfDocument doc, byte[] img)
        {
            string kind = Kind(img);
            if (kind == null) throw new PdfException("not a JPEG, PNG, TIFF, GIF or BMP image");
            if (kind == "gdi") { foreach (Picture p in Gdi(img)) Place(doc, p); }
            else Place(doc, kind == "jpeg" ? Jpeg(img) : Png(img));
        }

        private static void Place(PdfDocument doc, Picture p)
        {
            // Displayed size, after EXIF rotation.
            bool turned = p.Orientation >= 5;
            int dw = turned ? p.Height : p.Width, dh = turned ? p.Width : p.Height;

            double pageW, pageH, x, y, w, h;
            double inW = p.Dpi > 0 ? dw / p.Dpi : 0, inH = p.Dpi > 0 ? dh / p.Dpi : 0;
            if (p.Dpi >= 50 && p.Dpi <= 1200 && inW >= 1 && inH >= 1 && inW <= 17 && inH <= 17)
            {
                // A scan: its own paper size.
                pageW = inW * 72; pageH = inH * 72;
                x = 0; y = 0; w = pageW; h = pageH;
            }
            else
            {
                // A photo or screenshot: fitted on A4, turned to match its shape.
                bool landscape = dw > dh;
                pageW = landscape ? A4H : A4W; pageH = landscape ? A4W : A4H;
                double s = Math.Min((pageW - 2 * Margin) / dw, (pageH - 2 * Margin) / dh);
                w = dw * s; h = dh * s;
                x = (pageW - w) / 2; y = (pageH - h) / 2;
            }

            PdfPage page = doc.AddBlankPage(pageW, pageH);
            PdfDictionary xo = new PdfDictionary();
            PdfDictionary res = page.Dictionary.Get("Resources") as PdfDictionary;
            res.Set("XObject", xo);
            StringBuilder content = new StringBuilder();
            if (p.Strips == null)
            {
                xo.Set("Im1", p.Image);
                content.Append("q ").Append(Matrix(p.Orientation, x, y, w, h)).Append(" cm /Im1 Do Q\n");
            }
            else
            {
                // Each strip is drawn in its own band; rounding is absorbed by making every band
                // reach exactly the top of the one below, so no hairline shows between them.
                double top = y + h, rowH = h / p.Height;
                for (int i = 0; i < p.Strips.Count; i++)
                {
                    PdfTiff.Strip s = p.Strips[i];
                    xo.Set("Im" + (i + 1), s.Image);
                    double bandH = s.Rows * rowH, bottom = i == p.Strips.Count - 1 ? y : top - bandH;
                    content.Append("q ").Append(Matrix(1, x, bottom, w, top - bottom)).Append(" cm /Im").Append(i + 1).Append(" Do Q\n");
                    top = bottom;
                }
            }
            page.Dictionary.Set("Contents", new PdfStream(new PdfDictionary(), Encoding.ASCII.GetBytes(content.ToString())));
        }

        // Maps the image's unit square onto the w x h box at (x, y), applying EXIF orientation.
        private static string Matrix(int o, double x, double y, double w, double h)
        {
            double a, b, c, d, e, f;
            switch (o)
            {
                case 2: a = -w; b = 0; c = 0; d = h; e = x + w; f = y; break;
                case 3: a = -w; b = 0; c = 0; d = -h; e = x + w; f = y + h; break;
                case 4: a = w; b = 0; c = 0; d = -h; e = x; f = y + h; break;
                case 5: a = 0; b = -h; c = -w; d = 0; e = x + w; f = y + h; break;
                case 6: a = 0; b = -h; c = w; d = 0; e = x; f = y + h; break;
                case 7: a = 0; b = h; c = w; d = 0; e = x; f = y; break;
                case 8: a = 0; b = h; c = -w; d = 0; e = x + w; f = y; break;
                default: a = w; b = 0; c = 0; d = h; e = x; f = y; break;
            }
            return N(a) + " " + N(b) + " " + N(c) + " " + N(d) + " " + N(e) + " " + N(f);
        }

        private static string N(double v) { return PdfSerializer.Number(Math.Round(v, 4), false); }

        private sealed class Picture
        {
            public PdfStream Image;                 // the page's one image ...
            public List<PdfTiff.Strip> Strips;      // ... or CCITT strips stacked top to bottom
            public int Width, Height, Orientation = 1;
            public double Dpi;
        }

        // ---- JPEG ------------------------------------------------------------------------

        private static Picture Jpeg(byte[] d)
        {
            Picture p = new Picture();
            int comps = 0, precision = 8;
            bool adobe = false, sof = false;
            int i = 2;
            while (i + 3 < d.Length)
            {
                if (d[i] != 0xFF) { i++; continue; }
                int m = d[i + 1];
                if (m == 0xFF) { i++; continue; }
                if (m == 0xD8 || m == 0x01 || (m >= 0xD0 && m <= 0xD7)) { i += 2; continue; }
                if (m == 0xD9 || m == 0xDA) break;
                int len = d[i + 2] << 8 | d[i + 3];
                if (len < 2 || i + 2 + len > d.Length) break;
                int s = i + 4;
                if (m >= 0xC0 && m <= 0xCF && m != 0xC4 && m != 0xC8 && m != 0xCC && len >= 8)
                {
                    precision = d[s];
                    p.Height = d[s + 1] << 8 | d[s + 2];
                    p.Width = d[s + 3] << 8 | d[s + 4];
                    comps = d[s + 5];
                    sof = true;
                }
                else if (m == 0xE0 && len >= 16 && Ascii(d, s, 5) == "JFIF\0")
                {
                    int units = d[s + 7], xd = d[s + 8] << 8 | d[s + 9];
                    if (units == 1 && p.Dpi == 0) p.Dpi = xd;
                    else if (units == 2 && p.Dpi == 0) p.Dpi = xd * 2.54;
                }
                else if (m == 0xE1 && len >= 16 && Ascii(d, s, 6) == "Exif\0\0") Exif(d, s + 6, i + 2 + len, p);
                else if (m == 0xEE && len >= 12 && Ascii(d, s, 5) == "Adobe") adobe = true;
                i += 2 + len;
            }
            // A JPEG cut short still decodes to its top half; archiving half a scan without a
            // word is worse than refusing it. FF D9 cannot occur inside coded data (FF is stuffed),
            // so any end marker after the scan starts counts, even with a phone's trailer after it.
            bool ended = false;
            for (int k = i; k + 1 < d.Length; k++)
                if (d[k] == 0xFF && d[k + 1] == 0xD9) { ended = true; break; }
            if (!ended) throw new PdfException("the JPEG image is truncated or damaged (no end marker)");
            if (!sof || p.Width <= 0 || p.Height <= 0)
                throw new PdfException("the JPEG image is damaged: its size could not be read");
            if (precision != 8)
                throw new PdfException("12-bit JPEG images are not supported");
            if (comps != 1 && comps != 3 && comps != 4)
                throw new PdfException("unsupported JPEG colour layout (" + comps + " channels)");

            PdfDictionary x = ImageDict(p.Width, p.Height, comps == 1 ? "DeviceGray" : comps == 4 ? "DeviceCMYK" : "DeviceRGB");
            x.Set("Filter", new PdfName("DCTDecode"));
            // Photoshop and most scanners write CMYK JPEGs inverted, flagged by the Adobe marker.
            if (comps == 4 && adobe)
            {
                PdfArray dec = new PdfArray();
                for (int k = 0; k < 4; k++) { dec.Items.Add(new PdfNumber(1, true)); dec.Items.Add(new PdfNumber(0, true)); }
                x.Set("Decode", dec);
            }
            p.Image = new PdfStream(x, d);
            return p;
        }

        private static void Exif(byte[] d, int t, int end, Picture p)
        {
            if (t + 8 > end) return;
            bool le = d[t] == 'I';
            Func<int, int> u16 = o => o + 2 > end ? 0 : le ? d[o] | d[o + 1] << 8 : d[o] << 8 | d[o + 1];
            Func<int, long> u32 = o =>
            {
                if (o + 4 > end) return 0;
                uint a = d[o], b = d[o + 1], c = d[o + 2], e = d[o + 3];
                return le ? (long)(a | b << 8 | c << 16 | e << 24) : (long)(a << 24 | b << 16 | c << 8 | e);
            };
            long ifd = u32(t + 4);
            if (ifd <= 0 || t + ifd + 2 > end) return;
            int at = t + (int)ifd, n = u16(at);
            double xres = 0;
            int unit = 2;
            for (int k = 0; k < n && at + 2 + 12 * k + 12 <= end; k++)
            {
                int e = at + 2 + 12 * k, tag = u16(e);
                if (tag == 0x0112) { int o = u16(e + 8); if (o >= 1 && o <= 8) p.Orientation = o; }
                else if (tag == 0x0128) unit = u16(e + 8);
                else if (tag == 0x011A)
                {
                    long off = u32(e + 8);
                    if (off > 0 && t + off + 8 <= end)
                    {
                        long num = u32(t + (int)off), den = u32(t + (int)off + 4);
                        if (den > 0) xres = (double)num / den;
                    }
                }
            }
            if (p.Dpi == 0 && xres > 0) p.Dpi = unit == 3 ? xres * 2.54 : xres;
        }

        private static string Ascii(byte[] d, int at, int n)
        {
            return at + n <= d.Length ? Encoding.ASCII.GetString(d, at, n) : "";
        }

        private static PdfDictionary ImageDict(int w, int h, string cs)
        {
            PdfDictionary x = new PdfDictionary();
            x.Set("Type", new PdfName("XObject"));
            x.Set("Subtype", new PdfName("Image"));
            x.Set("Width", new PdfNumber(w, true));
            x.Set("Height", new PdfNumber(h, true));
            x.Set("ColorSpace", new PdfName(cs));
            x.Set("BitsPerComponent", new PdfNumber(8, true));
            return x;
        }

        // ---- TIFF, GIF, BMP through GDI+ ---------------------------------------------------

        // Each frame becomes a picture. Bilevel pages (fax, text scans) are stored as 1-bit
        // grey, grey pages as 8-bit grey, colour as 8-bit RGB, all Flate-compressed and
        // lossless; the scanner's resolution is kept so the page gets its paper size.
        private static List<Picture> Gdi(byte[] data)
        {
            List<Picture> list = new List<Picture>();
            bool tiff = data[0] == 'I' || data[0] == 'M';
            if (tiff)
            {
                // Our own reader first: lossless, exact resolution, and CCITT pages stay tiny.
                List<PdfTiff.Page> pages = null;
                try { pages = PdfTiff.Read(data); } catch (Exception) { pages = null; }
                if (pages != null)
                {
                    foreach (PdfTiff.Page tp in pages)
                    {
                        Picture p = new Picture();
                        p.Width = tp.Width; p.Height = tp.Height; p.Dpi = tp.Dpi;
                        p.Image = tp.Image; p.Strips = tp.Strips;
                        list.Add(p);
                    }
                    return list;
                }
            }
            try
            {
                using (MemoryStream ms = new MemoryStream(data))
                using (Image img = Image.FromStream(ms, true, false))
                {
                    // Every page of a TIFF; only the first frame of an animated GIF.
                    int frames = 1;
                    bool paged = false;
                    if (tiff)
                        foreach (Guid g in img.FrameDimensionsList)
                            if (g == FrameDimension.Page.Guid) { frames = img.GetFrameCount(FrameDimension.Page); paged = true; }
                    for (int f = 0; f < frames; f++)
                    {
                        if (paged) img.SelectActiveFrame(FrameDimension.Page, f);
                        list.Add(Frame(img));
                    }
                }
            }
            catch (PdfException) { throw; }
            catch (Exception e)
            {
                throw new PdfException("the image could not be decoded (" + e.Message + "); it may be damaged or use an unsupported variant");
            }
            if (list.Count == 0) throw new PdfException("the image has no frames");
            return list;
        }

        private static Picture Frame(Image img)
        {
            int w = img.Width, h = img.Height;
            if (w <= 0 || h <= 0) throw new PdfException("the image is empty");
            if ((long)w * h > 200000000L) throw new PdfException("the image is too large (" + w + " x " + h + " pixels)");
            byte[] rgb = new byte[w * h * 3];
            bool grey = true, bilevel = true;
            using (Bitmap b = new Bitmap(w, h, PixelFormat.Format32bppArgb))
            {
                // Transparency (GIF) is laid on white, as a viewer would show it.
                using (Graphics g = Graphics.FromImage(b))
                {
                    g.Clear(Color.White);
                    g.DrawImage(img, new Rectangle(0, 0, w, h), 0, 0, w, h, GraphicsUnit.Pixel);
                }
                BitmapData bd = b.LockBits(new Rectangle(0, 0, w, h), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
                try
                {
                    byte[] row = new byte[bd.Stride];
                    for (int y = 0; y < h; y++)
                    {
                        Marshal.Copy(new IntPtr(bd.Scan0.ToInt64() + (long)y * bd.Stride), row, 0, bd.Stride);
                        int o = y * w * 3;
                        for (int px = 0; px < w; px++)
                        {
                            byte bl = row[4 * px], gr = row[4 * px + 1], rd = row[4 * px + 2];
                            rgb[o + 3 * px] = rd; rgb[o + 3 * px + 1] = gr; rgb[o + 3 * px + 2] = bl;
                            if (grey && (rd != gr || gr != bl)) grey = false;
                            if (bilevel && !((rd == 0 && gr == 0 && bl == 0) || (rd == 255 && gr == 255 && bl == 255))) bilevel = false;
                        }
                    }
                }
                finally { b.UnlockBits(bd); }
            }
            Picture p = new Picture();
            p.Width = w; p.Height = h;
            float dpi = img.HorizontalResolution;
            // GDI+ reports 96 for images that carry no resolution; a real scanner never says 96.
            if (dpi > 0 && Math.Abs(dpi - 96) > 0.5 && Math.Abs(dpi - img.VerticalResolution) < 1) p.Dpi = dpi;
            PdfDictionary x;
            byte[] samples;
            if (bilevel)
            {
                int rowBytes = (w + 7) / 8;
                samples = new byte[rowBytes * h];
                for (int y = 0; y < h; y++)
                    for (int xx = 0; xx < w; xx++)
                        if (rgb[(y * w + xx) * 3] != 0) samples[y * rowBytes + (xx >> 3)] |= (byte)(0x80 >> (xx & 7));
                x = ImageDict(w, h, "DeviceGray");
                x.Set("BitsPerComponent", new PdfNumber(1, true));
            }
            else if (grey)
            {
                samples = new byte[w * h];
                for (int i = 0; i < samples.Length; i++) samples[i] = rgb[3 * i];
                x = ImageDict(w, h, "DeviceGray");
            }
            else
            {
                samples = rgb;
                x = ImageDict(w, h, "DeviceRGB");
            }
            x.Set("Filter", new PdfName("FlateDecode"));
            p.Image = new PdfStream(x, PdfaFontFixer.Deflate(samples));
            return p;
        }

        // ---- PNG -------------------------------------------------------------------------

        private static Picture Png(byte[] d)
        {
            Picture p = new Picture();
            int depth = 0, type = -1, interlace = 0;
            byte[] palette = null, trns = null;
            MemoryStream idat = new MemoryStream();
            int i = 8;
            bool ended = false;
            while (i + 8 <= d.Length)
            {
                long len = (long)((uint)d[i] << 24 | (uint)d[i + 1] << 16 | (uint)d[i + 2] << 8 | d[i + 3]);
                string tag = Encoding.ASCII.GetString(d, i + 4, 4);
                int s = i + 8;
                if (len < 0 || s + len > d.Length)
                {
                    if (tag == "IDAT") idat.Write(d, s, d.Length - s);
                    break;
                }
                int l = (int)len;
                if (tag == "IHDR" && l >= 13)
                {
                    p.Width = (int)((uint)d[s] << 24 | (uint)d[s + 1] << 16 | (uint)d[s + 2] << 8 | d[s + 3]);
                    p.Height = (int)((uint)d[s + 4] << 24 | (uint)d[s + 5] << 16 | (uint)d[s + 6] << 8 | d[s + 7]);
                    depth = d[s + 8]; type = d[s + 9]; interlace = d[s + 12];
                }
                else if (tag == "PLTE") { palette = new byte[l]; Buffer.BlockCopy(d, s, palette, 0, l); }
                else if (tag == "tRNS") { trns = new byte[l]; Buffer.BlockCopy(d, s, trns, 0, l); }
                else if (tag == "IDAT") idat.Write(d, s, l);
                else if (tag == "pHYs" && l >= 9 && d[s + 8] == 1)
                {
                    long ppm = (long)((uint)d[s] << 24 | (uint)d[s + 1] << 16 | (uint)d[s + 2] << 8 | d[s + 3]);
                    p.Dpi = ppm * 0.0254;
                }
                else if (tag == "IEND") { ended = true; break; }
                i = s + l + 4;
            }
            int channels = type == 0 ? 1 : type == 2 ? 3 : type == 3 ? 1 : type == 4 ? 2 : type == 6 ? 4 : 0;
            bool depthOk = type == 0 ? (depth == 1 || depth == 2 || depth == 4 || depth == 8 || depth == 16)
                         : type == 3 ? (depth == 1 || depth == 2 || depth == 4 || depth == 8)
                         : (depth == 8 || depth == 16);
            if (p.Width <= 0 || p.Height <= 0 || channels == 0 || !depthOk)
                throw new PdfException("the PNG image is damaged or uses an unknown format");
            if (type == 3 && palette == null) throw new PdfException("the PNG image is damaged: its palette is missing");
            if ((long)p.Width * p.Height > 200000000L)
                throw new PdfException("the image is too large (" + p.Width + " x " + p.Height + " pixels)");

            byte[] raw = PdfFilters.FlateDecode(idat.ToArray());
            int bitsPerPixel = channels * depth;
            // Unfiltered samples, one image at full size, still in the PNG's own layout.
            byte[] img = interlace == 1 ? Adam7(raw, p.Width, p.Height, bitsPerPixel) : Unfilter(raw, 0, p.Width, p.Height, bitsPerPixel);
            if (img == null)
                throw new PdfException("the PNG image is damaged or truncated" + (ended ? "" : " (no end marker)"));

            int rowBytes = (p.Width * bitsPerPixel + 7) / 8;
            bool rgb = type == 2 || type == 6 || type == 3;
            int outCh = rgb ? 3 : 1;
            byte[] colour = new byte[p.Width * p.Height * outCh];
            byte[] alpha = new byte[p.Width * p.Height];
            bool anyAlpha = false;
            int maxv = (1 << depth) - 1;
            for (int row = 0; row < p.Height; row++)
            {
                int rb = row * rowBytes;
                for (int col = 0; col < p.Width; col++)
                {
                    int px = row * p.Width + col;
                    int a = 255;
                    if (type == 3)
                    {
                        int idx = Sample(img, rb, col, depth);
                        int pi = 3 * idx;
                        if (pi + 2 < palette.Length)
                        {
                            colour[3 * px] = palette[pi]; colour[3 * px + 1] = palette[pi + 1]; colour[3 * px + 2] = palette[pi + 2];
                        }
                        if (trns != null && idx < trns.Length) a = trns[idx];
                    }
                    else if (depth < 8)
                    {
                        int v = Sample(img, rb, col, depth);
                        colour[px] = (byte)(v * 255 / maxv);
                        if (trns != null && trns.Length >= 2 && v == (trns[0] << 8 | trns[1])) a = 0;
                    }
                    else
                    {
                        int bps = depth / 8, at = rb + col * channels * bps;
                        int c0 = img[at];
                        if (type == 0 || type == 4)
                        {
                            colour[px] = (byte)c0;
                            if (type == 4) a = img[at + bps];
                            else if (trns != null && trns.Length >= 2 && Full(img, at, bps) == (trns[0] << 8 | trns[1])) a = 0;
                        }
                        else
                        {
                            colour[3 * px] = (byte)c0; colour[3 * px + 1] = img[at + bps]; colour[3 * px + 2] = img[at + 2 * bps];
                            if (type == 6) a = img[at + 3 * bps];
                            else if (trns != null && trns.Length >= 6
                                     && Full(img, at, bps) == (trns[0] << 8 | trns[1])
                                     && Full(img, at + bps, bps) == (trns[2] << 8 | trns[3])
                                     && Full(img, at + 2 * bps, bps) == (trns[4] << 8 | trns[5])) a = 0;
                        }
                    }
                    alpha[px] = (byte)a;
                    if (a != 255) anyAlpha = true;
                }
            }

            PdfDictionary x = ImageDict(p.Width, p.Height, rgb ? "DeviceRGB" : "DeviceGray");
            x.Set("Filter", new PdfName("FlateDecode"));
            if (anyAlpha)
            {
                PdfDictionary m = ImageDict(p.Width, p.Height, "DeviceGray");
                m.Set("Filter", new PdfName("FlateDecode"));
                x.Set("SMask", new PdfStream(m, PdfaFontFixer.Deflate(alpha)));
            }
            p.Image = new PdfStream(x, PdfaFontFixer.Deflate(colour));
            return p;
        }

        private static int Full(byte[] img, int at, int bps) { return bps == 2 ? img[at] << 8 | img[at + 1] : img[at]; }

        private static int Sample(byte[] img, int rowStart, int col, int depth)
        {
            int bit = col * depth;
            int b = img[rowStart + (bit >> 3)];
            return (b >> (8 - depth - (bit & 7))) & ((1 << depth) - 1);
        }

        // Reverses PNG row filters. Returns null when the data is too short.
        private static byte[] Unfilter(byte[] raw, int at, int w, int h, int bitsPerPixel)
        {
            int rowBytes = (w * bitsPerPixel + 7) / 8, bpp = Math.Max(1, bitsPerPixel / 8);
            if (at + (long)(rowBytes + 1) * h > raw.Length) return null;
            byte[] o = new byte[rowBytes * h];
            for (int r = 0; r < h; r++)
            {
                int f = raw[at + r * (rowBytes + 1)], src = at + r * (rowBytes + 1) + 1, dst = r * rowBytes, up = dst - rowBytes;
                for (int k = 0; k < rowBytes; k++)
                {
                    int x = raw[src + k];
                    int left = k >= bpp ? o[dst + k - bpp] : 0;
                    int above = r > 0 ? o[up + k] : 0;
                    int ul = r > 0 && k >= bpp ? o[up + k - bpp] : 0;
                    switch (f)
                    {
                        case 0: break;
                        case 1: x += left; break;
                        case 2: x += above; break;
                        case 3: x += (left + above) >> 1; break;
                        case 4:
                            int pp = left + above - ul, pa = Math.Abs(pp - left), pb = Math.Abs(pp - above), pc = Math.Abs(pp - ul);
                            x += pa <= pb && pa <= pc ? left : pb <= pc ? above : ul;
                            break;
                        default: return null;
                    }
                    o[dst + k] = (byte)x;
                }
            }
            return o;
        }

        private static readonly int[] StartX = { 0, 4, 0, 2, 0, 1, 0 }, StartY = { 0, 0, 4, 0, 2, 0, 1 };
        private static readonly int[] StepX = { 8, 8, 4, 4, 2, 2, 1 }, StepY = { 8, 8, 8, 4, 4, 2, 2 };

        private static byte[] Adam7(byte[] raw, int w, int h, int bitsPerPixel)
        {
            int rowBytes = (w * bitsPerPixel + 7) / 8;
            byte[] o = new byte[rowBytes * h];
            int at = 0;
            for (int pass = 0; pass < 7; pass++)
            {
                int pw = (w - StartX[pass] + StepX[pass] - 1) / StepX[pass];
                int ph = (h - StartY[pass] + StepY[pass] - 1) / StepY[pass];
                if (pw <= 0 || ph <= 0) continue;
                byte[] sub = Unfilter(raw, at, pw, ph, bitsPerPixel);
                if (sub == null) return null;
                int subRow = (pw * bitsPerPixel + 7) / 8;
                at += (subRow + 1) * ph;
                for (int y = 0; y < ph; y++)
                    for (int x = 0; x < pw; x++)
                        CopyPixel(sub, y * subRow, x, o, (StartY[pass] + y * StepY[pass]) * rowBytes, StartX[pass] + x * StepX[pass], bitsPerPixel);
            }
            return o;
        }

        private static void CopyPixel(byte[] src, int srcRow, int sx, byte[] dst, int dstRow, int dx, int bits)
        {
            if (bits >= 8)
            {
                int n = bits / 8;
                Buffer.BlockCopy(src, srcRow + sx * n, dst, dstRow + dx * n, n);
                return;
            }
            int v = Sample(src, srcRow, sx, bits);
            int bit = dx * bits, shift = 8 - bits - (bit & 7);
            dst[dstRow + (bit >> 3)] |= (byte)(v << shift);
        }
    }
}
