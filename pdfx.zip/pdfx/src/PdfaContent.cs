using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;

namespace Pdfx.Internal
{
    internal enum PdfaTok { Number, Name, String, ArrayStart, ArrayEnd, DictStart, DictEnd, Operator, InlineImage, Eof }

    internal struct PdfaToken
    {
        public PdfaTok Kind;
        public int Start;
        public int End;
        public string Text;
        public byte[] Bytes;
        public double Number;
    }

    // A content-stream tokenizer that keeps byte positions, so later passes can splice
    // marked-content operators around the exact bytes they came from.
    internal sealed class PdfaLexer
    {
        private readonly byte[] _d;
        private int _p;

        public PdfaLexer(byte[] data) { _d = data; }

        private static bool White(byte b) { return b == 0 || b == 9 || b == 10 || b == 12 || b == 13 || b == 32; }
        private static bool Delim(byte b) { return b == '(' || b == ')' || b == '<' || b == '>' || b == '[' || b == ']' || b == '{' || b == '}' || b == '/' || b == '%'; }

        public PdfaToken Next()
        {
            while (_p < _d.Length)
            {
                if (White(_d[_p])) { _p++; continue; }
                if (_d[_p] == '%') { while (_p < _d.Length && _d[_p] != 10 && _d[_p] != 13) _p++; continue; }
                break;
            }
            PdfaToken t = new PdfaToken();
            t.Start = _p;
            if (_p >= _d.Length) { t.Kind = PdfaTok.Eof; t.End = _p; return t; }
            byte c = _d[_p];
            if (c == '[') { _p++; t.Kind = PdfaTok.ArrayStart; }
            else if (c == ']') { _p++; t.Kind = PdfaTok.ArrayEnd; }
            else if (c == '<' && _p + 1 < _d.Length && _d[_p + 1] == '<') { _p += 2; t.Kind = PdfaTok.DictStart; }
            else if (c == '>' && _p + 1 < _d.Length && _d[_p + 1] == '>') { _p += 2; t.Kind = PdfaTok.DictEnd; }
            else if (c == '{' || c == '}' || c == '>' || c == ')') { _p++; t.Kind = PdfaTok.Operator; t.Text = ((char)c).ToString(); }
            else if (c == '/')
            {
                _p++;
                StringBuilder sb = new StringBuilder();
                while (_p < _d.Length && !White(_d[_p]) && !Delim(_d[_p]))
                {
                    if (_d[_p] == '#' && _p + 2 < _d.Length && Hex(_d[_p + 1]) >= 0 && Hex(_d[_p + 2]) >= 0)
                    {
                        sb.Append((char)(Hex(_d[_p + 1]) * 16 + Hex(_d[_p + 2])));
                        _p += 3;
                    }
                    else sb.Append((char)_d[_p++]);
                }
                t.Kind = PdfaTok.Name; t.Text = sb.ToString();
            }
            else if (c == '(') { t.Kind = PdfaTok.String; t.Bytes = Literal(); }
            else if (c == '<') { t.Kind = PdfaTok.String; t.Bytes = HexString(); }
            else
            {
                int s = _p;
                while (_p < _d.Length && !White(_d[_p]) && !Delim(_d[_p])) _p++;
                string w = Encoding.ASCII.GetString(_d, s, _p - s);
                double v;
                if (w.Length > 0 && (char.IsDigit(w[0]) || w[0] == '-' || w[0] == '+' || w[0] == '.')
                    && double.TryParse(w, NumberStyles.Float, CultureInfo.InvariantCulture, out v))
                {
                    t.Kind = PdfaTok.Number; t.Number = v; t.Text = w;
                }
                else
                {
                    t.Kind = PdfaTok.Operator; t.Text = w;
                    if (w == "BI") { SkipInlineImage(); t.Kind = PdfaTok.InlineImage; }
                }
            }
            t.End = _p;
            return t;
        }

        public string InlineImageDict;

        private void SkipInlineImage()
        {
            int dictStart = _p;
            while (_p < _d.Length)
            {
                PdfaToken k = Next();
                if (k.Kind == PdfaTok.Eof) return;
                if (k.Kind == PdfaTok.Operator && k.Text == "ID")
                {
                    InlineImageDict = Encoding.ASCII.GetString(_d, dictStart, k.Start - dictStart);
                    _p++;
                    while (_p + 1 < _d.Length)
                    {
                        if (_d[_p] == 'E' && _d[_p + 1] == 'I' && _p > 0 && White(_d[_p - 1])
                            && (_p + 2 >= _d.Length || White(_d[_p + 2]) || Delim(_d[_p + 2])))
                        {
                            _p += 2;
                            return;
                        }
                        _p++;
                    }
                    _p = _d.Length;
                    return;
                }
            }
        }

        private static int Hex(byte b)
        {
            if (b >= '0' && b <= '9') return b - '0';
            if (b >= 'a' && b <= 'f') return b - 'a' + 10;
            if (b >= 'A' && b <= 'F') return b - 'A' + 10;
            return -1;
        }

        private byte[] HexString()
        {
            _p++;
            List<byte> r = new List<byte>();
            int hi = -1;
            while (_p < _d.Length && _d[_p] != '>')
            {
                int h = Hex(_d[_p++]);
                if (h < 0) continue;
                if (hi < 0) hi = h; else { r.Add((byte)(hi * 16 + h)); hi = -1; }
            }
            if (hi >= 0) r.Add((byte)(hi * 16));
            _p++;
            return r.ToArray();
        }

        private byte[] Literal()
        {
            _p++;
            List<byte> r = new List<byte>();
            int depth = 1;
            while (_p < _d.Length)
            {
                byte b = _d[_p++];
                if (b == '\\' && _p < _d.Length)
                {
                    byte e = _d[_p++];
                    if (e == 'n') r.Add(10);
                    else if (e == 'r') r.Add(13);
                    else if (e == 't') r.Add(9);
                    else if (e == 'b') r.Add(8);
                    else if (e == 'f') r.Add(12);
                    else if (e >= '0' && e <= '7')
                    {
                        int v = e - '0';
                        for (int k = 0; k < 2 && _p < _d.Length && _d[_p] >= '0' && _d[_p] <= '7'; k++) v = v * 8 + (_d[_p++] - '0');
                        r.Add((byte)v);
                    }
                    else if (e == 13) { if (_p < _d.Length && _d[_p] == 10) _p++; }
                    else if (e == 10) { }
                    else r.Add(e);
                }
                else if (b == '(') { depth++; r.Add(b); }
                else if (b == ')') { if (--depth == 0) break; r.Add(b); }
                else r.Add(b);
            }
            return r.ToArray();
        }
    }

    // Decodes a stream of the OUTPUT document. Built only from the filter primitives
    // SPEC-01 pins down; PdfFilters.Decode wants the PdfFile the stream came from, and an
    // output stream has none.
    internal static class PdfaDecode
    {
        public static byte[] Decode(PdfStream s, PdfOutput o)
        {
            byte[] data = s.RawData;
            PdfObject f = R(o, s.Dict.Get("Filter"));
            List<string> names = new List<string>();
            if (f is PdfName) names.Add(((PdfName)f).Value);
            PdfArray fa = f as PdfArray;
            if (fa != null) for (int i = 0; i < fa.Count; i++) { PdfName n = R(o, fa[i]) as PdfName; if (n != null) names.Add(n.Value); }
            PdfObject dp = R(o, s.Dict.Get("DecodeParms"));
            for (int i = 0; i < names.Count; i++)
            {
                PdfDictionary parms = dp as PdfDictionary;
                if (dp is PdfArray) parms = R(o, ((PdfArray)dp)[i]) as PdfDictionary;
                else if (i > 0) parms = null;
                string n = names[i];
                if (n == "FlateDecode" || n == "Fl") data = PdfFilters.FlateDecode(data);
                else if (n == "LZWDecode" || n == "LZW") data = PdfFilters.LzwDecode(data, Int(o, parms, "EarlyChange", 1));
                else if (n == "ASCII85Decode" || n == "A85") data = PdfFilters.Ascii85Decode(data);
                else if (n == "ASCIIHexDecode" || n == "AHx") data = PdfFilters.AsciiHexDecode(data);
                else if (n == "RunLengthDecode" || n == "RL") data = PdfFilters.RunLengthDecode(data);
                else if (n == "Crypt") continue;
                else return data;
                int pred = Int(o, parms, "Predictor", 1);
                if (pred > 1)
                    data = PdfFilters.ApplyPredictor(data, pred, Int(o, parms, "Colors", 1),
                        Int(o, parms, "BitsPerComponent", 8), Int(o, parms, "Columns", 1));
            }
            return data;
        }

        private static int Int(PdfOutput o, PdfDictionary d, string key, int fallback)
        {
            PdfNumber n = d == null ? null : R(o, d.Get(key)) as PdfNumber;
            return n == null ? fallback : n.AsInt;
        }

        private static PdfObject R(PdfOutput o, PdfObject x)
        {
            int guard = 0;
            while (x is PdfRef && guard++ < 32) x = o.GetObject(((PdfRef)x).Number);
            return x;
        }
    }

    // Walks every content stream reachable from the pages: records which character codes
    // each font draws, and whether DeviceCMYK is used from inside a content stream.
    internal sealed class PdfaContentScanner
    {
        private readonly PdfOutput _o;
        public readonly Dictionary<PdfDictionary, HashSet<int>> Codes = new Dictionary<PdfDictionary, HashSet<int>>();
        public bool UsesCmyk;
        private readonly HashSet<PdfStream> _forms = new HashSet<PdfStream>();

        public PdfaContentScanner(PdfOutput o) { _o = o; }

        public PdfObject R(PdfObject x)
        {
            int guard = 0;
            while (x is PdfRef && guard++ < 32) x = _o.GetObject(((PdfRef)x).Number);
            return x;
        }

        public void Scan(byte[] content, PdfDictionary resources, int depth)
        {
            if (content == null || depth > 24) return;
            PdfaLexer lx = new PdfaLexer(content);
            List<PdfaToken> ops = new List<PdfaToken>();
            Stack<PdfDictionary> fontStack = new Stack<PdfDictionary>();
            PdfDictionary font = null;
            int arrayDepth = 0;
            List<byte[]> arrayStrings = new List<byte[]>();
            while (true)
            {
                PdfaToken t = lx.Next();
                if (t.Kind == PdfaTok.Eof) break;
                if (t.Kind == PdfaTok.ArrayStart) { arrayDepth++; if (arrayDepth == 1) arrayStrings.Clear(); continue; }
                if (t.Kind == PdfaTok.ArrayEnd) { arrayDepth--; if (arrayDepth == 0) ops.Add(new PdfaToken { Kind = PdfaTok.ArrayEnd }); continue; }
                if (arrayDepth > 0) { if (t.Kind == PdfaTok.String) arrayStrings.Add(t.Bytes); continue; }
                if (t.Kind == PdfaTok.InlineImage)
                {
                    string d = lx.InlineImageDict ?? "";
                    if (d.Contains("/CMYK") || d.Contains("/DeviceCMYK")) UsesCmyk = true;
                    ops.Clear();
                    continue;
                }
                if (t.Kind != PdfaTok.Operator) { ops.Add(t); continue; }

                string op = t.Text;
                if (op == "q") fontStack.Push(font);
                else if (op == "Q") { if (fontStack.Count > 0) font = fontStack.Pop(); }
                else if (op == "Tf")
                {
                    string nm = LastName(ops);
                    font = nm == null ? null : Lookup(resources, "Font", nm) as PdfDictionary;
                }
                else if (op == "Tj" || op == "'" || op == "\"")
                {
                    if (ops.Count > 0 && ops[ops.Count - 1].Kind == PdfaTok.String) Record(font, ops[ops.Count - 1].Bytes);
                }
                else if (op == "TJ")
                {
                    foreach (byte[] s in arrayStrings) Record(font, s);
                    arrayStrings.Clear();
                }
                else if (op == "k" || op == "K") UsesCmyk = true;
                else if (op == "cs" || op == "CS")
                {
                    string nm = LastName(ops);
                    if (nm == "DeviceCMYK") UsesCmyk = true;
                }
                else if (op == "Do")
                {
                    string nm = LastName(ops);
                    PdfStream x = nm == null ? null : R(LookupRaw(resources, "XObject", nm)) as PdfStream;
                    if (x != null && Name(x.Dict.Get("Subtype")) == "Form" && _forms.Add(x))
                    {
                        PdfDictionary res = R(x.Dict.Get("Resources")) as PdfDictionary ?? resources;
                        Scan(Decode(x), res, depth + 1);
                    }
                }
                ops.Clear();
            }
        }

        public byte[] Decode(PdfStream s)
        {
            try { return PdfaDecode.Decode(s, _o); }
            catch { return null; }
        }

        public void ScanFormOnce(PdfStream x, PdfDictionary fallback, int depth)
        {
            if (x == null || !_forms.Add(x)) return;
            PdfDictionary res = R(x.Dict.Get("Resources")) as PdfDictionary ?? fallback;
            Scan(Decode(x), res, depth);
        }

        private void Record(PdfDictionary font, byte[] s)
        {
            if (font == null || s == null) return;
            HashSet<int> set;
            if (!Codes.TryGetValue(font, out set)) { set = new HashSet<int>(); Codes[font] = set; }
            if (Name(font.Get("Subtype")) == "Type0")
            {
                for (int i = 0; i + 1 < s.Length; i += 2) set.Add(s[i] << 8 | s[i + 1]);
            }
            else foreach (byte b in s) set.Add(b);
        }

        private static string LastName(List<PdfaToken> ops)
        {
            for (int i = ops.Count - 1; i >= 0; i--) if (ops[i].Kind == PdfaTok.Name) return ops[i].Text;
            return null;
        }

        private PdfObject LookupRaw(PdfDictionary resources, string category, string name)
        {
            if (resources == null) return null;
            PdfDictionary cat = R(resources.Get(category)) as PdfDictionary;
            return cat == null ? null : cat.Get(name);
        }

        private PdfObject Lookup(PdfDictionary resources, string category, string name)
        {
            return R(LookupRaw(resources, category, name));
        }

        public static string Name(PdfObject o)
        {
            PdfName n = o as PdfName;
            return n == null ? null : n.Value;
        }
    }
}
