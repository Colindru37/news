using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;

namespace Pdfx.Internal
{
    // Builds logical structure for an untagged document (PDF/A level A): every text-showing
    // operator becomes marked content owned by a paragraph or heading, images become
    // figures, vector drawing becomes artifacts, links and fields are referenced as objects.
    internal sealed class PdfaTagger
    {
        private readonly PdfOutput _o;
        private readonly int _part;

        private sealed class Run
        {
            public PdfStream Target;
            public bool Artifact;
            public int Start, End;
            public double X, Y, X2, Size;
            public bool IsFigure;
            public int Mcid = -1;
            public Para Owner;
        }

        private sealed class Edit
        {
            public PdfStream Target;
            public int Start, End;
            public string Text;
        }

        private readonly List<Edit> _strips = new List<Edit>();
        private readonly Dictionary<PdfObject, int> _uses = new Dictionary<PdfObject, int>();
        private readonly Dictionary<PdfObject, int> _numbers = new Dictionary<PdfObject, int>();

        private sealed class Para
        {
            public readonly List<Run> Runs = new List<Run>();
            public double Top, Bottom, Left, Size, LastBase, Step;
            public string Type = "P";
            public int Lines = 1;
        }

        public PdfaTagger(PdfOutput o, int part) { _o = o; _part = part; }

        private PdfObject R(PdfObject x)
        {
            int guard = 0;
            while (x is PdfRef && guard++ < 32) x = _o.GetObject(((PdfRef)x).Number);
            return x;
        }

        private static string Name(PdfObject o) { PdfName n = o as PdfName; return n == null ? null : n.Value; }

        public void Tag(PdfDictionary cat, List<PdfDictionary> pages, Dictionary<PdfDictionary, PdfDictionary> pageRes, string lang)
        {
            int rootNum = _o.Reserve();
            int docNum = _o.Reserve();
            PdfArray docKids = new PdfArray();
            PdfArray nums = new PdfArray();
            int nextKey = 0;

            for (int i = 1; i <= _o.Count; i++)
            {
                PdfObject x = _o.GetObject(i);
                if ((x is PdfDictionary || x is PdfStream) && !_numbers.ContainsKey(x)) _numbers[x] = i;
            }
            foreach (PdfDictionary page in pages) CountUses(PageContent(page), pageRes[page], 0);

            foreach (PdfDictionary page in pages)
            {
                int pn;
                if (!_numbers.TryGetValue(page, out pn)) continue;
                PdfRef pageRef = new PdfRef(pn, 0);
                byte[] content = PageContent(page);
                List<Run> runs = new List<Run>();
                Dictionary<PdfStream, byte[]> forms = new Dictionary<PdfStream, byte[]>();
                PdfArray mb = R(page.Get("MediaBox")) as PdfArray;
                if (mb != null && mb.Count == 4)
                {
                    PdfNumber x0 = R(mb[0]) as PdfNumber, x1 = R(mb[2]) as PdfNumber;
                    if (x0 != null && x1 != null) _pageWidth = Math.Abs(x1.Value - x0.Value);
                }
                Interpret(content, pageRes[page], new M(1, 0, 0, 1, 0, 0), null, runs, forms, 0);
                List<Para> paras = Group(runs);

                Dictionary<PdfStream, List<PdfRef>> byMcid = new Dictionary<PdfStream, List<PdfRef>>();
                List<PdfRef> pageMcids = new List<PdfRef>();
                foreach (Para p in paras)
                {
                    int elemNum = _o.Reserve();
                    PdfArray k = new PdfArray();
                    foreach (Run r in p.Runs)
                    {
                        List<PdfRef> list = pageMcids;
                        if (r.Target != null && !byMcid.TryGetValue(r.Target, out list)) { list = new List<PdfRef>(); byMcid[r.Target] = list; }
                        r.Mcid = list.Count;
                        list.Add(new PdfRef(elemNum, 0));
                        if (r.Target == null) k.Items.Add(new PdfNumber(r.Mcid, true));
                        else
                        {
                            PdfDictionary mcr = new PdfDictionary();
                            mcr.Set("Type", new PdfName("MCR"));
                            mcr.Set("MCID", new PdfNumber(r.Mcid, true));
                            mcr.Set("Stm", new PdfRef(_numbers[r.Target], 0));
                            mcr.Set("Pg", pageRef);
                            k.Items.Add(mcr);
                        }
                    }
                    PdfDictionary e = new PdfDictionary();
                    e.Set("Type", new PdfName("StructElem"));
                    e.Set("S", new PdfName(p.Type));
                    e.Set("P", new PdfRef(docNum, 0));
                    e.Set("Pg", pageRef);
                    e.Set("K", k.Count == 1 ? k[0] : k);
                    _o.SetObject(elemNum, e);
                    docKids.Items.Add(new PdfRef(elemNum, 0));
                }

                page.Set("Contents", new PdfRef(_o.AddObject(Rewrite(content, runs, null)), 0));
                _strips.RemoveAll(e => e.Target == null);
                if (pageMcids.Count > 0)
                {
                    int key = nextKey++;
                    page.Set("StructParents", new PdfNumber(key, true));
                    PdfArray arr = new PdfArray();
                    foreach (PdfRef r in pageMcids) arr.Items.Add(r);
                    nums.Items.Add(new PdfNumber(key, true));
                    nums.Items.Add(arr);
                }
                else page.Remove("StructParents");

                foreach (KeyValuePair<PdfStream, byte[]> f in forms)
                {
                    PdfStream rewritten = Rewrite(f.Value, runs, f.Key);
                    f.Key.RawData = rewritten.RawData;
                    f.Key.Dict.Set("Filter", new PdfName("FlateDecode"));
                    f.Key.Dict.Remove("DecodeParms");
                    List<PdfRef> list;
                    if (!byMcid.TryGetValue(f.Key, out list)) { f.Key.Dict.Remove("StructParents"); continue; }
                    int key = nextKey++;
                    f.Key.Dict.Set("StructParents", new PdfNumber(key, true));
                    PdfArray arr = new PdfArray();
                    foreach (PdfRef r in list) arr.Items.Add(r);
                    nums.Items.Add(new PdfNumber(key, true));
                    nums.Items.Add(arr);
                }

                PdfArray annots = R(page.Get("Annots")) as PdfArray;
                if (annots == null) continue;
                for (int i = 0; i < annots.Count; i++)
                {
                    PdfRef aref = annots[i] as PdfRef;
                    PdfDictionary a = R(annots[i]) as PdfDictionary;
                    if (aref == null || a == null) continue;
                    string sub = Name(a.Get("Subtype"));
                    string type = sub == "Link" ? "Link" : sub == "Widget" ? "Form" : null;
                    if (type == null) continue;
                    int key = nextKey++;
                    a.Set("StructParent", new PdfNumber(key, true));
                    PdfDictionary objr = new PdfDictionary();
                    objr.Set("Type", new PdfName("OBJR"));
                    objr.Set("Obj", aref);
                    objr.Set("Pg", pageRef);
                    PdfDictionary e = new PdfDictionary();
                    e.Set("Type", new PdfName("StructElem"));
                    e.Set("S", new PdfName(type));
                    e.Set("P", new PdfRef(docNum, 0));
                    e.Set("Pg", pageRef);
                    e.Set("K", objr);
                    if (a.Has("Contents")) e.Set("Alt", a.Get("Contents"));
                    int en = _o.AddObject(e);
                    docKids.Items.Add(new PdfRef(en, 0));
                    nums.Items.Add(new PdfNumber(key, true));
                    nums.Items.Add(new PdfRef(en, 0));
                }
            }

            HashSet<PdfStream> done = new HashSet<PdfStream>();
            foreach (Edit e in _strips) if (e.Target != null) done.Add(e.Target);
            for (int i = 1; i <= _o.Count; i++)
            {
                PdfStream x = _o.GetObject(i) as PdfStream;
                if (x != null && Name(x.Dict.Get("Subtype")) == "Form" && x.Dict.Get("StructParents") == null) StripMcids(x);
            }

            PdfDictionary doc = new PdfDictionary();
            doc.Set("Type", new PdfName("StructElem"));
            doc.Set("S", new PdfName("Document"));
            doc.Set("P", new PdfRef(rootNum, 0));
            doc.Set("K", docKids);
            _o.SetObject(docNum, doc);

            PdfDictionary parentTree = new PdfDictionary();
            parentTree.Set("Nums", nums);
            PdfDictionary root = new PdfDictionary();
            root.Set("Type", new PdfName("StructTreeRoot"));
            root.Set("K", new PdfRef(docNum, 0));
            root.Set("ParentTree", new PdfRef(_o.AddObject(parentTree), 0));
            root.Set("ParentTreeNextKey", new PdfNumber(nextKey, true));
            _o.SetObject(rootNum, root);

            cat.Set("StructTreeRoot", new PdfRef(rootNum, 0));
        }

        private byte[] PageContent(PdfDictionary page)
        {
            PdfObject c = R(page.Get("Contents"));
            MemoryStream ms = new MemoryStream();
            List<PdfStream> parts = new List<PdfStream>();
            if (c is PdfStream) parts.Add((PdfStream)c);
            PdfArray arr = c as PdfArray;
            if (arr != null) for (int i = 0; i < arr.Count; i++) { PdfStream s = R(arr[i]) as PdfStream; if (s != null) parts.Add(s); }
            foreach (PdfStream s in parts)
            {
                byte[] b;
                try { b = PdfaDecode.Decode(s, _o); } catch { continue; }
                ms.Write(b, 0, b.Length);
                ms.WriteByte(10);
            }
            return ms.ToArray();
        }

        // ---- interpretation ----------------------------------------------------------

        private struct M
        {
            public double A, B, C, D, E, F;
            public M(double a, double b, double c, double d, double e, double f) { A = a; B = b; C = c; D = d; E = e; F = f; }
            public static M Mul(M m, M n)
            {
                return new M(m.A * n.A + m.B * n.C, m.A * n.B + m.B * n.D, m.C * n.A + m.D * n.C,
                             m.C * n.B + m.D * n.D, m.E * n.A + m.F * n.C + n.E, m.E * n.B + m.F * n.D + n.F);
            }
        }

        private sealed class GState
        {
            public M Ctm = new M(1, 0, 0, 1, 0, 0);
            public PdfDictionary Font;
            public double Size = 1, Tc, Tw, Tz = 1, TL, Rise;
            public GState Clone() { return (GState)MemberwiseClone(); }
        }

        private PdfObject XObject(PdfDictionary res, string name)
        {
            PdfDictionary xo = R(res == null ? null : res.Get("XObject")) as PdfDictionary;
            return xo == null || name == null ? null : R(xo.Get(name));
        }

        private byte[] Decode(PdfStream s)
        {
            try { return PdfaDecode.Decode(s, _o); } catch { return null; }
        }

        private void CountUses(byte[] content, PdfDictionary res, int depth)
        {
            if (content == null || depth > 12) return;
            PdfaLexer lx = new PdfaLexer(content);
            string last = null;
            while (true)
            {
                PdfaToken t = lx.Next();
                if (t.Kind == PdfaTok.Eof) break;
                if (t.Kind == PdfaTok.Name) { last = t.Text; continue; }
                if (t.Kind != PdfaTok.Operator) continue;
                if (t.Text == "Do")
                {
                    PdfStream x = XObject(res, last) as PdfStream;
                    if (x == null) continue;
                    int n;
                    _uses.TryGetValue(x, out n);
                    _uses[x] = n + 1;
                    if (n == 0 && Name(x.Dict.Get("Subtype")) == "Form")
                        CountUses(Decode(x), R(x.Dict.Get("Resources")) as PdfDictionary ?? res, depth + 1);
                }
                last = null;
            }
        }

        private void Interpret(byte[] content, PdfDictionary res, M baseCtm, PdfStream target,
                               List<Run> runs, Dictionary<PdfStream, byte[]> forms, int depth)
        {
            if (content == null) return;
            PdfaLexer lx = new PdfaLexer(content);
            Stack<GState> stack = new Stack<GState>();
            GState g = new GState();
            g.Ctm = baseCtm;
            M tm = new M(1, 0, 0, 1, 0, 0), tlm = tm;
            List<PdfaToken> operands = new List<PdfaToken>();
            List<PdfaToken> arrayItems = new List<PdfaToken>();
            int depthTok = 0;
            int operandStart = -1;
            int artifactDepth = 0;
            Stack<bool> mcIsArtifact = new Stack<bool>();
            int pathStart = -1;
            bool inText = false;
            int dictStart = -1;
            bool dictHasMcid = false;

            while (true)
            {
                PdfaToken t = lx.Next();
                if (t.Kind == PdfaTok.Eof) break;
                if (operandStart < 0 && t.Kind != PdfaTok.Operator) operandStart = t.Start;
                if (t.Kind == PdfaTok.ArrayStart) { depthTok++; if (depthTok == 1) arrayItems.Clear(); continue; }
                if (t.Kind == PdfaTok.ArrayEnd) { depthTok--; continue; }
                if (t.Kind == PdfaTok.DictStart) { if (depthTok == 0) { dictStart = t.Start; dictHasMcid = false; } depthTok++; continue; }
                if (t.Kind == PdfaTok.DictEnd) { depthTok--; continue; }
                if (depthTok > 0)
                {
                    if (t.Kind == PdfaTok.Name && t.Text == "MCID") dictHasMcid = true;
                    arrayItems.Add(t);
                    continue;
                }
                if (t.Kind == PdfaTok.InlineImage)
                {
                    if (artifactDepth == 0 && !inText)
                        runs.Add(Figure(operandStart >= 0 ? operandStart : t.Start, t.End, g.Ctm, target));
                    operands.Clear(); operandStart = -1; dictStart = -1;
                    continue;
                }
                if (t.Kind != PdfaTok.Operator) { operands.Add(t); continue; }

                string op = t.Text;
                int opStart = operandStart >= 0 ? operandStart : t.Start;
                switch (op)
                {
                    case "q": stack.Push(g.Clone()); break;
                    case "Q": if (stack.Count > 0) g = stack.Pop(); break;
                    case "cm":
                        if (operands.Count >= 6)
                            g.Ctm = M.Mul(new M(N(operands, 0), N(operands, 1), N(operands, 2), N(operands, 3), N(operands, 4), N(operands, 5)), g.Ctm);
                        break;
                    case "BT": inText = true; tm = tlm = new M(1, 0, 0, 1, 0, 0); break;
                    case "ET": inText = false; break;
                    case "Tf":
                        if (operands.Count >= 2)
                        {
                            PdfDictionary fonts = R(res == null ? null : res.Get("Font")) as PdfDictionary;
                            g.Font = fonts == null ? null : R(fonts.Get(operands[0].Text ?? "")) as PdfDictionary;
                            g.Size = N(operands, 1);
                        }
                        break;
                    case "Tc": g.Tc = N(operands, 0); break;
                    case "Tw": g.Tw = N(operands, 0); break;
                    case "Tz": g.Tz = N(operands, 0) / 100.0; break;
                    case "TL": g.TL = N(operands, 0); break;
                    case "Ts": g.Rise = N(operands, 0); break;
                    case "Td": tlm = M.Mul(new M(1, 0, 0, 1, N(operands, 0), N(operands, 1)), tlm); tm = tlm; break;
                    case "TD": g.TL = -N(operands, 1); tlm = M.Mul(new M(1, 0, 0, 1, N(operands, 0), N(operands, 1)), tlm); tm = tlm; break;
                    case "Tm": tlm = tm = new M(N(operands, 0), N(operands, 1), N(operands, 2), N(operands, 3), N(operands, 4), N(operands, 5)); break;
                    case "T*": tlm = M.Mul(new M(1, 0, 0, 1, 0, -g.TL), tlm); tm = tlm; break;
                    case "Tj": case "'": case "\"": case "TJ":
                        {
                            if (op == "'" || op == "\"") { tlm = M.Mul(new M(1, 0, 0, 1, 0, -g.TL), tlm); tm = tlm; }
                            if (op == "\"" && operands.Count >= 3) { g.Tw = N(operands, 0); g.Tc = N(operands, 1); }
                            M trm = M.Mul(new M(g.Size * g.Tz, 0, 0, g.Size, 0, g.Rise), M.Mul(tm, g.Ctm));
                            double x0 = trm.E, y0 = trm.F;
                            double adv = Advance(g, op == "TJ" ? arrayItems : operands, op == "TJ");
                            tm = M.Mul(new M(1, 0, 0, 1, adv, 0), tm);
                            M end = M.Mul(new M(g.Size * g.Tz, 0, 0, g.Size, 0, g.Rise), M.Mul(tm, g.Ctm));
                            if (artifactDepth == 0)
                            {
                                Run r = new Run();
                                r.Target = target;
                                r.Artifact = Blank(g.Font, op == "TJ" ? arrayItems : operands);
                                r.Start = opStart; r.End = t.End;
                                r.X = Math.Min(x0, end.E); r.X2 = Math.Max(x0, end.E); r.Y = y0;
                                r.Size = Math.Max(1, Math.Sqrt(Math.Abs(trm.A * trm.D - trm.B * trm.C)));
                                runs.Add(r);
                            }
                            break;
                        }
                    case "Do":
                        {
                            string nm = operands.Count > 0 ? operands[operands.Count - 1].Text : null;
                            PdfStream x = XObject(res, nm) as PdfStream;
                            if (artifactDepth > 0 || inText || x == null) break;
                            int uses;
                            _uses.TryGetValue(x, out uses);
                            bool form = Name(x.Dict.Get("Subtype")) == "Form";
                            if (uses > 1)
                            {
                                Run r = new Run();
                                r.Target = target; r.Start = opStart; r.End = t.End; r.Artifact = true;
                                runs.Add(r);
                            }
                            else if (form && depth < 8 && !forms.ContainsKey(x))
                            {
                                byte[] fc = Decode(x);
                                if (fc == null) break;
                                forms[x] = fc;
                                M fm = new M(1, 0, 0, 1, 0, 0);
                                PdfArray mat = R(x.Dict.Get("Matrix")) as PdfArray;
                                if (mat != null && mat.Count == 6)
                                {
                                    double[] v = new double[6];
                                    for (int i = 0; i < 6; i++) { PdfNumber n = R(mat[i]) as PdfNumber; v[i] = n == null ? 0 : n.Value; }
                                    fm = new M(v[0], v[1], v[2], v[3], v[4], v[5]);
                                }
                                Interpret(fc, R(x.Dict.Get("Resources")) as PdfDictionary ?? res, M.Mul(fm, g.Ctm), x, runs, forms, depth + 1);
                            }
                            else if (!form) runs.Add(Figure(opStart, t.End, g.Ctm, target));
                            break;
                        }
                    case "BMC": case "BDC":
                        {
                            bool art = operands.Count > 0 && operands[0].Kind == PdfaTok.Name && operands[0].Text == "Artifact";
                            mcIsArtifact.Push(art);
                            if (art) artifactDepth++;
                            if (op == "BDC" && dictStart >= 0 && dictHasMcid)
                            {
                                Edit e = new Edit();
                                e.Target = target; e.Start = dictStart; e.End = t.End; e.Text = "BMC";
                                _strips.Add(e);
                            }
                            break;
                        }
                    case "EMC":
                        if (mcIsArtifact.Count > 0 && mcIsArtifact.Pop()) artifactDepth--;
                        break;
                    case "m": case "re":
                        if (pathStart < 0 && !inText) pathStart = opStart;
                        break;
                    case "S": case "s": case "f": case "F": case "f*": case "B": case "B*": case "b": case "b*": case "n":
                        if (pathStart >= 0 && artifactDepth == 0)
                        {
                            Run r = new Run();
                            r.Target = target; r.Start = pathStart; r.End = t.End; r.Artifact = true;
                            runs.Add(r);
                        }
                        pathStart = -1;
                        break;
                    case "sh":
                        if (artifactDepth == 0 && !inText)
                        {
                            Run r = new Run();
                            r.Target = target; r.Start = opStart; r.End = t.End; r.Artifact = true;
                            runs.Add(r);
                        }
                        break;
                }
                operands.Clear();
                operandStart = -1;
                dictStart = -1;
            }
        }

        private readonly Dictionary<PdfDictionary, Dictionary<int, int>> _uni = new Dictionary<PdfDictionary, Dictionary<int, int>>();

        // True when every character the operator shows is white space, read through the
        // font's ToUnicode CMap (or the code itself for a simple font without one).
        private bool Blank(PdfDictionary font, List<PdfaToken> items)
        {
            if (font == null) return false;
            Dictionary<int, int> map;
            if (!_uni.TryGetValue(font, out map)) { map = _unicode(font); _uni[font] = map; }
            bool two = Name(font.Get("Subtype")) == "Type0";
            bool any = false;
            foreach (PdfaToken it in items)
            {
                if (it.Kind != PdfaTok.String || it.Bytes == null) continue;
                for (int i = 0; i < it.Bytes.Length; i += two ? 2 : 1)
                {
                    int code = two ? (i + 1 < it.Bytes.Length ? it.Bytes[i] << 8 | it.Bytes[i + 1] : it.Bytes[i]) : it.Bytes[i];
                    int u;
                    if (!map.TryGetValue(code, out u)) { if (two) return false; u = code; }
                    if (!(u == 32 || u == 9 || u == 10 || u == 13 || u == 0xA0 || u == 0x3000)) return false;
                    any = true;
                }
            }
            return any;
        }

        public Func<PdfDictionary, Dictionary<int, int>> _unicode = f => new Dictionary<int, int>();

        private static Run Figure(int start, int end, M ctm, PdfStream target)
        {
            Run r = new Run();
            r.Target = target;
            r.Start = start; r.End = end; r.IsFigure = true;
            double x1 = ctm.E, y1 = ctm.F, x2 = ctm.E + ctm.A + ctm.C, y2 = ctm.F + ctm.B + ctm.D;
            r.X = Math.Min(x1, x2); r.X2 = Math.Max(x1, x2); r.Y = Math.Max(y1, y2);
            r.Size = Math.Max(1, Math.Abs(y2 - y1));
            return r;
        }

        private static double N(List<PdfaToken> ops, int i)
        {
            return i < ops.Count && ops[i].Kind == PdfaTok.Number ? ops[i].Number : 0;
        }

        private double Advance(GState g, List<PdfaToken> items, bool tj)
        {
            double tx = 0;
            bool twoByte = Name(g.Font == null ? null : g.Font.Get("Subtype")) == "Type0";
            foreach (PdfaToken it in items)
            {
                if (it.Kind == PdfaTok.Number) { if (tj) tx -= it.Number / 1000.0 * g.Size * g.Tz; continue; }
                if (it.Kind != PdfaTok.String || it.Bytes == null) continue;
                byte[] s = it.Bytes;
                for (int i = 0; i < s.Length; i += twoByte ? 2 : 1)
                {
                    int code = twoByte ? (i + 1 < s.Length ? s[i] << 8 | s[i + 1] : s[i]) : s[i];
                    double w = Width(g.Font, code) / 1000.0;
                    tx += (w * g.Size + g.Tc + (!twoByte && code == 32 ? g.Tw : 0)) * g.Tz;
                }
                if (!tj) break;
            }
            return g.Tz == 0 ? 0 : tx / g.Tz;
        }

        private readonly Dictionary<PdfDictionary, Dictionary<int, double>> _widths = new Dictionary<PdfDictionary, Dictionary<int, double>>();

        private double Width(PdfDictionary font, int code)
        {
            if (font == null) return 500;
            Dictionary<int, double> w;
            if (!_widths.TryGetValue(font, out w))
            {
                w = new Dictionary<int, double>();
                if (Name(font.Get("Subtype")) == "Type0")
                {
                    PdfArray desc = R(font.Get("DescendantFonts")) as PdfArray;
                    PdfDictionary cid = desc == null ? null : R(desc[0]) as PdfDictionary;
                    PdfNumber dw = cid == null ? null : R(cid.Get("DW")) as PdfNumber;
                    w[-1] = dw == null ? 1000 : dw.Value;
                    PdfArray arr = cid == null ? null : R(cid.Get("W")) as PdfArray;
                    if (arr != null)
                        for (int i = 0; i < arr.Count;)
                        {
                            PdfNumber c0 = R(arr[i]) as PdfNumber;
                            if (c0 == null) break;
                            PdfArray list = R(i + 1 < arr.Count ? arr[i + 1] : null) as PdfArray;
                            if (list != null)
                            {
                                for (int k = 0; k < list.Count; k++) { PdfNumber v = R(list[k]) as PdfNumber; if (v != null) w[c0.AsInt + k] = v.Value; }
                                i += 2;
                            }
                            else
                            {
                                PdfNumber c1 = R(i + 1 < arr.Count ? arr[i + 1] : null) as PdfNumber;
                                PdfNumber v = R(i + 2 < arr.Count ? arr[i + 2] : null) as PdfNumber;
                                if (c1 == null || v == null) break;
                                for (int c = c0.AsInt; c <= c1.AsInt && c - c0.AsInt < 65536; c++) w[c] = v.Value;
                                i += 3;
                            }
                        }
                }
                else
                {
                    PdfNumber fc = R(font.Get("FirstChar")) as PdfNumber;
                    PdfArray ws = R(font.Get("Widths")) as PdfArray;
                    if (fc != null && ws != null)
                        for (int i = 0; i < ws.Count; i++) { PdfNumber v = R(ws[i]) as PdfNumber; if (v != null) w[fc.AsInt + i] = v.Value; }
                    PdfDictionary fd = R(font.Get("FontDescriptor")) as PdfDictionary;
                    PdfNumber mw = fd == null ? null : R(fd.Get("MissingWidth")) as PdfNumber;
                    w[-1] = mw == null ? 500 : mw.Value;
                }
                _widths[font] = w;
            }
            double v2;
            return w.TryGetValue(code, out v2) ? v2 : w[-1];
        }

        // ---- grouping ----------------------------------------------------------------

        private double _pageWidth = 612;

        private List<Para> Group(List<Run> runs)
        {
            List<Run> text = new List<Run>();
            foreach (Run r in runs) if (!r.Artifact && !r.IsFigure) text.Add(r);

            List<List<Run>> lines = new List<List<Run>>();
            List<Run> sorted = new List<Run>(text);
            sorted.Sort((a, b) => b.Y != a.Y ? b.Y.CompareTo(a.Y) : a.X.CompareTo(b.X));
            foreach (Run r in sorted)
            {
                List<Run> hit = null;
                foreach (List<Run> l in lines)
                {
                    Run f = l[0];
                    if (Math.Abs(f.Y - r.Y) <= 0.4 * Math.Max(f.Size, r.Size)) { hit = l; break; }
                }
                if (hit == null) { hit = new List<Run>(); lines.Add(hit); }
                hit.Add(r);
            }

            List<List<Run>> segs = new List<List<Run>>();
            foreach (List<Run> l in lines)
            {
                l.Sort((a, b) => a.X.CompareTo(b.X));
                List<Run> cur = new List<Run>();
                double right = double.NegativeInfinity;
                foreach (Run r in l)
                {
                    if (cur.Count > 0 && r.X - right > 3.0 * r.Size) { segs.Add(cur); cur = new List<Run>(); }
                    cur.Add(r);
                    right = Math.Max(right, r.X2);
                }
                if (cur.Count > 0) segs.Add(cur);
            }
            segs = Order(segs, 0);

            List<double> sizes = new List<double>();
            foreach (Run r in text) sizes.Add(Math.Round(r.Size, 1));
            sizes.Sort();
            double body = sizes.Count == 0 ? 10 : sizes[sizes.Count / 2];

            List<Para> paras = new List<Para>();
            foreach (List<Run> s in segs)
            {
                double size = 0;
                foreach (Run r in s) size = Math.Max(size, r.Size);
                double top = MaxY(s), left = s[0].X;
                Para last = null;
                for (int i = paras.Count - 1; i >= 0 && i >= paras.Count - 3; i--)
                {
                    Para p = paras[i];
                    bool sameSize = Math.Abs(p.Size - size) <= 0.15 * Math.Max(p.Size, size);
                    double step = p.LastBase - top;
                    // A paragraph keeps its own line spacing; a larger step is a break.
                    double limit = p.Lines >= 2 ? p.Step * 1.15 + 0.5 : 1.5 * Math.Max(p.Size, size);
                    if (sameSize && step > 0.3 * size && step <= limit && Math.Abs(p.Left - left) <= 6 * size)
                    {
                        last = p;
                        break;
                    }
                }
                if (last == null)
                {
                    last = new Para();
                    last.Top = top; last.Left = left; last.Size = size;
                    paras.Add(last);
                }
                else
                {
                    if (last.Lines == 1) last.Step = last.LastBase - top;
                    last.Lines++;
                }
                last.LastBase = top;
                last.Bottom = top - size;
                last.Left = Math.Min(last.Left, left);
                foreach (Run r in s) { last.Runs.Add(r); r.Owner = last; }
            }

            List<double> headSizes = new List<double>();
            foreach (Para p in paras)
                if (p.Size >= 1.25 * body && p.Lines <= 3 && !headSizes.Contains(Math.Round(p.Size, 1))) headSizes.Add(Math.Round(p.Size, 1));
            headSizes.Sort((a, b) => b.CompareTo(a));
            foreach (Para p in paras)
            {
                int rank = headSizes.IndexOf(Math.Round(p.Size, 1));
                if (rank >= 0 && p.Size >= 1.25 * body && p.Lines <= 3) p.Type = "H" + Math.Min(rank + 1, 6);
            }

            foreach (Run r in runs)
            {
                if (!r.IsFigure || r.Artifact) continue;
                Para f = new Para();
                f.Type = "Figure";
                f.Runs.Add(r);
                f.Top = r.Y; f.Left = r.X; f.Size = r.Size;
                r.Owner = f;
                int at = paras.Count;
                for (int i = 0; i < paras.Count; i++) if (paras[i].Top < r.Y) { at = i; break; }
                paras.Insert(at, f);
            }
            return paras;
        }

        private static double Left(List<Run> s) { double v = double.PositiveInfinity; foreach (Run r in s) v = Math.Min(v, r.X); return v; }
        private static double Right(List<Run> s) { double v = double.NegativeInfinity; foreach (Run r in s) v = Math.Max(v, r.X2); return v; }
        private static double Size(List<Run> s) { double v = 0; foreach (Run r in s) v = Math.Max(v, r.Size); return v; }

        // Recursive XY-cut. A vertical gutter splits columns only when the two sides do
        // not share baselines; aligned rows are a table or a form and read row by row.
        private List<List<Run>> Order(List<List<Run>> segs, int depth)
        {
            if (segs.Count <= 1 || depth > 60) return segs;

            List<List<Run>> byX = new List<List<Run>>(segs);
            byX.Sort((a, b) => Left(a).CompareTo(Left(b)));
            double gapX = 0; int cutX = -1;
            double reach = Right(byX[0]);
            for (int i = 1; i < byX.Count; i++)
            {
                double gap = Left(byX[i]) - reach;
                if (gap > gapX) { gapX = gap; cutX = i; }
                reach = Math.Max(reach, Right(byX[i]));
            }

            List<List<Run>> byY = new List<List<Run>>(segs);
            byY.Sort((a, b) => MaxY(b).CompareTo(MaxY(a)));
            double gapY = 0; int cutY = -1;
            double floor = MaxY(byY[0]) - Size(byY[0]);
            for (int i = 1; i < byY.Count; i++)
            {
                double g = floor - MaxY(byY[i]);
                if (g > gapY) { gapY = g; cutY = i; }
                floor = Math.Min(floor, MaxY(byY[i]) - Size(byY[i]));
            }

            double body = 0;
            foreach (List<Run> sgm in segs) body += Size(sgm);
            body /= segs.Count;

            // The wider gap wins (classic XY-cut); a vertical cut must also pass module 6's
            // columns-versus-table test.
            if (cutX > 0 && gapX > gapY && gapX >= Math.Max(0.8 * body, PdfText.GutterRatio * _pageWidth)
                && IsColumns(byX.GetRange(0, cutX), byX.GetRange(cutX, byX.Count - cutX)))
            {
                List<List<Run>> res = Order(byX.GetRange(0, cutX), depth + 1);
                res.AddRange(Order(byX.GetRange(cutX, byX.Count - cutX), depth + 1));
                return res;
            }
            if (cutY > 0)
            {
                List<List<Run>> res = Order(byY.GetRange(0, cutY), depth + 1);
                res.AddRange(Order(byY.GetRange(cutY, byY.Count - cutY), depth + 1));
                return res;
            }
            byY.Sort((a, b) =>
            {
                double ya = MaxY(a), yb = MaxY(b);
                return Math.Abs(ya - yb) > 0.4 * Math.Max(Size(a), Size(b)) ? yb.CompareTo(ya) : Left(a).CompareTo(Left(b));
            });
            return byY;
        }

        // Module 6's test, applied from both sides: it is a table when most lines of
        // either side (within the other side's height) share a baseline with the other.
        // Only the right side is sparse in a table with empty cells, which is why one side
        // is not enough here.
        private static bool IsColumns(List<List<Run>> left, List<List<Run>> right)
        {
            int el, al, er, ar;
            Aligned(left, right, out el, out al);
            Aligned(right, left, out er, out ar);
            if (left.Count < 3 || right.Count < 3) return al == 0 && ar == 0;
            bool table = (el > 0 && al > 0.7 * el) || (er > 0 && ar > 0.7 * er);
            return !table;
        }

        private static void Aligned(List<List<Run>> a, List<List<Run>> b, out int eligible, out int aligned)
        {
            double top = double.MinValue, bottom = double.MaxValue;
            foreach (List<Run> r in b) { top = Math.Max(top, MaxY(r)); bottom = Math.Min(bottom, MaxY(r)); }
            eligible = 0; aligned = 0;
            foreach (List<Run> l in a)
            {
                double tol = 0.3 * Size(l);
                if (MaxY(l) > top + tol || MaxY(l) < bottom - tol) continue;
                eligible++;
                foreach (List<Run> r in b)
                    if (Math.Abs(MaxY(l) - MaxY(r)) <= Math.Max(tol, 0.3 * Size(r))) { aligned++; break; }
            }
        }

        private static double MaxY(List<Run> s)
        {
            double y = double.NegativeInfinity;
            foreach (Run r in s) y = Math.Max(y, r.Y);
            return y;
        }

        // ---- rewriting ---------------------------------------------------------------

        // Marked content that claims an MCID no structure element owns is turned into
        // plain marked content (BMC), keeping the nesting intact.
        private void StripMcids(PdfStream x)
        {
            byte[] data = Decode(x);
            if (data == null) return;
            PdfaLexer lx = new PdfaLexer(data);
            List<int[]> spans = new List<int[]>();
            int depth = 0, dictStart = -1;
            bool mcid = false;
            while (true)
            {
                PdfaToken t = lx.Next();
                if (t.Kind == PdfaTok.Eof) break;
                if (t.Kind == PdfaTok.DictStart) { if (depth == 0) { dictStart = t.Start; mcid = false; } depth++; continue; }
                if (t.Kind == PdfaTok.DictEnd) { depth--; continue; }
                if (depth > 0) { if (t.Kind == PdfaTok.Name && t.Text == "MCID") mcid = true; continue; }
                if (t.Kind == PdfaTok.Operator)
                {
                    if (t.Text == "BDC" && dictStart >= 0 && mcid) spans.Add(new[] { dictStart, t.End });
                    dictStart = -1;
                }
            }
            if (spans.Count == 0) return;
            MemoryStream ms = new MemoryStream();
            int at = 0;
            byte[] bmc = Encoding.ASCII.GetBytes("BMC");
            foreach (int[] sp in spans) { ms.Write(data, at, sp[0] - at); ms.Write(bmc, 0, bmc.Length); at = sp[1]; }
            ms.Write(data, at, data.Length - at);
            x.RawData = PdfaFontFixer.Deflate(ms.ToArray());
            x.Dict.Set("Filter", new PdfName("FlateDecode"));
            x.Dict.Remove("DecodeParms");
        }

        private PdfStream Rewrite(byte[] content, List<Run> runs, PdfStream target)
        {
            List<Edit> edits = new List<Edit>();
            foreach (Run r in runs)
            {
                if (r.Target != target) continue;
                Edit e = new Edit();
                e.Start = r.Start; e.End = r.End;
                e.Text = r.Artifact || r.Owner == null
                    ? "/Artifact BMC\n"
                    : "/" + r.Owner.Type + " <</MCID " + r.Mcid.ToString(CultureInfo.InvariantCulture) + ">> BDC\n";
                edits.Add(e);
            }
            foreach (Edit s in _strips) if (s.Target == target) edits.Add(new Edit { Start = s.Start, End = s.End, Text = null });
            edits.Sort((a, b) => a.Start.CompareTo(b.Start));
            MemoryStream ms = new MemoryStream();
            int at = 0;
            foreach (Edit e in edits)
            {
                if (e.Start < at) continue;
                ms.Write(content, at, e.Start - at);
                if (e.Text == null)
                {
                    byte[] bmc = Encoding.ASCII.GetBytes("BMC");
                    ms.Write(bmc, 0, bmc.Length);
                }
                else
                {
                    byte[] ob = Encoding.ASCII.GetBytes(e.Text);
                    ms.Write(ob, 0, ob.Length);
                    ms.Write(content, e.Start, e.End - e.Start);
                    byte[] cb = Encoding.ASCII.GetBytes("\nEMC\n");
                    ms.Write(cb, 0, cb.Length);
                }
                at = e.End;
            }
            ms.Write(content, at, content.Length - at);
            PdfDictionary d = new PdfDictionary();
            d.Set("Filter", new PdfName("FlateDecode"));
            return new PdfStream(d, PdfaFontFixer.Deflate(ms.ToArray()));
        }
    }
}
