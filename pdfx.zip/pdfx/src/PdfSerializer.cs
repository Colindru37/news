using System;
using System.Globalization;
using System.IO;
using System.Text;

namespace Pdfx.Internal
{
    public sealed class PdfSerializer
    {
        private readonly Stream _out;
        private int _pos;

        public PdfSerializer(Stream target) { _out = target; }

        // Set per indirect object while a protected file is written; null leaves data as it is.
        internal Func<byte[], byte[]> Encrypt;

        public int Position { get { return _pos; } }

        public void Ascii(string s)
        {
            byte[] b = Encoding.ASCII.GetBytes(s);
            _out.Write(b, 0, b.Length);
            _pos += b.Length;
        }

        public void Bytes(byte[] b)
        {
            _out.Write(b, 0, b.Length);
            _pos += b.Length;
        }

        public static string Number(double value, bool isInteger)
        {
            if (isInteger || value == Math.Floor(value) && Math.Abs(value) < 1e15)
                return ((long)Math.Round(value)).ToString(CultureInfo.InvariantCulture);

            string s = value.ToString("0.######", CultureInfo.InvariantCulture);
            if (s == "-0") s = "0";
            return s;
        }

        public static string Name(string value)
        {
            StringBuilder sb = new StringBuilder("/");
            for (int i = 0; i < value.Length; i++)
            {
                char c = value[i];
                byte b = (byte)c;
                if (c > 126 || c < 33 || PdfLexer.IsDelim(b) || c == '#')
                    sb.Append('#').Append(((int)c & 0xFF).ToString("X2"));
                else
                    sb.Append(c);
            }
            return sb.ToString();
        }

        public static string LiteralString(byte[] bytes)
        {
            StringBuilder sb = new StringBuilder("(");
            for (int i = 0; i < bytes.Length; i++)
            {
                byte b = bytes[i];
                if (b == (byte)'(') sb.Append("\\(");
                else if (b == (byte)')') sb.Append("\\)");
                else if (b == (byte)'\\') sb.Append("\\\\");
                else if (b == 10) sb.Append("\\n");
                else if (b == 13) sb.Append("\\r");
                else if (b == 9) sb.Append("\\t");
                else if (b == 8) sb.Append("\\b");
                else if (b == 12) sb.Append("\\f");
                else if (b < 32 || b > 126) sb.Append('\\').Append(Convert.ToString(b, 8).PadLeft(3, '0'));
                else sb.Append((char)b);
            }
            sb.Append(')');
            return sb.ToString();
        }

        public void WriteObject(PdfObject o)
        {
            if (o == null || o is PdfNull) { Ascii("null"); return; }

            PdfBool bo = o as PdfBool;
            if (bo != null) { Ascii(bo.Value ? "true" : "false"); return; }

            PdfNumber n = o as PdfNumber;
            if (n != null) { Ascii(Number(n.Value, n.IsInteger)); return; }

            PdfName nm = o as PdfName;
            if (nm != null) { Ascii(Name(nm.Value)); return; }

            PdfString st = o as PdfString;
            if (st != null) { Ascii(LiteralString(Encrypt != null ? Encrypt(st.Bytes) : st.Bytes)); return; }

            PdfRef r = o as PdfRef;
            if (r != null) { Ascii(r.Number + " " + r.Generation + " R"); return; }

            PdfArray a = o as PdfArray;
            if (a != null)
            {
                Ascii("[");
                for (int i = 0; i < a.Count; i++)
                {
                    if (i > 0) Ascii(" ");
                    WriteObject(a[i]);
                }
                Ascii("]");
                return;
            }

            PdfStream s = o as PdfStream;
            if (s != null)
            {
                byte[] data = Encrypt != null ? Encrypt(s.RawData) : s.RawData;
                s.Dict.Set("Length", new PdfNumber(data.Length, true));
                WriteDictionary(s.Dict);
                Ascii("\nstream\n");
                Bytes(data);
                Ascii("\nendstream");
                return;
            }

            PdfDictionary d = o as PdfDictionary;
            if (d != null) { WriteDictionary(d); return; }

            Ascii("null");
        }

        private void WriteDictionary(PdfDictionary d)
        {
            Ascii("<<");
            foreach (System.Collections.Generic.KeyValuePair<string, PdfObject> kv in d.Map)
            {
                Ascii(" " + Name(kv.Key) + " ");
                WriteObject(kv.Value);
            }
            Ascii(" >>");
        }
    }
}
