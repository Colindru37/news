using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using Pdfx.Internal;

namespace Pdfx
{
    // A file embedded in the document (the PDF's paperclip panel). Data is decoded only when asked.
    public sealed class PdfAttachment
    {
        internal PdfFile Source;            // set when read from a file
        internal PdfObject SourceSpec;      // its filespec there
        internal PdfStream SourceStream;
        private byte[] _data;
        private bool _edited;
        private string _description, _mime, _relationship;
        private DateTime? _modified;

        public string FileName { get; private set; }

        // Shown next to the file in a viewer.
        public string Description { get { return _description; } set { _description = value; _edited = true; } }

        // e.g. "application/xml". Required by PDF/A-3 (filled in from the file name when empty).
        public string MimeType { get { return _mime; } set { _mime = value; _edited = true; } }

        // PDF/A-3: how the file relates to the document. Source, Data, Alternative, Supplement or
        // Unspecified (the default). An e-invoice's XML is "Data" or "Alternative".
        public string Relationship { get { return _relationship; } set { _relationship = value; _edited = true; } }

        public DateTime? Modified { get { return _modified; } set { _modified = value; _edited = true; } }

        internal PdfAttachment(string fileName) { FileName = fileName; }

        internal static PdfAttachment FromData(string fileName, byte[] data)
        {
            PdfAttachment a = new PdfAttachment(fileName);
            a._data = data;
            a._mime = PdfAttachmentIo.GuessMime(fileName);
            a._modified = DateTime.Now;
            a._edited = true;
            return a;
        }

        internal static PdfAttachment FromFile(PdfFile f, string fileName, PdfObject spec, PdfStream ef, string desc, string mime, string rel, DateTime? mod)
        {
            PdfAttachment a = new PdfAttachment(fileName);
            a.Source = f; a.SourceSpec = spec; a.SourceStream = ef;
            a._description = desc; a._mime = mime; a._relationship = rel; a._modified = mod;
            return a;
        }

        internal bool Edited { get { return _edited; } }

        public byte[] GetData()
        {
            if (_data == null)
            {
                if (SourceStream == null) return new byte[0];
                _data = PdfFilters.Decode(SourceStream, Source);
            }
            return (byte[])_data.Clone();
        }

        public int Size { get { return GetData().Length; } }

        // Writes the file into a folder under its own (made-safe) name and returns the path.
        // An existing file of the same name is replaced, like every other output.
        public string SaveToFolder(string folder)
        {
            return SaveToFolder(folder, null);
        }

        // taken: paths already written by this batch, which must not be overwritten.
        internal string SaveToFolder(string folder, HashSet<string> taken)
        {
            folder = PdfComposer.OutputFolder(folder);
            string name = PdfAttachmentIo.SafeName(FileName);
            string path = Path.Combine(folder, name);
            for (int n = 2; taken != null && taken.Contains(path); n++)
                path = Path.Combine(folder, Path.GetFileNameWithoutExtension(name) + " (" + n + ")" + Path.GetExtension(name));
            File.WriteAllBytes(path, GetData());
            if (taken != null) taken.Add(path);
            return path;
        }
    }
}

namespace Pdfx.Internal
{
    internal static class PdfAttachmentIo
    {
        public static List<PdfAttachment> Read(PdfFile f, PdfDictionary root)
        {
            List<PdfAttachment> list = new List<PdfAttachment>();
            PdfDictionary names = f.Resolve(root.Get("Names")) as PdfDictionary;
            PdfDictionary tree = names == null ? null : f.Resolve(names.Get("EmbeddedFiles")) as PdfDictionary;
            if (tree == null) return list;
            PdfOutlines.NameTree(f, tree, (key, v) =>
            {
                PdfAttachment a = FromSpec(f, v, key);
                if (a != null) list.Add(a);
            }, 0, new HashSet<int>());
            return list;
        }

        public static PdfAttachment FromSpec(PdfFile f, PdfObject specRef, string key)
        {
            PdfDictionary spec = f.Resolve(specRef) as PdfDictionary;
            if (spec == null) return null;
            PdfDictionary ef = f.Resolve(spec.Get("EF")) as PdfDictionary;
            PdfStream s = ef == null ? null : (f.Resolve(ef.Get("UF")) as PdfStream ?? f.Resolve(ef.Get("F")) as PdfStream);
            if (s == null) return null;
            string name = Text(f, spec.Get("UF")) ?? Text(f, spec.Get("F")) ?? key ?? "attachment";
            string desc = Text(f, spec.Get("Desc"));
            PdfName sub = f.Resolve(s.Dict.Get("Subtype")) as PdfName;
            PdfName rel = f.Resolve(spec.Get("AFRelationship")) as PdfName;
            PdfDictionary prm = f.Resolve(s.Dict.Get("Params")) as PdfDictionary;
            DateTime? mod = prm == null ? null : ParseDate(Text(f, prm.Get("ModDate")));
            return PdfAttachment.FromFile(f, name, specRef, s, desc, sub == null ? null : sub.Value, rel == null ? null : rel.Value, mod);
        }

        private static string Text(PdfFile f, PdfObject o)
        {
            PdfString s = f.Resolve(o) as PdfString;
            if (s == null) return null;
            string t = s.AsText().TrimEnd('\0');
            return t.Length == 0 ? null : t;
        }

        public static void Write(PdfOutput o, PdfDictionary cat, IList<PdfAttachment> list)
        {
            if (list.Count == 0) return;
            // Name-tree keys must be unique and sorted.
            SortedDictionary<string, int> byKey = new SortedDictionary<string, int>(StringComparer.Ordinal);
            foreach (PdfAttachment a in list)
            {
                string key = a.FileName;
                for (int n = 2; byKey.ContainsKey(key); n++) key = Path.GetFileNameWithoutExtension(a.FileName) + " (" + n + ")" + Path.GetExtension(a.FileName);
                byKey[key] = Spec(o, a);
            }
            PdfArray arr = new PdfArray();
            foreach (KeyValuePair<string, int> kv in byKey)
            {
                arr.Items.Add(new PdfString(PdfDocument.TextBytes(kv.Key), false));
                arr.Items.Add(new PdfRef(kv.Value, 0));
            }
            PdfDictionary tree = new PdfDictionary();
            tree.Set("Names", arr);
            PdfDictionary names = new PdfDictionary();
            names.Set("EmbeddedFiles", tree);
            cat.Set("Names", names);
        }

        private static int Spec(PdfOutput o, PdfAttachment a)
        {
            if (a.Source != null && !a.Edited)
            {
                PdfObject imported = o.Import(a.Source, a.SourceSpec);
                PdfRef r = imported as PdfRef;
                return r != null ? r.Number : o.AddObject(imported);
            }
            byte[] data = a.GetData();
            PdfDictionary sd = new PdfDictionary();
            sd.Set("Type", new PdfName("EmbeddedFile"));
            string mime = string.IsNullOrEmpty(a.MimeType) ? GuessMime(a.FileName) : a.MimeType;
            sd.Set("Subtype", new PdfName(mime));
            PdfDictionary prm = new PdfDictionary();
            prm.Set("Size", new PdfNumber(data.Length, true));
            if (a.Modified.HasValue) prm.Set("ModDate", new PdfString(Encoding.ASCII.GetBytes(PdfDate(a.Modified.Value)), false));
            sd.Set("Params", prm);
            sd.Set("Filter", new PdfName("FlateDecode"));
            int sNum = o.AddObject(new PdfStream(sd, PdfaFontFixer.Deflate(data)));

            PdfDictionary spec = new PdfDictionary();
            spec.Set("Type", new PdfName("Filespec"));
            spec.Set("F", new PdfString(Ascii(a.FileName), false));
            spec.Set("UF", new PdfString(PdfDocument.TextBytes(a.FileName), false));
            PdfDictionary ef = new PdfDictionary();
            ef.Set("F", new PdfRef(sNum, 0));
            ef.Set("UF", new PdfRef(sNum, 0));
            spec.Set("EF", ef);
            if (!string.IsNullOrEmpty(a.Description)) spec.Set("Desc", new PdfString(PdfDocument.TextBytes(a.Description), false));
            spec.Set("AFRelationship", new PdfName(Relationship(a.Relationship)));
            return o.AddObject(spec);
        }

        public static string Relationship(string r)
        {
            foreach (string ok in new[] { "Source", "Data", "Alternative", "Supplement", "EncryptedPayload", "FormData", "Schema", "Unspecified" })
                if (string.Equals(ok, r, StringComparison.OrdinalIgnoreCase)) return ok;
            return "Unspecified";
        }

        private static byte[] Ascii(string s)
        {
            byte[] b = new byte[s.Length];
            for (int i = 0; i < s.Length; i++) b[i] = s[i] >= 32 && s[i] < 127 ? (byte)s[i] : (byte)'_';
            return b;
        }

        public static string PdfDate(DateTime t)
        {
            TimeSpan off = TimeZoneInfo.Local.GetUtcOffset(t);
            return "D:" + t.ToString("yyyyMMddHHmmss", CultureInfo.InvariantCulture)
                + (off < TimeSpan.Zero ? "-" : "+") + Math.Abs(off.Hours).ToString("00") + "'" + Math.Abs(off.Minutes).ToString("00") + "'";
        }

        private static DateTime? ParseDate(string s)
        {
            if (s == null) return null;
            if (s.StartsWith("D:", StringComparison.Ordinal)) s = s.Substring(2);
            if (s.Length < 8) return null;
            DateTime t;
            string core = s.Length >= 14 ? s.Substring(0, 14) : s.Substring(0, 8);
            string fmt = core.Length == 14 ? "yyyyMMddHHmmss" : "yyyyMMdd";
            return DateTime.TryParseExact(core, fmt, CultureInfo.InvariantCulture, DateTimeStyles.None, out t) ? t : (DateTime?)null;
        }

        public static string GuessMime(string name)
        {
            switch ((Path.GetExtension(name ?? "") ?? "").ToLowerInvariant())
            {
                case ".xml": return "application/xml";
                case ".pdf": return "application/pdf";
                case ".txt": case ".log": return "text/plain";
                case ".csv": return "text/csv";
                case ".json": return "application/json";
                case ".html": case ".htm": return "text/html";
                case ".jpg": case ".jpeg": return "image/jpeg";
                case ".png": return "image/png";
                case ".tif": case ".tiff": return "image/tiff";
                case ".eml": return "message/rfc822";
                case ".msg": return "application/vnd.ms-outlook";
                case ".docx": return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
                case ".xlsx": return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                case ".zip": return "application/zip";
                default: return "application/octet-stream";
            }
        }

        // An attachment's name comes from the PDF, so it is untrusted: no folders, no "..",
        // nothing Windows refuses in a file name.
        public static string SafeName(string name)
        {
            string n = (name ?? "").Replace('\\', '/');
            int slash = n.LastIndexOf('/');
            if (slash >= 0) n = n.Substring(slash + 1);
            StringBuilder sb = new StringBuilder();
            foreach (char c in n) sb.Append(c < 32 || "<>:\"|?*".IndexOf(c) >= 0 ? '_' : c);
            n = sb.ToString().Trim().TrimEnd('.');
            string stem = n.Contains(".") ? n.Substring(0, n.IndexOf('.')) : n;
            string[] reserved = { "CON", "PRN", "AUX", "NUL", "COM1", "COM2", "COM3", "COM4", "LPT1", "LPT2", "LPT3" };
            if (Array.IndexOf(reserved, stem.ToUpperInvariant()) >= 0) n = "_" + n;
            if (n.Length == 0 || n == "." || n == "..") n = "attachment";
            if (n.Length > 120) n = n.Substring(0, 100) + Path.GetExtension(n);
            return n;
        }
    }
}
