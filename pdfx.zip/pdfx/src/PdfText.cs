using System;
using System.Collections.Generic;
using System.Text;
using Pdfx.Internal;

namespace Pdfx
{
    public sealed class PdfWord
    {
        public string Text;
        public double X;
        public double Y;
        public double Width;
        public double Height;

        public double Right { get { return X + Width; } }
    }

    public sealed class PdfLine
    {
        public readonly List<PdfWord> Words = new List<PdfWord>();
        public double Y;
        public double Height;

        public string Text
        {
            get
            {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < Words.Count; i++)
                {
                    if (i > 0) sb.Append(' ');
                    sb.Append(Words[i].Text);
                }
                return sb.ToString();
            }
        }

        public double Left { get { return Words.Count == 0 ? 0 : Words[0].X; } }
        public double Right
        {
            get
            {
                double r = 0;
                for (int i = 0; i < Words.Count; i++) if (Words[i].Right > r) r = Words[i].Right;
                return r;
            }
        }
    }

    public static class PdfText
    {
        public static double WordGapRatio = 0.25;
        public static double LineToleranceRatio = 0.45;
        public static double GutterRatio = 0.05;
        public static double SegmentGapRatio = 2.0;

        public static string Extract(PdfPage page)
        {
            List<PdfLine> lines = Lines(page);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < lines.Count; i++)
            {
                if (i > 0) sb.Append("\r\n");
                sb.Append(lines[i].Text);
            }
            return sb.ToString();
        }

        public static string ExtractRegion(PdfPage page, double x0, double y0, double x1, double y1)
        {
            if (x1 < x0) { double t = x0; x0 = x1; x1 = t; }
            if (y1 < y0) { double t = y0; y0 = y1; y1 = t; }

            List<PdfLine> lines = Lines(page);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < lines.Count; i++)
            {
                StringBuilder line = new StringBuilder();
                for (int k = 0; k < lines[i].Words.Count; k++)
                {
                    PdfWord w = lines[i].Words[k];
                    double cx = w.X + w.Width / 2;
                    double cy = w.Y + w.Height / 2;
                    if (cx < x0 || cx > x1 || cy < y0 || cy > y1) continue;
                    if (line.Length > 0) line.Append(' ');
                    line.Append(w.Text);
                }
                if (line.Length == 0) continue;
                if (sb.Length > 0) sb.Append("\r\n");
                sb.Append(line);
            }
            return sb.ToString();
        }

        public static string Describe(PdfPage page)
        {
            StringBuilder sb = new StringBuilder();
            List<PdfLine> lines = Lines(page);
            sb.Append("page ").Append(Math.Round(page.Width)).Append('x')
              .Append(Math.Round(page.Height)).Append(" rot=").Append(page.Rotation)
              .Append(" lines=").Append(lines.Count).Append(Environment.NewLine);
            for (int i = 0; i < lines.Count; i++)
            {
                PdfLine l = lines[i];
                sb.Append("x ").Append(PadLeft(Math.Round(l.Left)))
                  .Append("..").Append(PadLeft(Math.Round(l.Right)))
                  .Append("  y ").Append(PadLeft(Math.Round(l.Y)))
                  .Append("  h ").Append(PadLeft(Math.Round(l.Height)))
                  .Append("  ").Append(l.Text).Append(Environment.NewLine);
            }
            return sb.ToString();
        }

        public static List<PdfLine> FindText(PdfPage page, string needle)
        {
            List<PdfLine> hits = new List<PdfLine>();
            if (string.IsNullOrEmpty(needle)) return hits;
            List<PdfLine> lines = Lines(page);
            for (int i = 0; i < lines.Count; i++)
                if (lines[i].Text.IndexOf(needle, StringComparison.OrdinalIgnoreCase) >= 0)
                    hits.Add(lines[i]);
            return hits;
        }

        private static string PadLeft(double v)
        {
            string s = PdfSerializer.Number(v, false);
            while (s.Length < 4) s = " " + s;
            return s;
        }

        public static List<PdfWord> Words(PdfPage page)
        {
            List<PdfWord> all = new List<PdfWord>();
            List<PdfLine> lines = Lines(page);
            for (int i = 0; i < lines.Count; i++) all.AddRange(lines[i].Words);
            return all;
        }

        public static List<PdfLine> Lines(PdfPage page)
        {
            List<PdfGlyph> glyphs = PdfContentReader.Extract(page);
            if (glyphs.Count == 0) return new List<PdfLine>();

            Dictionary<int, List<PdfGlyph>> byDirection = new Dictionary<int, List<PdfGlyph>>();
            for (int i = 0; i < glyphs.Count; i++)
            {
                List<PdfGlyph> bucket;
                if (!byDirection.TryGetValue(glyphs[i].Rotation, out bucket))
                {
                    bucket = new List<PdfGlyph>();
                    byDirection[glyphs[i].Rotation] = bucket;
                }
                bucket.Add(glyphs[i]);
            }

            List<int> directions = new List<int>(byDirection.Keys);
            directions.Sort(delegate (int a, int b)
            {
                int c = byDirection[b].Count.CompareTo(byDirection[a].Count);
                return c != 0 ? c : a.CompareTo(b);
            });

            List<PdfLine> all = new List<PdfLine>();
            for (int d = 0; d < directions.Count; d++)
            {
                List<PdfGlyph> bucket = byDirection[directions[d]];
                Flatten(directions[d], bucket);

                List<PdfLine> lines = BuildLines(bucket);
                if (lines.Count == 0) continue;
                Order(lines, SpanOf(lines), all, 0);
            }
            return all;
        }

        private static void Flatten(int rotation, List<PdfGlyph> glyphs)
        {
            if (rotation == 0) return;
            for (int i = 0; i < glyphs.Count; i++)
            {
                PdfGlyph g = glyphs[i];
                double x = g.X, y = g.Y;
                if (rotation == 90) { g.X = y; g.Y = -x; }
                else if (rotation == 180) { g.X = -x; g.Y = -y; }
                else { g.X = -y; g.Y = x; }
                glyphs[i] = g;
            }
        }

        private static double SpanOf(List<PdfLine> lines)
        {
            double lo = double.MaxValue, hi = double.MinValue;
            for (int i = 0; i < lines.Count; i++)
            {
                if (lines[i].Left < lo) lo = lines[i].Left;
                if (lines[i].Right > hi) hi = lines[i].Right;
            }
            return hi > lo ? hi - lo : 1;
        }

        private static double PageWidth(PdfPage page)
        {
            int r = page.Rotation;
            return (r == 90 || r == 270) ? page.Height : page.Width;
        }

        private static void Orient(PdfPage page, List<PdfGlyph> glyphs)
        {
            int r = page.Rotation;
            if (r == 0) return;

            double w = page.Width, h = page.Height;
            for (int i = 0; i < glyphs.Count; i++)
            {
                PdfGlyph g = glyphs[i];
                double x = g.X, y = g.Y;
                if (r == 90) { g.X = y; g.Y = w - x; }
                else if (r == 180) { g.X = w - x - g.Width; g.Y = h - y; }
                else { g.X = h - y; g.Y = x; }
                glyphs[i] = g;
            }
        }

        private static List<PdfLine> BuildLines(List<PdfGlyph> glyphs)
        {
            List<PdfGlyph> sorted = new List<PdfGlyph>(glyphs);
            sorted.Sort(delegate (PdfGlyph a, PdfGlyph b)
            {
                int c = b.Y.CompareTo(a.Y);
                if (c != 0) return c;
                return a.X.CompareTo(b.X);
            });

            List<List<PdfGlyph>> rows = new List<List<PdfGlyph>>();
            List<PdfGlyph> current = null;
            double currentY = 0, currentSize = 0;

            for (int i = 0; i < sorted.Count; i++)
            {
                PdfGlyph g = sorted[i];
                double size = g.FontSize > 0 ? g.FontSize : 10;
                double tol = LineToleranceRatio * Math.Max(size, currentSize > 0 ? currentSize : size);

                if (current == null || Math.Abs(g.Y - currentY) > tol)
                {
                    current = new List<PdfGlyph>();
                    rows.Add(current);
                    currentY = g.Y;
                    currentSize = size;
                }
                current.Add(g);
                if (size > currentSize) currentSize = size;
            }

            List<PdfLine> lines = new List<PdfLine>();
            for (int i = 0; i < rows.Count; i++)
            {
                List<PdfGlyph> row = rows[i];
                row.Sort(delegate (PdfGlyph a, PdfGlyph b) { return a.X.CompareTo(b.X); });

                PdfLine line = new PdfLine();
                StringBuilder word = new StringBuilder();
                double wordX = 0, wordSize = 0, prevRight = 0;
                bool started = false;

                for (int k = 0; k < row.Count; k++)
                {
                    PdfGlyph g = row[k];
                    double size = g.FontSize > 0 ? g.FontSize : 10;
                    bool isSpace = g.Text == " ";

                    if (!started)
                    {
                        if (isSpace) continue;
                        started = true;
                        wordX = g.X;
                        wordSize = size;
                        word.Append(g.Text);
                        prevRight = g.X + g.Width;
                        continue;
                    }

                    double gap = g.X - prevRight;
                    bool split = isSpace || gap > WordGapRatio * Math.Max(size, wordSize);

                    if (split)
                    {
                        if (word.Length > 0) Emit(line, word, wordX, prevRight, g.Y, wordSize);
                        word.Length = 0;
                        if (isSpace) { prevRight = g.X + g.Width; continue; }
                        wordX = g.X;
                        wordSize = size;
                    }

                    if (word.Length == 0) { wordX = g.X; wordSize = size; }
                    word.Append(g.Text);
                    if (size > wordSize) wordSize = size;
                    prevRight = g.X + g.Width;
                }

                if (word.Length > 0) Emit(line, word, wordX, prevRight, row[row.Count - 1].Y, wordSize);
                if (line.Words.Count == 0) continue;

                double height = 0;
                for (int k = 0; k < row.Count; k++)
                    if (row[k].FontSize > height) height = row[k].FontSize;
                if (height <= 0) height = 10;

                PdfLine segment = new PdfLine();
                segment.Y = row[0].Y;
                segment.Height = height;
                for (int k = 0; k < line.Words.Count; k++)
                {
                    if (segment.Words.Count > 0)
                    {
                        double gap = line.Words[k].X - segment.Right;
                        if (gap > SegmentGapRatio * height)
                        {
                            lines.Add(segment);
                            segment = new PdfLine();
                            segment.Y = row[0].Y;
                            segment.Height = height;
                        }
                    }
                    segment.Words.Add(line.Words[k]);
                }
                if (segment.Words.Count > 0) lines.Add(segment);
            }

            return lines;
        }

        private static void Emit(PdfLine line, StringBuilder word, double x, double right,
                                 double y, double size)
        {
            PdfWord w = new PdfWord();
            w.Text = word.ToString();
            w.X = x;
            w.Y = y;
            w.Width = Math.Max(0, right - x);
            w.Height = size;
            line.Words.Add(w);
        }

        private static void Order(List<PdfLine> lines, double pageWidth, List<PdfLine> into, int depth)
        {
            if (lines.Count == 0) return;

            if (lines.Count == 1 || depth >= 8)
            {
                into.AddRange(MergeRows(lines));
                return;
            }

            double cut;
            if (lines.Count >= 3 && FindGutter(lines, pageWidth, out cut))
            {
                List<PdfLine> left = new List<PdfLine>();
                List<PdfLine> right = new List<PdfLine>();
                for (int i = 0; i < lines.Count; i++)
                    (lines[i].Right <= cut ? left : right).Add(lines[i]);
                Order(left, pageWidth, into, depth + 1);
                Order(right, pageWidth, into, depth + 1);
                return;
            }

            double band;
            if (FindBandSplit(lines, out band))
            {
                List<PdfLine> top = new List<PdfLine>();
                List<PdfLine> bottom = new List<PdfLine>();
                for (int i = 0; i < lines.Count; i++)
                    (lines[i].Y >= band ? top : bottom).Add(lines[i]);
                if (top.Count > 0 && bottom.Count > 0)
                {
                    Order(top, pageWidth, into, depth + 1);
                    Order(bottom, pageWidth, into, depth + 1);
                    return;
                }
            }

            into.AddRange(MergeRows(lines));
        }

        private static List<PdfLine> MergeRows(List<PdfLine> lines)
        {
            List<PdfLine> sorted = SortByY(lines);
            List<PdfLine> merged = new List<PdfLine>();

            for (int i = 0; i < sorted.Count; i++)
            {
                PdfLine line = sorted[i];
                PdfLine last = merged.Count > 0 ? merged[merged.Count - 1] : null;
                double tol = 0.3 * Math.Max(line.Height, last == null ? line.Height : last.Height);

                if (last != null && Math.Abs(last.Y - line.Y) <= tol)
                {
                    last.Words.AddRange(line.Words);
                    last.Words.Sort(delegate (PdfWord a, PdfWord b) { return a.X.CompareTo(b.X); });
                    if (line.Height > last.Height) last.Height = line.Height;
                    continue;
                }

                PdfLine copy = new PdfLine();
                copy.Y = line.Y;
                copy.Height = line.Height;
                copy.Words.AddRange(line.Words);
                merged.Add(copy);
            }
            return merged;
        }

        private static List<PdfLine> SortByY(List<PdfLine> lines)
        {
            List<PdfLine> sorted = new List<PdfLine>(lines);
            sorted.Sort(delegate (PdfLine a, PdfLine b)
            {
                int c = b.Y.CompareTo(a.Y);
                if (c != 0) return c;
                return a.Left.CompareTo(b.Left);
            });
            return sorted;
        }

        private static bool FindBandSplit(List<PdfLine> lines, out double band)
        {
            band = 0;
            List<PdfLine> sorted = SortByY(lines);

            List<double> gaps = new List<double>();
            for (int i = 1; i < sorted.Count; i++) gaps.Add(sorted[i - 1].Y - sorted[i].Y);
            if (gaps.Count == 0) return false;

            List<double> heights = new List<double>();
            for (int i = 0; i < sorted.Count; i++) heights.Add(sorted[i].Height > 0 ? sorted[i].Height : 10);
            heights.Sort();
            double median = heights[heights.Count / 2];

            double best = 0;
            int bestAt = -1;
            for (int i = 0; i < gaps.Count; i++)
                if (gaps[i] > best) { best = gaps[i]; bestAt = i; }

            if (bestAt < 0 || best < 1.6 * median) return false;

            band = sorted[bestAt].Y - best / 2;
            return true;
        }

        private static bool FindGutter(List<PdfLine> lines, double pageWidth, out double cut)
        {
            cut = 0;
            if (pageWidth <= 0) return false;

            List<double[]> spans = new List<double[]>();
            for (int i = 0; i < lines.Count; i++)
                spans.Add(new double[] { lines[i].Left, lines[i].Right });
            spans.Sort(delegate (double[] a, double[] b) { return a[0].CompareTo(b[0]); });

            double reach = spans[0][1];
            double bestGap = 0, bestCut = 0;
            for (int i = 1; i < spans.Count; i++)
            {
                if (spans[i][0] > reach)
                {
                    double gap = spans[i][0] - reach;
                    if (gap > bestGap) { bestGap = gap; bestCut = reach + gap / 2; }
                }
                if (spans[i][1] > reach) reach = spans[i][1];
            }

            if (bestGap < GutterRatio * pageWidth) return false;

            int leftCount = 0, rightCount = 0;
            for (int i = 0; i < lines.Count; i++)
            {
                if (lines[i].Right <= bestCut) leftCount++;
                else if (lines[i].Left >= bestCut) rightCount++;
                else return false;
            }
            if (leftCount < 3 || rightCount < 3) return false;

            double rightTop = double.MinValue, rightBottom = double.MaxValue;
            for (int i = 0; i < lines.Count; i++)
            {
                if (lines[i].Left < bestCut) continue;
                if (lines[i].Y > rightTop) rightTop = lines[i].Y;
                if (lines[i].Y < rightBottom) rightBottom = lines[i].Y;
            }

            int eligible = 0, aligned = 0;
            for (int i = 0; i < lines.Count; i++)
            {
                if (lines[i].Right > bestCut) continue;
                double tol = 0.3 * Math.Max(1, lines[i].Height);
                if (lines[i].Y > rightTop + tol || lines[i].Y < rightBottom - tol) continue;
                eligible++;
                for (int k = 0; k < lines.Count; k++)
                {
                    if (lines[k].Left < bestCut) continue;
                    if (Math.Abs(lines[k].Y - lines[i].Y) <= tol) { aligned++; break; }
                }
            }
            if (eligible > 0 && aligned > 0.7 * eligible) return false;

            cut = bestCut;
            return true;
        }
    }
}
