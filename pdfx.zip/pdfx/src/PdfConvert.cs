using System;
using System.Collections.Generic;
using System.Text;
using Pdfx.Internal;

namespace Pdfx
{
    public sealed class PdfConvertOptions
    {
        public int FirstPage = 0;
        public int LastPage = -1;
        public string PageSeparator = "\f";
        public bool IncludePageMarkers = false;
        public bool DetectHeadings = true;
        public bool DetectTables = true;
    }

    internal static class PdfConvert
    {
        // Module 6 joins lines with CRLF. Conversion output is LF-only so that it
        // is byte-stable and testable on any platform, so every line that arrives
        // from there is normalised here rather than changing module 6.
        internal static string[] PageLines(PdfPage page)
        {
            string raw = PdfText.Extract(page);
            if (raw == null) return new string[0];
            raw = raw.Replace("\r\n", "\n").Replace("\r", "\n");
            if (raw.Length == 0) return new string[0];

            string[] parts = raw.Split('\n');
            for (int i = 0; i < parts.Length; i++)
                parts[i] = TrimEnd(parts[i]);
            return parts;
        }

        // Leading whitespace is preserved - indentation carries meaning in
        // statements and tables. Only trailing whitespace goes.
        private static string TrimEnd(string s)
        {
            int end = s.Length;
            while (end > 0 && (s[end - 1] == ' ' || s[end - 1] == '\t')) end--;
            return end == s.Length ? s : s.Substring(0, end);
        }

        internal static void ResolveRange(PdfConvertOptions o, int pageCount,
                                          out int first, out int last)
        {
            first = o.FirstPage;
            last = o.LastPage < 0 ? pageCount - 1 : o.LastPage;

            if (pageCount == 0) throw new Internal.PdfException("document has no pages");
            if (first < 0 || first >= pageCount)
                throw new Internal.PdfException("first page out of range: " + first);
            if (last < first || last >= pageCount)
                throw new Internal.PdfException("last page out of range: " + last);
        }

        // ---- HTML ------------------------------------------------------

        internal static string Escape(string s)
        {
            if (s == null) return "";
            StringBuilder sb = new StringBuilder(s.Length);
            for (int i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if (c == '&') sb.Append("&amp;");
                else if (c == '<') sb.Append("&lt;");
                else if (c == '>') sb.Append("&gt;");
                else sb.Append(c);
            }
            return sb.ToString();
        }

        private static double Median(List<double> xs)
        {
            if (xs.Count == 0) return 0;
            xs.Sort();
            int m = xs.Count / 2;
            return xs.Count % 2 == 1 ? xs[m] : (xs[m - 1] + xs[m]) / 2.0;
        }

        private static double MedianHeight(List<PdfLine> lines)
        {
            List<double> hs = new List<double>();
            for (int i = 0; i < lines.Count; i++)
                if (lines[i].Height > 0) hs.Add(lines[i].Height);
            return Median(hs);
        }

        // A line is "cellular" when it contains at least one internal gap much
        // wider than a word space. Module 6 has already merged a table row into a
        // single PdfLine and its private segmentation is not reachable, so the
        // cell boundaries are recovered here from word geometry.
        private static List<int> CellBreaks(PdfLine line)
        {
            List<int> breaks = new List<int>();
            if (line.Words.Count < 2) return breaks;

            double h = line.Height > 0 ? line.Height : 10;
            double threshold = h * PdfText.SegmentGapRatio;

            for (int i = 1; i < line.Words.Count; i++)
            {
                double gap = line.Words[i].X - line.Words[i - 1].Right;
                if (gap >= threshold) breaks.Add(i);
            }
            return breaks;
        }

        private static List<string> Cells(PdfLine line, List<int> breaks)
        {
            List<string> cells = new List<string>();
            int start = 0;
            for (int b = 0; b <= breaks.Count; b++)
            {
                int end = b < breaks.Count ? breaks[b] : line.Words.Count;
                StringBuilder sb = new StringBuilder();
                for (int i = start; i < end; i++)
                {
                    if (sb.Length > 0) sb.Append(' ');
                    sb.Append(line.Words[i].Text);
                }
                cells.Add(sb.ToString());
                start = end;
            }
            return cells;
        }

        private static bool IsHeading(PdfLine line, double median, out bool big)
        {
            big = false;
            if (median <= 0 || line.Height <= 0) return false;
            if (line.Words.Count >= 15) return false;
            double ratio = line.Height / median;
            if (ratio >= 1.6) { big = true; return true; }
            return ratio >= 1.2;
        }

        private static string JoinParagraph(List<PdfLine> para)
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < para.Count; i++)
            {
                string t = para[i].Text;
                if (i == 0) { sb.Append(t); continue; }
                if (sb.Length > 0 && sb[sb.Length - 1] == '-')
                {
                    sb.Remove(sb.Length - 1, 1);
                    sb.Append(t);
                }
                else
                {
                    sb.Append(' ');
                    sb.Append(t);
                }
            }
            return sb.ToString();
        }

        private static bool SameParagraph(List<PdfLine> para, PdfLine prev, PdfLine line)
        {
            double h = prev.Height > 0 ? prev.Height : 10;
            double gap = prev.Y - line.Y;
            if (gap > h * 1.5) return false;
            if (gap < 0) return false;

            double baseLeft = para[0].Left;
            if (Math.Abs(line.Left - baseLeft) <= 2.0) return true;

            // A first line indented further than the second is a first-line
            // indent, which OPENS a paragraph rather than ending one.
            if (para.Count == 1 && para[0].Left > line.Left + 2.0) return true;

            return false;
        }

        private static void RenderPage(StringBuilder sb, PdfPage page, int number,
                                       PdfConvertOptions o)
        {
            RenderPage(sb, page, number, o, false);
        }

        // One renderer for HTML and Markdown: the structure (headings, paragraphs, tables)
        // is decided once, only the markup differs.
        private static void RenderPage(StringBuilder sb, PdfPage page, int number,
                                       PdfConvertOptions o, bool md)
        {
            if (md)
            {
                if (o.IncludePageMarkers) sb.Append("<!-- page ").Append(number).Append(" -->\n\n");
            }
            else
            {
                sb.Append("<div class=\"page\" id=\"page-");
                sb.Append(number);
                sb.Append("\">\n");
            }

            List<PdfLine> lines = PdfText.Lines(page);
            double median = MedianHeight(lines);

            List<PdfLine> para = new List<PdfLine>();
            int i = 0;
            while (i < lines.Count)
            {
                PdfLine line = lines[i];

                if (line.Words.Count == 0) { i++; continue; }

                bool big;
                if (o.DetectHeadings && IsHeading(line, median, out big))
                {
                    FlushParagraph(sb, para, md);
                    if (md) sb.Append(big ? "# " : "## ").Append(MdText(line.Text)).Append("\n\n");
                    else
                    {
                        string tag = big ? "h1" : "h2";
                        sb.Append('<').Append(tag).Append('>');
                        sb.Append(Escape(line.Text));
                        sb.Append("</").Append(tag).Append(">\n");
                    }
                    i++;
                    continue;
                }

                if (o.DetectTables)
                {
                    int run = TableRun(lines, i);
                    if (run >= 2)
                    {
                        FlushParagraph(sb, para, md);
                        if (md)
                        {
                            // A Markdown table needs a header row; the first row serves.
                            for (int r = i; r < i + run; r++)
                            {
                                List<string> cells = Cells(lines[r], CellBreaks(lines[r]));
                                sb.Append('|');
                                for (int c = 0; c < cells.Count; c++) sb.Append(' ').Append(MdCell(cells[c])).Append(" |");
                                sb.Append('\n');
                                if (r == i)
                                {
                                    sb.Append('|');
                                    for (int c = 0; c < cells.Count; c++) sb.Append(" --- |");
                                    sb.Append('\n');
                                }
                            }
                            sb.Append('\n');
                        }
                        else
                        {
                            sb.Append("<table>\n");
                            for (int r = i; r < i + run; r++)
                            {
                                List<string> cells = Cells(lines[r], CellBreaks(lines[r]));
                                sb.Append("<tr>");
                                for (int c = 0; c < cells.Count; c++)
                                {
                                    sb.Append("<td>");
                                    sb.Append(Escape(cells[c]));
                                    sb.Append("</td>");
                                }
                                sb.Append("</tr>\n");
                            }
                            sb.Append("</table>\n");
                        }
                        i += run;
                        continue;
                    }
                }

                if (para.Count > 0 && !SameParagraph(para, para[para.Count - 1], line))
                    FlushParagraph(sb, para, md);
                para.Add(line);
                i++;
            }
            FlushParagraph(sb, para, md);

            if (!md) sb.Append("</div>\n");
        }

        // Text that must read as text in Markdown: a line starting with "#", ">" or a list
        // marker would otherwise turn into a heading, quote or list.
        private static string MdText(string s)
        {
            string t = s.TrimStart();
            if (t.Length == 0) return s;
            char c = t[0];
            bool marker = c == '#' || c == '>' || c == '+' || ((c == '-' || c == '*') && t.Length > 1 && t[1] == ' ');
            if (!marker)
            {
                int k = 0;
                while (k < t.Length && char.IsDigit(t[k])) k++;
                marker = k > 0 && k + 1 < t.Length && (t[k] == '.' || t[k] == ')') && t[k + 1] == ' ';
            }
            return marker ? "\\" + t : s;
        }

        private static string MdCell(string s)
        {
            return s.Replace("|", "\\|").Replace("\n", " ");
        }

        // How many consecutive lines starting at `from` look like table rows:
        // each has the same number of cell breaks, and at least two cells.
        private static int TableRun(List<PdfLine> lines, int from)
        {
            List<int> first = CellBreaks(lines[from]);
            if (first.Count == 0) return 0;

            int run = 1;
            for (int i = from + 1; i < lines.Count; i++)
            {
                List<int> b = CellBreaks(lines[i]);
                if (b.Count != first.Count) break;
                run++;
            }
            return run;
        }

        private static void FlushParagraph(StringBuilder sb, List<PdfLine> para)
        {
            FlushParagraph(sb, para, false);
        }

        private static void FlushParagraph(StringBuilder sb, List<PdfLine> para, bool md)
        {
            if (para.Count == 0) return;
            if (md) sb.Append(MdText(JoinParagraph(para))).Append("\n\n");
            else
            {
                sb.Append("<p>");
                sb.Append(Escape(JoinParagraph(para)));
                sb.Append("</p>\n");
            }
            para.Clear();
        }

        // Markdown: "# Title" and "## Subtitle" for headings, blank-line paragraphs, pipe
        // tables. Plain text otherwise, so it pastes into a wiki, a ticket or a chat as it is.
        internal static string ToMarkdown(PdfDocument doc, PdfConvertOptions o)
        {
            int first, last;
            ResolveRange(o, doc.PageCount, out first, out last);
            StringBuilder sb = new StringBuilder();
            for (int i = first; i <= last; i++)
            {
                int before = sb.Length;
                RenderPage(sb, doc.GetPage(i), i + 1, o, true);
                if (i < last && sb.Length > before && !o.IncludePageMarkers) sb.Append("---\n\n");
            }
            return sb.ToString().TrimEnd('\n') + "\n";
        }

        internal static string ToHtml(PdfDocument doc, PdfConvertOptions o)
        {
            int first, last;
            ResolveRange(o, doc.PageCount, out first, out last);

            StringBuilder sb = new StringBuilder();
            sb.Append("<!DOCTYPE html>\n");
            sb.Append("<meta charset=\"utf-8\">\n");
            sb.Append("<title>");
            sb.Append(Escape(doc.Title == null ? "" : doc.Title));
            sb.Append("</title>\n");

            for (int i = first; i <= last; i++)
                RenderPage(sb, doc.GetPage(i), i + 1, o);

            return sb.ToString();
        }

        internal static string ToText(PdfDocument doc, PdfConvertOptions o)
        {
            int first, last;
            ResolveRange(o, doc.PageCount, out first, out last);

            StringBuilder sb = new StringBuilder();
            for (int i = first; i <= last; i++)
            {
                if (i > first) sb.Append(o.PageSeparator);
                if (o.IncludePageMarkers)
                {
                    sb.Append("[page ");
                    sb.Append(i + 1);
                    sb.Append("]\n");
                }
                string[] lines = PageLines(doc.GetPage(i));
                for (int k = 0; k < lines.Length; k++)
                {
                    if (k > 0) sb.Append('\n');
                    sb.Append(lines[k]);
                }
            }
            return sb.ToString();
        }
    }
}
