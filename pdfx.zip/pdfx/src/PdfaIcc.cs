using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Pdfx.Internal
{
    // ICC v2.1 profiles generated in code: nothing can be shipped alongside the DLL.
    internal static class PdfaIcc
    {
        private static readonly double[] D50 = { 0.9642, 1.0, 0.8249 };

        public static byte[] Srgb()
        {
            List<KeyValuePair<string, byte[]>> tags = new List<KeyValuePair<string, byte[]>>();
            tags.Add(Tag("desc", Desc("sRGB IEC61966-2.1")));
            tags.Add(Tag("cprt", Text("No copyright, use freely")));
            tags.Add(Tag("wtpt", Xyz(D50[0], D50[1], D50[2])));
            tags.Add(Tag("rXYZ", Xyz(0.4361, 0.2225, 0.0139)));
            tags.Add(Tag("gXYZ", Xyz(0.3851, 0.7169, 0.0971)));
            tags.Add(Tag("bXYZ", Xyz(0.1431, 0.0606, 0.7141)));
            byte[] trc = SrgbCurve();
            tags.Add(Tag("rTRC", trc));
            tags.Add(Tag("gTRC", trc));
            tags.Add(Tag("bTRC", trc));
            return Assemble("mntr", "RGB ", "XYZ ", tags);
        }

        public static byte[] Gray()
        {
            List<KeyValuePair<string, byte[]>> tags = new List<KeyValuePair<string, byte[]>>();
            tags.Add(Tag("desc", Desc("Pdfx gray, sRGB tone curve")));
            tags.Add(Tag("cprt", Text("No copyright, use freely")));
            tags.Add(Tag("wtpt", Xyz(D50[0], D50[1], D50[2])));
            tags.Add(Tag("kTRC", SrgbCurve()));
            return Assemble("mntr", "GRAY", "XYZ ", tags);
        }

        // Input-class CMYK -> Lab profile on a 7-point grid fitted to a coated-paper
        // characterisation. Lets DeviceCMYK stand next to an RGB output intent via DefaultCMYK.
        public static byte[] Cmyk()
        {
            List<KeyValuePair<string, byte[]>> tags = new List<KeyValuePair<string, byte[]>>();
            tags.Add(Tag("desc", Desc("Pdfx naive CMYK")));
            tags.Add(Tag("cprt", Text("No copyright, use freely")));
            tags.Add(Tag("wtpt", Xyz(D50[0], D50[1], D50[2])));
            tags.Add(Tag("A2B0", CmykLut()));
            return Assemble("scnr", "CMYK", "Lab ", tags);
        }

        private static KeyValuePair<string, byte[]> Tag(string sig, byte[] data)
        {
            return new KeyValuePair<string, byte[]>(sig, data);
        }

        private static byte[] Assemble(string cls, string space, string pcs, List<KeyValuePair<string, byte[]>> tags)
        {
            MemoryStream body = new MemoryStream();
            int tableLen = 4 + 12 * tags.Count;
            int dataStart = 128 + tableLen;
            Dictionary<byte[], int> placed = new Dictionary<byte[], int>();
            List<int[]> entries = new List<int[]>();
            for (int i = 0; i < tags.Count; i++)
            {
                byte[] d = tags[i].Value;
                int off;
                if (!placed.TryGetValue(d, out off))
                {
                    off = dataStart + (int)body.Length;
                    body.Write(d, 0, d.Length);
                    while (body.Length % 4 != 0) body.WriteByte(0);
                    placed[d] = off;
                }
                entries.Add(new[] { off, d.Length });
            }

            int size = dataStart + (int)body.Length;
            MemoryStream ms = new MemoryStream();
            U32(ms, (uint)size);
            Ascii(ms, "none");
            U32(ms, 0x02100000);
            Ascii(ms, cls);
            Ascii(ms, space);
            Ascii(ms, pcs);
            U16(ms, 2026); U16(ms, 1); U16(ms, 1); U16(ms, 0); U16(ms, 0); U16(ms, 0);
            Ascii(ms, "acsp");
            U32(ms, 0); U32(ms, 0); U32(ms, 0); U32(ms, 0);
            U32(ms, 0); U32(ms, 0);
            U32(ms, 0);
            S15(ms, D50[0]); S15(ms, D50[1]); S15(ms, D50[2]);
            U32(ms, 0);
            while (ms.Length < 128) ms.WriteByte(0);

            U32(ms, (uint)tags.Count);
            for (int i = 0; i < tags.Count; i++)
            {
                Ascii(ms, tags[i].Key);
                U32(ms, (uint)entries[i][0]);
                U32(ms, (uint)entries[i][1]);
            }
            body.WriteTo(ms);
            return ms.ToArray();
        }

        private static byte[] Desc(string s)
        {
            MemoryStream ms = new MemoryStream();
            Ascii(ms, "desc");
            U32(ms, 0);
            U32(ms, (uint)(s.Length + 1));
            Ascii(ms, s);
            ms.WriteByte(0);
            U32(ms, 0);
            U32(ms, 0);
            U16(ms, 0);
            ms.WriteByte(0);
            for (int i = 0; i < 67; i++) ms.WriteByte(0);
            return ms.ToArray();
        }

        private static byte[] Text(string s)
        {
            MemoryStream ms = new MemoryStream();
            Ascii(ms, "text");
            U32(ms, 0);
            Ascii(ms, s);
            ms.WriteByte(0);
            return ms.ToArray();
        }

        private static byte[] Xyz(double x, double y, double z)
        {
            MemoryStream ms = new MemoryStream();
            Ascii(ms, "XYZ ");
            U32(ms, 0);
            S15(ms, x); S15(ms, y); S15(ms, z);
            return ms.ToArray();
        }

        private static byte[] SrgbCurve()
        {
            const int n = 256;
            MemoryStream ms = new MemoryStream();
            Ascii(ms, "curv");
            U32(ms, 0);
            U32(ms, n);
            for (int i = 0; i < n; i++)
            {
                double v = Linear(i / (double)(n - 1));
                U16(ms, (ushort)Math.Round(v * 65535));
            }
            return ms.ToArray();
        }

        private static double Linear(double c)
        {
            return c <= 0.04045 ? c / 12.92 : Math.Pow((c + 0.055) / 1.055, 2.4);
        }

        private static byte[] CmykLut()
        {
            int grid = PdfaTables.CmykGrid;
            byte[] clut = Convert.FromBase64String(PdfaTables.CmykLab);
            if (clut.Length != grid * grid * grid * grid * 3) throw new PdfException("CMYK table is corrupt");
            MemoryStream ms = new MemoryStream();
            Ascii(ms, "mft1");
            U32(ms, 0);
            ms.WriteByte(4); ms.WriteByte(3); ms.WriteByte((byte)grid); ms.WriteByte(0);
            for (int r = 0; r < 3; r++)
                for (int c = 0; c < 3; c++) S15(ms, r == c ? 1.0 : 0.0);
            for (int ch = 0; ch < 4; ch++)
                for (int i = 0; i < 256; i++) ms.WriteByte((byte)i);
            ms.Write(clut, 0, clut.Length);
            for (int ch = 0; ch < 3; ch++)
                for (int i = 0; i < 256; i++) ms.WriteByte((byte)i);
            return ms.ToArray();
        }

        private static void Ascii(Stream s, string t)
        {
            byte[] b = Encoding.ASCII.GetBytes(t);
            s.Write(b, 0, b.Length);
        }

        private static void U32(Stream s, uint v)
        {
            s.WriteByte((byte)(v >> 24)); s.WriteByte((byte)(v >> 16));
            s.WriteByte((byte)(v >> 8)); s.WriteByte((byte)v);
        }

        private static void U16(Stream s, ushort v)
        {
            s.WriteByte((byte)(v >> 8)); s.WriteByte((byte)v);
        }

        private static void U16(Stream s, int v) { U16(s, (ushort)v); }

        private static void S15(Stream s, double v)
        {
            U32(s, unchecked((uint)(int)Math.Round(v * 65536)));
        }
    }
}
