using System;
using System.Collections.Generic;

namespace Pdfx.Internal
{
    // The page tree flattened into pages, each carrying what it inherits from its parents.
    internal static class PdfPageTree
    {
        private static readonly string[] Inheritable = { "Resources", "MediaBox", "CropBox", "Rotate" };

        public static List<PdfPage> Pages(PdfFile f)
        {
            PdfDictionary root = f.Resolve(f.Trailer.Get("Root")) as PdfDictionary;
            if (root == null) throw new PdfException("not a PDF file, or damaged beyond repair (no document catalog)");
            List<PdfPage> pages = new List<PdfPage>();
            Collect(f, root.Get("Pages"), new PdfDictionary(), pages, new HashSet<int>(), 0);
            return pages;
        }

        public static void Collect(PdfFile f, PdfObject nodeRef, PdfDictionary inherited,
                                    List<PdfPage> into, HashSet<int> guard, int depth)
        {
            if (depth > 64) return;

            PdfRef r = nodeRef as PdfRef;
            if (r != null && !guard.Add(r.Number)) return;

            PdfDictionary node = f.Resolve(nodeRef) as PdfDictionary;
            if (node == null) return;

            PdfDictionary inh = new PdfDictionary();
            foreach (KeyValuePair<string, PdfObject> kv in inherited.Map) inh.Set(kv.Key, kv.Value);
            for (int i = 0; i < Inheritable.Length; i++)
                if (node.Has(Inheritable[i])) inh.Set(Inheritable[i], node.Get(Inheritable[i]));

            PdfArray kids = f.Resolve(node.Get("Kids")) as PdfArray;
            PdfName type = f.Resolve(node.Get("Type")) as PdfName;
            bool isLeaf = type != null && type.Value == "Page";

            if (!isLeaf && kids != null)
            {
                for (int i = 0; i < kids.Count; i++)
                    Collect(f, kids[i], inh, into, guard, depth + 1);
                return;
            }

            PdfDictionary page = new PdfDictionary();
            foreach (KeyValuePair<string, PdfObject> kv in node.Map)
            {
                if (kv.Key == "Parent") continue;
                page.Set(kv.Key, kv.Value);
            }
            for (int i = 0; i < Inheritable.Length; i++)
                if (!page.Has(Inheritable[i]) && inh.Has(Inheritable[i]))
                    page.Set(Inheritable[i], inh.Get(Inheritable[i]));
            page.Set("Type", new PdfName("Page"));

            PdfPage made = new PdfPage(f, page);
            if (r != null) made.SourceNumber = r.Number;
            into.Add(made);
        }
    }
}
