using System;
using System.Collections.Generic;
using System.Text;

namespace Pdfx.Internal
{
    public sealed class PdfFontInfo
    {
        private readonly Dictionary<int, double> _widths = new Dictionary<int, double>();
        private readonly Dictionary<int, string> _toUnicode = new Dictionary<int, string>();
        private readonly Dictionary<int, string> _differences = new Dictionary<int, string>();
        private double _defaultWidth = 500;
        private bool _twoByte;
        private bool _identity;

        public string BaseFont { get; private set; }
        public bool IsCid { get { return _twoByte; } }

        public static PdfFontInfo Build(PdfFile f, PdfDictionary font)
        {
            PdfFontInfo info = new PdfFontInfo();
            if (font == null) return info;

            PdfName bf = f.Resolve(font.Get("BaseFont")) as PdfName;
            info.BaseFont = bf == null ? "" : bf.Value;

            PdfName subtype = f.Resolve(font.Get("Subtype")) as PdfName;
            string st = subtype == null ? "" : subtype.Value;

            if (st == "Type0")
            {
                info._twoByte = true;
                PdfName enc = f.Resolve(font.Get("Encoding")) as PdfName;
                info._identity = enc == null || enc.Value.StartsWith("Identity");

                PdfArray desc = f.Resolve(font.Get("DescendantFonts")) as PdfArray;
                PdfDictionary d0 = desc != null && desc.Count > 0
                    ? f.Resolve(desc[0]) as PdfDictionary : null;
                if (d0 != null)
                {
                    PdfNumber dw = f.Resolve(d0.Get("DW")) as PdfNumber;
                    info._defaultWidth = dw != null ? dw.Value : 1000;
                    info.ReadCidWidths(f, f.Resolve(d0.Get("W")) as PdfArray);
                }
                else info._defaultWidth = 1000;
            }
            else
            {
                info.ReadSimpleWidths(f, font);
                info.ReadEncoding(f, font);
                if (info._widths.Count == 0)
                {
                    int[] std = StandardWidths.For(info.BaseFont);
                    if (std != null)
                        for (int i = 0; i < std.Length; i++) info._widths[32 + i] = std[i];
                }
                if (info.BaseFont.IndexOf("Courier", StringComparison.OrdinalIgnoreCase) >= 0)
                    info._defaultWidth = 600;
            }

            PdfStream tu = f.Resolve(font.Get("ToUnicode")) as PdfStream;
            if (tu != null)
            {
                try { info.ReadToUnicode(PdfFilters.Decode(tu, f)); }
                catch { }
            }

            return info;
        }

        private void ReadSimpleWidths(PdfFile f, PdfDictionary font)
        {
            PdfNumber first = f.Resolve(font.Get("FirstChar")) as PdfNumber;
            PdfArray w = f.Resolve(font.Get("Widths")) as PdfArray;
            if (first != null && w != null)
            {
                int fc = first.AsInt;
                for (int i = 0; i < w.Count; i++)
                {
                    PdfNumber n = f.Resolve(w[i]) as PdfNumber;
                    if (n != null && n.Value > 0) _widths[fc + i] = n.Value;
                }
            }

            PdfDictionary fd = f.Resolve(font.Get("FontDescriptor")) as PdfDictionary;
            if (fd != null)
            {
                PdfNumber mw = f.Resolve(fd.Get("MissingWidth")) as PdfNumber;
                if (mw != null && mw.Value > 0) _defaultWidth = mw.Value;
            }
        }

        private void ReadCidWidths(PdfFile f, PdfArray w)
        {
            if (w == null) return;
            int i = 0;
            while (i < w.Count)
            {
                PdfNumber a = f.Resolve(w[i]) as PdfNumber;
                if (a == null) break;
                PdfObject next = i + 1 < w.Count ? f.Resolve(w[i + 1]) : null;

                PdfArray list = next as PdfArray;
                if (list != null)
                {
                    int start = a.AsInt;
                    for (int k = 0; k < list.Count; k++)
                    {
                        PdfNumber v = f.Resolve(list[k]) as PdfNumber;
                        if (v != null) _widths[start + k] = v.Value;
                    }
                    i += 2;
                    continue;
                }

                PdfNumber b = next as PdfNumber;
                PdfNumber c = i + 2 < w.Count ? f.Resolve(w[i + 2]) as PdfNumber : null;
                if (b == null || c == null) break;
                int lo = a.AsInt, hi = b.AsInt;
                if (hi - lo > 65535) hi = lo + 65535;
                for (int cid = lo; cid <= hi; cid++) _widths[cid] = c.Value;
                i += 3;
            }
        }

        private void ReadEncoding(PdfFile f, PdfDictionary font)
        {
            PdfObject enc = f.Resolve(font.Get("Encoding"));
            PdfDictionary ed = enc as PdfDictionary;
            if (ed == null) return;

            PdfArray diff = f.Resolve(ed.Get("Differences")) as PdfArray;
            if (diff == null) return;

            int code = 0;
            for (int i = 0; i < diff.Count; i++)
            {
                PdfObject it = f.Resolve(diff[i]);
                PdfNumber n = it as PdfNumber;
                if (n != null) { code = n.AsInt; continue; }
                PdfName nm = it as PdfName;
                if (nm != null) _differences[code++] = nm.Value;
            }
        }

        private void ReadToUnicode(byte[] data)
        {
            PdfLexer lex = new PdfLexer(data);
            List<Token> pending = new List<Token>();

            while (true)
            {
                Token t = lex.Next();
                if (t.Type == TokenType.Eof) break;

                if (t.Type == TokenType.Keyword && t.Text == "beginbfchar")
                {
                    while (true)
                    {
                        Token src = lex.Next();
                        if (src.Type != TokenType.String) break;
                        Token dst = lex.Next();
                        if (dst.Type != TokenType.String) break;
                        _toUnicode[CodeOf(src.Bytes)] = TextOf(dst.Bytes);
                    }
                    continue;
                }

                if (t.Type == TokenType.Keyword && t.Text == "beginbfrange")
                {
                    while (true)
                    {
                        Token lo = lex.Next();
                        if (lo.Type != TokenType.String) break;
                        Token hi = lex.Next();
                        if (hi.Type != TokenType.String) break;

                        int a = CodeOf(lo.Bytes), b = CodeOf(hi.Bytes);
                        if (b < a) b = a;
                        if (b - a > 65535) b = a + 65535;

                        int save = lex.Position;
                        Token dst = lex.Next();
                        if (dst.Type == TokenType.String)
                        {
                            string text = TextOf(dst.Bytes);
                            for (int c = a; c <= b; c++)
                            {
                                _toUnicode[c] = text;
                                text = Bump(text);
                            }
                        }
                        else if (dst.Type == TokenType.ArrayStart)
                        {
                            int c = a;
                            while (true)
                            {
                                Token e = lex.Next();
                                if (e.Type != TokenType.String) break;
                                if (c <= b) _toUnicode[c++] = TextOf(e.Bytes);
                            }
                        }
                        else lex.Position = save;
                    }
                    continue;
                }

                pending.Add(t);
                if (pending.Count > 64) pending.Clear();
            }
        }

        private static string Bump(string text)
        {
            if (text.Length == 0) return text;
            char[] c = text.ToCharArray();
            c[c.Length - 1] = (char)(c[c.Length - 1] + 1);
            return new string(c);
        }

        private static int CodeOf(byte[] b)
        {
            int v = 0;
            for (int i = 0; i < b.Length && i < 4; i++) v = (v << 8) | b[i];
            return v;
        }

        private static string TextOf(byte[] b)
        {
            if (b.Length >= 2 && (b.Length % 2) == 0)
            {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i + 1 < b.Length; i += 2)
                {
                    sb.Append((char)((b[i] << 8) | b[i + 1]));
                }
                return sb.ToString();
            }
            StringBuilder s = new StringBuilder();
            for (int i = 0; i < b.Length; i++) s.Append((char)b[i]);
            return s.ToString();
        }

        public void Decode(byte[] raw, List<int> codes)
        {
            codes.Clear();
            if (_twoByte)
            {
                for (int i = 0; i + 1 < raw.Length; i += 2)
                    codes.Add((raw[i] << 8) | raw[i + 1]);
                if ((raw.Length % 2) == 1) codes.Add(raw[raw.Length - 1]);
                return;
            }
            for (int i = 0; i < raw.Length; i++) codes.Add(raw[i]);
        }

        public double WidthOf(int code)
        {
            double w;
            if (_widths.TryGetValue(code, out w)) return w / 1000.0;
            return _defaultWidth / 1000.0;
        }

        public string TextFor(int code)
        {
            string s;
            if (_toUnicode.TryGetValue(code, out s)) return s;

            if (!_twoByte)
            {
                string glyph;
                if (_differences.TryGetValue(code, out glyph))
                {
                    string mapped = GlyphNames.ToText(glyph);
                    if (mapped != null) return mapped;
                }
                return WinAnsi.ToText(code);
            }

            return string.Empty;
        }
    }

    public static class WinAnsi
    {
        private static readonly int[] High =
        {
            0x20AC, 0x0000, 0x201A, 0x0192, 0x201E, 0x2026, 0x2020, 0x2021,
            0x02C6, 0x2030, 0x0160, 0x2039, 0x0152, 0x0000, 0x017D, 0x0000,
            0x0000, 0x2018, 0x2019, 0x201C, 0x201D, 0x2022, 0x2013, 0x2014,
            0x02DC, 0x2122, 0x0161, 0x203A, 0x0153, 0x0000, 0x017E, 0x0178
        };

        public static string ToText(int code)
        {
            if (code < 32) return string.Empty;
            if (code < 127) return ((char)code).ToString();
            if (code >= 128 && code <= 159)
            {
                int u = High[code - 128];
                return u == 0 ? string.Empty : ((char)u).ToString();
            }
            if (code <= 255) return ((char)code).ToString();
            return string.Empty;
        }
    }

    public static class GlyphNames
    {
        private static readonly Dictionary<string, string> Named = Build();

        public static string ToText(string glyph)
        {
            if (string.IsNullOrEmpty(glyph)) return null;

            string v;
            if (Named.TryGetValue(glyph, out v)) return v;

            if (glyph.Length >= 7 && glyph.StartsWith("uni", StringComparison.Ordinal))
            {
                int u = HexVal(glyph.Substring(3, 4));
                if (u > 0) return ((char)u).ToString();
            }
            if (glyph.Length == 7 && glyph.StartsWith("uni", StringComparison.Ordinal))
            {
                int u = HexVal(glyph.Substring(3));
                if (u > 0) return ((char)u).ToString();
            }
            if (glyph.Length > 1 && glyph[0] == 'u')
            {
                int u = HexVal(glyph.Substring(1));
                if (u > 0) return ((char)u).ToString();
            }
            if (glyph.Length == 1) return glyph;
            return null;
        }

        private static int HexVal(string s)
        {
            int v = 0;
            for (int i = 0; i < s.Length; i++)
            {
                char c = s[i];
                int d;
                if (c >= '0' && c <= '9') d = c - '0';
                else if (c >= 'a' && c <= 'f') d = c - 'a' + 10;
                else if (c >= 'A' && c <= 'F') d = c - 'A' + 10;
                else return 0;
                v = v * 16 + d;
            }
            return v;
        }

        private static Dictionary<string, string> Build()
        {
            Dictionary<string, string> m = new Dictionary<string, string>(StringComparer.Ordinal);
            string[] letters = { "A","B","C","D","E","F","G","H","I","J","K","L","M",
                                 "N","O","P","Q","R","S","T","U","V","W","X","Y","Z" };
            for (int i = 0; i < letters.Length; i++)
            {
                m[letters[i]] = letters[i];
                m[letters[i].ToLowerInvariant()] = letters[i].ToLowerInvariant();
            }
            string[] digits = { "zero","one","two","three","four","five","six","seven","eight","nine" };
            for (int i = 0; i < digits.Length; i++) m[digits[i]] = ((char)('0' + i)).ToString();

            m["space"] = " "; m["period"] = "."; m["comma"] = ","; m["colon"] = ":";
            m["semicolon"] = ";"; m["hyphen"] = "-"; m["endash"] = "\u2013"; m["emdash"] = "\u2014";
            m["parenleft"] = "("; m["parenright"] = ")"; m["bracketleft"] = "[";
            m["bracketright"] = "]"; m["braceleft"] = "{"; m["braceright"] = "}";
            m["slash"] = "/"; m["backslash"] = "\\"; m["question"] = "?"; m["exclam"] = "!";
            m["quotesingle"] = "'"; m["quotedbl"] = "\""; m["quoteright"] = "\u2019";
            m["quoteleft"] = "\u2018"; m["quotedblleft"] = "\u201C"; m["quotedblright"] = "\u201D";
            m["ampersand"] = "&"; m["at"] = "@"; m["numbersign"] = "#"; m["dollar"] = "$";
            m["percent"] = "%"; m["plus"] = "+"; m["equal"] = "="; m["less"] = "<";
            m["greater"] = ">"; m["asterisk"] = "*"; m["underscore"] = "_"; m["bullet"] = "\u2022";
            m["degree"] = "\u00B0"; m["euro"] = "\u20AC"; m["sterling"] = "\u00A3";
            m["adieresis"] = "\u00E4"; m["odieresis"] = "\u00F6"; m["udieresis"] = "\u00FC";
            m["Adieresis"] = "\u00C4"; m["Odieresis"] = "\u00D6"; m["Udieresis"] = "\u00DC";
            m["germandbls"] = "\u00DF"; m["eacute"] = "\u00E9"; m["egrave"] = "\u00E8";
            m["agrave"] = "\u00E0"; m["ccedilla"] = "\u00E7"; m["ntilde"] = "\u00F1";
            m["abreve"] = "\u0103"; m["Abreve"] = "\u0102"; m["acircumflex"] = "\u00E2";
            m["icircumflex"] = "\u00EE"; m["scommaaccent"] = "\u0219"; m["tcommaaccent"] = "\u021B";
            return m;
        }
    }

    public static class StandardWidths
    {
        private const string HelveticaIdx = "DDGKKRNAEEHLDEDDKKKKKKKKKKDDLLLKTNNOONMPODJNKQOPNPONMONSNNMDDDIKEKKJKKDKKBBJBQKKKKEJDKJOJJJFCFL";
        private static readonly int[] HelveticaVal = { 191, 222, 260, 278, 333, 334, 355, 389, 469, 500, 556, 584, 611, 667, 722, 778, 833, 889, 944, 1015 };
        private const string HelveticaBoldIdx = "BDFHHOLADDEIBDBBHHHHHHHHHHDDIIIJQLLLLKJMLBHLJNLMKMLKJLKPKKJDBDIHDHJHJHDJJBBHBOJJJJEHDJHMHHGECEI";
        private static readonly int[] HelveticaBoldVal = { 238, 278, 280, 333, 389, 474, 500, 556, 584, 611, 667, 722, 778, 833, 889, 944, 975 };
        private const string TimesIdx = "CEGKKSRAEEKNCECDKKKKKKKKKKDDNNNHUQPPQOMQQEFQOTQQMQPMOQQVQQOEDEIKEHKHKHEKKDDKDRKKKKEFDKKQKKHJBJL";
        private static readonly int[] TimesVal = { 180, 200, 250, 278, 333, 389, 408, 444, 469, 480, 500, 541, 556, 564, 611, 667, 722, 778, 833, 889, 921, 944 };
        private const string TimesBoldIdx = "BDJHHURCDDHLBDBCHHHHHHHHHHDDLLLHSPOPPONQQEHQOTPQNQPKOPPUPPODCDMHDHKGKGDHKCDKCRKHKKGEDKHPHHGFAFI";
        private static readonly int[] TimesBoldVal = { 220, 250, 278, 333, 389, 394, 444, 500, 520, 555, 556, 570, 581, 611, 667, 722, 778, 833, 930, 944, 1000 };
        private const string TimesItalicIdx = "BEHKKSRAEEKPBEBDKKKKKKKKKKEEPPPKTNNOQNNQQEJOMSOQNQNKMQNSNMMFDFIKEKKJKJDKKDDJDQKKKKFFDKJOJJFGCGL";
        private static readonly int[] TimesItalicVal = { 214, 250, 275, 278, 333, 389, 400, 420, 422, 444, 500, 541, 556, 611, 667, 675, 722, 778, 833, 920 };
        private const string TimesBoldItalicIdx = "BFIHHQOCDDHKBDBCHHHHHHHHHHDDKKKHPMMMNMMNOFHMLRNNLNMJLNMRMLLDCDKHDHHGHGDHJCCHCOJHHHFFCJGMHGFEAEK";
        private static readonly int[] TimesBoldItalicVal = { 220, 250, 278, 333, 348, 389, 444, 500, 555, 556, 570, 611, 667, 722, 778, 832, 833, 889 };

        public static int[] For(string baseFont)
        {
            if (string.IsNullOrEmpty(baseFont)) return null;
            string n = baseFont;
            int plus = n.IndexOf('+');
            if (plus >= 0 && plus + 1 < n.Length) n = n.Substring(plus + 1);
            n = n.ToLowerInvariant();

            bool bold = n.Contains("bold");
            bool italic = n.Contains("italic") || n.Contains("oblique");

            if (n.Contains("courier") || n.Contains("mono"))
            {
                int[] fixedWidths = new int[95];
                for (int i = 0; i < 95; i++) fixedWidths[i] = 600;
                return fixedWidths;
            }

            if (n.Contains("times") || n.Contains("serif") || n.Contains("roman")
                || n.Contains("georgia") || n.Contains("garamond") || n.Contains("book"))
            {
                if (bold && italic) return Expand(TimesBoldItalicIdx, TimesBoldItalicVal);
                if (bold) return Expand(TimesBoldIdx, TimesBoldVal);
                if (italic) return Expand(TimesItalicIdx, TimesItalicVal);
                return Expand(TimesIdx, TimesVal);
            }

            if (bold) return Expand(HelveticaBoldIdx, HelveticaBoldVal);
            return Expand(HelveticaIdx, HelveticaVal);
        }

        private static int[] Expand(string index, int[] values)
        {
            int[] r = new int[index.Length];
            for (int i = 0; i < index.Length; i++)
            {
                int k = index[i] - 'A';
                r[i] = (k >= 0 && k < values.Length) ? values[k] : 500;
            }
            return r;
        }
    }
}
