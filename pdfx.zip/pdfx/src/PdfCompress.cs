using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;
using Pdfx.Internal;

namespace Pdfx
{
    public sealed class PdfCompressOptions
    {
        // JPEG quality for re-encoded images, 1-100.
        public int ImageQuality = 75;
        // Images shown at more than this resolution are scaled down to it.
        public int MaxDpi = 150;
        public string Password;
    }

    public static partial class PdfComposer
    {
        // Smaller file, same document: large photos and scans are scaled to MaxDpi and
        // re-encoded as JPEG, uncompressed streams are deflated. Everything else (text, fonts,
        // forms, bookmarks, attachments, PDF/A metadata) is kept as it is. Returns the new size
        // in bytes; when nothing could be gained the original is written unchanged.
        public static long Compress(string input, string output)
        {
            return Compress(input, output, new PdfCompressOptions());
        }

        public static long Compress(string input, string output, PdfCompressOptions options)
        {
            if (options == null) options = new PdfCompressOptions();
            if (options.ImageQuality < 1 || options.ImageQuality > 100) throw new ArgumentException("ImageQuality must be between 1 and 100", "options");
            if (options.MaxDpi < 36) throw new ArgumentException("MaxDpi below 36 would make pages unreadable", "options");
            byte[] src = ReadInput(input);
            if (PdfImages.IsImage(src)) src = PdfImages.ToPdf(new[] { src });
            else PdfImages.RefuseText(src);
            byte[] made = PdfCompressor.Run(src, options);
            byte[] best = made != null && made.Length < src.Length ? made : src;
            WriteOutput(output, best);
            return best.Length;
        }
    }
}

namespace Pdfx.Internal
{
    internal static class PdfCompressor
    {
        public static byte[] Run(byte[] source, PdfCompressOptions opt)
        {
            PdfFile f = PdfFile.Open(source);
            if (f.IsEncrypted && f.Decryptor == null)
            {
                if (opt.Password != null) f.Unlock(opt.Password);
                if (f.Decryptor == null)
                    throw new PdfException("cannot compress: the document is encrypted and "
                        + (opt.Password == null ? "no password was given" : "the password is wrong"));
            }
            PdfObject rootRef = f.Trailer.Get("Root");
            if (!(f.Resolve(rootRef) is PdfDictionary)) throw new PdfException("not a PDF file, or damaged beyond repair (no document catalog)");

            PdfOutput o = new PdfOutput();
            o.Trailer.Set("Root", o.Import(f, rootRef));
            if (f.Trailer.Has("Info")) o.Trailer.Set("Info", o.Import(f, f.Trailer.Get("Info")));
            if (f.Trailer.Has("ID")) o.Trailer.Set("ID", o.Import(f, f.Trailer.Get("ID")));

            // How large each image is drawn, to know its effective resolution.
            Dictionary<PdfStream, double> dpi = new Dictionary<PdfStream, double>();
            PdfDictionary cat = Res(o, o.Trailer.Get("Root")) as PdfDictionary;
            Pages(o, cat == null ? null : cat.Get("Pages"), null, dpi, new HashSet<PdfObject>(), 0);

            for (int i = 1; i <= o.Count; i++)
            {
                PdfStream s = o.GetObject(i) as PdfStream;
                if (s == null) continue;
                PdfName type = Res(o, s.Dict.Get("Type")) as PdfName, sub = Res(o, s.Dict.Get("Subtype")) as PdfName;
                if (sub != null && sub.Value == "Image")
                {
                    double d;
                    PdfStream better = Image(o, s, dpi.TryGetValue(s, out d) ? d : 0, opt);
                    if (better != null) o.SetObject(i, better);
                }
                else if (!s.Dict.Has("Filter") && s.RawData.Length >= 256 && (type == null || (type.Value != "Metadata" && type.Value != "XRef")))
                {
                    PdfDictionary d = new PdfDictionary();
                    foreach (KeyValuePair<string, PdfObject> kv in s.Dict.Map) if (kv.Key != "Length" && kv.Key != "DecodeParms") d.Set(kv.Key, kv.Value);
                    d.Set("Filter", new PdfName("FlateDecode"));
                    o.SetObject(i, new PdfStream(d, PdfaFontFixer.Deflate(s.RawData)));
                }
            }
            return o.ToBytes();
        }

        private static PdfObject Res(PdfOutput o, PdfObject x)
        {
            for (int k = 0; k < 32; k++)
            {
                PdfRef r = x as PdfRef;
                if (r == null) return x;
                x = o.GetObject(r.Number);
            }
            return null;
        }

        // ---- where images are drawn --------------------------------------------------------

        private static void Pages(PdfOutput o, PdfObject node, PdfDictionary inheritedRes, Dictionary<PdfStream, double> dpi, HashSet<PdfObject> seen, int depth)
        {
            PdfDictionary n = Res(o, node) as PdfDictionary;
            if (n == null || depth > 64 || !seen.Add(n)) return;
            PdfDictionary res = Res(o, n.Get("Resources")) as PdfDictionary ?? inheritedRes;
            PdfArray kids = Res(o, n.Get("Kids")) as PdfArray;
            if (kids != null) { foreach (PdfObject k in kids.Items) Pages(o, k, res, dpi, seen, depth + 1); return; }
            Draw(o, Contents(o, n.Get("Contents")), res, new double[] { 1, 0, 0, 1, 0, 0 }, dpi, 0);
        }

        private static byte[] Contents(PdfOutput o, PdfObject c)
        {
            c = Res(o, c);
            MemoryStream ms = new MemoryStream();
            PdfArray arr = c as PdfArray;
            List<PdfObject> parts = arr != null ? arr.Items : new List<PdfObject> { c };
            foreach (PdfObject p in parts)
            {
                PdfStream s = Res(o, p) as PdfStream;
                if (s == null) continue;
                byte[] b = PdfaDecode.Decode(s, o);
                if (b != null) { ms.Write(b, 0, b.Length); ms.WriteByte((byte)'\n'); }
            }
            return ms.ToArray();
        }

        private static void Draw(PdfOutput o, byte[] content, PdfDictionary res, double[] start, Dictionary<PdfStream, double> dpi, int depth)
        {
            if (content == null || depth > 8) return;
            PdfDictionary xobjects = res == null ? null : Res(o, res.Get("XObject")) as PdfDictionary;
            Stack<double[]> stack = new Stack<double[]>();
            double[] ctm = (double[])start.Clone();
            List<PdfaToken> args = new List<PdfaToken>();
            PdfaLexer lx = new PdfaLexer(content);
            while (true)
            {
                PdfaToken t = lx.Next();
                if (t.Kind == PdfaTok.Eof) break;
                if (t.Kind != PdfaTok.Operator) { args.Add(t); continue; }
                if (t.Text == "q") stack.Push((double[])ctm.Clone());
                else if (t.Text == "Q") { if (stack.Count > 0) ctm = stack.Pop(); }
                else if (t.Text == "cm" && args.Count >= 6)
                {
                    double[] m = new double[6];
                    for (int k = 0; k < 6; k++) m[k] = args[args.Count - 6 + k].Number;
                    ctm = Mul(m, ctm);
                }
                else if (t.Text == "Do" && args.Count >= 1 && args[args.Count - 1].Kind == PdfaTok.Name && xobjects != null)
                {
                    PdfStream x = Res(o, xobjects.Get(args[args.Count - 1].Text)) as PdfStream;
                    PdfName sub = x == null ? null : Res(o, x.Dict.Get("Subtype")) as PdfName;
                    if (sub != null && sub.Value == "Image")
                    {
                        PdfNumber w = Res(o, x.Dict.Get("Width")) as PdfNumber, h = Res(o, x.Dict.Get("Height")) as PdfNumber;
                        double sw = Math.Sqrt(ctm[0] * ctm[0] + ctm[1] * ctm[1]), sh = Math.Sqrt(ctm[2] * ctm[2] + ctm[3] * ctm[3]);
                        if (w != null && h != null && sw > 0.5 && sh > 0.5)
                        {
                            double need = Math.Max(w.Value / (sw / 72), h.Value / (sh / 72));
                            double had;
                            // Drawn several times: keep the sharpest use.
                            dpi[x] = dpi.TryGetValue(x, out had) ? Math.Min(had, need) : need;
                        }
                    }
                    else if (sub != null && sub.Value == "Form")
                    {
                        double[] fm = { 1, 0, 0, 1, 0, 0 };
                        PdfArray mx = Res(o, x.Dict.Get("Matrix")) as PdfArray;
                        if (mx != null && mx.Count == 6) for (int k = 0; k < 6; k++) { PdfNumber v = Res(o, mx[k]) as PdfNumber; if (v != null) fm[k] = v.Value; }
                        PdfDictionary fres = Res(o, x.Dict.Get("Resources")) as PdfDictionary ?? res;
                        Draw(o, PdfaDecode.Decode(x, o), fres, Mul(fm, ctm), dpi, depth + 1);
                    }
                }
                args.Clear();
            }
        }

        private static double[] Mul(double[] a, double[] b)
        {
            return new double[]
            {
                a[0] * b[0] + a[1] * b[2], a[0] * b[1] + a[1] * b[3],
                a[2] * b[0] + a[3] * b[2], a[2] * b[1] + a[3] * b[3],
                a[4] * b[0] + a[5] * b[2] + b[4], a[4] * b[1] + a[5] * b[3] + b[5]
            };
        }

        // ---- one image -------------------------------------------------------------------

        private static PdfStream Image(PdfOutput o, PdfStream s, double dpi, PdfCompressOptions opt)
        {
            if (s.RawData.Length < 20000) return null;
            PdfDictionary d = s.Dict;
            PdfNumber w = Res(o, d.Get("Width")) as PdfNumber, h = Res(o, d.Get("Height")) as PdfNumber, bpc = Res(o, d.Get("BitsPerComponent")) as PdfNumber;
            if (w == null || h == null || bpc == null || bpc.AsInt != 8) return null;
            PdfBool mask = Res(o, d.Get("ImageMask")) as PdfBool;
            if ((mask != null && mask.Value) || Res(o, d.Get("Mask")) is PdfArray || d.Has("Decode")) return null;
            // A soft mask with /Matte must keep the image's exact size.
            PdfStream smask = Res(o, d.Get("SMask")) as PdfStream;
            if (smask != null && smask.Dict.Has("Matte")) return null;

            int comps = Components(o, d.Get("ColorSpace"));
            if (comps != 1 && comps != 3) return null;

            List<string> filters = new List<string>();
            PdfObject fo = Res(o, d.Get("Filter"));
            if (fo is PdfName) filters.Add(((PdfName)fo).Value);
            else if (fo is PdfArray) foreach (PdfObject x in ((PdfArray)fo).Items) { PdfName nm = Res(o, x) as PdfName; if (nm == null) return null; filters.Add(nm.Value); }
            bool jpeg = filters.Count == 1 && filters[0] == "DCTDecode";
            foreach (string fl in filters)
                if (fl != "FlateDecode" && fl != "LZWDecode" && fl != "DCTDecode" && fl != "ASCII85Decode" && fl != "ASCIIHexDecode" && fl != "RunLengthDecode") return null;
            if (filters.Contains("DCTDecode") && !jpeg) return null;

            double scale = dpi > opt.MaxDpi * 1.1 ? opt.MaxDpi / dpi : 1;
            if (jpeg && scale == 1) return null;          // re-encoding a JPEG at the same size only loses quality
            int nw = Math.Max(1, (int)Math.Round(w.AsInt * scale)), nh = Math.Max(1, (int)Math.Round(h.AsInt * scale));

            byte[] encoded;
            try
            {
                using (Bitmap src = jpeg ? DecodeJpeg(s.RawData) : FromSamples(PdfaDecode.Decode(s, o), w.AsInt, h.AsInt, comps))
                {
                    if (src == null) return null;
                    using (Bitmap dst = Resize(src, nw, nh)) encoded = Jpeg(dst, opt.ImageQuality);
                }
            }
            catch (Exception) { return null; }          // an image GDI+ cannot handle stays as it was
            if (encoded == null || encoded.Length > s.RawData.Length * 0.9) return null;

            PdfDictionary nd = new PdfDictionary();
            foreach (KeyValuePair<string, PdfObject> kv in d.Map)
                if (kv.Key != "Length" && kv.Key != "Filter" && kv.Key != "DecodeParms") nd.Set(kv.Key, kv.Value);
            nd.Set("Width", new PdfNumber(nw, true));
            nd.Set("Height", new PdfNumber(nh, true));
            nd.Set("Filter", new PdfName("DCTDecode"));
            // GDI+ writes three-channel JPEGs; a grey image becomes RGB with equal channels.
            if (comps == 1) nd.Set("ColorSpace", new PdfName("DeviceRGB"));
            return new PdfStream(nd, encoded);
        }

        private static int Components(PdfOutput o, PdfObject cs)
        {
            cs = Res(o, cs);
            PdfName n = cs as PdfName;
            if (n != null) return n.Value == "DeviceGray" ? 1 : n.Value == "DeviceRGB" ? 3 : 0;
            PdfArray a = cs as PdfArray;
            if (a == null || a.Count < 2) return 0;
            PdfName kind = Res(o, a[0]) as PdfName;
            if (kind == null || kind.Value != "ICCBased") return 0;
            PdfStream icc = Res(o, a[1]) as PdfStream;
            PdfNumber nn = icc == null ? null : Res(o, icc.Dict.Get("N")) as PdfNumber;
            // An ICC-based RGB image keeps its profile; grey ICC would become device RGB, so no.
            return nn != null && nn.AsInt == 3 ? 3 : 0;
        }

        private static Bitmap DecodeJpeg(byte[] data)
        {
            using (MemoryStream ms = new MemoryStream(data))
            using (Image img = System.Drawing.Image.FromStream(ms))
                return new Bitmap(img);
        }

        private static Bitmap FromSamples(byte[] samples, int w, int h, int comps)
        {
            if (samples == null || samples.Length < (long)w * h * comps) return null;
            Bitmap b = new Bitmap(w, h, PixelFormat.Format24bppRgb);
            BitmapData bd = b.LockBits(new Rectangle(0, 0, w, h), ImageLockMode.WriteOnly, PixelFormat.Format24bppRgb);
            try
            {
                byte[] row = new byte[bd.Stride];
                for (int y = 0; y < h; y++)
                {
                    int src = y * w * comps;
                    for (int x = 0; x < w; x++)
                    {
                        // GDI+ rows are blue, green, red.
                        if (comps == 3) { row[3 * x] = samples[src + 3 * x + 2]; row[3 * x + 1] = samples[src + 3 * x + 1]; row[3 * x + 2] = samples[src + 3 * x]; }
                        else { byte g = samples[src + x]; row[3 * x] = g; row[3 * x + 1] = g; row[3 * x + 2] = g; }
                    }
                    Marshal.Copy(row, 0, new IntPtr(bd.Scan0.ToInt64() + (long)y * bd.Stride), bd.Stride);
                }
            }
            finally { b.UnlockBits(bd); }
            return b;
        }

        private static Bitmap Resize(Bitmap src, int w, int h)
        {
            Bitmap dst = new Bitmap(w, h, PixelFormat.Format24bppRgb);
            using (Graphics g = Graphics.FromImage(dst))
            {
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                g.CompositingMode = CompositingMode.SourceCopy;
                using (ImageAttributes ia = new ImageAttributes())
                {
                    ia.SetWrapMode(WrapMode.TileFlipXY);    // no dark fringe at the edges
                    g.DrawImage(src, new Rectangle(0, 0, w, h), 0, 0, src.Width, src.Height, GraphicsUnit.Pixel, ia);
                }
            }
            return dst;
        }

        private static byte[] Jpeg(Bitmap b, int quality)
        {
            ImageCodecInfo codec = null;
            foreach (ImageCodecInfo c in ImageCodecInfo.GetImageEncoders()) if (c.FormatID == ImageFormat.Jpeg.Guid) codec = c;
            if (codec == null) return null;
            using (EncoderParameters ps = new EncoderParameters(1))
            using (MemoryStream ms = new MemoryStream())
            {
                ps.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, (long)quality);
                b.Save(ms, codec, ps);
                return ms.ToArray();
            }
        }
    }
}
