using System;

namespace Pdfx.Internal
{
    // RFC 1321 MD5. See PdfCrypt.Md5 for why this is not MD5.Create().
    internal static class Md5Hash
    {
        private static readonly int[] S =
        {
            7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22,
            5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20,
            4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23,
            6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21
        };

        private static readonly uint[] K = MakeK();

        private static uint[] MakeK()
        {
            uint[] k = new uint[64];
            for (int i = 0; i < 64; i++) k[i] = (uint)(long)Math.Floor(Math.Abs(Math.Sin(i + 1)) * 4294967296.0);
            return k;
        }

        public static byte[] Compute(byte[] data)
        {
            long bits = (long)data.Length * 8;
            int padded = ((data.Length + 8) / 64 + 1) * 64;
            byte[] m = new byte[padded];
            Buffer.BlockCopy(data, 0, m, 0, data.Length);
            m[data.Length] = 0x80;
            for (int i = 0; i < 8; i++) m[padded - 8 + i] = (byte)(bits >> (8 * i));

            uint a0 = 0x67452301, b0 = 0xefcdab89, c0 = 0x98badcfe, d0 = 0x10325476;
            uint[] w = new uint[16];
            for (int off = 0; off < padded; off += 64)
            {
                for (int i = 0; i < 16; i++)
                    w[i] = (uint)(m[off + 4 * i] | m[off + 4 * i + 1] << 8 | m[off + 4 * i + 2] << 16 | m[off + 4 * i + 3] << 24);
                uint a = a0, b = b0, c = c0, d = d0;
                for (int i = 0; i < 64; i++)
                {
                    uint f;
                    int g;
                    if (i < 16) { f = (b & c) | (~b & d); g = i; }
                    else if (i < 32) { f = (d & b) | (~d & c); g = (5 * i + 1) % 16; }
                    else if (i < 48) { f = b ^ c ^ d; g = (3 * i + 5) % 16; }
                    else { f = c ^ (b | ~d); g = (7 * i) % 16; }
                    f = f + a + K[i] + w[g];
                    a = d;
                    d = c;
                    c = b;
                    b = b + (f << S[i] | f >> (32 - S[i]));
                }
                a0 += a; b0 += b; c0 += c; d0 += d;
            }
            byte[] r = new byte[16];
            uint[] h = { a0, b0, c0, d0 };
            for (int i = 0; i < 4; i++)
                for (int j = 0; j < 4; j++) r[4 * i + j] = (byte)(h[i] >> (8 * j));
            return r;
        }
    }
}
