using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using Pdfx.Internal;

namespace Pdfx
{
    public sealed class PdfPageNumberOptions
    {
        // {page} and {total} are replaced; anything else is printed as written.
        public string Format = "Page {page} of {total}";
        // bottom-center, bottom-left, bottom-right, top-center, top-left, top-right.
        public string Position = "bottom-center";
        public double FontSize = 9;
        // Distance from the page edge, in points (72 = one inch).
        public double Margin = 28;
        // The number printed on the first numbered page.
        public int StartAt = 1;
        // Leave the first N pages (a cover, say) without a number; they still count.
        public int SkipFirstPages;
        public PdfStampOptions Style = new PdfStampOptions();
    }

    public static partial class PdfComposer
    {
        // ---- merging ---------------------------------------------------------------------

        // Merge, adding one top-level bookmark per input (its file name) with that input's own
        // bookmarks nested beneath it.
        public static void Merge(string[] inputs, string output, bool bookmarkEachFile)
        {
            if (!bookmarkEachFile) { Merge(inputs, output); return; }
            MergeCore(inputs, output, true);
        }

        // ---- page numbers ----------------------------------------------------------------

        public static void AddPageNumbers(string input, string output)
        {
            AddPageNumbers(input, output, new PdfPageNumberOptions());
        }

        public static void AddPageNumbers(string input, string output, PdfPageNumberOptions options)
        {
            if (options == null) options = new PdfPageNumberOptions();
            using (PdfDocument d = PdfDocument.Open(input))
            {
                int total = d.PageCount + options.StartAt - 1;
                Number(d, options, i => Fill(options.Format, i + options.StartAt, total));
                d.Save(output);
            }
        }

        // Bates numbering: prefix + zero-padded counter on every page, e.g. ACME000001.
        // Returns the next unused number, so a batch of files can continue the sequence.
        public static int AddBates(string input, string output, string prefix, int startNumber)
        {
            return AddBates(input, output, prefix, startNumber, 6, "bottom-right");
        }

        public static int AddBates(string input, string output, string prefix, int startNumber, int digits, string position)
        {
            if (startNumber < 0) throw new ArgumentException("the Bates number cannot be negative", "startNumber");
            if (digits < 1 || digits > 12) throw new ArgumentException("digits must be between 1 and 12", "digits");
            PdfPageNumberOptions o = new PdfPageNumberOptions();
            o.Position = position ?? "bottom-right";
            int pages;
            using (PdfDocument d = PdfDocument.Open(input))
            {
                pages = d.PageCount;
                if ((long)startNumber + pages > int.MaxValue) throw new ArgumentException("the Bates numbers would overflow", "startNumber");
                Number(d, o, i => (prefix ?? "") + (startNumber + i).ToString().PadLeft(digits, '0'));
                d.Save(output);
            }
            return startNumber + pages;
        }

        private static string Fill(string format, int page, int total)
        {
            string f = format ?? "{page}";
            f = Regex.Replace(f, @"\{page\}", page.ToString(), RegexOptions.IgnoreCase);
            return Regex.Replace(f, @"\{total\}", total.ToString(), RegexOptions.IgnoreCase);
        }

        private static void Number(PdfDocument d, PdfPageNumberOptions o, Func<int, string> label)
        {
            string pos = (o.Position ?? "").ToLowerInvariant().Replace("-", "").Replace(" ", "").Replace("_", "");
            bool top = pos.StartsWith("top", StringComparison.Ordinal);
            if (!top && !pos.StartsWith("bottom", StringComparison.Ordinal) && pos.Length > 0)
                throw new ArgumentException("unknown position '" + o.Position + "'; use bottom-center, bottom-left, bottom-right, top-center, top-left or top-right", "options");
            string side = pos.EndsWith("left", StringComparison.Ordinal) ? "left" : pos.EndsWith("right", StringComparison.Ordinal) ? "right" : "center";

            PdfStampOptions style = (o.Style ?? new PdfStampOptions()).Copy();
            style.FontSize = o.FontSize > 0 ? o.FontSize : 9;
            style.Rotation = 0;
            List<string> labels = new List<string>();
            bool plain = true;
            for (int i = 0; i < d.PageCount; i++) { labels.Add(label(i)); if (!PdfStamp.Plain(labels[i])) plain = false; }
            // One embedded font for every page when the labels need one.
            EmbeddedFont font = plain ? null : EmbeddedFont.Load(false);

            for (int i = 0; i < d.PageCount; i++)
            {
                if (i < o.SkipFirstPages) continue;
                PdfPage p = d.GetPage(i);
                string text = labels[i];
                double w = font == null ? PdfStamp.MeasureText(text, style.FontName, style.FontSize) : PdfStamp.Measure(text, style.FontSize, font);
                double x = side == "left" ? o.Margin : side == "right" ? p.VisibleWidth - o.Margin - w : (p.VisibleWidth - w) / 2;
                double y = top ? p.VisibleHeight - o.Margin - style.FontSize : o.Margin;
                PdfStamp.AddText(p, text, x, y, style, font);
            }
            if (font != null) font.Finish();
        }

        // ---- watermark -------------------------------------------------------------------

        // Diagonal text across every page (e.g. COPY, ANULAT). options: size, colour, opacity;
        // null = 48 pt grey at 15% opacity. One embedded font serves all pages when needed.
        public static void AddWatermark(string input, string output, string text, PdfStampOptions options)
        {
            if (string.IsNullOrEmpty(text) || text.Trim().Length == 0) throw new ArgumentException("the watermark text is empty", "text");
            using (PdfDocument d = PdfDocument.Open(input))
            {
                EmbeddedFont font = PdfStamp.Plain(text) ? null : EmbeddedFont.Load(false);
                for (int i = 0; i < d.PageCount; i++) PdfStamp.AddWatermark(d.GetPage(i), text, options, font);
                if (font != null) font.Finish();
                d.Save(output);
            }
        }

        // ---- splitting -------------------------------------------------------------------

        // Every N pages into its own file: prefix0001.pdf, prefix0002.pdf, ...
        public static string[] SplitEvery(string input, string outputFolder, int pagesPerFile, string prefix)
        {
            if (pagesPerFile < 1) throw new ArgumentException("pagesPerFile must be at least 1", "pagesPerFile");
            using (PdfDocument src = PdfDocument.Open(input))
            {
                List<int> starts = new List<int>();
                for (int i = 0; i < src.PageCount; i += pagesPerFile) starts.Add(i);
                return WriteParts(src, starts, null, outputFolder, prefix);
            }
        }

        // A new file starts at every page whose text contains marker (case and spacing ignored).
        // Pages before the first marker form the first file.
        public static string[] SplitByText(string input, string outputFolder, string marker, string prefix)
        {
            if (string.IsNullOrEmpty(marker) || marker.Trim().Length == 0) throw new ArgumentException("the marker text is empty", "marker");
            string m = Squash(marker);
            using (PdfDocument src = PdfDocument.Open(input))
            {
                List<int> starts = new List<int> { 0 };
                for (int i = 1; i < src.PageCount; i++)
                    if (Squash(PdfText.Extract(src.GetPage(i))).IndexOf(m, StringComparison.OrdinalIgnoreCase) >= 0) starts.Add(i);
                return WriteParts(src, starts, null, outputFolder, prefix);
            }
        }

        // A new file starts at every page matching the regular expression, and is named after
        // the match: its first group if it has one (e.g. @"Client no\.?\s*(\d+)" -> 1234567.pdf).
        // Pages before the first match go to "_start.pdf". Same names get " (2)".
        public static string[] SplitByPattern(string input, string outputFolder, string pattern)
        {
            if (string.IsNullOrEmpty(pattern)) throw new ArgumentException("the pattern is empty", "pattern");
            Regex rx = new Regex(pattern, RegexOptions.IgnoreCase | RegexOptions.CultureInvariant, TimeSpan.FromSeconds(5));
            using (PdfDocument src = PdfDocument.Open(input))
            {
                List<int> starts = new List<int>();
                List<string> names = new List<string>();
                for (int i = 0; i < src.PageCount; i++)
                {
                    Match mt;
                    try { mt = rx.Match(Squash(PdfText.Extract(src.GetPage(i)))); }
                    catch (RegexMatchTimeoutException)
                    {
                        throw new Internal.PdfException("the pattern took too long on page " + (i + 1) + "; simplify it (avoid nested repeats like (a+)+)");
                    }
                    if (!mt.Success) continue;
                    starts.Add(i);
                    string n = mt.Groups.Count > 1 && mt.Groups[1].Success ? mt.Groups[1].Value : mt.Value;
                    names.Add(n.Trim().Length == 0 ? "match" : n.Trim());
                }
                if (starts.Count == 0) throw new Internal.PdfException("the pattern matched no page, so there is nothing to split on");
                if (starts[0] != 0) { starts.Insert(0, 0); names.Insert(0, "_start"); }
                return WriteParts(src, starts, names, outputFolder, null);
            }
        }

        // One file per top-level bookmark, named after it.
        public static string[] SplitByBookmarks(string input, string outputFolder)
        {
            using (PdfDocument src = PdfDocument.Open(input))
            {
                SortedDictionary<int, string> at = new SortedDictionary<int, string>();
                foreach (PdfBookmark b in src.Bookmarks)
                    if (b.PageIndex >= 0 && !at.ContainsKey(b.PageIndex)) at[b.PageIndex] = b.Title;
                if (at.Count == 0) throw new Internal.PdfException("the document has no bookmarks that point at a page");
                List<int> starts = new List<int>(at.Keys);
                List<string> names = new List<string>(at.Values);
                if (starts[0] != 0) { starts.Insert(0, 0); names.Insert(0, "_start"); }
                return WriteParts(src, starts, names, outputFolder, null);
            }
        }

        private static string[] WriteParts(PdfDocument src, List<int> starts, List<string> names, string folder, string prefix)
        {
            folder = OutputFolder(folder);
            List<string> made = new List<string>();
            for (int k = 0; k < starts.Count; k++)
            {
                int first = starts[k], last = k + 1 < starts.Count ? starts[k + 1] - 1 : src.PageCount - 1;
                // A matched value such as "a/b" names a file, not a path: separators become "_".
                string name = names != null ? PdfAttachmentIo.SafeName(names[k].Replace('/', '_').Replace('\\', '_')) : (prefix ?? "part") + (k + 1).ToString("D4");
                if (!name.EndsWith(".pdf", StringComparison.OrdinalIgnoreCase)) name += ".pdf";
                string path = names != null ? FreeIn(folder, name, made) : Path.Combine(folder, name);
                using (PdfDocument part = src.ExtractPages(first, last)) part.Save(path);
                made.Add(path);
            }
            return made.ToArray();
        }

        // Unique among the files this call made (an older file of the same name is replaced,
        // as with every other output).
        private static string FreeIn(string folder, string name, List<string> made)
        {
            string path = Path.Combine(folder, name);
            for (int n = 2; made.Contains(path); n++)
                path = Path.Combine(folder, Path.GetFileNameWithoutExtension(name) + " (" + n + ")" + Path.GetExtension(name));
            return path;
        }

        private static string Squash(string s)
        {
            StringBuilder sb = new StringBuilder(s.Length);
            bool space = false;
            foreach (char c in s)
            {
                if (char.IsWhiteSpace(c)) { space = sb.Length > 0; continue; }
                if (space) { sb.Append(' '); space = false; }
                sb.Append(c);
            }
            return sb.ToString();
        }

        // ---- attachments -----------------------------------------------------------------

        public static void AddAttachments(string input, string[] files, string output)
        {
            AddAttachments(input, files, output, null);
        }

        // relationship: for PDF/A-3 (Source, Data, Alternative, Supplement; default Unspecified).
        public static void AddAttachments(string input, string[] files, string output, string relationship)
        {
            if (files == null || files.Length == 0) throw new ArgumentException("no files to attach", "files");
            using (PdfDocument d = PdfDocument.Open(input))
            {
                foreach (string f in files)
                {
                    PdfAttachment a = d.AddAttachment(f);
                    if (relationship != null) a.Relationship = PdfAttachmentIo.Relationship(relationship);
                }
                d.Save(output);
            }
        }

        // Every embedded file, including those pinned to a page as a paperclip annotation.
        // Returns the paths written; names are made safe and never overwrite each other.
        public static string[] ExtractAttachments(string input, string outputFolder)
        {
            if (outputFolder == null) throw new ArgumentNullException("outputFolder");
            List<string> made = new List<string>();
            HashSet<string> taken = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            using (PdfDocument d = PdfDocument.Open(input))
            {
                foreach (PdfAttachment a in d.Attachments) made.Add(a.SaveToFolder(outputFolder, taken));
                for (int i = 0; i < d.PageCount; i++)
                {
                    PdfPage p = d.GetPage(i);
                    if (p.Source == null) continue;
                    PdfArray annots = p.Source.Resolve(p.Dict.Get("Annots")) as PdfArray;
                    if (annots == null) continue;
                    foreach (PdfObject a in annots.Items)
                    {
                        PdfDictionary ad = p.Source.Resolve(a) as PdfDictionary;
                        PdfName sub = ad == null ? null : p.Source.Resolve(ad.Get("Subtype")) as PdfName;
                        if (sub == null || sub.Value != "FileAttachment") continue;
                        PdfAttachment fa = PdfAttachmentIo.FromSpec(p.Source, ad.Get("FS"), null);
                        if (fa != null) made.Add(fa.SaveToFolder(outputFolder, taken));
                    }
                }
            }
            return made.ToArray();
        }
    }
}
