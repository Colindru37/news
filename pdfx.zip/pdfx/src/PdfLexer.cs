using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace Pdfx.Internal
{
    public enum TokenType { Number, Name, String, ArrayStart, ArrayEnd, DictStart, DictEnd, Keyword, Eof }

    public struct Token
    {
        public TokenType Type;
        public double Number;
        public bool IsInteger;
        public string Text;
        public byte[] Bytes;
        public bool WasHex;
    }

    public sealed class PdfLexer
    {
        public readonly byte[] Data;
        public int Position;

        public PdfLexer(byte[] data) { Data = data; Position = 0; }

        public static bool IsWhite(byte b)
        {
            return b == 0 || b == 9 || b == 10 || b == 12 || b == 13 || b == 32;
        }

        public static bool IsDelim(byte b)
        {
            return b == (byte)'(' || b == (byte)')' || b == (byte)'<' || b == (byte)'>'
                || b == (byte)'[' || b == (byte)']' || b == (byte)'{' || b == (byte)'}'
                || b == (byte)'/' || b == (byte)'%';
        }

        public static bool IsRegular(byte b) { return !IsWhite(b) && !IsDelim(b); }

        private static bool IsHexDigit(byte b)
        {
            return (b >= (byte)'0' && b <= (byte)'9')
                || (b >= (byte)'a' && b <= (byte)'f')
                || (b >= (byte)'A' && b <= (byte)'F');
        }

        private static int HexVal(byte b)
        {
            if (b >= (byte)'0' && b <= (byte)'9') return b - (byte)'0';
            if (b >= (byte)'a' && b <= (byte)'f') return b - (byte)'a' + 10;
            return b - (byte)'A' + 10;
        }

        public void SkipWhite()
        {
            while (Position < Data.Length)
            {
                byte b = Data[Position];
                if (IsWhite(b)) { Position++; continue; }
                if (b == (byte)'%')
                {
                    while (Position < Data.Length && Data[Position] != 13 && Data[Position] != 10) Position++;
                    continue;
                }
                break;
            }
        }

        public Token Next()
        {
            SkipWhite();
            Token t = new Token();
            if (Position >= Data.Length) { t.Type = TokenType.Eof; return t; }

            byte b = Data[Position];

            if (b == (byte)'[') { Position++; t.Type = TokenType.ArrayStart; return t; }
            if (b == (byte)']') { Position++; t.Type = TokenType.ArrayEnd; return t; }

            if (b == (byte)'<')
            {
                if (Position + 1 < Data.Length && Data[Position + 1] == (byte)'<')
                {
                    Position += 2; t.Type = TokenType.DictStart; return t;
                }
                Position++;
                t.Type = TokenType.String; t.WasHex = true; t.Bytes = ReadHexString();
                return t;
            }

            if (b == (byte)'>')
            {
                if (Position + 1 < Data.Length && Data[Position + 1] == (byte)'>')
                {
                    Position += 2; t.Type = TokenType.DictEnd; return t;
                }
                Position++; t.Type = TokenType.Keyword; t.Text = ">"; return t;
            }

            if (b == (byte)'(')
            {
                Position++;
                t.Type = TokenType.String; t.WasHex = false; t.Bytes = ReadLiteralString();
                return t;
            }

            if (b == (byte)'/')
            {
                Position++;
                t.Type = TokenType.Name; t.Text = ReadName();
                return t;
            }

            if (b == (byte)'{' || b == (byte)'}' || b == (byte)')')
            {
                Position++; t.Type = TokenType.Keyword; t.Text = ((char)b).ToString(); return t;
            }

            if (b == (byte)'+' || b == (byte)'-' || b == (byte)'.' || (b >= (byte)'0' && b <= (byte)'9'))
                return ReadNumber();

            int s = Position;
            while (Position < Data.Length && IsRegular(Data[Position])) Position++;
            if (Position == s) { Position++; t.Type = TokenType.Keyword; t.Text = ((char)b).ToString(); return t; }
            t.Type = TokenType.Keyword;
            t.Text = Encoding.ASCII.GetString(Data, s, Position - s);
            return t;
        }

        private Token ReadNumber()
        {
            int s = Position;
            bool isInt = true;
            if (Position < Data.Length && (Data[Position] == (byte)'+' || Data[Position] == (byte)'-')) Position++;
            while (Position < Data.Length)
            {
                byte c = Data[Position];
                if (c >= (byte)'0' && c <= (byte)'9') { Position++; continue; }
                if (c == (byte)'.') { isInt = false; Position++; continue; }
                if (c == (byte)'+' || c == (byte)'-') { Position++; continue; }
                break;
            }
            string text = Encoding.ASCII.GetString(Data, s, Position - s);
            double v;
            if (!double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out v))
                v = ParseLoose(text);

            Token t = new Token();
            t.Type = TokenType.Number;
            t.Number = v;
            t.IsInteger = isInt;
            return t;
        }

        private static double ParseLoose(string s)
        {
            StringBuilder sb = new StringBuilder();
            bool dot = false;
            for (int i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if (c == '-' || c == '+')
                {
                    if (sb.Length == 0) { if (c == '-') sb.Append(c); }
                    else break;
                }
                else if (c == '.')
                {
                    if (dot) break;
                    dot = true; sb.Append(c);
                }
                else if (c >= '0' && c <= '9') sb.Append(c);
                else break;
            }
            double v;
            double.TryParse(sb.ToString(), NumberStyles.Float, CultureInfo.InvariantCulture, out v);
            return v;
        }

        private string ReadName()
        {
            StringBuilder sb = new StringBuilder();
            while (Position < Data.Length)
            {
                byte c = Data[Position];
                if (!IsRegular(c)) break;
                if (c == (byte)'#' && Position + 2 < Data.Length
                    && IsHexDigit(Data[Position + 1]) && IsHexDigit(Data[Position + 2]))
                {
                    int v = HexVal(Data[Position + 1]) * 16 + HexVal(Data[Position + 2]);
                    sb.Append((char)v);
                    Position += 3;
                    continue;
                }
                sb.Append((char)c);
                Position++;
            }
            return sb.ToString();
        }

        private byte[] ReadHexString()
        {
            List<byte> outp = new List<byte>();
            int hi = -1;
            while (Position < Data.Length)
            {
                byte c = Data[Position++];
                if (c == (byte)'>') break;
                if (IsWhite(c)) continue;
                if (!IsHexDigit(c)) continue;
                int v = HexVal(c);
                if (hi < 0) hi = v;
                else { outp.Add((byte)(hi * 16 + v)); hi = -1; }
            }
            if (hi >= 0) outp.Add((byte)(hi * 16));
            return outp.ToArray();
        }

        private byte[] ReadLiteralString()
        {
            List<byte> outp = new List<byte>();
            int depth = 1;
            while (Position < Data.Length)
            {
                byte c = Data[Position++];

                if (c == (byte)'\\')
                {
                    if (Position >= Data.Length) break;
                    byte e = Data[Position++];
                    if (e == (byte)'n') { outp.Add(10); continue; }
                    if (e == (byte)'r') { outp.Add(13); continue; }
                    if (e == (byte)'t') { outp.Add(9); continue; }
                    if (e == (byte)'b') { outp.Add(8); continue; }
                    if (e == (byte)'f') { outp.Add(12); continue; }
                    if (e == (byte)'(') { outp.Add((byte)'('); continue; }
                    if (e == (byte)')') { outp.Add((byte)')'); continue; }
                    if (e == (byte)'\\') { outp.Add((byte)'\\'); continue; }
                    if (e == 13) { if (Position < Data.Length && Data[Position] == 10) Position++; continue; }
                    if (e == 10) { continue; }
                    if (e >= (byte)'0' && e <= (byte)'7')
                    {
                        int v = e - (byte)'0';
                        for (int k = 0; k < 2 && Position < Data.Length
                                        && Data[Position] >= (byte)'0' && Data[Position] <= (byte)'7'; k++)
                        {
                            v = v * 8 + (Data[Position] - (byte)'0');
                            Position++;
                        }
                        outp.Add((byte)(v & 0xFF));
                        continue;
                    }
                    outp.Add(e);
                    continue;
                }

                if (c == 13)
                {
                    if (Position < Data.Length && Data[Position] == 10) Position++;
                    outp.Add(10);
                    continue;
                }

                if (c == (byte)'(') { depth++; outp.Add(c); continue; }
                if (c == (byte)')')
                {
                    depth--;
                    if (depth == 0) break;
                    outp.Add(c);
                    continue;
                }

                outp.Add(c);
            }
            return outp.ToArray();
        }
    }
}
