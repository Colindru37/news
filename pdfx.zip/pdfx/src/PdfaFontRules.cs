using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;

namespace Pdfx.Internal
{
    internal sealed partial class PdfaJob
    {
        private static bool IsSubsetName(string n)
        {
            if (n == null || n.Length < 8 || n[6] != '+') return false;
            for (int i = 0; i < 6; i++) if (n[i] < 'A' || n[i] > 'Z') return false;
            return true;
        }

        private byte[] Decoded(PdfStream s)
        {
            try { return PdfaDecode.Decode(s, _o); } catch { return null; }
        }

        private void Restore(PdfStream s, byte[] plain, bool setLength1)
        {
            s.RawData = PdfaFontFixer.Deflate(plain);
            s.Dict.Set("Filter", new PdfName("FlateDecode"));
            s.Dict.Remove("DecodeParms");
            if (setLength1) s.Dict.Set("Length1", new PdfNumber(plain.Length, true));
        }

        // PDF/A-1 font program rules that later parts relaxed.
        private void FixEmbeddedSimpleForPart1(PdfDictionary font, PdfDictionary fd, string sub)
        {
            PdfNumber fl = R(fd.Get("Flags")) as PdfNumber;
            bool symbolic = fl != null && (fl.AsInt & 4) != 0;
            PdfStream ff2 = R(fd.Get("FontFile2")) as PdfStream;
            if (sub == "TrueType" && symbolic && ff2 != null)
            {
                byte[] prog = Decoded(ff2);
                byte[] one = prog == null ? null : PdfaFontPrograms.KeepOneCmap(prog);
                if (one != null) Restore(ff2, one, true);
            }
            string baseFont = Name(font.Get("BaseFont"));
            if ((sub == "Type1" || sub == "MMType1") && IsSubsetName(baseFont) && !(R(fd.Get("CharSet")) is PdfString))
            {
                List<string> names = null;
                PdfStream ff = R(fd.Get("FontFile")) as PdfStream;
                PdfStream ff3 = R(fd.Get("FontFile3")) as PdfStream;
                try
                {
                    if (ff != null)
                    {
                        byte[] prog = Decoded(ff);
                        PdfNumber l1 = R(ff.Dict.Get("Length1")) as PdfNumber;
                        if (prog != null) names = PdfaFontPrograms.Type1Glyphs(prog, l1 == null ? -1 : l1.AsInt);
                    }
                    else if (ff3 != null)
                    {
                        byte[] prog = Decoded(ff3);
                        List<int> cids;
                        if (prog != null) PdfaFontPrograms.CffGlyphs(prog, out names, out cids);
                    }
                }
                catch { names = null; }
                if (names != null)
                    fd.Set("CharSet", new PdfString(Encoding.ASCII.GetBytes(PdfaFontPrograms.CharSet(names)), false));
                else WarnOnce("could not list the glyphs of subset font " + baseFont + " (PDF/A-1 wants a CharSet)");
            }
        }

        private void FixCidForPart1(PdfDictionary type0, PdfDictionary cid, PdfDictionary fd)
        {
            if (fd == null || fd.Has("CIDSet")) return;
            string baseFont = Name(type0.Get("BaseFont")) ?? Name(cid.Get("BaseFont"));
            if (!IsSubsetName(baseFont)) return;
            byte[] bits = null;
            try
            {
                PdfStream ff2 = R(fd.Get("FontFile2")) as PdfStream;
                PdfStream ff3 = R(fd.Get("FontFile3")) as PdfStream;
                if (ff2 != null)
                {
                    byte[] prog = Decoded(ff2);
                    PdfStream map = R(cid.Get("CIDToGIDMap")) as PdfStream;
                    byte[] mapBytes = map == null ? null : Decoded(map);
                    if (prog != null) bits = PdfaFontPrograms.CidSetTrueType(prog, mapBytes);
                }
                else if (ff3 != null)
                {
                    byte[] prog = Decoded(ff3);
                    List<string> names; List<int> cids;
                    if (prog != null)
                    {
                        PdfaFontPrograms.CffGlyphs(prog, out names, out cids);
                        if (cids == null && names != null) { cids = new List<int>(); for (int i = 0; i < names.Count; i++) cids.Add(i); }
                        if (cids != null) bits = PdfaFontPrograms.CidSetFromCids(cids);
                    }
                }
            }
            catch { bits = null; }
            if (bits == null) { WarnOnce("could not build a CIDSet for " + baseFont + " (PDF/A-1 wants one)"); return; }
            PdfDictionary d = new PdfDictionary();
            d.Set("Filter", new PdfName("FlateDecode"));
            fd.Set("CIDSet", new PdfRef(_o.AddObject(new PdfStream(d, PdfaFontFixer.Deflate(bits))), 0));
        }

        // ---- PDF/A-1 colour profiles -------------------------------------------------

        private int _profilesReplaced;

        private void FixIccForPart1(PdfStream s)
        {
            if (_part != 1 || !s.Dict.Has("N") || s.Dict.Has("Subtype") || s.Dict.Has("Type")) return;
            byte[] data = Decoded(s);
            if (data == null || data.Length < 128 || data[36] != 'a' || data[37] != 'c' || data[38] != 's' || data[39] != 'p') return;
            if (data[8] <= 2) return;
            PdfNumber n = R(s.Dict.Get("N")) as PdfNumber;
            string space = Encoding.ASCII.GetString(data, 16, 4);
            byte[] repl = null;
            if (n != null && n.AsInt == 3 && space == "RGB ") repl = PdfaIcc.Srgb();
            else if (n != null && n.AsInt == 1 && space == "GRAY") repl = PdfaIcc.Gray();
            else if (n != null && n.AsInt == 4 && space == "CMYK") repl = PdfaIcc.Cmyk();
            if (repl == null)
                throw new PdfException("document uses an ICC v" + data[8] + " " + space.Trim() + " colour profile that PDF/A-1 cannot carry; convert to PDF/A-2 instead");
            Restore(s, repl, false);
            if (_profilesReplaced++ == 0)
                _warn.Add("replaced ICC v4 colour profiles with v2 equivalents (PDF/A-1 predates v4); colours may shift slightly");
        }

        // ---- PDF/A-1 numeric limits in content streams --------------------------------

        private readonly HashSet<PdfStream> _content = new HashSet<PdfStream>();

        private void CollectContentStreams()
        {
            foreach (PdfDictionary page in _pages)
            {
                PdfObject c = R(page.Get("Contents"));
                if (c is PdfStream) _content.Add((PdfStream)c);
                PdfArray arr = c as PdfArray;
                if (arr != null) for (int i = 0; i < arr.Count; i++) { PdfStream s = R(arr[i]) as PdfStream; if (s != null) _content.Add(s); }
            }
            for (int i = 1; i <= _o.Count; i++)
            {
                PdfObject o = _o.GetObject(i);
                PdfStream s = o as PdfStream;
                if (s != null)
                {
                    if (Name(s.Dict.Get("Subtype")) == "Form") _content.Add(s);
                    PdfNumber pt = R(s.Dict.Get("PatternType")) as PdfNumber;
                    if (pt != null && pt.AsInt == 1) _content.Add(s);
                }
                PdfDictionary d = o as PdfDictionary;
                if (d != null && Name(d.Get("Subtype")) == "Type3")
                {
                    PdfDictionary procs = R(d.Get("CharProcs")) as PdfDictionary;
                    if (procs != null)
                        foreach (KeyValuePair<string, PdfObject> kv in procs.Map) { PdfStream p = R(kv.Value) as PdfStream; if (p != null) _content.Add(p); }
                }
            }
        }

        // A real beyond +/-32767 inside an array is a TJ adjustment; it is split into
        // several adjustments that sum to the same displacement.
        private void FixContentLimits()
        {
            CollectContentStreams();
            foreach (PdfStream s in _content)
            {
                byte[] data = Decoded(s);
                if (data == null) continue;
                PdfaLexer lx = new PdfaLexer(data);
                List<int[]> spans = new List<int[]>();
                List<string> repl = new List<string>();
                int depth = 0;
                bool tooBig = false;
                while (true)
                {
                    PdfaToken t = lx.Next();
                    if (t.Kind == PdfaTok.Eof) break;
                    if (t.Kind == PdfaTok.ArrayStart) depth++;
                    else if (t.Kind == PdfaTok.ArrayEnd) depth--;
                    else if (t.Kind == PdfaTok.Number && Math.Abs(t.Number) > 32767)
                    {
                        if (depth > 0)
                        {
                            spans.Add(new[] { t.Start, t.End });
                            repl.Add(Split(t.Number));
                        }
                        else tooBig = true;
                    }
                }
                if (tooBig) WarnOnce("a content stream has a coordinate beyond PDF/A-1's 32767 limit");
                if (spans.Count == 0) continue;
                MemoryStream ms = new MemoryStream();
                int at = 0;
                for (int i = 0; i < spans.Count; i++)
                {
                    ms.Write(data, at, spans[i][0] - at);
                    byte[] r = Encoding.ASCII.GetBytes(repl[i]);
                    ms.Write(r, 0, r.Length);
                    at = spans[i][1];
                }
                ms.Write(data, at, data.Length - at);
                Restore(s, ms.ToArray(), false);
            }
        }

        private static string Split(double v)
        {
            StringBuilder sb = new StringBuilder();
            double sign = v < 0 ? -1 : 1;
            double rest = Math.Abs(v);
            while (rest > 32767)
            {
                sb.Append(sign < 0 ? "-32767 " : "32767 ");
                rest -= 32767;
            }
            sb.Append((sign * rest).ToString("0.###", CultureInfo.InvariantCulture));
            return sb.ToString();
        }

        // ---- Unicode (U and A levels) ------------------------------------------------

        private void EnsureUnicode(PdfaFontFixer fixer)
        {
            int unknown = 0;
            foreach (KeyValuePair<PdfDictionary, HashSet<int>> kv in _scan.Codes)
            {
                PdfDictionary font = kv.Key;
                string sub = Name(font.Get("Subtype"));
                bool twoByte = sub == "Type0";
                if (twoByte)
                {
                    string enc = Name(R(font.Get("Encoding")));
                    if (enc != "Identity-H" && enc != "Identity-V") continue;
                }
                Dictionary<int, int> have = fixer.ReadToUnicode(font);
                List<int> missing = new List<int>();
                foreach (int c in kv.Value)
                {
                    int u;
                    if (!have.TryGetValue(c, out u) || u <= 0 || u == 0xFEFF || u == 0xFFFE) missing.Add(c);
                }
                if (missing.Count == 0) continue;
                missing.Sort();
                Dictionary<int, int> add = new Dictionary<int, int>();
                foreach (int c in missing)
                {
                    int u = Derive(fixer, font, sub, c);
                    if (u <= 0 || u == 0xFEFF || u == 0xFFFE) { u = 0xFFFD; unknown++; }
                    add[c] = u;
                }
                fixer.AddToUnicode(font, add, twoByte);
            }
            if (_conf == 'A') unknown += FixPrivateUse(fixer);
            if (unknown > 0)
                _warn.Add(unknown + " character(s) have no known Unicode meaning in the source; mapped to U+FFFD");
        }

        // Level A forbids Private Use Area code points without ActualText. Symbol-font
        // characters (Word maps them to U+F0xx) are restored through the Symbol encoding;
        // anything else in the PUA has no standard meaning and becomes U+FFFD.
        private int FixPrivateUse(PdfaFontFixer fixer)
        {
            int unknown = 0;
            string[] symbol = PdfaGlyphs.Encoding("Symbol");
            foreach (KeyValuePair<PdfDictionary, HashSet<int>> kv in _scan.Codes)
            {
                PdfDictionary font = kv.Key;
                bool twoByte = Name(font.Get("Subtype")) == "Type0";
                Dictionary<int, int> have = fixer.ReadToUnicode(font);
                string bf = (Name(font.Get("BaseFont")) ?? "").ToLowerInvariant();
                Dictionary<int, int> fix = new Dictionary<int, int>();
                bool isSymbol = bf.Contains("symbol") || (!twoByte && HasSymbolMetrics(font, kv.Value, have));
                foreach (int c in kv.Value)
                {
                    int u;
                    if (!have.TryGetValue(c, out u) || u < 0xE000 || u > 0xF8FF) continue;
                    int r = -1;
                    if (isSymbol && u >= 0xF020 && u <= 0xF0FF) r = PdfaGlyphs.Unicode(symbol[u - 0xF000]);
                    if (r <= 0 || (r >= 0xE000 && r <= 0xF8FF)) r = ProgramGlyphUnicode(font, c);
                    if (r <= 0 || (r >= 0xE000 && r <= 0xF8FF)) { r = 0xFFFD; unknown++; }
                    fix[c] = r;
                }
                if (fix.Count > 0) fixer.AddToUnicode(font, fix, twoByte);
            }
            return unknown;
        }

        private static int[] _symbolWidths;

        // Word writes Symbol characters as U+F0xx and subset producers can anonymise the font
        // name ("font000000002e0c3485"). The widths still give it away: every used private-use
        // code must carry Adobe Symbol's advance for that character. One match on a round width
        // (250, 500, 1000) is too weak to call; two or more, or one distinctive width, is not.
        private bool HasSymbolMetrics(PdfDictionary font, HashSet<int> used, Dictionary<int, int> have)
        {
            if (_symbolWidths == null)
            {
                string[] p = PdfaTables.SymbolWidths.Split(' ');
                int[] w = new int[p.Length];
                for (int i = 0; i < p.Length; i++) w[i] = int.Parse(p[i], CultureInfo.InvariantCulture);
                _symbolWidths = w;
            }
            PdfArray widths = R(font.Get("Widths")) as PdfArray;
            PdfNumber first = R(font.Get("FirstChar")) as PdfNumber;
            if (widths == null || first == null) return false;
            int matched = 0, lastWidth = 0;
            foreach (int c in used)
            {
                int u;
                if (!have.TryGetValue(c, out u) || u < 0xE000 || u > 0xF8FF) continue;
                if (u < 0xF020 || u > 0xF0FF) return false;
                int sw = _symbolWidths[u - 0xF000];
                int i = c - first.AsInt;
                PdfNumber w = i >= 0 && i < widths.Count ? R(widths[i]) as PdfNumber : null;
                if (sw == 0 || w == null || Math.Abs(w.Value - sw) > 1) return false;
                matched++;
                lastWidth = sw;
            }
            return matched >= 2 || (matched == 1 && lastWidth % 50 != 0);
        }

        // The embedded TrueType program's own name for the glyph a code draws.
        private int ProgramGlyphUnicode(PdfDictionary font, int code)
        {
            PdfDictionary fd = R(font.Get("FontDescriptor")) as PdfDictionary;
            int gid;
            if (Name(font.Get("Subtype")) == "Type0")
            {
                PdfArray desc = R(font.Get("DescendantFonts")) as PdfArray;
                PdfDictionary cid = desc == null ? null : R(desc[0]) as PdfDictionary;
                if (cid == null) return -1;
                fd = R(cid.Get("FontDescriptor")) as PdfDictionary;
                gid = code;
                PdfStream map = R(cid.Get("CIDToGIDMap")) as PdfStream;
                if (map != null)
                {
                    byte[] m = Decoded(map);
                    gid = m != null && 2 * code + 1 < m.Length ? m[2 * code] << 8 | m[2 * code + 1] : 0;
                }
            }
            else
            {
                PdfaTrueType t0 = Program(fd);
                gid = t0 == null ? 0 : t0.GlyphForCode(code);
            }
            PdfaTrueType t = Program(fd);
            if (t == null || gid == 0) return -1;
            return PdfaGlyphs.Unicode(t.GlyphName(gid));
        }

        // ---- logical structure (A levels) --------------------------------------------

        private static readonly string[] Std14 = { "Document", "Part", "Art", "Sect", "Div", "BlockQuote", "Caption", "TOC", "TOCI",
            "Index", "NonStruct", "Private", "P", "H", "H1", "H2", "H3", "H4", "H5", "H6", "L", "LI", "Lbl", "LBody", "Table", "TR",
            "TH", "TD", "Span", "Quote", "Note", "Reference", "BibEntry", "Code", "Link", "Figure", "Formula", "Form" };
        private static readonly string[] Std17 = { "THead", "TBody", "TFoot", "Annot", "Ruby", "RB", "RT", "RP", "Warichu", "WT", "WP" };

        private bool IsStandard(string t)
        {
            return Array.IndexOf(Std14, t) >= 0 || (_part > 1 && Array.IndexOf(Std17, t) >= 0);
        }

        private void Structure()
        {
            PdfDictionary root = R(_cat.Get("StructTreeRoot")) as PdfDictionary;
            bool tagged = root != null && ReferencesContent(root.Get("K"), new HashSet<PdfObject>(), 0);
            if (root != null && !tagged)
            {
                _cat.Remove("StructTreeRoot");
                _warn.Add("discarded an empty structure tree left by the producing application");
            }
            else if (tagged && !Linked(root))
            {
                tagged = false;
                _cat.Remove("StructTreeRoot");
                _cat.Remove("MarkInfo");
                _warn.Add("discarded a structure tree that no longer reaches its content (the file was re-imposed after tagging)");
            }
            if (tagged) FixRoleMap(root);
            else
            {
                foreach (PdfDictionary page in _pages) page.Remove("StructParents");
                PdfaTagger tagger = new PdfaTagger(_o, _part);
                PdfaFontFixer reader = new PdfaFontFixer(_o, _opt, _warn);
                tagger._unicode = reader.ReadToUnicode;
                tagger.Tag(_cat, _pages, _pageRes, _opt.Language);
                _warn.Add("added logical structure (headings, paragraphs, figures) inferred from layout");
            }
            PdfDictionary mi = R(_cat.Get("MarkInfo")) as PdfDictionary ?? new PdfDictionary();
            mi.Set("Marked", PdfBool.True);
            mi.Remove("Suspects");
            _cat.Set("MarkInfo", mi);
            if (!(R(_cat.Get("Lang")) is PdfString) && !string.IsNullOrEmpty(_opt.Language))
                _cat.Set("Lang", Text(_opt.Language));
        }

        // A structure tree is only real if it reaches marked content or an annotation.
        private bool ReferencesContent(PdfObject k, HashSet<PdfObject> seen, int depth)
        {
            if (k == null || depth > 200) return false;
            if (k is PdfNumber) return true;
            PdfObject v = R(k);
            if (v is PdfNumber) return true;
            if (v == null || !seen.Add(v)) return false;
            PdfArray a = v as PdfArray;
            if (a != null) { for (int i = 0; i < a.Count; i++) if (ReferencesContent(a[i], seen, depth + 1)) return true; return false; }
            PdfDictionary d = v as PdfDictionary;
            if (d == null) return false;
            string type = Name(d.Get("Type"));
            if (type == "MCR" || type == "OBJR") return true;
            return ReferencesContent(d.Get("K"), seen, depth + 1);
        }

        // Every content stream that carries MCIDs must be reachable through the parent
        // tree via its StructParents key, or its marked content belongs to nothing.
        private bool Linked(PdfDictionary root)
        {
            HashSet<int> keys = new HashSet<int>();
            CollectNumKeys(R(root.Get("ParentTree")) as PdfDictionary, keys, 0);
            foreach (PdfDictionary page in _pages)
                if (Contains(PageContent(page), "/MCID") && !HasKey(page, keys)) return false;
            for (int i = 1; i <= _o.Count; i++)
            {
                PdfStream x = _o.GetObject(i) as PdfStream;
                if (x == null || Name(x.Dict.Get("Subtype")) != "Form") continue;
                if (Contains(Decoded(x), "/MCID") && !HasKey(x.Dict, keys)) return false;
            }
            return true;
        }

        private bool HasKey(PdfDictionary d, HashSet<int> keys)
        {
            PdfNumber n = R(d.Get("StructParents")) as PdfNumber;
            return n != null && keys.Contains(n.AsInt);
        }

        private void CollectNumKeys(PdfDictionary node, HashSet<int> keys, int depth)
        {
            if (node == null || depth > 32) return;
            PdfArray nums = R(node.Get("Nums")) as PdfArray;
            if (nums != null) for (int i = 0; i + 1 < nums.Count; i += 2) { PdfNumber k = R(nums[i]) as PdfNumber; if (k != null) keys.Add(k.AsInt); }
            PdfArray kids = R(node.Get("Kids")) as PdfArray;
            if (kids != null) for (int i = 0; i < kids.Count; i++) CollectNumKeys(R(kids[i]) as PdfDictionary, keys, depth + 1);
        }

        private static bool Contains(byte[] data, string needle)
        {
            if (data == null) return false;
            byte[] n = Encoding.ASCII.GetBytes(needle);
            for (int i = 0; i + n.Length <= data.Length; i++)
            {
                int k = 0;
                while (k < n.Length && data[i + k] == n[k]) k++;
                if (k == n.Length) return true;
            }
            return false;
        }

        private void FixRoleMap(PdfDictionary root)
        {
            HashSet<string> types = new HashSet<string>();
            CollectTypes(root.Get("K"), types, new HashSet<PdfObject>(), 0);
            PdfDictionary map = R(root.Get("RoleMap")) as PdfDictionary;
            if (map == null) { map = new PdfDictionary(); root.Set("RoleMap", map); }
            foreach (string t in types)
            {
                string cur = t;
                for (int i = 0; i < 16 && !IsStandard(cur); i++)
                {
                    string next = Name(R(map.Get(cur)));
                    if (next == null || next == cur) break;
                    cur = next;
                }
                if (IsStandard(cur)) continue;
                map.Set(t, new PdfName(Guess(t)));
            }
            // A chain that went through a type this part does not know is cut short.
            foreach (string k in new List<string>(map.Map.Keys))
            {
                string v = Name(R(map.Get(k)));
                if (v != null && !IsStandard(v) && !map.Has(v)) map.Set(k, new PdfName(Guess(v)));
            }
        }

        private string Guess(string t)
        {
            string l = t.ToLowerInvariant();
            if (l == "thead" || l == "tbody" || l == "tfoot") return "NonStruct";
            if (l == "annot") return "Span";
            if (l == "ruby" || l == "rb" || l == "rt" || l == "rp" || l == "warichu" || l == "wt" || l == "wp") return "Span";
            if (l.Contains("title") || l.Contains("heading")) return "H";
            if (l.Contains("figure") || l.Contains("image") || l.Contains("shape") || l.Contains("chart") || l.Contains("diagram") || l.Contains("picture")) return "Figure";
            if (l.Contains("table")) return "Table";
            if (l.Contains("list")) return "L";
            if (l.Contains("note")) return "Note";
            if (l.Contains("link")) return "Link";
            if (l.Contains("span") || l.Contains("char") || l.Contains("inline")) return "Span";
            if (l.Contains("para") || l == "text" || l.Contains("body")) return "P";
            return "Div";
        }

        private void CollectTypes(PdfObject k, HashSet<string> into, HashSet<PdfObject> seen, int depth)
        {
            if (k == null || depth > 200) return;
            PdfObject v = R(k);
            if (v == null || !seen.Add(v)) return;
            PdfArray a = v as PdfArray;
            if (a != null) { for (int i = 0; i < a.Count; i++) CollectTypes(a[i], into, seen, depth + 1); return; }
            PdfDictionary d = v as PdfDictionary;
            if (d == null) return;
            string s = Name(R(d.Get("S")));
            if (s != null && Name(d.Get("Type")) != "MCR" && Name(d.Get("Type")) != "OBJR") into.Add(s);
            CollectTypes(d.Get("K"), into, seen, depth + 1);
        }

        private readonly Dictionary<PdfDictionary, PdfaTrueType> _programs = new Dictionary<PdfDictionary, PdfaTrueType>();

        private PdfaTrueType Program(PdfDictionary fd)
        {
            if (fd == null) return null;
            PdfaTrueType t;
            if (_programs.TryGetValue(fd, out t)) return t;
            t = null;
            PdfStream ff2 = R(fd.Get("FontFile2")) as PdfStream;
            byte[] prog = ff2 == null ? null : Decoded(ff2);
            if (prog != null) { try { t = PdfaTrueType.Parse(prog, 0); } catch { t = null; } }
            _programs[fd] = t;
            return t;
        }

        private int Derive(PdfaFontFixer fixer, PdfDictionary font, string sub, int code)
        {
            if (sub == "Type0")
            {
                PdfArray desc = R(font.Get("DescendantFonts")) as PdfArray;
                PdfDictionary cid = desc == null ? null : R(desc[0]) as PdfDictionary;
                if (cid == null) return -1;
                PdfaTrueType t = Program(R(cid.Get("FontDescriptor")) as PdfDictionary);
                if (t == null) return -1;
                int gid = code;
                PdfStream map = R(cid.Get("CIDToGIDMap")) as PdfStream;
                if (map != null)
                {
                    byte[] m = Decoded(map);
                    gid = m != null && 2 * code + 1 < m.Length ? m[2 * code] << 8 | m[2 * code + 1] : 0;
                }
                int u = t.UnicodeForGlyph(gid);
                return u > 0 ? u : PdfaGlyphs.Unicode(t.GlyphName(gid));
            }
            if (code < 0 || code > 255) return -1;
            PdfDictionary fd = R(font.Get("FontDescriptor")) as PdfDictionary;
            PdfNumber fl = fd == null ? null : R(fd.Get("Flags")) as PdfNumber;
            bool symbolic = fl != null && (fl.AsInt & 4) != 0;
            if (font.Has("Encoding") || !symbolic || sub == "Type3")
            {
                int u = PdfaGlyphs.Unicode(fixer.GlyphNames(font)[code]);
                if (u > 0) return u;
            }
            PdfaTrueType tt = Program(fd);
            if (tt != null)
            {
                int gid = tt.GlyphForCode(code);
                if (gid != 0)
                {
                    int u = tt.UnicodeForGlyph(gid);
                    if (u > 0 && (u < 0xE000 || u > 0xF8FF)) return u;
                    u = PdfaGlyphs.Unicode(tt.GlyphName(gid));
                    if (u > 0) return u;
                }
            }
            return -1;
        }
    }
}
