using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Pdfx.Internal
{
    internal sealed class PdfaTrueType
    {
        private readonly byte[] _d;
        private readonly int _base;
        private readonly Dictionary<string, int[]> _tables = new Dictionary<string, int[]>(StringComparer.Ordinal);

        public string Path;
        public string Family = "";
        public string Subfamily = "";
        public string PostScriptName = "";
        public bool Bold;
        public bool Italic;
        public int Weight = 400;
        public int FsType;
        public int UnitsPerEm = 1000;
        public int NumGlyphs;
        public short XMin, YMin, XMax, YMax;
        public int Ascent, Descent, CapHeight;
        public double ItalicAngle;
        public bool FixedPitch;
        public bool Serif;
        private ushort[] _advance;
        private int _locFormat;
        private Dictionary<int, int> _unicode;
        private Dictionary<int, int> _symbol;

        private PdfaTrueType(byte[] d, int b) { _d = d; _base = b; }

        public static PdfaTrueType Parse(byte[] data, int fontIndex)
        {
            if (data == null || data.Length < 12) throw new PdfException("not a TrueType font: too short");
            int b = 0;
            if (Tag(data, 0) == "ttcf")
            {
                int count = (int)U32(data, 8);
                if (fontIndex < 0 || fontIndex >= count) throw new PdfException("font index out of range in collection");
                b = (int)U32(data, 12 + 4 * fontIndex);
            }
            uint ver = U32(data, b);
            if (ver == 0x4F54544F) throw new PdfException("font has CFF outlines (OpenType/CFF), not TrueType");
            if (ver != 0x00010000 && ver != 0x74727565) throw new PdfException("not a TrueType font");
            PdfaTrueType t = new PdfaTrueType(data, b);
            int n = U16(data, b + 4);
            for (int i = 0; i < n; i++)
            {
                int r = b + 12 + 16 * i;
                t._tables[Tag(data, r)] = new[] { (int)U32(data, r + 8), (int)U32(data, r + 12) };
            }
            if (!t.Has("head") || !t.Has("maxp"))
                throw new PdfException("TrueType font is missing its head or maxp table");
            t.ReadMetrics();
            return t;
        }

        public bool Has(string tag) { return _tables.ContainsKey(tag); }
        public bool HasOutlines { get { return Has("glyf") && Has("loca"); } }

        private int Off(string tag) { return _tables[tag][0]; }
        private int Len(string tag) { return _tables[tag][1]; }

        private void ReadMetrics()
        {
            int h = Off("head");
            UnitsPerEm = U16(_d, h + 18);
            if (UnitsPerEm == 0) UnitsPerEm = 1000;
            XMin = S16(_d, h + 36); YMin = S16(_d, h + 38); XMax = S16(_d, h + 40); YMax = S16(_d, h + 42);
            int macStyle = U16(_d, h + 44);
            _locFormat = S16(_d, h + 50);
            Bold = (macStyle & 1) != 0;
            Italic = (macStyle & 2) != 0;
            NumGlyphs = U16(_d, Off("maxp") + 4);
            _advance = new ushort[NumGlyphs];
            if (Has("hhea") && Has("hmtx"))
            {
                int hh = Off("hhea");
                Ascent = S16(_d, hh + 4);
                Descent = S16(_d, hh + 6);
                int nh = U16(_d, hh + 34);
                int hm = Off("hmtx");
                ushort last = 0;
                for (int g = 0; g < NumGlyphs; g++)
                {
                    if (g < nh && hm + 4 * g + 1 < _d.Length) last = (ushort)U16(_d, hm + 4 * g);
                    _advance[g] = last;
                }
            }
            CapHeight = (int)(Ascent * 0.7);
            if (Has("OS/2"))
            {
                int o = Off("OS/2");
                int v = U16(_d, o);
                Weight = U16(_d, o + 4);
                FsType = U16(_d, o + 8);
                int sel = U16(_d, o + 62);
                if ((sel & 1) != 0) Italic = true;
                if ((sel & 32) != 0) Bold = true;
                int family = _d[o + 30];
                Serif = family >= 1 && family <= 7;
                if (v >= 2 && Len("OS/2") >= 90)
                {
                    int ch = S16(_d, o + 88);
                    if (ch > 0) CapHeight = ch;
                }
            }
            if (Weight >= 600) Bold = true;
            if (Has("post"))
            {
                int p = Off("post");
                ItalicAngle = S16(_d, p + 4) + U16(_d, p + 6) / 65536.0;
                FixedPitch = U32(_d, p + 12) != 0;
            }
            ReadNames();
        }

        private void ReadNames()
        {
            if (!Has("name")) return;
            string[] v = Names(_d, Off("name"));
            Family = v[0];
            Subfamily = v[1];
            PostScriptName = v[2].Length > 0 ? v[2] : Family.Replace(" ", "");
        }

        // family (typographic if present), subfamily, PostScript name. Windows en-US
        // records win over other Windows records, which win over Mac Roman ones.
        internal static string[] Names(byte[] d, int o)
        {
            int count = U16(d, o + 2);
            int strings = o + U16(d, o + 4);
            string[] val = new string[18];
            int[] rank = new int[18];
            for (int i = 0; i < count; i++)
            {
                int r = o + 6 + 12 * i;
                if (r + 12 > d.Length) break;
                int plat = U16(d, r), enc = U16(d, r + 2), lang = U16(d, r + 4), id = U16(d, r + 6);
                int len = U16(d, r + 8), off = U16(d, r + 10);
                if (id >= 18 || strings + off + len > d.Length) continue;
                int rk;
                string s;
                if (plat == 3 && (enc == 0 || enc == 1 || enc == 10))
                {
                    rk = lang == 0x409 ? 3 : 2;
                    s = Encoding.BigEndianUnicode.GetString(d, strings + off, len);
                }
                else if (plat == 1 && enc == 0)
                {
                    rk = 1;
                    s = Encoding.ASCII.GetString(d, strings + off, len);
                }
                else continue;
                if (rk > rank[id]) { rank[id] = rk; val[id] = s; }
            }
            return new[] { val[16] ?? val[1] ?? "", val[17] ?? val[2] ?? "", val[6] ?? "" };
        }

        public double AdvanceOf(int gid)
        {
            if (gid < 0 || gid >= NumGlyphs) return 0;
            return _advance[gid] * 1000.0 / UnitsPerEm;
        }

        public double Scale(int v) { return v * 1000.0 / UnitsPerEm; }

        public int GlyphForUnicode(int u)
        {
            if (_unicode == null) LoadCmaps();
            int g;
            return _unicode.TryGetValue(u, out g) ? g : 0;
        }

        // Symbol-encoded fonts (Windows Symbol, Wingdings) map code c at 0xF000 + c.
        public int GlyphForSymbolCode(int code)
        {
            if (_unicode == null) LoadCmaps();
            int g;
            if (_symbol.TryGetValue(0xF000 + code, out g)) return g;
            if (_symbol.TryGetValue(code, out g)) return g;
            return 0;
        }

        public bool IsSymbolEncoded
        {
            get { if (_unicode == null) LoadCmaps(); return _symbol.Count > 0 && _unicode.Count == 0; }
        }

        public bool GlyphHasOutline(int gid)
        {
            if (!HasOutlines || gid < 0 || gid >= NumGlyphs) return false;
            return GlyphLength(gid) > 0;
        }

        private void LoadCmaps()
        {
            _unicode = new Dictionary<int, int>();
            _symbol = new Dictionary<int, int>();
            if (!Has("cmap")) return;
            int c = Off("cmap");
            int n = U16(_d, c + 2);
            int best = -1, bestRank = 0;
            int sym = -1;
            for (int i = 0; i < n; i++)
            {
                int r = c + 4 + 8 * i;
                int plat = U16(_d, r), enc = U16(_d, r + 2);
                int off = c + (int)U32(_d, r + 4);
                int rank = 0;
                if (plat == 3 && enc == 10) rank = 4;
                else if (plat == 3 && enc == 1) rank = 3;
                else if (plat == 0) rank = 2;
                if (rank > bestRank) { bestRank = rank; best = off; }
                if (plat == 3 && enc == 0) sym = off;
            }
            if (best >= 0) ReadSubtable(best, _unicode);
            if (sym >= 0) ReadSubtable(sym, _symbol);
        }

        private void ReadSubtable(int o, Dictionary<int, int> into)
        {
            int format = U16(_d, o);
            if (format == 4)
            {
                int segX2 = U16(_d, o + 6);
                int ends = o + 14, starts = ends + segX2 + 2, deltas = starts + segX2, ranges = deltas + segX2;
                for (int s = 0; s < segX2 / 2; s++)
                {
                    int end = U16(_d, ends + 2 * s), start = U16(_d, starts + 2 * s);
                    int delta = S16(_d, deltas + 2 * s), ro = U16(_d, ranges + 2 * s);
                    for (int ch = start; ch <= end && ch != 0xFFFF; ch++)
                    {
                        int g;
                        if (ro == 0) g = (ch + delta) & 0xFFFF;
                        else
                        {
                            int a = ranges + 2 * s + ro + 2 * (ch - start);
                            if (a + 1 >= _d.Length) continue;
                            g = U16(_d, a);
                            if (g != 0) g = (g + delta) & 0xFFFF;
                        }
                        if (g != 0 && !into.ContainsKey(ch)) into[ch] = g;
                    }
                }
            }
            else if (format == 12)
            {
                int groups = (int)U32(_d, o + 12);
                for (int i = 0; i < groups; i++)
                {
                    int r = o + 16 + 12 * i;
                    int start = (int)U32(_d, r), end = (int)U32(_d, r + 4), g = (int)U32(_d, r + 8);
                    for (int ch = start; ch <= end && ch < 0x110000; ch++)
                        if (!into.ContainsKey(ch)) into[ch] = g + (ch - start);
                }
            }
            else if (format == 0)
            {
                for (int ch = 0; ch < 256; ch++) { int g = _d[o + 6 + ch]; if (g != 0) into[ch] = g; }
            }
            else if (format == 6)
            {
                int first = U16(_d, o + 6), count = U16(_d, o + 8);
                for (int i = 0; i < count; i++) { int g = U16(_d, o + 10 + 2 * i); if (g != 0) into[first + i] = g; }
            }
        }

        private int GlyphOffset(int gid)
        {
            int l = Off("loca");
            return _locFormat == 0 ? U16(_d, l + 2 * gid) * 2 : (int)U32(_d, l + 4 * gid);
        }

        private int GlyphLength(int gid) { return GlyphOffset(gid + 1) - GlyphOffset(gid); }

        // Every glyph id stays where it is; glyphs outside the set are emptied. The cmap
        // is replaced by a single (3,0) table: code -> gid, which is what a symbolic
        // simple TrueType font is read through.
        public byte[] Subset(ICollection<int> keepGids, IDictionary<int, int> codeToGid)
        {
            HashSet<int> keep = new HashSet<int>(keepGids);
            keep.Add(0);
            List<int> queue = new List<int>(keep);
            while (queue.Count > 0)
            {
                int g = queue[queue.Count - 1];
                queue.RemoveAt(queue.Count - 1);
                foreach (int c in Components(g)) if (keep.Add(c)) queue.Add(c);
            }

            MemoryStream glyf = new MemoryStream();
            uint[] loca = new uint[NumGlyphs + 1];
            int gbase = Off("glyf");
            for (int g = 0; g < NumGlyphs; g++)
            {
                loca[g] = (uint)glyf.Length;
                if (!keep.Contains(g)) continue;
                int len = GlyphLength(g);
                if (len <= 0) continue;
                glyf.Write(_d, gbase + GlyphOffset(g), len);
                while (glyf.Length % 4 != 0) glyf.WriteByte(0);
            }
            loca[NumGlyphs] = (uint)glyf.Length;

            byte[] locaBytes = new byte[4 * (NumGlyphs + 1)];
            for (int i = 0; i <= NumGlyphs; i++) W32(locaBytes, 4 * i, loca[i]);

            SortedDictionary<string, byte[]> outT = new SortedDictionary<string, byte[]>(StringComparer.Ordinal);
            byte[] head = Copy("head");
            W32(head, 8, 0);
            W16(head, 50, 1);
            outT["head"] = head;
            outT["hhea"] = Copy("hhea");
            outT["maxp"] = Copy("maxp");
            outT["hmtx"] = Copy("hmtx");
            outT["loca"] = locaBytes;
            outT["glyf"] = glyf.ToArray();
            outT["cmap"] = SymbolCmap(codeToGid);
            string[] optional = { "cvt ", "fpgm", "prep", "OS/2", "name" };
            for (int i = 0; i < optional.Length; i++) if (Has(optional[i])) outT[optional[i]] = Copy(optional[i]);
            if (Has("post") && Len("post") >= 32)
            {
                byte[] post = new byte[32];
                Buffer.BlockCopy(_d, Off("post"), post, 0, 32);
                W32(post, 0, 0x00030000);
                outT["post"] = post;
            }
            return Write(outT);
        }

        private IEnumerable<int> Components(int gid)
        {
            List<int> r = new List<int>();
            if (!HasOutlines || gid < 0 || gid >= NumGlyphs || GlyphLength(gid) < 10) return r;
            int p = Off("glyf") + GlyphOffset(gid);
            if (S16(_d, p) >= 0) return r;
            p += 10;
            while (true)
            {
                int flags = U16(_d, p);
                r.Add(U16(_d, p + 2));
                p += 4 + ((flags & 1) != 0 ? 4 : 2);
                if ((flags & 8) != 0) p += 2;
                else if ((flags & 0x40) != 0) p += 4;
                else if ((flags & 0x80) != 0) p += 8;
                if ((flags & 0x20) == 0) break;
            }
            return r;
        }

        private static byte[] SymbolCmap(IDictionary<int, int> codeToGid)
        {
            List<int> codes = new List<int>(codeToGid.Keys);
            codes.Sort();
            List<int[]> segs = new List<int[]>();
            for (int i = 0; i < codes.Count; i++)
                segs.Add(new[] { 0xF000 + codes[i], codeToGid[codes[i]] });
            int segCount = segs.Count + 1;
            MemoryStream ms = new MemoryStream();
            int len = 16 + 8 * segCount;
            int pow = 1, log = 0;
            while (pow * 2 <= segCount) { pow *= 2; log++; }
            BW16(ms, 0); BW16(ms, 1);
            BW16(ms, 3); BW16(ms, 0); BW32(ms, 12);
            BW16(ms, 4); BW16(ms, len); BW16(ms, 0);
            BW16(ms, segCount * 2); BW16(ms, pow * 2); BW16(ms, log); BW16(ms, segCount * 2 - pow * 2);
            foreach (int[] s in segs) BW16(ms, s[0]);
            BW16(ms, 0xFFFF);
            BW16(ms, 0);
            foreach (int[] s in segs) BW16(ms, s[0]);
            BW16(ms, 0xFFFF);
            foreach (int[] s in segs) BW16(ms, (s[1] - s[0]) & 0xFFFF);
            BW16(ms, 1);
            for (int i = 0; i < segCount; i++) BW16(ms, 0);
            return ms.ToArray();
        }

        private byte[] Copy(string tag)
        {
            byte[] b = new byte[Len(tag)];
            Buffer.BlockCopy(_d, Off(tag), b, 0, b.Length);
            return b;
        }

        internal static byte[] WriteTables(SortedDictionary<string, byte[]> tables) { return Write(tables); }

        private Dictionary<int, int> _reverse;

        // Lowest Unicode value that the font's own cmap maps to this glyph, or -1.
        public int UnicodeForGlyph(int gid)
        {
            if (_unicode == null) LoadCmaps();
            if (_reverse == null)
            {
                _reverse = new Dictionary<int, int>();
                foreach (KeyValuePair<int, int> kv in _unicode)
                {
                    int cur;
                    if (!_reverse.TryGetValue(kv.Value, out cur) || kv.Key < cur) _reverse[kv.Value] = kv.Key;
                }
            }
            int u;
            return _reverse.TryGetValue(gid, out u) ? u : -1;
        }

        private string[] _postNames;

        // Glyph name from a format 2 'post' table, or null.
        public string GlyphName(int gid)
        {
            if (_postNames == null)
            {
                _postNames = new string[0];
                if (Has("post") && Len("post") >= 34 && U32(_d, Off("post")) == 0x00020000)
                {
                    int p = Off("post") + 32;
                    int n = U16(_d, p);
                    int[] idx = new int[n];
                    for (int i = 0; i < n; i++) idx[i] = U16(_d, p + 2 + 2 * i);
                    List<string> extra = new List<string>();
                    int q = p + 2 + 2 * n, end = Off("post") + Len("post");
                    while (q < end) { int l = _d[q]; if (q + 1 + l > end) break; extra.Add(Encoding.ASCII.GetString(_d, q + 1, l)); q += 1 + l; }
                    string[] mac = PdfaTables.MacGlyphs.Split(' ');
                    _postNames = new string[n];
                    for (int i = 0; i < n; i++)
                        _postNames[i] = idx[i] < 258 ? (idx[i] < mac.Length ? mac[idx[i]] : null)
                            : (idx[i] - 258 < extra.Count ? extra[idx[i] - 258] : null);
                }
            }
            return gid >= 0 && gid < _postNames.Length ? _postNames[gid] : null;
        }

        // gid reached by a simple-font code: (3,0) at 0xF000+code or code, then (1,0) by code.
        public int GlyphForCode(int code)
        {
            int g = GlyphForSymbolCode(code);
            if (g != 0) return g;
            if (_mac == null)
            {
                _mac = new Dictionary<int, int>();
                if (!Has("cmap")) return 0;
                int c = Off("cmap");
                int n = U16(_d, c + 2);
                for (int i = 0; i < n; i++)
                {
                    int r = c + 4 + 8 * i;
                    if (U16(_d, r) == 1 && U16(_d, r + 2) == 0) ReadSubtable(c + (int)U32(_d, r + 4), _mac);
                }
            }
            return _mac.TryGetValue(code, out g) ? g : 0;
        }

        private Dictionary<int, int> _mac;

        private static byte[] Write(SortedDictionary<string, byte[]> tables)
        {
            int n = tables.Count;
            int pow = 1, log = 0;
            while (pow * 2 <= n) { pow *= 2; log++; }
            MemoryStream ms = new MemoryStream();
            BW32(ms, 0x00010000);
            BW16(ms, n); BW16(ms, pow * 16); BW16(ms, log); BW16(ms, n * 16 - pow * 16);
            int offset = 12 + 16 * n;
            List<KeyValuePair<string, byte[]>> list = new List<KeyValuePair<string, byte[]>>(tables);
            int headOffset = 0;
            uint total = 0;
            foreach (KeyValuePair<string, byte[]> kv in list)
            {
                uint sum = Checksum(kv.Value);
                total += sum;
                ms.Write(Encoding.ASCII.GetBytes(kv.Key), 0, 4);
                BW32(ms, sum);
                BW32(ms, (uint)offset);
                BW32(ms, (uint)kv.Value.Length);
                if (kv.Key == "head") headOffset = offset;
                offset += (kv.Value.Length + 3) & ~3;
            }
            foreach (KeyValuePair<string, byte[]> kv in list)
            {
                ms.Write(kv.Value, 0, kv.Value.Length);
                while (ms.Length % 4 != 0) ms.WriteByte(0);
            }
            byte[] font = ms.ToArray();
            total += Checksum(font, 0, 12 + 16 * n);
            W32(font, headOffset + 8, unchecked(0xB1B0AFBA - total));
            return font;
        }

        private static uint Checksum(byte[] b) { return Checksum(b, 0, b.Length); }

        private static uint Checksum(byte[] b, int start, int len)
        {
            uint sum = 0;
            for (int i = 0; i < len; i += 4)
            {
                uint v = 0;
                for (int k = 0; k < 4; k++)
                    v = (v << 8) | (uint)(start + i + k < start + len ? b[start + i + k] : 0);
                sum = unchecked(sum + v);
            }
            return sum;
        }

        private static string Tag(byte[] d, int o) { return Encoding.ASCII.GetString(d, o, 4); }
        private static uint U32(byte[] d, int o) { return (uint)(d[o] << 24 | d[o + 1] << 16 | d[o + 2] << 8 | d[o + 3]); }
        internal static int U16(byte[] d, int o) { return d[o] << 8 | d[o + 1]; }
        private static short S16(byte[] d, int o) { return (short)(d[o] << 8 | d[o + 1]); }
        private static void W32(byte[] d, int o, uint v) { d[o] = (byte)(v >> 24); d[o + 1] = (byte)(v >> 16); d[o + 2] = (byte)(v >> 8); d[o + 3] = (byte)v; }
        private static void W16(byte[] d, int o, int v) { d[o] = (byte)(v >> 8); d[o + 1] = (byte)v; }
        private static void BW32(Stream s, uint v) { s.WriteByte((byte)(v >> 24)); s.WriteByte((byte)(v >> 16)); s.WriteByte((byte)(v >> 8)); s.WriteByte((byte)v); }
        private static void BW16(Stream s, int v) { s.WriteByte((byte)(v >> 8)); s.WriteByte((byte)v); }
    }

    // Finds TrueType files on this machine by family and style. The index reads only the
    // first part of each file it can, and is built once per process.
    internal static class PdfaFontLocator
    {
        internal sealed class Entry
        {
            public string Path;
            public int Index;
            public string Family;
            public string PostScript;
            public bool Bold;
            public bool Italic;
            public int Weight;
        }

        private static readonly object Gate = new object();
        private static Dictionary<string, List<Entry>> _cacheByDirs = new Dictionary<string, List<Entry>>();

        public static List<string> Directories(IList<string> extra)
        {
            List<string> dirs = new List<string>();
            if (extra != null) foreach (string e in extra) if (!string.IsNullOrEmpty(e)) dirs.Add(e);
            try
            {
                string sys = Environment.GetFolderPath(Environment.SpecialFolder.Fonts);
                if (!string.IsNullOrEmpty(sys)) dirs.Add(sys);
            }
            catch { }
            string win = Environment.GetEnvironmentVariable("WINDIR");
            if (!string.IsNullOrEmpty(win)) dirs.Add(System.IO.Path.Combine(win, "Fonts"));
            string local = Environment.GetEnvironmentVariable("LOCALAPPDATA");
            if (!string.IsNullOrEmpty(local)) dirs.Add(System.IO.Path.Combine(local, @"Microsoft\Windows\Fonts"));
            dirs.Add("/usr/share/fonts");
            dirs.Add("/usr/local/share/fonts");
            string home = Environment.GetEnvironmentVariable("HOME");
            if (!string.IsNullOrEmpty(home)) dirs.Add(System.IO.Path.Combine(home, ".local/share/fonts"));
            List<string> existing = new List<string>();
            foreach (string d in dirs)
                if (Directory.Exists(d) && !existing.Contains(d)) existing.Add(d);
            return existing;
        }

        public static List<Entry> Index(IList<string> extra)
        {
            List<string> dirs = Directories(extra);
            string key = string.Join("|", dirs.ToArray());
            lock (Gate)
            {
                List<Entry> cached;
                if (_cacheByDirs.TryGetValue(key, out cached)) return cached;
                List<Entry> all = new List<Entry>();
                foreach (string d in dirs)
                {
                    string[] files;
                    try { files = Directory.GetFiles(d, "*.*", SearchOption.AllDirectories); }
                    catch { continue; }
                    foreach (string f in files)
                    {
                        string ext = System.IO.Path.GetExtension(f).ToLowerInvariant();
                        if (ext != ".ttf" && ext != ".ttc") continue;
                        try { all.AddRange(Probe(f)); } catch { }
                    }
                }
                _cacheByDirs[key] = all;
                return all;
            }
        }

        // Reads only the table directory and the head, OS/2 and name tables.
        private static List<Entry> Probe(string path)
        {
            List<Entry> r = new List<Entry>();
            using (FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read))
            {
                byte[] hdr = ReadAt(fs, 0, 16);
                List<long> starts = new List<long>();
                if (hdr[0] == 't' && hdr[1] == 't' && hdr[2] == 'c' && hdr[3] == 'f')
                {
                    int count = Math.Min(16, hdr[8] << 24 | hdr[9] << 16 | hdr[10] << 8 | hdr[11]);
                    byte[] offs = ReadAt(fs, 12, 4 * count);
                    for (int i = 0; i < count; i++)
                        starts.Add((uint)(offs[4 * i] << 24 | offs[4 * i + 1] << 16 | offs[4 * i + 2] << 8 | offs[4 * i + 3]));
                }
                else starts.Add(0);
                for (int idx = 0; idx < starts.Count; idx++)
                {
                    byte[] off = ReadAt(fs, starts[idx], 12);
                    uint ver = (uint)(off[0] << 24 | off[1] << 16 | off[2] << 8 | off[3]);
                    if (ver != 0x00010000 && ver != 0x74727565) continue;
                    int n = off[4] << 8 | off[5];
                    byte[] dir = ReadAt(fs, starts[idx] + 12, 16 * n);
                    Dictionary<string, long[]> t = new Dictionary<string, long[]>();
                    for (int i = 0; i < n; i++)
                    {
                        string tag = Encoding.ASCII.GetString(dir, 16 * i, 4);
                        long o = (uint)(dir[16 * i + 8] << 24 | dir[16 * i + 9] << 16 | dir[16 * i + 10] << 8 | dir[16 * i + 11]);
                        long l = (uint)(dir[16 * i + 12] << 24 | dir[16 * i + 13] << 16 | dir[16 * i + 14] << 8 | dir[16 * i + 15]);
                        t[tag] = new[] { o, l };
                    }
                    if (!t.ContainsKey("glyf") || !t.ContainsKey("name") || !t.ContainsKey("head")) continue;
                    byte[] name = ReadAt(fs, t["name"][0], (int)Math.Min(t["name"][1], 1 << 20));
                    string[] names = PdfaTrueType.Names(name, 0);
                    byte[] head = ReadAt(fs, t["head"][0], 54);
                    int mac = head[44] << 8 | head[45];
                    bool bold = (mac & 1) != 0, italic = (mac & 2) != 0;
                    int weight = bold ? 700 : 400;
                    if (t.ContainsKey("OS/2"))
                    {
                        byte[] os2 = ReadAt(fs, t["OS/2"][0], 64);
                        weight = os2[4] << 8 | os2[5];
                        int sel = os2[62] << 8 | os2[63];
                        if ((sel & 1) != 0) italic = true;
                        if ((sel & 32) != 0 || weight >= 600) bold = true;
                    }
                    Entry e = new Entry();
                    e.Path = path; e.Index = idx; e.Family = names[0]; e.PostScript = names[2];
                    e.Bold = bold; e.Italic = italic; e.Weight = weight;
                    r.Add(e);
                }
            }
            return r;
        }

        private static byte[] ReadAt(FileStream fs, long pos, int len)
        {
            byte[] b = new byte[len];
            fs.Position = pos;
            int got = 0;
            while (got < len)
            {
                int k = fs.Read(b, got, len - got);
                if (k <= 0) throw new EndOfStreamException();
                got += k;
            }
            return b;
        }

        public static string Norm(string s)
        {
            if (s == null) return "";
            StringBuilder sb = new StringBuilder();
            foreach (char c in s.ToLowerInvariant()) if (char.IsLetterOrDigit(c)) sb.Append(c);
            return sb.ToString();
        }

        public static Entry Find(IList<string> extra, string family, bool bold, bool italic)
        {
            string nf = Norm(family);
            Entry best = null;
            int bestScore = -1;
            foreach (Entry e in Index(extra))
            {
                if (Norm(e.Family) != nf) continue;
                int score = (e.Bold == bold ? 2000 : 0) + (e.Italic == italic ? 1000 : 0)
                    - Math.Min(999, Math.Abs(e.Weight - (bold ? 700 : 400)));
                if (score > bestScore) { bestScore = score; best = e; }
            }
            return best;
        }

        public static Entry FindPostScript(IList<string> extra, string psName)
        {
            string n = Norm(psName);
            foreach (Entry e in Index(extra)) if (Norm(e.PostScript) == n) return e;
            return null;
        }
    }
}
