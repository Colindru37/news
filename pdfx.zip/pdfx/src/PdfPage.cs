using System;
using Pdfx.Internal;

namespace Pdfx
{
    public sealed class PdfPage
    {
        internal PdfFile Source;
        internal PdfDictionary Dict;
        internal PdfDictionary OwnedResources;
        internal int SourceNumber = -1;     // object number in Source, for bookmark destinations
        internal double[] FitTo;            // set by ResizePages: the page is wrapped onto this size when saved

        // The area a viewer shows: CropBox clipped to MediaBox, normalised.
        internal double[] VisibleBox
        {
            get
            {
                double[] m = MediaBox, c = ReadBox("CropBox");
                if (c == null) return m;
                double[] r = { Math.Max(m[0], c[0]), Math.Max(m[1], c[1]), Math.Min(m[2], c[2]), Math.Min(m[3], c[3]) };
                return r[2] - r[0] < 1 || r[3] - r[1] < 1 ? m : r;
            }
        }

        internal PdfPage(PdfFile source, PdfDictionary dict)
        {
            Source = source;
            Dict = dict;
        }

        public PdfDictionary Dictionary { get { return Dict; } }
        public PdfFile SourceFile { get { return Source; } }

        public double[] MediaBox
        {
            get
            {
                double[] box = ReadBox("MediaBox");
                if (box == null) box = new double[] { 0, 0, 612, 792 };
                return box;
            }
            set
            {
                if (value == null || value.Length != 4)
                    throw new Internal.PdfException("MediaBox needs four numbers");
                PdfArray a = new PdfArray();
                for (int i = 0; i < 4; i++) a.Items.Add(new PdfNumber(value[i], false));
                Dict.Set("MediaBox", a);
            }
        }

        public double Width { get { double[] b = MediaBox; return Math.Abs(b[2] - b[0]); } }
        public double Height { get { double[] b = MediaBox; return Math.Abs(b[3] - b[1]); } }

        // Width/Height are the MediaBox, which is NOT how the page is displayed
        // when /Rotate is 90 or 270. Anything positioning against the page as a
        // reader shows it - a footer, a right margin, a centred watermark -
        // must use these instead.
        public double VisibleWidth
        {
            get { int r = Rotation; return (r == 90 || r == 270) ? Height : Width; }
        }

        public double VisibleHeight
        {
            get { int r = Rotation; return (r == 90 || r == 270) ? Width : Height; }
        }

        public int Rotation
        {
            get
            {
                PdfObject o = Dict.Get("Rotate");
                if (Source != null) o = Source.Resolve(o);
                PdfNumber n = o as PdfNumber;
                return n == null ? 0 : Normalise(n.AsInt);
            }
            set { Dict.Set("Rotate", new PdfNumber(Normalise(value), true)); }
        }

        public static int Normalise(int degrees)
        {
            int d = degrees % 360;
            if (d < 0) d += 360;
            d = ((d + 45) / 90) * 90;
            return d % 360;
        }

        private double[] ReadBox(string key)
        {
            PdfObject o = Dict.Get(key);
            if (Source != null) o = Source.Resolve(o);
            PdfArray a = o as PdfArray;
            if (a == null || a.Count < 4) return null;
            double[] r = new double[4];
            for (int i = 0; i < 4; i++)
            {
                PdfObject it = Source != null ? Source.Resolve(a[i]) : a[i];
                PdfNumber n = it as PdfNumber;
                if (n == null) return null;
                r[i] = n.Value;
            }
            if (r[0] > r[2]) { double t = r[0]; r[0] = r[2]; r[2] = t; }
            if (r[1] > r[3]) { double t = r[1]; r[1] = r[3]; r[3] = t; }
            return r;
        }
    }
}
