using System;
using System.Collections.Generic;
using System.IO;

namespace Pdfx.Internal
{
    public sealed class PdfOutput
    {
        private readonly List<PdfObject> _objects = new List<PdfObject>();
        private readonly Dictionary<PdfFile, Dictionary<int, int>> _imported =
            new Dictionary<PdfFile, Dictionary<int, int>>();

        public readonly PdfDictionary Trailer = new PdfDictionary();

        // When set, every string and stream is encrypted on the way out, except the
        // encryption dictionary itself and the trailer.
        internal PdfEncryptor Encryptor;

        public int Count { get { return _objects.Count; } }

        public int AddObject(PdfObject o)
        {
            _objects.Add(o ?? PdfNull.Instance);
            return _objects.Count;
        }

        public int Reserve()
        {
            _objects.Add(PdfNull.Instance);
            return _objects.Count;
        }

        public void SetObject(int number, PdfObject o)
        {
            if (number < 1 || number > _objects.Count)
                throw new PdfException("object number out of range: " + number);
            _objects[number - 1] = o ?? PdfNull.Instance;
        }

        public PdfObject GetObject(int number)
        {
            if (number < 1 || number > _objects.Count)
                throw new PdfException("object number out of range: " + number);
            return _objects[number - 1];
        }

        // Declares that source object oldNum is already present as newNum, so later imports
        // that reach it (an annotation's /P, say) link to it instead of copying it again.
        internal void PreMap(PdfFile source, int oldNum, int newNum)
        {
            if (source == null || oldNum <= 0) return;
            Dictionary<int, int> map;
            if (!_imported.TryGetValue(source, out map)) { map = new Dictionary<int, int>(); _imported[source] = map; }
            if (!map.ContainsKey(oldNum)) map[oldNum] = newNum;
        }

        public PdfObject Import(PdfFile source, PdfObject o)
        {
            if (source == null) throw new ArgumentNullException("source");
            if (source.IsEncrypted && source.Decryptor == null)
                throw new PdfException(
                    "cannot import from an encrypted document with no decryptor: "
                    + "its streams would be copied still encrypted and the result would be unreadable");

            Dictionary<int, int> map;
            if (!_imported.TryGetValue(source, out map))
            {
                map = new Dictionary<int, int>();
                _imported[source] = map;
            }
            return Copy(source, o, map);
        }

        // A page built in memory (no source file). Copied, so writing never edits the caller's
        // objects: the writer turns direct streams into references in place, and a second save
        // of an edited original would point those references into the wrong file.
        public PdfObject CopyDirect(PdfObject o)
        {
            return Copy(null, o, null);
        }

        // Direct objects shared by several pages (one font dictionary on every stamped page)
        // are copied once per output and stay shared.
        private readonly Dictionary<PdfObject, PdfObject> _direct = new Dictionary<PdfObject, PdfObject>(Same.Instance);
        private readonly Dictionary<PdfObject, int> _promoted = new Dictionary<PdfObject, int>(Same.Instance);

        private sealed class Same : IEqualityComparer<PdfObject>
        {
            public static readonly Same Instance = new Same();
            public bool Equals(PdfObject a, PdfObject b) { return ReferenceEquals(a, b); }
            public int GetHashCode(PdfObject o) { return System.Runtime.CompilerServices.RuntimeHelpers.GetHashCode(o); }
        }

        private PdfObject Copy(PdfFile source, PdfObject o, Dictionary<int, int> map)
        {
            if (o == null) return PdfNull.Instance;
            if (o is PdfArray || o is PdfDictionary || o is PdfStream)
            {
                PdfObject done;
                if (_direct.TryGetValue(o, out done)) return done;
                PdfObject made = CopyContainer(source, o, map);
                _direct[o] = made;
                return made;
            }

            PdfRef r = o as PdfRef;
            if (r != null)
            {
                int mapped;
                if (map.TryGetValue(r.Number, out mapped))
                    return new PdfRef(mapped, 0);

                if (source == null) return r;
                int slot = Reserve();
                map[r.Number] = slot;
                PdfObject target = source.GetObject(r.Number, r.Generation);
                SetObject(slot, Copy(source, target, map));
                return new PdfRef(slot, 0);
            }
            return o;
        }

        private PdfObject CopyContainer(PdfFile source, PdfObject o, Dictionary<int, int> map)
        {
            PdfArray a = o as PdfArray;
            if (a != null)
            {
                PdfArray copy = new PdfArray();
                for (int i = 0; i < a.Count; i++) copy.Items.Add(Copy(source, a[i], map));
                return copy;
            }

            PdfStream s = o as PdfStream;
            if (s != null)
            {
                PdfDictionary cd = new PdfDictionary();
                foreach (KeyValuePair<string, PdfObject> kv in s.Dict.Map)
                {
                    if (kv.Key == "Length") continue;
                    cd.Set(kv.Key, Copy(source, kv.Value, map));
                }
                byte[] raw = new byte[s.RawData.Length];
                Buffer.BlockCopy(s.RawData, 0, raw, 0, raw.Length);
                return new PdfStream(cd, raw);
            }

            PdfDictionary d = o as PdfDictionary;
            if (d != null)
            {
                PdfDictionary copy = new PdfDictionary();
                foreach (KeyValuePair<string, PdfObject> kv in d.Map)
                    copy.Set(kv.Key, Copy(source, kv.Value, map));
                return copy;
            }

            return o;
        }

        public void Save(string path)
        {
            using (FileStream fs = new FileStream(path, FileMode.Create, FileAccess.Write))
                Save(fs);
        }

        public byte[] ToBytes()
        {
            using (MemoryStream ms = new MemoryStream())
            {
                Save(ms);
                return ms.ToArray();
            }
        }

        public void Save(Stream target)
        {
            if (_objects.Count == 0) throw new PdfException("nothing to save: no objects");

            PromoteStreams();
            int encNum = 0;
            if (Encryptor != null)
            {
                encNum = AddObject(Encryptor.Dictionary);
                Trailer.Set("Encrypt", new PdfRef(encNum, 0));
                PdfArray id = new PdfArray();
                id.Items.Add(new PdfString(Encryptor.FileId, true));
                id.Items.Add(new PdfString(Encryptor.FileId, true));
                Trailer.Set("ID", id);
            }

            PdfSerializer w = new PdfSerializer(target);
            w.Ascii("%PDF-1.7\n");
            w.Bytes(new byte[] { (byte)'%', 0xE2, 0xE3, 0xCF, 0xD3, (byte)'\n' });

            int[] offsets = new int[_objects.Count + 1];
            for (int i = 1; i <= _objects.Count; i++)
            {
                offsets[i] = w.Position;
                w.Ascii(i + " 0 obj\n");
                int num = i;
                w.Encrypt = Encryptor != null && i != encNum ? (Func<byte[], byte[]>)(b => Encryptor.Encrypt(b, num, 0)) : null;
                w.WriteObject(_objects[i - 1]);
                w.Ascii("\nendobj\n");
            }

            int xrefPos = w.Position;
            int size = _objects.Count + 1;
            w.Ascii("xref\n0 " + size + "\n");
            w.Ascii("0000000000 65535 f \n");
            for (int i = 1; i <= _objects.Count; i++)
                w.Ascii(offsets[i].ToString("D10") + " 00000 n \n");

            Trailer.Set("Size", new PdfNumber(size, true));
            Trailer.Remove("Prev");
            Trailer.Remove("XRefStm");

            w.Encrypt = null;
            w.Ascii("trailer\n");
            w.WriteObject(Trailer);
            w.Ascii("\nstartxref\n" + xrefPos + "\n%%EOF\n");
        }
    
        private void PromoteStreams()
        {
            for (int i = 0; i < _objects.Count; i++)
            {
                PdfStream st = _objects[i] as PdfStream;
                PromoteIn(st != null ? st.Dict : _objects[i], 0);
            }
        }

        // One object number per stream instance, however many places refer to it.
        private int Promote(PdfStream s)
        {
            int n;
            if (_promoted.TryGetValue(s, out n)) return n;
            n = AddObject(s);
            _promoted[s] = n;
            return n;
        }

        private void PromoteIn(PdfObject o, int depth)
        {
            if (o == null || depth > 32) return;

            PdfArray a = o as PdfArray;
            if (a != null)
            {
                for (int i = 0; i < a.Count; i++)
                {
                    PdfStream s = a[i] as PdfStream;
                    if (s != null)
                    {
                        int n = Promote(s);
                        a.Items[i] = new PdfRef(n, 0);
                        PromoteIn(s.Dict, depth + 1);
                    }
                    else PromoteIn(a[i], depth + 1);
                }
                return;
            }

            PdfDictionary d = o as PdfDictionary;
            if (d == null) return;

            List<string> keys = new List<string>(d.Map.Keys);
            for (int i = 0; i < keys.Count; i++)
            {
                PdfObject v = d.Get(keys[i]);
                PdfStream s = v as PdfStream;
                if (s != null)
                {
                    int n = Promote(s);
                    d.Set(keys[i], new PdfRef(n, 0));
                    PromoteIn(s.Dict, depth + 1);
                }
                else PromoteIn(v, depth + 1);
            }
        }
}
}
