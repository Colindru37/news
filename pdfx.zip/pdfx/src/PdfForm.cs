using System;
using System.Collections.Generic;
using System.Text;
using Pdfx.Internal;

namespace Pdfx
{
    public sealed class PdfFormField
    {
        public string Name;
        public string FullName;
        public string Type;
        public string Value;
        public bool ReadOnly;
        public string[] Options;
        public int PageIndex = -1;
        public double[] Rect;

        internal PdfDictionary Dict;
        internal PdfDictionary Widget;
    }

    public static class PdfForm
    {
        public static bool HasForm(PdfDocument doc)
        {
            return doc != null && doc.AcroForm != null;
        }

        public static List<PdfFormField> Fields(PdfDocument doc)
        {
            List<PdfFormField> found = new List<PdfFormField>();
            if (doc == null || doc.AcroForm == null) return found;

            PdfFile f = doc.PrimaryFile;
            PdfArray roots = f.Resolve(doc.AcroForm.Get("Fields")) as PdfArray;
            if (roots == null) return found;

            Dictionary<int, int> pageOf = WidgetPages(doc, f);
            for (int i = 0; i < roots.Count; i++)
                Walk(f, roots[i], null, "", found, pageOf, 0);
            return found;
        }

        private static Dictionary<int, int> WidgetPages(PdfDocument doc, PdfFile f)
        {
            Dictionary<int, int> map = new Dictionary<int, int>();
            for (int p = 0; p < doc.PageCount; p++)
            {
                PdfArray annots = f.Resolve(doc.GetPage(p).Dictionary.Get("Annots")) as PdfArray;
                if (annots == null) continue;
                for (int i = 0; i < annots.Count; i++)
                {
                    PdfRef r = annots[i] as PdfRef;
                    if (r != null && !map.ContainsKey(r.Number)) map[r.Number] = p;
                }
            }
            return map;
        }

        private static void Walk(PdfFile f, PdfObject nodeRef, PdfDictionary inherited,
                                 string prefix, List<PdfFormField> into,
                                 Dictionary<int, int> pageOf, int depth)
        {
            if (depth > 16) return;
            PdfDictionary node = f.Resolve(nodeRef) as PdfDictionary;
            if (node == null) return;

            PdfString t = f.Resolve(node.Get("T")) as PdfString;
            string name = t == null ? "" : t.AsText();
            string full = prefix.Length == 0 ? name : (name.Length == 0 ? prefix : prefix + "." + name);

            PdfArray kids = f.Resolve(node.Get("Kids")) as PdfArray;
            bool hasFieldKids = false;
            if (kids != null)
                for (int i = 0; i < kids.Count; i++)
                {
                    PdfDictionary kid = f.Resolve(kids[i]) as PdfDictionary;
                    if (kid != null && kid.Has("T")) hasFieldKids = true;
                }

            if (hasFieldKids)
            {
                for (int i = 0; i < kids.Count; i++)
                    Walk(f, kids[i], node, full, into, pageOf, depth + 1);
                return;
            }

            PdfFormField field = new PdfFormField();
            field.Name = name;
            field.FullName = full;
            field.Dict = node;
            field.Type = TypeOf(f, node, inherited);
            field.Value = ValueOf(f, node, inherited);
            field.ReadOnly = (IntOf(f, node, inherited, "Ff") & 1) != 0;
            field.Options = OptionsOf(f, node, inherited);

            PdfObject widgetRef = nodeRef;
            PdfDictionary widget = node;
            if (kids != null && kids.Count > 0)
            {
                widgetRef = kids[0];
                widget = f.Resolve(widgetRef) as PdfDictionary ?? node;
            }
            field.Widget = widget;

            PdfRef wr = widgetRef as PdfRef;
            int page;
            if (wr != null && pageOf.TryGetValue(wr.Number, out page)) field.PageIndex = page;

            PdfArray rect = f.Resolve(widget.Get("Rect")) as PdfArray;
            if (rect != null && rect.Count >= 4)
            {
                double[] r = new double[4];
                for (int i = 0; i < 4; i++)
                {
                    PdfNumber n = f.Resolve(rect[i]) as PdfNumber;
                    r[i] = n == null ? 0 : n.Value;
                }
                if (r[0] > r[2]) { double s = r[0]; r[0] = r[2]; r[2] = s; }
                if (r[1] > r[3]) { double s = r[1]; r[1] = r[3]; r[3] = s; }
                field.Rect = r;
            }

            into.Add(field);
        }

        private static string TypeOf(PdfFile f, PdfDictionary node, PdfDictionary inherited)
        {
            PdfName ft = f.Resolve(node.Get("FT")) as PdfName;
            if (ft == null && inherited != null) ft = f.Resolve(inherited.Get("FT")) as PdfName;
            if (ft == null) return "Unknown";

            if (ft.Value == "Tx") return "Text";
            if (ft.Value == "Ch") return "Choice";
            if (ft.Value == "Sig") return "Signature";
            if (ft.Value != "Btn") return ft.Value;

            int flags = IntOf(f, node, inherited, "Ff");
            if ((flags & (1 << 16)) != 0) return "PushButton";
            if ((flags & (1 << 15)) != 0) return "Radio";
            return "Checkbox";
        }

        private static string ValueOf(PdfFile f, PdfDictionary node, PdfDictionary inherited)
        {
            PdfObject v = f.Resolve(node.Get("V"));
            if ((v == null || v is PdfNull) && inherited != null) v = f.Resolve(inherited.Get("V"));

            PdfString s = v as PdfString;
            if (s != null) return s.AsText();
            PdfName n = v as PdfName;
            if (n != null) return n.Value;
            PdfNumber num = v as PdfNumber;
            if (num != null) return PdfSerializer.Number(num.Value, num.IsInteger);
            return "";
        }

        private static string[] OptionsOf(PdfFile f, PdfDictionary node, PdfDictionary inherited)
        {
            PdfArray opt = f.Resolve(node.Get("Opt")) as PdfArray;
            if (opt == null && inherited != null) opt = f.Resolve(inherited.Get("Opt")) as PdfArray;
            if (opt == null) return null;

            List<string> values = new List<string>();
            for (int i = 0; i < opt.Count; i++)
            {
                PdfObject item = f.Resolve(opt[i]);
                PdfString s = item as PdfString;
                if (s != null) { values.Add(s.AsText()); continue; }
                PdfArray pair = item as PdfArray;
                if (pair != null && pair.Count >= 2)
                {
                    PdfString shown = f.Resolve(pair[1]) as PdfString;
                    if (shown != null) values.Add(shown.AsText());
                }
            }
            return values.ToArray();
        }

        private static int IntOf(PdfFile f, PdfDictionary node, PdfDictionary inherited, string key)
        {
            PdfNumber n = f.Resolve(node.Get(key)) as PdfNumber;
            if (n == null && inherited != null) n = f.Resolve(inherited.Get(key)) as PdfNumber;
            return n == null ? 0 : n.AsInt;
        }

        public static bool SetValue(PdfDocument doc, string fullName, string value)
        {
            if (doc == null || doc.AcroForm == null) return false;
            PdfFile f = doc.PrimaryFile;

            List<PdfFormField> all = Fields(doc);
            PdfFormField field = null;
            for (int i = 0; i < all.Count; i++)
                if (all[i].FullName == fullName) { field = all[i]; break; }
            if (field == null) return false;

            if (field.Type == "Checkbox" || field.Type == "Radio")
            {
                bool on = value == "1" || value == "true" || value == "True"
                       || value == "Yes" || value == "yes" || value == "on";
                string onState = OnState(f, field.Widget);
                string state = on ? onState : "Off";
                field.Dict.Set("V", new PdfName(state));
                field.Widget.Set("AS", new PdfName(state));
                field.Value = state;
                return true;
            }

            field.Dict.Set("V", new PdfString(Text(value), false));
            field.Value = value;
            BuildTextAppearance(doc, field, value);
            doc.AcroForm.Set("NeedAppearances", PdfBool.True);
            return true;
        }

        private static string OnState(PdfFile f, PdfDictionary widget)
        {
            PdfDictionary ap = f.Resolve(widget.Get("AP")) as PdfDictionary;
            PdfDictionary normal = ap == null ? null : f.Resolve(ap.Get("N")) as PdfDictionary;
            if (normal != null)
                foreach (string k in normal.Map.Keys)
                    if (k != "Off") return k;
            return "Yes";
        }

        private static void BuildTextAppearance(PdfDocument doc, PdfFormField field, string value)
        {
            if (field.Rect == null) return;
            double w = field.Rect[2] - field.Rect[0];
            double h = field.Rect[3] - field.Rect[1];
            if (w <= 0 || h <= 0) return;

            double size = h * 0.65;
            if (size > 12) size = 12;
            if (size < 4) size = 4;

            StringBuilder c = new StringBuilder();
            c.Append("/Tx BMC\nq\nBT\n/PdfxFHelvetica ")
             .Append(PdfSerializer.Number(size, false))
             .Append(" Tf 0 g\n2 ")
             .Append(PdfSerializer.Number((h - size) / 2 + size * 0.15, false))
             .Append(" Td\n")
             .Append(PdfSerializer.LiteralString(Text(value)))
             .Append(" Tj\nET\nQ\nEMC\n");

            PdfDictionary font = new PdfDictionary();
            font.Set("Type", new PdfName("Font"));
            font.Set("Subtype", new PdfName("Type1"));
            font.Set("BaseFont", new PdfName("Helvetica"));
            font.Set("Encoding", new PdfName("WinAnsiEncoding"));

            PdfDictionary fonts = new PdfDictionary();
            fonts.Set("PdfxFHelvetica", font);
            PdfDictionary res = new PdfDictionary();
            res.Set("Font", fonts);

            PdfArray bbox = new PdfArray();
            bbox.Items.Add(new PdfNumber(0, true));
            bbox.Items.Add(new PdfNumber(0, true));
            bbox.Items.Add(new PdfNumber(w, false));
            bbox.Items.Add(new PdfNumber(h, false));

            PdfDictionary sd = new PdfDictionary();
            sd.Set("Type", new PdfName("XObject"));
            sd.Set("Subtype", new PdfName("Form"));
            sd.Set("BBox", bbox);
            sd.Set("Resources", res);

            PdfDictionary ap = new PdfDictionary();
            ap.Set("N", new PdfStream(sd, Encoding.ASCII.GetBytes(c.ToString())));
            field.Widget.Set("AP", ap);
        }

        public static int Flatten(PdfDocument doc)
        {
            if (doc == null) return 0;
            PdfFile f = doc.PrimaryFile;
            int drawn = 0;

            for (int p = 0; p < doc.PageCount; p++)
            {
                PdfPage page = doc.GetPage(p);
                PdfArray annots = f.Resolve(page.Dictionary.Get("Annots")) as PdfArray;
                if (annots == null) continue;

                PdfArray keep = new PdfArray();
                for (int i = 0; i < annots.Count; i++)
                {
                    PdfDictionary a = f.Resolve(annots[i]) as PdfDictionary;
                    PdfName sub = a == null ? null : f.Resolve(a.Get("Subtype")) as PdfName;
                    if (a == null || sub == null || sub.Value != "Widget") { keep.Items.Add(annots[i]); continue; }

                    if (DrawWidget(doc, page, f, a)) drawn++;
                }

                if (keep.Count > 0) page.Dictionary.Set("Annots", keep);
                else page.Dictionary.Remove("Annots");
            }

            doc.AcroForm = null;
            return drawn;
        }

        private static bool DrawWidget(PdfDocument doc, PdfPage page, PdfFile f, PdfDictionary widget)
        {
            PdfDictionary ap = f.Resolve(widget.Get("AP")) as PdfDictionary;
            if (ap == null) return false;

            PdfObject normal = f.Resolve(ap.Get("N"));
            PdfStream form = normal as PdfStream;
            if (form == null)
            {
                PdfDictionary states = normal as PdfDictionary;
                if (states == null) return false;
                PdfName state = f.Resolve(widget.Get("AS")) as PdfName;
                string want = state != null ? state.Value : null;
                if (want != null) form = f.Resolve(states.Get(want)) as PdfStream;
                if (form == null) return false;
            }

            PdfArray rect = f.Resolve(widget.Get("Rect")) as PdfArray;
            if (rect == null || rect.Count < 4) return false;
            double rx0 = Num(f, rect[0]), ry0 = Num(f, rect[1]);
            double rx1 = Num(f, rect[2]), ry1 = Num(f, rect[3]);
            if (rx0 > rx1) { double t = rx0; rx0 = rx1; rx1 = t; }
            if (ry0 > ry1) { double t = ry0; ry0 = ry1; ry1 = t; }

            double bx0 = 0, by0 = 0, bx1 = rx1 - rx0, by1 = ry1 - ry0;
            PdfArray bbox = f.Resolve(form.Dict.Get("BBox")) as PdfArray;
            if (bbox != null && bbox.Count >= 4)
            {
                bx0 = Num(f, bbox[0]); by0 = Num(f, bbox[1]);
                bx1 = Num(f, bbox[2]); by1 = Num(f, bbox[3]);
                if (bx0 > bx1) { double t = bx0; bx0 = bx1; bx1 = t; }
                if (by0 > by1) { double t = by0; by0 = by1; by1 = t; }
            }

            double bw = bx1 - bx0, bh = by1 - by0;
            double sx = bw > 0 ? (rx1 - rx0) / bw : 1;
            double sy = bh > 0 ? (ry1 - ry0) / bh : 1;

            string key = PdfStamp.AddFormXObject(page, form);
            StringBuilder c = new StringBuilder();
            c.Append("q\n")
             .Append(PdfSerializer.Number(sx, false)).Append(" 0 0 ")
             .Append(PdfSerializer.Number(sy, false)).Append(' ')
             .Append(PdfSerializer.Number(rx0 - bx0 * sx, false)).Append(' ')
             .Append(PdfSerializer.Number(ry0 - by0 * sy, false)).Append(" cm\n")
             .Append("/").Append(key).Append(" Do\nQ\n");

            PdfStamp.AppendContent(page, Encoding.ASCII.GetBytes(c.ToString()));
            return true;
        }

        private static double Num(PdfFile f, PdfObject o)
        {
            PdfNumber n = f.Resolve(o) as PdfNumber;
            return n == null ? 0 : n.Value;
        }

        private static byte[] Text(string value)
        {
            if (value == null) return new byte[0];
            bool ascii = true;
            for (int i = 0; i < value.Length; i++) if (value[i] > 126) { ascii = false; break; }
            if (ascii)
            {
                byte[] b = new byte[value.Length];
                for (int i = 0; i < value.Length; i++) b[i] = (byte)value[i];
                return b;
            }
            byte[] u = Encoding.BigEndianUnicode.GetBytes(value);
            byte[] r = new byte[u.Length + 2];
            r[0] = 0xFE; r[1] = 0xFF;
            Buffer.BlockCopy(u, 0, r, 2, u.Length);
            return r;
        }
    }
}
