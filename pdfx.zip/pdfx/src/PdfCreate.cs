using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using Pdfx.Internal;

namespace Pdfx
{
    public static partial class PdfComposer
    {
        // One page per image (JPEG or PNG). Scans keep their paper size; photos are fitted
        // on A4 and turned upright from their EXIF orientation. PDFs in the list are welcome
        // too: this is Merge under the name people look for.
        public static void ImagesToPdf(string[] images, string output)
        {
            Merge(images, output);
        }

        // Plain text on A4 pages, wrapped to the page, in an embedded system font so every
        // character (diacritics included) is kept. A form feed starts a new page.
        public static void TextToPdf(string text, string output)
        {
            TextToPdf(text, output, false);
        }

        public static void TextToPdf(string text, string output, bool monospace)
        {
            if (text == null) throw new ArgumentNullException("text");
            if (output == null) throw new ArgumentNullException("output");
            WriteOutput(output, PdfTextPages.Build(text, monospace));
        }

        // A text file: UTF-8 or UTF-16 with a byte-order mark, UTF-8 without one, otherwise
        // the machine's ANSI code page.
        public static void TextFileToPdf(string input, string output)
        {
            byte[] b = ReadInput(input);
            string kind = PdfImages.IsImage(b) ? "an image" : StartsWith(b, "%PDF") ? "a PDF" : LooksBinary(b) ? "a binary file" : null;
            if (kind != null) throw new Internal.PdfException("not a text file (it is " + kind + "): " + input);
            TextToPdf(DecodeText(b), output, false);
        }

        // Text, Markdown or HTML to a UTF-8 file; the output's extension picks the form
        // (.md, .html/.htm, anything else = plain text).
        public static void ConvertToText(string input, string output)
        {
            ConvertToText(input, output, null);
        }

        public static void ConvertToText(string input, string output, string password)
        {
            if (output == null) throw new ArgumentNullException("output");
            string ext = Path.GetExtension(CleanPath(output)).ToLowerInvariant();
            using (PdfDocument d = PdfDocument.Open(ReadInput(input), password))
            {
                string text = ext == ".md" || ext == ".markdown" ? d.ToMarkdown() : ext == ".html" || ext == ".htm" ? d.ToHtml() : d.ToText();
                WriteOutput(output, new UTF8Encoding(false).GetBytes(text));
            }
        }

        public static int GetPageCount(string path)
        {
            return GetPageCount(path, null);
        }

        public static int GetPageCount(string path, string password)
        {
            byte[] b = ReadInput(path);
            using (PdfDocument d = PdfDocument.Open(b, password)) return d.PageCount;
        }

        // True when the file cannot be opened without a password. A file that is encrypted
        // only against editing (empty open password) opens freely and returns false.
        public static bool NeedsPassword(string path)
        {
            byte[] b = ReadInput(path);
            if (PdfImages.IsImage(b)) return false;
            using (PdfFile f = PdfFile.Open(b)) return f.IsEncrypted && f.Decryptor == null;
        }

        public static void RemovePassword(string input, string password, string output)
        {
            if (output == null) throw new ArgumentNullException("output");
            byte[] b = ReadInput(input);
            using (PdfDocument d = PdfDocument.Open(b, password)) d.Save(output);
        }

        // Paths copied from Explorer ("Copy as path") arrive wrapped in quotes.
        internal static string CleanPath(string path)
        {
            if (path == null) throw new ArgumentNullException("path");
            string p = path.Trim();
            if (p.Length >= 2 && p[0] == '"' && p[p.Length - 1] == '"') p = p.Substring(1, p.Length - 2).Trim();
            if (p.Length == 0) throw new ArgumentException("the file path is empty", "path");
            return p;
        }

        // A folder to write into: created if missing, refused in words if it is a file.
        internal static string OutputFolder(string folder)
        {
            if (folder == null) throw new ArgumentNullException("outputFolder");
            folder = CleanPath(folder);
            if (File.Exists(folder)) throw new Internal.PdfException("the output folder is an existing file: " + folder);
            Directory.CreateDirectory(folder);
            return folder;
        }

        // Every output goes through here: the folder is created if missing, and a folder
        // given as the output is refused in words instead of "access denied".
        internal static void WriteOutput(string path, byte[] data)
        {
            if (path == null) throw new ArgumentNullException("path");
            path = CleanPath(path);
            if (Directory.Exists(path)) throw new Internal.PdfException("the output path is a folder, not a file: " + path);
            string dir = Path.GetDirectoryName(Path.GetFullPath(path));
            if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir)) Directory.CreateDirectory(dir);
            File.WriteAllBytes(path, data);
        }

        internal static byte[] ReadInput(string path)
        {
            path = CleanPath(path);
            if (Directory.Exists(path)) throw new Internal.PdfException("expected a file but got a folder: " + path);
            if (!File.Exists(path)) throw new Internal.PdfException("file not found: " + path);
            byte[] b = File.ReadAllBytes(path);
            if (b.Length == 0) throw new Internal.PdfException("the file is empty: " + path);
            return b;
        }

        internal static bool StartsWith(byte[] b, string s)
        {
            if (b.Length < s.Length) return false;
            for (int i = 0; i < s.Length; i++) if (b[i] != s[i]) return false;
            return true;
        }

        // NUL bytes outside UTF-16 text mean binary.
        internal static bool LooksBinary(byte[] b)
        {
            if (b.Length >= 2 && ((b[0] == 0xFF && b[1] == 0xFE) || (b[0] == 0xFE && b[1] == 0xFF))) return false;
            int n = Math.Min(b.Length, 8192), zeros = 0;
            for (int i = 0; i < n; i++) if (b[i] == 0) zeros++;
            return zeros > 0;
        }

        internal static string DecodeText(byte[] b)
        {
            if (b.Length >= 3 && b[0] == 0xEF && b[1] == 0xBB && b[2] == 0xBF) return Encoding.UTF8.GetString(b, 3, b.Length - 3);
            if (b.Length >= 2 && b[0] == 0xFF && b[1] == 0xFE) return Encoding.Unicode.GetString(b, 2, b.Length - 2);
            if (b.Length >= 2 && b[0] == 0xFE && b[1] == 0xFF) return Encoding.BigEndianUnicode.GetString(b, 2, b.Length - 2);
            try { return new UTF8Encoding(false, true).GetString(b); }
            catch (DecoderFallbackException) { return Encoding.Default.GetString(b); }
        }
    }
}

namespace Pdfx.Internal
{
    internal static class PdfTextPages
    {
        private const double PageW = 595.276, PageH = 841.89, Margin = 56.7, Size = 10, Leading = 13;

        private static readonly string[] Proportional = { "Arial", "Liberation Sans", "Arimo", "DejaVu Sans", "Noto Sans", "Segoe UI", "Calibri" };
        private static readonly string[] Mono = { "Courier New", "Liberation Mono", "Cousine", "DejaVu Sans Mono", "Consolas", "Noto Sans Mono" };

        public static byte[] Build(string text, bool monospace)
        {
            PdfaTrueType font = LoadFont(monospace);
            EmbeddedFont f = new EmbeddedFont(font);

            List<List<string>> pages = Layout(Clean(text), f);
            PdfDocument doc = PdfDocument.Create();
            PdfDictionary type0 = f.Type0();
            foreach (List<string> lines in pages)
            {
                PdfPage page = doc.AddBlankPage(PageW, PageH);
                PdfDictionary fonts = new PdfDictionary();
                fonts.Set("F1", type0);
                ((PdfDictionary)page.Dictionary.Get("Resources")).Set("Font", fonts);
                StringBuilder c = new StringBuilder();
                c.Append("BT /F1 ").Append(N(Size)).Append(" Tf ").Append(N(Leading)).Append(" TL ");
                c.Append(N(Margin)).Append(' ').Append(N(PageH - Margin - Size)).Append(" Td\n");
                for (int i = 0; i < lines.Count; i++)
                {
                    if (i > 0) c.Append("T*\n");
                    if (lines[i].Length > 0) c.Append('<').Append(f.Hex(lines[i])).Append("> Tj\n");
                }
                c.Append("ET\n");
                page.Dictionary.Set("Contents", new PdfStream(new PdfDictionary(), Encoding.ASCII.GetBytes(c.ToString())));
            }
            f.Finish();
            return doc.ToBytes();
        }

        internal static PdfaTrueType LoadFont(bool monospace)
        {
            foreach (string family in monospace ? Mono : Proportional)
            {
                PdfaFontLocator.Entry e = PdfaFontLocator.Find(null, family, false, false);
                if (e == null) continue;
                try
                {
                    PdfaTrueType t = PdfaTrueType.Parse(File.ReadAllBytes(e.Path), e.Index);
                    if (t != null && t.HasOutlines && t.GlyphForUnicode('A') > 0) return t;
                }
                catch (Exception) { }
            }
            throw new PdfException("no usable TrueType font was found on this machine (looked for "
                + string.Join(", ", monospace ? Mono : Proportional) + ")");
        }

        // Line breaks normalised, tabs expanded, control and invisible characters dropped.
        private static string Clean(string s)
        {
            StringBuilder sb = new StringBuilder(s.Length);
            for (int i = 0; i < s.Length; i++)
            {
                char ch = s[i];
                if (ch == '\r') { sb.Append('\n'); if (i + 1 < s.Length && s[i + 1] == '\n') i++; continue; }
                if (ch == '\n' || ch == '\f') { sb.Append(ch); continue; }
                if (ch == '\t') { sb.Append("    "); continue; }
                if (char.IsHighSurrogate(ch) && i + 1 < s.Length && char.IsLowSurrogate(s[i + 1])) { sb.Append(ch).Append(s[++i]); continue; }
                if (char.IsSurrogate(ch)) { sb.Append('?'); continue; }
                if (ch == '\u2028' || ch == '\u2029' || ch == '\u0085') { sb.Append('\n'); continue; }
                if (ch < ' ' || (ch >= '\u007F' && ch < '\u00A0') || ch == '\uFEFF' || ch == '\u200B' || ch == '\u00AD') continue;
                sb.Append(ch);
            }
            return sb.ToString();
        }

        private static List<List<string>> Layout(string text, EmbeddedFont f)
        {
            double width = PageW - 2 * Margin;
            int perPage = (int)((PageH - 2 * Margin) / Leading);
            List<List<string>> pages = new List<List<string>>();
            List<string> cur = new List<string>();
            pages.Add(cur);
            string[] blocks = text.Split('\f');
            for (int b = 0; b < blocks.Length; b++)
            {
                if (b > 0) { cur = new List<string>(); pages.Add(cur); }
                foreach (string para in blocks[b].Split('\n'))
                    foreach (string line in Wrap(para, f, width))
                    {
                        if (cur.Count >= perPage) { cur = new List<string>(); pages.Add(cur); }
                        cur.Add(line);
                    }
            }
            // A trailing line break or form feed adds nothing visible; drop the empty last page.
            while (pages.Count > 1 && pages[pages.Count - 1].TrueForAll(l => l.Length == 0)) pages.RemoveAt(pages.Count - 1);
            return pages;
        }

        private static IEnumerable<string> Wrap(string para, EmbeddedFont f, double width)
        {
            if (para.Length == 0) { yield return ""; yield break; }
            int start = 0;
            while (start < para.Length)
            {
                int end = start, lastSpace = -1;
                double w = 0;
                while (end < para.Length)
                {
                    int step = char.IsSurrogatePair(para, end) ? 2 : 1;
                    double cw = f.Width(char.ConvertToUtf32(para, end)) * Size / 1000;
                    if (w + cw > width && end > start) break;
                    if (para[end] == ' ') lastSpace = end;
                    w += cw;
                    end += step;
                }
                if (end >= para.Length) { yield return para.Substring(start).TrimEnd(' '); yield break; }
                int cut = lastSpace > start ? lastSpace : end;
                yield return para.Substring(start, cut - start).TrimEnd(' ');
                start = cut;
                while (start < para.Length && para[start] == ' ') start++;
            }
        }

        private static string N(double v) { return PdfSerializer.Number(Math.Round(v, 3), false); }
    }

    // An embedded Identity-H subset: CID = glyph id, so every glyph in the font is reachable.
    internal sealed class EmbeddedFont
    {
        private readonly PdfaTrueType _t;
        private readonly int _fallback;
        private readonly Dictionary<int, int> _gidToUni = new Dictionary<int, int>();
        private PdfDictionary _type0, _cid, _desc;

        public EmbeddedFont(PdfaTrueType t)
        {
            _t = t;
            _fallback = t.GlyphForUnicode('?');
        }

        public static EmbeddedFont Load(bool monospace) { return new EmbeddedFont(PdfTextPages.LoadFont(monospace)); }

        private int Gid(int u)
        {
            if (u != ' ' && u < 0x10000 && char.IsWhiteSpace((char)u)) u = ' ';
            int g = _t.GlyphForUnicode(u);
            if (g <= 0 || (u != ' ' && !_t.GlyphHasOutline(g))) { g = _fallback; u = '?'; }
            if (g > 0 && !_gidToUni.ContainsKey(g)) _gidToUni[g] = u;
            return g;
        }

        public double Width(int u)
        {
            if (u != ' ' && u < 0x10000 && char.IsWhiteSpace((char)u)) u = ' ';
            int g = _t.GlyphForUnicode(u);
            if (g <= 0) g = _fallback;
            return _t.AdvanceOf(g);
        }

        public string Hex(string s)
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < s.Length; i++)
            {
                int u = char.ConvertToUtf32(s, i);
                if (char.IsSurrogatePair(s, i)) i++;
                int g = Gid(u);
                if (g > 0) sb.Append(g.ToString("X4"));
            }
            return sb.ToString();
        }

        public PdfDictionary Type0()
        {
            if (_type0 != null) return _type0;
            string name = "PDFXAA+" + Sanitise(_t.PostScriptName.Length > 0 ? _t.PostScriptName : _t.Family);
            _desc = new PdfDictionary();
            _desc.Set("Type", new PdfName("FontDescriptor"));
            _desc.Set("FontName", new PdfName(name));
            _desc.Set("Flags", new PdfNumber(_t.FixedPitch ? 33 : 32, true));
            PdfArray bbox = new PdfArray();
            foreach (int v in new int[] { _t.XMin, _t.YMin, _t.XMax, _t.YMax }) bbox.Items.Add(new PdfNumber(Math.Round(_t.Scale(v)), true));
            _desc.Set("FontBBox", bbox);
            _desc.Set("ItalicAngle", new PdfNumber(_t.ItalicAngle, false));
            _desc.Set("Ascent", new PdfNumber(Math.Round(_t.Scale(_t.Ascent)), true));
            _desc.Set("Descent", new PdfNumber(Math.Round(_t.Scale(_t.Descent)), true));
            _desc.Set("CapHeight", new PdfNumber(Math.Round(_t.Scale(_t.CapHeight > 0 ? _t.CapHeight : _t.Ascent)), true));
            _desc.Set("StemV", new PdfNumber(80, true));

            PdfDictionary info = new PdfDictionary();
            info.Set("Registry", new PdfString(Encoding.ASCII.GetBytes("Adobe"), false));
            info.Set("Ordering", new PdfString(Encoding.ASCII.GetBytes("Identity"), false));
            info.Set("Supplement", new PdfNumber(0, true));

            _cid = new PdfDictionary();
            _cid.Set("Type", new PdfName("Font"));
            _cid.Set("Subtype", new PdfName("CIDFontType2"));
            _cid.Set("BaseFont", new PdfName(name));
            _cid.Set("CIDSystemInfo", info);
            _cid.Set("FontDescriptor", _desc);
            _cid.Set("CIDToGIDMap", new PdfName("Identity"));

            PdfArray desc = new PdfArray();
            desc.Items.Add(_cid);
            _type0 = new PdfDictionary();
            _type0.Set("Type", new PdfName("Font"));
            _type0.Set("Subtype", new PdfName("Type0"));
            _type0.Set("BaseFont", new PdfName(name));
            _type0.Set("Encoding", new PdfName("Identity-H"));
            _type0.Set("DescendantFonts", desc);
            return _type0;
        }

        // Called after every page is laid out: only now is the glyph set known.
        public void Finish()
        {
            List<int> gids = new List<int>(_gidToUni.Keys);
            gids.Sort();
            PdfArray w = new PdfArray();
            foreach (int g in gids)
            {
                PdfArray one = new PdfArray();
                one.Items.Add(new PdfNumber(Math.Round(_t.AdvanceOf(g), 3), false));
                w.Items.Add(new PdfNumber(g, true));
                w.Items.Add(one);
            }
            _cid.Set("W", w);
            _cid.Set("DW", new PdfNumber(1000, true));

            byte[] prog = _t.Subset(gids, new Dictionary<int, int>());
            PdfDictionary fd = new PdfDictionary();
            fd.Set("Length1", new PdfNumber(prog.Length, true));
            fd.Set("Filter", new PdfName("FlateDecode"));
            _desc.Set("FontFile2", new PdfStream(fd, PdfaFontFixer.Deflate(prog)));

            PdfStream tu = PdfaFontFixer.ToUnicodeStream(_gidToUni, true);
            _type0.Set("ToUnicode", tu);
        }

        private static string Sanitise(string s)
        {
            StringBuilder sb = new StringBuilder();
            foreach (char c in s) if (c > ' ' && c < 127 && "()<>[]{}/%#".IndexOf(c) < 0) sb.Append(c);
            return sb.Length == 0 ? "Font" : sb.ToString();
        }
    }
}
