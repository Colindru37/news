using System;
using System.Collections.Generic;
using Pdfx.Internal;

namespace Pdfx
{
    // A bookmark (outline item). It points at a page object, not a page number, so it follows
    // its page through merges, moves and deletions; when the page is gone, PageIndex is -1.
    public sealed class PdfBookmark
    {
        internal PdfDocument Doc;
        internal PdfPage Page;
        internal PdfObject[] View;              // destination after the page: /Fit, /XYZ 0 792 0, ...
        internal PdfFile ActionSource;          // a non-GoTo action (link, script) carried as-is
        internal PdfObject Action;
        internal PdfObject Colour, Style;
        // False for a bookmark that never pointed anywhere in its source file: it is kept as a
        // title. A bookmark that pointed at a page that is now gone is dropped instead.
        internal bool HadTarget = true;
        private readonly List<PdfBookmark> _children = new List<PdfBookmark>();

        public string Title { get; set; }
        public bool IsOpen { get; set; }
        public IList<PdfBookmark> Children { get { return _children; } }

        public int PageIndex { get { return Page == null || Doc == null ? -1 : Doc.IndexOfPage(Page); } }

        internal PdfBookmark(PdfDocument doc, string title, PdfPage page)
        {
            Doc = doc;
            Title = title ?? "";
            Page = page;
        }

        public PdfBookmark AddChild(string title, int pageIndex)
        {
            PdfBookmark b = new PdfBookmark(Doc, title, Doc.GetPage(pageIndex));
            _children.Add(b);
            return b;
        }

        internal PdfBookmark CloneInto(PdfDocument target)
        {
            PdfBookmark b = new PdfBookmark(target, Title, Page);
            b.IsOpen = IsOpen; b.View = View; b.ActionSource = ActionSource; b.Action = Action;
            b.Colour = Colour; b.Style = Style; b.HadTarget = HadTarget;
            foreach (PdfBookmark c in _children) b._children.Add(c.CloneInto(target));
            return b;
        }

        // Live: has a page in its document, an action, or a live child.
        internal bool IsLive()
        {
            if (PageIndex >= 0 || Action != null || !HadTarget) return true;
            foreach (PdfBookmark c in _children) if (c.IsLive()) return true;
            return false;
        }
    }
}

namespace Pdfx.Internal
{
    internal static class PdfOutlines
    {
        // ---- reading -------------------------------------------------------------------

        public static List<PdfBookmark> Read(PdfDocument doc, PdfFile f, PdfDictionary root, Dictionary<int, PdfPage> byNumber)
        {
            List<PdfBookmark> list = new List<PdfBookmark>();
            PdfDictionary outlines = f.Resolve(root.Get("Outlines")) as PdfDictionary;
            if (outlines == null) return list;
            int budget = 100000;
            ReadSiblings(doc, f, root, outlines.Get("First"), list, byNumber, new HashSet<int>(), 0, ref budget);
            return list;
        }

        private static void ReadSiblings(PdfDocument doc, PdfFile f, PdfDictionary root, PdfObject first, List<PdfBookmark> into,
                                         Dictionary<int, PdfPage> byNumber, HashSet<int> seen, int depth, ref int budget)
        {
            if (depth > 64) return;
            PdfObject cur = first;
            while (cur != null && budget-- > 0)
            {
                PdfRef r = cur as PdfRef;
                if (r != null && !seen.Add(r.Number)) return;
                PdfDictionary item = f.Resolve(cur) as PdfDictionary;
                if (item == null) return;

                PdfString t = f.Resolve(item.Get("Title")) as PdfString;
                PdfBookmark b = new PdfBookmark(doc, t == null ? "" : t.AsText().TrimEnd('\0'), null);
                PdfNumber count = f.Resolve(item.Get("Count")) as PdfNumber;
                b.IsOpen = count != null && count.Value > 0;
                b.Colour = Simple(f.Resolve(item.Get("C")));
                b.Style = Simple(f.Resolve(item.Get("F")));

                PdfObject dest = item.Get("Dest");
                PdfDictionary action = f.Resolve(item.Get("A")) as PdfDictionary;
                if (dest == null && action != null)
                {
                    PdfName s = f.Resolve(action.Get("S")) as PdfName;
                    if (s != null && s.Value == "GoTo") dest = action.Get("D");
                    else { b.ActionSource = f; b.Action = item.Get("A"); }
                }
                if (dest != null) Resolve(f, root, dest, byNumber, b);
                b.HadTarget = b.Page != null || b.Action != null;

                ReadSiblings(doc, f, root, item.Get("First"), (List<PdfBookmark>)b.Children, byNumber, seen, depth + 1, ref budget);
                into.Add(b);
                cur = item.Get("Next");
            }
        }

        private static void Resolve(PdfFile f, PdfDictionary root, PdfObject dest, Dictionary<int, PdfPage> byNumber, PdfBookmark b)
        {
            PdfObject d = f.Resolve(dest);
            if (d is PdfName || d is PdfString) d = Named(f, root, d);
            PdfDictionary dd = d as PdfDictionary;
            if (dd != null) d = f.Resolve(dd.Get("D"));
            PdfArray arr = d as PdfArray;
            if (arr == null || arr.Count == 0) return;
            PdfRef page = arr[0] as PdfRef;
            PdfPage p;
            if (page != null && byNumber.TryGetValue(page.Number, out p)) b.Page = p;
            List<PdfObject> view = new List<PdfObject>();
            for (int i = 1; i < arr.Count; i++)
            {
                PdfObject v = Simple(f.Resolve(arr[i]));
                if (v == null) { view.Clear(); break; }
                view.Add(v);
            }
            if (view.Count > 0) b.View = view.ToArray();
        }

        // Named destinations: the old /Dests dictionary or the /Names /Dests name tree.
        private static PdfObject Named(PdfFile f, PdfDictionary root, PdfObject name)
        {
            PdfName n = name as PdfName;
            PdfString s = name as PdfString;
            PdfDictionary old = f.Resolve(root.Get("Dests")) as PdfDictionary;
            if (old != null && n != null) return f.Resolve(old.Get(n.Value));
            PdfDictionary names = f.Resolve(root.Get("Names")) as PdfDictionary;
            PdfDictionary tree = names == null ? null : f.Resolve(names.Get("Dests")) as PdfDictionary;
            if (tree == null) return null;
            string key = s != null ? s.AsText() : n.Value;
            PdfObject found = null;
            NameTree(f, tree, (k, v) => { if (found == null && k == key) found = f.Resolve(v); }, 0, new HashSet<int>());
            return found;
        }

        public static void NameTree(PdfFile f, PdfDictionary node, Action<string, PdfObject> visit, int depth, HashSet<int> seen)
        {
            if (node == null || depth > 32) return;
            PdfArray names = f.Resolve(node.Get("Names")) as PdfArray;
            if (names != null)
                for (int i = 0; i + 1 < names.Count; i += 2)
                {
                    PdfString k = f.Resolve(names[i]) as PdfString;
                    if (k != null) visit(k.AsText(), names[i + 1]);
                }
            PdfArray kids = f.Resolve(node.Get("Kids")) as PdfArray;
            if (kids == null) return;
            for (int i = 0; i < kids.Count; i++)
            {
                PdfRef r = kids[i] as PdfRef;
                if (r != null && !seen.Add(r.Number)) continue;
                NameTree(f, f.Resolve(kids[i]) as PdfDictionary, visit, depth + 1, seen);
            }
        }

        // Numbers, names, null and arrays of numbers only: safe to carry into a new file.
        private static PdfObject Simple(PdfObject o)
        {
            if (o is PdfNumber || o is PdfName || o is PdfNull) return o;
            PdfArray a = o as PdfArray;
            if (a == null) return null;
            PdfArray c = new PdfArray();
            foreach (PdfObject x in a.Items) { if (!(x is PdfNumber)) return null; c.Items.Add(x); }
            return c;
        }

        // ---- writing -------------------------------------------------------------------

        public static void Write(PdfOutput o, PdfDictionary cat, IList<PdfBookmark> top, Dictionary<PdfPage, int> pageRefs)
        {
            List<PdfBookmark> live = new List<PdfBookmark>();
            foreach (PdfBookmark b in top) if (b.IsLive()) live.Add(b);
            if (live.Count == 0) return;
            int rootNum = o.Reserve();
            PdfDictionary outlines = new PdfDictionary();
            outlines.Set("Type", new PdfName("Outlines"));
            int visible = WriteLevel(o, live, rootNum, outlines, pageRefs);
            outlines.Set("Count", new PdfNumber(visible, true));
            o.SetObject(rootNum, outlines);
            cat.Set("Outlines", new PdfRef(rootNum, 0));
        }

        // Writes one sibling list under parent; returns how many items are visible below parent.
        private static int WriteLevel(PdfOutput o, List<PdfBookmark> items, int parentNum, PdfDictionary parent, Dictionary<PdfPage, int> pageRefs)
        {
            int[] nums = new int[items.Count];
            for (int i = 0; i < items.Count; i++) nums[i] = o.Reserve();
            parent.Set("First", new PdfRef(nums[0], 0));
            parent.Set("Last", new PdfRef(nums[nums.Length - 1], 0));
            int visible = 0;
            for (int i = 0; i < items.Count; i++)
            {
                PdfBookmark b = items[i];
                PdfDictionary d = new PdfDictionary();
                d.Set("Title", new PdfString(PdfDocument.TextBytes(b.Title), false));
                d.Set("Parent", new PdfRef(parentNum, 0));
                if (i > 0) d.Set("Prev", new PdfRef(nums[i - 1], 0));
                if (i + 1 < items.Count) d.Set("Next", new PdfRef(nums[i + 1], 0));
                int pageNum;
                if (b.Page != null && b.PageIndex >= 0 && pageRefs.TryGetValue(b.Page, out pageNum))
                {
                    PdfArray dest = new PdfArray();
                    dest.Items.Add(new PdfRef(pageNum, 0));
                    if (b.View != null) foreach (PdfObject v in b.View) dest.Items.Add(v);
                    else dest.Items.Add(new PdfName("Fit"));
                    d.Set("Dest", dest);
                }
                else if (b.Action != null && b.ActionSource != null) d.Set("A", o.Import(b.ActionSource, b.Action));
                if (b.Colour != null) d.Set("C", b.Colour);
                if (b.Style != null) d.Set("F", b.Style);

                List<PdfBookmark> kids = new List<PdfBookmark>();
                foreach (PdfBookmark c in b.Children) if (c.IsLive()) kids.Add(c);
                visible++;
                if (kids.Count > 0)
                {
                    int below = WriteLevel(o, kids, nums[i], d, pageRefs);
                    d.Set("Count", new PdfNumber(b.IsOpen ? below : -below, true));
                    if (b.IsOpen) visible += below;
                }
                o.SetObject(nums[i], d);
            }
            return visible;
        }
    }
}
