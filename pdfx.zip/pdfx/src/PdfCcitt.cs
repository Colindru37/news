using System;
using System.Collections.Generic;

namespace Pdfx.Internal
{
    // CCITT fax decoder (ITU-T T.4 / T.6): Group 3 one-dimensional (K = 0), Group 3 mixed
    // (K > 0) and Group 4 (K < 0), as PDF's CCITTFaxDecode describes them. Output is one bit per
    // pixel, rows padded to whole bytes, in PDF's convention: a black pixel is 0 unless BlackIs1.
    internal static class PdfCcitt
    {
        private const int Eol = -2, Bad = -1;

        // run lengths for white and black, keyed by (length << 16) | code
        private static readonly Dictionary<int, int> White = new Dictionary<int, int>();
        private static readonly Dictionary<int, int> Black = new Dictionary<int, int>();

        private static readonly string[] WhiteTerm =
        {
            "00110101", "000111", "0111", "1000", "1011", "1100", "1110", "1111", "10011", "10100",
            "00111", "01000", "001000", "000011", "110100", "110101", "101010", "101011", "0100111", "0001100",
            "0001000", "0010111", "0000011", "0000100", "0101000", "0101011", "0010011", "0100100", "0011000", "00000010",
            "00000011", "00011010", "00011011", "00010010", "00010011", "00010100", "00010101", "00010110", "00010111", "00101000",
            "00101001", "00101010", "00101011", "00101100", "00101101", "00000100", "00000101", "00001010", "00001011", "01010010",
            "01010011", "01010100", "01010101", "00100100", "00100101", "01011000", "01011001", "01011010", "01011011", "01001010",
            "01001011", "00110010", "00110011", "00110100"
        };

        private static readonly string[] WhiteMakeup =
        {
            "11011", "10010", "010111", "0110111", "00110110", "00110111", "01100100", "01100101", "01101000", "01100111",
            "011001100", "011001101", "011010010", "011010011", "011010100", "011010101", "011010110", "011010111", "011011000", "011011001",
            "011011010", "011011011", "010011000", "010011001", "010011010", "011000", "010011011"
        };

        private static readonly string[] BlackTerm =
        {
            "0000110111", "010", "11", "10", "011", "0011", "0010", "00011", "000101", "000100",
            "0000100", "0000101", "0000111", "00000100", "00000111", "000011000", "0000010111", "0000011000", "0000001000", "00001100111",
            "00001101000", "00001101100", "00000110111", "00000101000", "00000010111", "00000011000", "000011001010", "000011001011", "000011001100", "000011001101",
            "000001101000", "000001101001", "000001101010", "000001101011", "000011010010", "000011010011", "000011010100", "000011010101", "000011010110", "000011010111",
            "000001101100", "000001101101", "000011011010", "000011011011", "000001010100", "000001010101", "000001010110", "000001010111", "000001100100", "000001100101",
            "000001010010", "000001010011", "000000100100", "000000110111", "000000111000", "000000100111", "000000101000", "000001011000", "000001011001", "000000101011",
            "000000101100", "000001011010", "000001100110", "000001100111"
        };

        private static readonly string[] BlackMakeup =
        {
            "0000001111", "000011001000", "000011001001", "000001011011", "000000110011", "000000110100", "000000110101", "0000001101100", "0000001101101", "0000001001010",
            "0000001001011", "0000001001100", "0000001001101", "0000001110010", "0000001110011", "0000001110100", "0000001110101", "0000001110110", "0000001110111", "0000001010010",
            "0000001010011", "0000001010100", "0000001010101", "0000001011010", "0000001011011", "0000001100100", "0000001100101"
        };

        private static readonly string[] ExtMakeup =
        {
            "00000001000", "00000001100", "00000001101", "000000010010", "000000010011", "000000010100", "000000010101",
            "000000010110", "000000010111", "000000011100", "000000011101", "000000011110", "000000011111"
        };

        static PdfCcitt()
        {
            for (int i = 0; i < 64; i++) { Add(White, WhiteTerm[i], i); Add(Black, BlackTerm[i], i); }
            for (int i = 0; i < 27; i++) { Add(White, WhiteMakeup[i], 64 * (i + 1)); Add(Black, BlackMakeup[i], 64 * (i + 1)); }
            for (int i = 0; i < 13; i++) { Add(White, ExtMakeup[i], 1792 + 64 * i); Add(Black, ExtMakeup[i], 1792 + 64 * i); }
        }

        private static void Add(Dictionary<int, int> t, string code, int run)
        {
            t.Add((code.Length << 16) | Convert.ToInt32(code, 2), run);
        }

        private sealed class Bits
        {
            private readonly byte[] _d;
            public int Pos;                                 // in bits
            public Bits(byte[] d) { _d = d; }
            public bool End { get { return Pos >= _d.Length * 8; } }
            public int Bit()
            {
                if (Pos >= _d.Length * 8) { Pos++; return 0; }
                int b = (_d[Pos >> 3] >> (7 - (Pos & 7))) & 1;
                Pos++;
                return b;
            }
            public int Peek(int n)
            {
                int save = Pos, v = 0;
                for (int i = 0; i < n; i++) v = (v << 1) | Bit();
                Pos = save;
                return v;
            }
            public void Align() { Pos = (Pos + 7) & ~7; }
            public bool Past { get { return Pos > _d.Length * 8 + 32; } }
        }

        // One run length (makeup codes added up, then a terminating code); Bad on an unknown code.
        private static int Run(Bits b, bool black)
        {
            Dictionary<int, int> t = black ? Black : White;
            int total = 0;
            while (true)
            {
                int code = 0, len = 0, run = Bad;
                while (len < 13)
                {
                    code = (code << 1) | b.Bit();
                    len++;
                    int r;
                    if (t.TryGetValue((len << 16) | code, out r)) { run = r; break; }
                }
                if (run == Bad) return Bad;
                total += run;
                if (run < 64) return total;
            }
        }

        // Consumes an end-of-line code (eleven or more zeros, then a one) if one is next.
        private static bool SkipEol(Bits b)
        {
            int save = b.Pos, zeros = 0;
            while (!b.End && b.Peek(1) == 0 && zeros < 64) { b.Bit(); zeros++; }
            if (zeros >= 11 && !b.End && b.Peek(1) == 1) { b.Bit(); return true; }
            b.Pos = save;
            return false;
        }

        public static byte[] Decode(byte[] data, int k, int columns, int rows, bool byteAlign, bool blackIs1)
        {
            if (columns <= 0 || columns > 100000) throw new PdfException("fax image has a bad width: " + columns);
            Bits b = new Bits(data);
            List<bool[]> lines = new List<bool[]>();         // true = black
            bool[] refLine = new bool[columns];
            int limit = rows > 0 ? rows : 200000;
            while (lines.Count < limit && !b.Past)
            {
                bool eol = false;
                if (k >= 0)
                {
                    eol = SkipEol(b);
                    if (!eol && byteAlign) b.Align();
                }
                else if (byteAlign) b.Align();
                if (k < 0 && b.Peek(12) == 1 && b.Peek(24) == 0x001001) break;          // end of block
                if (eol && SkipEol(b)) break;                                               // two EOLs: end of page
                if (b.End) break;
                bool twoD = k < 0;
                if (k > 0) twoD = b.Bit() == 0;
                bool[] cur = new bool[columns];
                bool ok = twoD ? Line2D(b, refLine, cur, columns) : Line1D(b, cur, columns);
                if (!ok)
                {
                    if (lines.Count == 0) throw new PdfException("fax image data is damaged from the first line");
                    break;                                   // keep what decoded; the rest stays white
                }
                lines.Add(cur);
                refLine = cur;
            }
            int h = rows > 0 ? rows : lines.Count;
            int stride = (columns + 7) / 8;
            byte[] outp = new byte[stride * h];
            byte blackBit = blackIs1 ? (byte)1 : (byte)0;
            for (int y = 0; y < h; y++)
            {
                bool[] line = y < lines.Count ? lines[y] : null;
                for (int x = 0; x < columns; x++)
                {
                    bool black = line != null && line[x];
                    if ((black ? blackBit : 1 - blackBit) == 1) outp[y * stride + (x >> 3)] |= (byte)(0x80 >> (x & 7));
                }
            }
            return outp;
        }

        public static int DecodedRows(byte[] decoded, int columns) { return decoded.Length / ((columns + 7) / 8); }

        private static void Fill(bool[] line, int from, int to, bool black)
        {
            if (from < 0) from = 0;
            if (to > line.Length) to = line.Length;
            for (int i = from; i < to; i++) line[i] = black;
        }

        private static bool Line1D(Bits b, bool[] cur, int columns)
        {
            int x = 0;
            bool black = false;
            while (x < columns)
            {
                int run = Run(b, black);
                if (run < 0) return false;
                Fill(cur, x, x + run, black);
                x += run;
                black = !black;
            }
            return true;
        }

        // b1: first changing element on the reference line right of a0 whose colour is the
        // opposite of a0's colour; b2 the next changing element after it.
        private static int Changing(bool[] line, int after, int columns)
        {
            if (after < 0)
            {
                if (columns > 0 && line[0]) return 0;
                after = 0;
            }
            for (int i = after + 1; i < columns; i++) if (line[i] != line[i - 1]) return i;
            return columns;
        }

        private static int FindB1(bool[] refLine, int a0, bool colour, int columns)
        {
            int p = a0;
            while (true)
            {
                int c = Changing(refLine, p, columns);
                if (c >= columns) return columns;
                if (refLine[c] != colour && (c > a0 || a0 < 0)) return c;
                p = c;
            }
        }

        private static bool Line2D(Bits b, bool[] refLine, bool[] cur, int columns)
        {
            int a0 = -1;
            bool colour = false;                             // false = white
            while (a0 < columns)
            {
                int b1 = FindB1(refLine, a0, colour, columns);
                int b2 = b1 >= columns ? columns : Changing(refLine, b1, columns);
                int start = a0 < 0 ? 0 : a0;
                if (b.Bit() == 1) { Fill(cur, start, b1, colour); a0 = b1; colour = !colour; continue; }        // V0
                int m2 = b.Bit();
                if (m2 == 1)
                {
                    int m3 = b.Bit();                        // 011 VR1, 010 VL1
                    int a1 = m3 == 1 ? b1 + 1 : b1 - 1;
                    if (a1 < start || a1 > columns) return false;
                    Fill(cur, start, a1, colour); a0 = a1; colour = !colour; continue;
                }
                if (b.Bit() == 1)                            // 001 horizontal
                {
                    int r1 = Run(b, colour), r2 = r1 < 0 ? -1 : Run(b, !colour);
                    if (r1 < 0 || r2 < 0) return false;
                    Fill(cur, start, start + r1, colour);
                    Fill(cur, start + r1, start + r1 + r2, !colour);
                    a0 = start + r1 + r2;
                    continue;
                }
                if (b.Bit() == 1) { Fill(cur, start, b2, colour); a0 = b2; continue; }                        // 0001 pass
                int v = 0, n = 4;                            // 00001x / 000001x vertical 2 and 3
                while (n < 7 && v == 0) { v = b.Bit(); n++; }
                if (v == 0) return false;                    // extension or EOL: not image data
                int d = n == 5 ? 2 : n == 6 ? 3 : -1;
                if (d < 0) return false;
                int dir = b.Bit();                           // 1 = right, 0 = left
                int a = dir == 1 ? b1 + d : b1 - d;
                if (a < start || a > columns) return false;
                Fill(cur, start, a, colour); a0 = a; colour = !colour;
            }
            return true;
        }
    }
}
