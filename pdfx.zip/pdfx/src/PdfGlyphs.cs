using System;
using System.Collections.Generic;

namespace Pdfx.Internal
{
    // Glyph outlines from fonts embedded in a PDF (TrueType and CFF, simple and CID-keyed), so typed
    // text can be drawn into a page image for OCR when the PDF's text layer cannot be trusted.
    internal sealed class GlyphPath
    {
        // commands: 0 move (x,y), 1 line (x,y), 2 quad (cx,cy,x,y), 3 cubic (c1x,c1y,c2x,c2y,x,y)
        public readonly List<int> Ops = new List<int>();
        public readonly List<double> Pts = new List<double>();
        public void Move(double x, double y) { Ops.Add(0); Pts.Add(x); Pts.Add(y); }
        public void Line(double x, double y) { Ops.Add(1); Pts.Add(x); Pts.Add(y); }
        public void Quad(double cx, double cy, double x, double y) { Ops.Add(2); Pts.Add(cx); Pts.Add(cy); Pts.Add(x); Pts.Add(y); }
        public void Cubic(double ax, double ay, double bx, double by, double x, double y) { Ops.Add(3); Pts.Add(ax); Pts.Add(ay); Pts.Add(bx); Pts.Add(by); Pts.Add(x); Pts.Add(y); }
        public bool Empty { get { return Ops.Count == 0; } }
    }

    // One embedded font program and the way the PDF's codes reach its glyphs.
    internal sealed class PdfFontProgram
    {
        private TrueTypeOutlines _tt;
        private CffOutlines _cff;
        private bool _cid;                          // Type0: code = CID
        private int[] _cidToGid;                    // null = identity
        private bool _symbolic;
        private Dictionary<int, string> _names;     // simple fonts: code -> glyph name (Differences)
        private string _baseEncoding;
        private readonly Dictionary<int, GlyphPath> _cache = new Dictionary<int, GlyphPath>();
        public string Problem;                      // why this font cannot be drawn, or null
        public double UnitsToText = 0.001;          // glyph units -> text space (1/em)
        public bool Usable { get { return _tt != null || _cff != null; } }

        public static PdfFontProgram Build(PdfFile f, PdfDictionary font)
        {
            PdfFontProgram p = new PdfFontProgram();
            if (font == null) { p.Problem = "no font"; return p; }
            try { p.Load(f, font); }
            catch (Exception e) { p._tt = null; p._cff = null; p.Problem = "font unreadable: " + e.Message; }
            return p;
        }

        private void Load(PdfFile f, PdfDictionary font)
        {
            PdfName st = f.Resolve(font.Get("Subtype")) as PdfName;
            string subtype = st == null ? "" : st.Value;
            PdfDictionary target = font;
            if (subtype == "Type0")
            {
                _cid = true;
                PdfArray desc = f.Resolve(font.Get("DescendantFonts")) as PdfArray;
                target = desc != null && desc.Count > 0 ? f.Resolve(desc[0]) as PdfDictionary : null;
                if (target == null) { Problem = "Type0 font without descendant"; return; }
                PdfObject c2g = f.Resolve(target.Get("CIDToGIDMap"));
                PdfStream c2gs = c2g as PdfStream;
                if (c2gs != null)
                {
                    byte[] m = PdfFilters.Decode(c2gs, f);
                    _cidToGid = new int[m.Length / 2];
                    for (int i = 0; i < _cidToGid.Length; i++) _cidToGid[i] = (m[2 * i] << 8) | m[2 * i + 1];
                }
            }
            else if (subtype == "Type3") { Problem = "Type3 font (drawn by the PDF itself) is not drawn"; return; }
            PdfDictionary fd = f.Resolve(target.Get("FontDescriptor")) as PdfDictionary;
            if (fd == null) { Problem = "font is not embedded"; return; }
            PdfNumber flags = f.Resolve(fd.Get("Flags")) as PdfNumber;
            _symbolic = flags != null && (flags.AsInt & 4) != 0;
            if (!_cid)
            {
                PdfObject enc = f.Resolve(font.Get("Encoding"));
                if (enc is PdfName) _baseEncoding = ((PdfName)enc).Value;
                PdfDictionary ed = enc as PdfDictionary;
                if (ed != null)
                {
                    PdfName be = f.Resolve(ed.Get("BaseEncoding")) as PdfName;
                    if (be != null) _baseEncoding = be.Value;
                    PdfArray diff = f.Resolve(ed.Get("Differences")) as PdfArray;
                    if (diff != null)
                    {
                        _names = new Dictionary<int, string>();
                        int code = 0;
                        foreach (PdfObject o in diff.Items)
                        {
                            PdfObject it = f.Resolve(o);
                            if (it is PdfNumber) code = ((PdfNumber)it).AsInt;
                            else if (it is PdfName) _names[code++] = ((PdfName)it).Value;
                        }
                    }
                }
            }
            PdfStream ff2 = f.Resolve(fd.Get("FontFile2")) as PdfStream;
            PdfStream ff3 = f.Resolve(fd.Get("FontFile3")) as PdfStream;
            if (ff2 != null)
            {
                _tt = new TrueTypeOutlines(PdfFilters.Decode(ff2, f));
                UnitsToText = 1.0 / _tt.UnitsPerEm;
            }
            else if (ff3 != null)
            {
                byte[] data = PdfFilters.Decode(ff3, f);
                if (data.Length >= 4 && data[0] == 'O' && data[1] == 'T' && data[2] == 'T' && data[3] == 'O')
                    data = TrueTypeOutlines.Table(data, "CFF ");
                else if (data.Length >= 4 && ((data[0] == 0 && data[1] == 1 && data[2] == 0 && data[3] == 0) || (data[0] == 't' && data[1] == 'r')))
                {
                    _tt = new TrueTypeOutlines(data);
                    UnitsToText = 1.0 / _tt.UnitsPerEm;
                    return;
                }
                _cff = new CffOutlines(data);
                UnitsToText = _cff.FontMatrixScale;
            }
            else if (fd.Has("FontFile")) Problem = "Type1 font program is not drawn";
            else Problem = "font is not embedded";
        }

        public GlyphPath Outline(int code)
        {
            GlyphPath g;
            if (_cache.TryGetValue(code, out g)) return g;
            g = null;
            try
            {
                int gid = GidFor(code);
                if (gid >= 0) g = _tt != null ? _tt.Glyph(gid) : _cff.Glyph(gid);
            }
            catch (Exception) { g = null; }
            _cache[code] = g;
            return g;
        }

        private int GidFor(int code)
        {
            if (_cid)
            {
                if (_cidToGid != null) return code < _cidToGid.Length ? _cidToGid[code] : 0;
                if (_cff != null) return _cff.GidForCid(code);
                return code;
            }
            if (_tt != null)
            {
                string name = null;
                if (_names != null) _names.TryGetValue(code, out name);
                // a symbolic font is reached by its own (3,0) or (1,0) table; a text font by Unicode
                if (!_symbolic || name != null)
                {
                    string u = name != null ? GlyphNames.ToText(name) : (_baseEncoding == "MacRomanEncoding" ? null : WinAnsi.ToText(code));
                    if (!string.IsNullOrEmpty(u) && u.Length == 1)
                    {
                        int gid = _tt.Lookup(3, 1, u[0]);
                        if (gid > 0) return gid;
                    }
                    if (name != null) { int byName = _tt.ByPostName(name); if (byName > 0) return byName; }
                }
                int s = _tt.Lookup(3, 0, 0xF000 + code);
                if (s <= 0) s = _tt.Lookup(3, 0, code);
                if (s <= 0) s = _tt.Lookup(1, 0, code);
                if (s <= 0) s = _tt.Lookup(3, 1, code);
                return s;
            }
            if (_cff != null)
            {
                string name = null;
                if (_names != null) _names.TryGetValue(code, out name);
                if (name != null) { int byName = _cff.GidForName(name); if (byName > 0) return byName; }
                return _cff.GidForCode(code);
            }
            return -1;
        }
    }

    internal sealed class TrueTypeOutlines
    {
        private readonly byte[] _d;
        private readonly Dictionary<string, int> _off = new Dictionary<string, int>();
        private readonly Dictionary<string, int> _len = new Dictionary<string, int>();
        public readonly int UnitsPerEm;
        private readonly bool _longLoca;
        private readonly int _numGlyphs;
        private Dictionary<string, int> _postNames;

        public TrueTypeOutlines(byte[] d)
        {
            _d = d;
            int at = 0;
            if (d.Length >= 12 && d[0] == 't' && d[1] == 't' && d[2] == 'c' && d[3] == 'f') at = (int)U32(12);
            int n = U16(at + 4);
            for (int i = 0; i < n; i++)
            {
                int r = at + 12 + 16 * i;
                string tag = "" + (char)d[r] + (char)d[r + 1] + (char)d[r + 2] + (char)d[r + 3];
                _off[tag] = (int)U32(r + 8);
                _len[tag] = (int)U32(r + 12);
            }
            if (!_off.ContainsKey("glyf") || !_off.ContainsKey("loca") || !_off.ContainsKey("head")) throw new PdfException("TrueType font without outlines");
            UnitsPerEm = U16(_off["head"] + 18);
            if (UnitsPerEm < 16 || UnitsPerEm > 16384) UnitsPerEm = 1000;
            _longLoca = S16(_off["head"] + 50) != 0;
            _numGlyphs = _off.ContainsKey("maxp") ? U16(_off["maxp"] + 4) : (_len["loca"] / (_longLoca ? 4 : 2)) - 1;
        }

        public static byte[] Table(byte[] d, string tag)
        {
            TrueTypeOutlinesRaw r = new TrueTypeOutlinesRaw(d);
            return r.Get(tag);
        }

        private int U16(int o) { return o + 1 < _d.Length ? (_d[o] << 8) | _d[o + 1] : 0; }
        private int S16(int o) { return (short)U16(o); }
        private uint U32(int o) { return o + 3 < _d.Length ? ((uint)_d[o] << 24) | ((uint)_d[o + 1] << 16) | ((uint)_d[o + 2] << 8) | _d[o + 3] : 0; }

        private int GlyphStart(int gid, out int len)
        {
            len = 0;
            if (gid < 0 || gid >= _numGlyphs) return -1;
            int l = _off["loca"];
            int a, b;
            if (_longLoca) { a = (int)U32(l + 4 * gid); b = (int)U32(l + 4 * gid + 4); }
            else { a = 2 * U16(l + 2 * gid); b = 2 * U16(l + 2 * gid + 2); }
            len = b - a;
            return _off["glyf"] + a;
        }

        public GlyphPath Glyph(int gid)
        {
            GlyphPath p = new GlyphPath();
            AddGlyph(p, gid, 1, 0, 0, 1, 0, 0, 0);
            return p;
        }

        private void AddGlyph(GlyphPath p, int gid, double a, double b, double c, double d, double e, double f, int depth)
        {
            if (depth > 8) return;
            int len;
            int g = GlyphStart(gid, out len);
            if (g < 0 || len <= 0) return;
            int contours = S16(g);
            if (contours >= 0) { Simple(p, g, contours, a, b, c, d, e, f); return; }
            int at = g + 10;
            while (true)
            {
                int flags = U16(at), comp = U16(at + 2);
                at += 4;
                double dx, dy;
                if ((flags & 1) != 0) { dx = S16(at); dy = S16(at + 2); at += 4; }
                else { dx = (sbyte)_d[at]; dy = (sbyte)_d[at + 1]; at += 2; }
                if ((flags & 2) == 0) { dx = 0; dy = 0; }       // point matching: not used for drawing
                double ca = 1, cb = 0, cc = 0, cd = 1;
                if ((flags & 8) != 0) { ca = cd = F2(at); at += 2; }
                else if ((flags & 0x40) != 0) { ca = F2(at); cd = F2(at + 2); at += 4; }
                else if ((flags & 0x80) != 0) { ca = F2(at); cb = F2(at + 2); cc = F2(at + 4); cd = F2(at + 6); at += 8; }
                // component matrix then the parent's
                double na = ca * a + cb * c, nb = ca * b + cb * d, nc = cc * a + cd * c, nd = cc * b + cd * d;
                double ne = dx * a + dy * c + e, nf = dx * b + dy * d + f;
                AddGlyph(p, comp, na, nb, nc, nd, ne, nf, depth + 1);
                if ((flags & 0x20) == 0) break;
            }
        }

        private double F2(int o) { return S16(o) / 16384.0; }

        private void Simple(GlyphPath p, int g, int contours, double a, double b, double c, double d, double e, double f)
        {
            if (contours == 0) return;
            int[] ends = new int[contours];
            for (int i = 0; i < contours; i++) ends[i] = U16(g + 10 + 2 * i);
            int n = ends[contours - 1] + 1;
            if (n <= 0 || n > 65535) return;
            int at = g + 10 + 2 * contours;
            int ins = U16(at);
            at += 2 + ins;
            byte[] fl = new byte[n];
            for (int i = 0; i < n; )
            {
                byte v = _d[at++];
                fl[i++] = v;
                if ((v & 8) != 0) { int rep = _d[at++]; while (rep-- > 0 && i < n) fl[i++] = v; }
            }
            double[] xs = new double[n], ys = new double[n];
            int x = 0;
            for (int i = 0; i < n; i++)
            {
                if ((fl[i] & 2) != 0) { int v = _d[at++]; x += (fl[i] & 16) != 0 ? v : -v; }
                else if ((fl[i] & 16) == 0) { x += S16(at); at += 2; }
                xs[i] = x;
            }
            int y = 0;
            for (int i = 0; i < n; i++)
            {
                if ((fl[i] & 4) != 0) { int v = _d[at++]; y += (fl[i] & 32) != 0 ? v : -v; }
                else if ((fl[i] & 32) == 0) { y += S16(at); at += 2; }
                ys[i] = y;
            }
            for (int i = 0; i < n; i++)
            {
                double tx = xs[i] * a + ys[i] * c + e, ty = xs[i] * b + ys[i] * d + f;
                xs[i] = tx; ys[i] = ty;
            }
            int start = 0;
            for (int k = 0; k < contours; k++)
            {
                int end = ends[k];
                if (end < start || end >= n) return;
                Contour(p, xs, ys, fl, start, end);
                start = end + 1;
            }
        }

        // a closed quadratic B-spline: two off-curve points in a row imply an on-curve one between them
        private static void Contour(GlyphPath p, double[] xs, double[] ys, byte[] fl, int s, int e)
        {
            int count = e - s + 1;
            if (count < 2) return;
            Func<int, bool> on = i => (fl[s + ((i % count) + count) % count] & 1) != 0;
            Func<int, double> X = i => xs[s + ((i % count) + count) % count];
            Func<int, double> Y = i => ys[s + ((i % count) + count) % count];
            int first = -1;
            for (int i = 0; i < count; i++) if (on(i)) { first = i; break; }
            double sx, sy;
            if (first < 0) { sx = (X(0) + X(1)) / 2; sy = (Y(0) + Y(1)) / 2; first = 0; }   // all off-curve
            else { sx = X(first); sy = Y(first); }
            p.Move(sx, sy);
            bool startsOff = !on(first);
            int idx = first + (startsOff ? 0 : 1);
            for (int step = 0; step < count; step++, idx++)
            {
                if (on(idx)) { p.Line(X(idx), Y(idx)); continue; }
                double cx = X(idx), cy = Y(idx), nx, ny;
                if (on(idx + 1)) { nx = X(idx + 1); ny = Y(idx + 1); idx++; step++; }
                else { nx = (cx + X(idx + 1)) / 2; ny = (cy + Y(idx + 1)) / 2; }
                p.Quad(cx, cy, nx, ny);
            }
            p.Line(sx, sy);
        }

        public int Lookup(int platform, int encoding, int code)
        {
            int cmap;
            if (!_off.TryGetValue("cmap", out cmap)) return 0;
            int n = U16(cmap + 2);
            for (int i = 0; i < n; i++)
            {
                int r = cmap + 4 + 8 * i;
                if (U16(r) != platform || U16(r + 2) != encoding) continue;
                int t = cmap + (int)U32(r + 4);
                int g = Sub(t, code);
                if (g > 0) return g;
            }
            return 0;
        }

        private int Sub(int t, int code)
        {
            int format = U16(t);
            if (format == 0) return code >= 0 && code < 256 ? _d[t + 6 + code] : 0;
            if (format == 6)
            {
                int first = U16(t + 6), cnt = U16(t + 8);
                return code >= first && code < first + cnt ? U16(t + 10 + 2 * (code - first)) : 0;
            }
            if (format == 4)
            {
                int segX2 = U16(t + 6);
                int ends = t + 14, starts = ends + segX2 + 2, deltas = starts + segX2, ranges = deltas + segX2;
                for (int i = 0; i < segX2 / 2; i++)
                {
                    int end = U16(ends + 2 * i);
                    if (code > end) continue;
                    int st = U16(starts + 2 * i);
                    if (code < st) return 0;
                    int delta = S16(deltas + 2 * i), ro = U16(ranges + 2 * i);
                    if (ro == 0) return (code + delta) & 0xFFFF;
                    int gi = U16(ranges + 2 * i + ro + 2 * (code - st));
                    return gi == 0 ? 0 : (gi + delta) & 0xFFFF;
                }
                return 0;
            }
            if (format == 12)
            {
                int groups = (int)U32(t + 12);
                for (int i = 0; i < groups; i++)
                {
                    int r = t + 16 + 12 * i;
                    uint a = U32(r), b = U32(r + 4);
                    if (code >= a && code <= b) return (int)(U32(r + 8) + (code - a));
                }
            }
            return 0;
        }

        // glyph names from a version 2 'post' table (custom names only; standard Mac names by index)
        public int ByPostName(string name)
        {
            if (_postNames == null)
            {
                _postNames = new Dictionary<string, int>();
                int post;
                if (_off.TryGetValue("post", out post) && U32(post) == 0x00020000)
                {
                    int n = U16(post + 32);
                    int namesAt = post + 34 + 2 * n;
                    List<string> custom = new List<string>();
                    int at = namesAt;
                    while (at < post + _len["post"] && at < _d.Length)
                    {
                        int l = _d[at];
                        if (at + 1 + l > _d.Length) break;
                        char[] cs = new char[l];
                        for (int i = 0; i < l; i++) cs[i] = (char)_d[at + 1 + i];
                        custom.Add(new string(cs));
                        at += 1 + l;
                    }
                    for (int g = 0; g < n; g++)
                    {
                        int idx = U16(post + 34 + 2 * g);
                        if (idx >= 258 && idx - 258 < custom.Count && !_postNames.ContainsKey(custom[idx - 258])) _postNames[custom[idx - 258]] = g;
                    }
                }
            }
            int r;
            return _postNames.TryGetValue(name, out r) ? r : 0;
        }
    }

    internal sealed class TrueTypeOutlinesRaw
    {
        private readonly byte[] _d;
        public TrueTypeOutlinesRaw(byte[] d) { _d = d; }
        public byte[] Get(string tag)
        {
            int n = (_d[4] << 8) | _d[5];
            for (int i = 0; i < n; i++)
            {
                int r = 12 + 16 * i;
                if (_d[r] == tag[0] && _d[r + 1] == tag[1] && _d[r + 2] == tag[2] && _d[r + 3] == tag[3])
                {
                    int off = (_d[r + 8] << 24) | (_d[r + 9] << 16) | (_d[r + 10] << 8) | _d[r + 11];
                    int len = (_d[r + 12] << 24) | (_d[r + 13] << 16) | (_d[r + 14] << 8) | _d[r + 15];
                    byte[] t = new byte[len];
                    Buffer.BlockCopy(_d, off, t, 0, len);
                    return t;
                }
            }
            throw new PdfException("OpenType font without a '" + tag + "' table");
        }
    }

    internal sealed class CffOutlines
    {
        private readonly byte[] _d;
        private readonly List<int[]> _charStrings;          // [start, end) per glyph
        private readonly List<int[]> _gsubrs;
        private readonly List<int[]> _lsubrs;                // non-CID fonts
        private readonly List<List<int[]>> _fdSubrs;         // CID fonts: per font dict
        private readonly byte[] _fdSelect;                   // gid -> FD index
        private readonly int[] _charset;                     // gid -> SID or CID
        private readonly bool _isCid;
        private readonly Dictionary<int, int> _encoding = new Dictionary<int, int>();   // code -> gid
        private readonly List<string> _strings;
        public readonly double FontMatrixScale = 0.001;

        public CffOutlines(byte[] d)
        {
            _d = d;
            int at = d[2];
            List<int[]> names = Index(ref at);
            List<int[]> tops = Index(ref at);
            List<int[]> strs = Index(ref at);
            _strings = new List<string>();
            foreach (int[] s in strs) _strings.Add(Str(s));
            _gsubrs = Index(ref at);
            if (tops.Count == 0) throw new PdfException("CFF font without a Top DICT");
            Dictionary<int, List<double>> top = Dict(tops[0][0], tops[0][1]);
            List<double> v;
            if (top.TryGetValue(1207, out v) && v.Count >= 4 && v[0] != 0) FontMatrixScale = Math.Abs(v[0]);
            if (!top.TryGetValue(17, out v)) throw new PdfException("CFF font without CharStrings");
            int cs = (int)v[0];
            _charStrings = Index(ref cs);
            int n = _charStrings.Count;
            _isCid = top.ContainsKey(1230);
            _charset = new int[n];
            int charsetAt = top.TryGetValue(15, out v) ? (int)v[0] : 0;
            if (charsetAt > 2) ReadCharset(charsetAt, n);
            else for (int i = 0; i < n; i++) _charset[i] = i;
            if (_isCid)
            {
                _fdSubrs = new List<List<int[]>>();
                if (top.TryGetValue(1236, out v))
                {
                    int fa = (int)v[0];
                    foreach (int[] fdict in Index(ref fa))
                        _fdSubrs.Add(PrivateSubrs(Dict(fdict[0], fdict[1])));
                }
                _fdSelect = new byte[n];
                if (top.TryGetValue(1237, out v)) ReadFdSelect((int)v[0], n);
            }
            else
            {
                _lsubrs = PrivateSubrs(top);
                int encAt = top.TryGetValue(16, out v) ? (int)v[0] : 0;
                if (encAt > 1) ReadEncoding(encAt);
                else
                {
                    // standard encoding: code -> name -> gid through the charset's SIDs
                    for (int code = 0; code < 256; code++)
                    {
                        int sid = StandardEncodingSid(code);
                        if (sid == 0) continue;
                        for (int g = 1; g < n; g++) if (_charset[g] == sid) { _encoding[code] = g; break; }
                    }
                }
            }
        }

        private int U16(int o) { return (_d[o] << 8) | _d[o + 1]; }
        private int Off(int o, int size) { int r = 0; for (int i = 0; i < size; i++) r = (r << 8) | _d[o + i]; return r; }
        private string Str(int[] s) { char[] c = new char[s[1] - s[0]]; for (int i = 0; i < c.Length; i++) c[i] = (char)_d[s[0] + i]; return new string(c); }

        private List<int[]> Index(ref int at)
        {
            List<int[]> r = new List<int[]>();
            int count = U16(at);
            if (count == 0) { at += 2; return r; }
            int os = _d[at + 2];
            int offs = at + 3, data = offs + (count + 1) * os - 1;
            for (int i = 0; i < count; i++) r.Add(new[] { data + Off(offs + i * os, os), data + Off(offs + (i + 1) * os, os) });
            at = data + Off(offs + count * os, os);
            return r;
        }

        // DICT: operator (12 x -> 1200 + x) -> operands
        private Dictionary<int, List<double>> Dict(int s, int e)
        {
            Dictionary<int, List<double>> r = new Dictionary<int, List<double>>();
            List<double> ops = new List<double>();
            int i = s;
            while (i < e)
            {
                int b = _d[i];
                if (b <= 21)
                {
                    int op = b;
                    if (b == 12) { op = 1200 + _d[i + 1]; i++; }
                    r[op] = ops;
                    ops = new List<double>();
                    i++;
                }
                else if (b == 28) { ops.Add((short)U16(i + 1)); i += 3; }
                else if (b == 29) { ops.Add((_d[i + 1] << 24) | (_d[i + 2] << 16) | (_d[i + 3] << 8) | _d[i + 4]); i += 5; }
                else if (b == 30)
                {
                    System.Text.StringBuilder sb = new System.Text.StringBuilder();
                    i++;
                    bool done = false;
                    while (!done && i < e)
                    {
                        int byt = _d[i++];
                        for (int h = 0; h < 2 && !done; h++)
                        {
                            int nib = h == 0 ? byt >> 4 : byt & 15;
                            if (nib <= 9) sb.Append((char)('0' + nib));
                            else if (nib == 10) sb.Append('.');
                            else if (nib == 11) sb.Append('E');
                            else if (nib == 12) sb.Append("E-");
                            else if (nib == 14) sb.Append('-');
                            else if (nib == 15) done = true;
                        }
                    }
                    double val;
                    ops.Add(double.TryParse(sb.ToString(), System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out val) ? val : 0);
                }
                else if (b >= 32 && b <= 246) { ops.Add(b - 139); i++; }
                else if (b >= 247 && b <= 250) { ops.Add((b - 247) * 256 + _d[i + 1] + 108); i += 2; }
                else if (b >= 251 && b <= 254) { ops.Add(-(b - 251) * 256 - _d[i + 1] - 108); i += 2; }
                else i++;
            }
            return r;
        }

        private List<int[]> PrivateSubrs(Dictionary<int, List<double>> dict)
        {
            List<double> v;
            if (!dict.TryGetValue(18, out v) || v.Count < 2) return new List<int[]>();
            int size = (int)v[0], off = (int)v[1];
            Dictionary<int, List<double>> priv = Dict(off, off + size);
            if (!priv.TryGetValue(19, out v)) return new List<int[]>();
            int at = off + (int)v[0];
            return Index(ref at);
        }

        private void ReadCharset(int at, int n)
        {
            int fmt = _d[at++];
            int g = 1;
            if (fmt == 0) { while (g < n) { _charset[g++] = U16(at); at += 2; } return; }
            while (g < n)
            {
                int first = U16(at);
                int left = fmt == 1 ? _d[at + 2] : U16(at + 2);
                at += fmt == 1 ? 3 : 4;
                for (int k = 0; k <= left && g < n; k++) _charset[g++] = first + k;
            }
        }

        private void ReadFdSelect(int at, int n)
        {
            int fmt = _d[at];
            if (fmt == 0) { for (int g = 0; g < n; g++) _fdSelect[g] = _d[at + 1 + g]; return; }
            if (fmt == 3)
            {
                int ranges = U16(at + 1);
                for (int r = 0; r < ranges; r++)
                {
                    int first = U16(at + 3 + 3 * r), fd = _d[at + 5 + 3 * r], next = U16(at + 6 + 3 * r);
                    for (int g = first; g < next && g < n; g++) _fdSelect[g] = (byte)fd;
                }
            }
        }

        private void ReadEncoding(int at)
        {
            int fmt = _d[at] & 0x7F;
            bool supplements = (_d[at] & 0x80) != 0;
            int p = at + 1;
            if (fmt == 0)
            {
                int n = _d[p++];
                for (int g = 1; g <= n; g++) _encoding[_d[p++]] = g;
            }
            else if (fmt == 1)
            {
                int ranges = _d[p++], g = 1;
                for (int r = 0; r < ranges; r++)
                {
                    int first = _d[p], left = _d[p + 1];
                    p += 2;
                    for (int k = 0; k <= left; k++) _encoding[first + k] = g++;
                }
            }
            if (supplements)
            {
                int ns = _d[p++];
                for (int s = 0; s < ns; s++)
                {
                    int code = _d[p], sid = U16(p + 1);
                    p += 3;
                    for (int g = 1; g < _charset.Length; g++) if (_charset[g] == sid) { _encoding[code] = g; break; }
                }
            }
        }

        public int GidForCid(int cid)
        {
            if (!_isCid) return cid < _charStrings.Count ? cid : 0;
            for (int g = 0; g < _charset.Length; g++) if (_charset[g] == cid) return g;
            return 0;
        }

        public int GidForCode(int code)
        {
            int g;
            if (_encoding.TryGetValue(code, out g)) return g;
            return code < _charStrings.Count ? code : 0;
        }

        // only custom strings (SID 391 and up) are known here; standard names come through the encoding
        public int GidForName(string name)
        {
            int idx = _strings.IndexOf(name);
            if (idx < 0) return 0;
            int sid = 391 + idx;
            for (int g = 1; g < _charset.Length; g++) if (_charset[g] == sid) return g;
            return 0;
        }

        private static int StandardEncodingSid(int code)
        {
            // Standard Encoding: printable ASCII 32-126 are SIDs 1-95 in order
            if (code >= 32 && code <= 126) return code - 31;
            return 0;
        }

        // ---- Type 2 charstrings ------------------------------------------------------------

        private static int Bias(int n) { return n < 1240 ? 107 : n < 33900 ? 1131 : 32768; }

        public GlyphPath Glyph(int gid)
        {
            if (gid < 0 || gid >= _charStrings.Count) return null;
            List<int[]> local = _isCid ? (_fdSubrs.Count > 0 ? _fdSubrs[Math.Min(_fdSelect[gid], _fdSubrs.Count - 1)] : new List<int[]>()) : _lsubrs;
            Interp t = new Interp();
            t.Run(this, _charStrings[gid], local, 0);
            if (t.Open) t.P.Line(t.SX, t.SY);
            return t.P;
        }

        private sealed class Interp
        {
            public readonly GlyphPath P = new GlyphPath();
            public readonly List<double> S = new List<double>();
            public double X, Y, SX, SY;
            public bool Open, WidthSeen, Ended;
            public int Stems;

            void Close() { if (Open) { P.Line(SX, SY); Open = false; } }
            void MoveTo(double dx, double dy) { Close(); X += dx; Y += dy; SX = X; SY = Y; P.Move(X, Y); Open = true; }
            void LineTo(double dx, double dy) { X += dx; Y += dy; P.Line(X, Y); }
            void CurveTo(double a, double b, double c, double d, double e, double f)
            {
                double x1 = X + a, y1 = Y + b, x2 = x1 + c, y2 = y1 + d;
                X = x2 + e; Y = y2 + f;
                P.Cubic(x1, y1, x2, y2, X, Y);
            }
            void Width(int expectedEven) { if (!WidthSeen) { if (S.Count > expectedEven && ((S.Count - expectedEven) % 2 == 1 || expectedEven < 0)) S.RemoveAt(0); WidthSeen = true; } }

            public void Run(CffOutlines c, int[] cs, List<int[]> local, int depth)
            {
                if (depth > 10 || Ended) return;
                byte[] d = c._d;
                int i = cs[0];
                while (i < cs[1] && !Ended)
                {
                    int b = d[i];
                    if (b >= 32 || b == 28)
                    {
                        if (b == 28) { S.Add((short)((d[i + 1] << 8) | d[i + 2])); i += 3; }
                        else if (b <= 246) { S.Add(b - 139); i++; }
                        else if (b <= 250) { S.Add((b - 247) * 256 + d[i + 1] + 108); i += 2; }
                        else if (b <= 254) { S.Add(-(b - 251) * 256 - d[i + 1] - 108); i += 2; }
                        else { S.Add(((d[i + 1] << 24) | (d[i + 2] << 16) | (d[i + 3] << 8) | d[i + 4]) / 65536.0); i += 5; }
                        continue;
                    }
                    i++;
                    switch (b)
                    {
                        case 1: case 3: case 18: case 23:              // stems
                            if (!WidthSeen && S.Count % 2 == 1) S.RemoveAt(0);
                            WidthSeen = true;
                            Stems += S.Count / 2; S.Clear(); break;
                        case 19: case 20:                              // hintmask, cntrmask
                            if (!WidthSeen && S.Count % 2 == 1) S.RemoveAt(0);
                            WidthSeen = true;
                            Stems += S.Count / 2; S.Clear();
                            i += (Stems + 7) / 8; break;
                        case 21:
                            if (!WidthSeen && S.Count > 2) S.RemoveAt(0);
                            WidthSeen = true;
                            if (S.Count >= 2) MoveTo(S[0], S[1]); S.Clear(); break;
                        case 22:
                            if (!WidthSeen && S.Count > 1) S.RemoveAt(0);
                            WidthSeen = true;
                            if (S.Count >= 1) MoveTo(S[0], 0); S.Clear(); break;
                        case 4:
                            if (!WidthSeen && S.Count > 1) S.RemoveAt(0);
                            WidthSeen = true;
                            if (S.Count >= 1) MoveTo(0, S[0]); S.Clear(); break;
                        case 5: for (int k = 0; k + 1 < S.Count; k += 2) LineTo(S[k], S[k + 1]); S.Clear(); break;
                        case 6: case 7:
                        {
                            bool h = b == 6;
                            for (int k = 0; k < S.Count; k++) { if (h) LineTo(S[k], 0); else LineTo(0, S[k]); h = !h; }
                            S.Clear(); break;
                        }
                        case 8: for (int k = 0; k + 5 < S.Count; k += 6) CurveTo(S[k], S[k + 1], S[k + 2], S[k + 3], S[k + 4], S[k + 5]); S.Clear(); break;
                        case 24:
                        {
                            int k = 0;
                            for (; k + 5 < S.Count - 2; k += 6) CurveTo(S[k], S[k + 1], S[k + 2], S[k + 3], S[k + 4], S[k + 5]);
                            if (k + 1 < S.Count) LineTo(S[k], S[k + 1]);
                            S.Clear(); break;
                        }
                        case 25:
                        {
                            int k = 0;
                            for (; k + 1 < S.Count - 6; k += 2) LineTo(S[k], S[k + 1]);
                            if (k + 5 < S.Count) CurveTo(S[k], S[k + 1], S[k + 2], S[k + 3], S[k + 4], S[k + 5]);
                            S.Clear(); break;
                        }
                        case 26:
                        {
                            int k = 0; double dx1 = 0;
                            if (S.Count % 4 == 1) { dx1 = S[0]; k = 1; }
                            for (; k + 3 < S.Count; k += 4) { CurveTo(dx1, S[k], S[k + 1], S[k + 2], 0, S[k + 3]); dx1 = 0; }
                            S.Clear(); break;
                        }
                        case 27:
                        {
                            int k = 0; double dy1 = 0;
                            if (S.Count % 4 == 1) { dy1 = S[0]; k = 1; }
                            for (; k + 3 < S.Count; k += 4) { CurveTo(S[k], dy1, S[k + 1], S[k + 2], S[k + 3], 0); dy1 = 0; }
                            S.Clear(); break;
                        }
                        case 30: case 31:
                        {
                            bool h = b == 31;
                            int k = 0;
                            while (k + 3 < S.Count)
                            {
                                bool last = k + 4 >= S.Count - 1;
                                double extra = last && S.Count - k == 5 ? S[k + 4] : 0;
                                if (h) CurveTo(S[k], 0, S[k + 1], S[k + 2], extra, S[k + 3]);
                                else CurveTo(0, S[k], S[k + 1], S[k + 2], S[k + 3], extra);
                                h = !h; k += 4;
                            }
                            S.Clear(); break;
                        }
                        case 10: case 29:
                        {
                            if (S.Count == 0) break;
                            List<int[]> subrs = b == 10 ? local : c._gsubrs;
                            int idx = (int)S[S.Count - 1] + Bias(subrs.Count);
                            S.RemoveAt(S.Count - 1);
                            if (idx >= 0 && idx < subrs.Count) Run(c, subrs[idx], local, depth + 1);
                            break;
                        }
                        case 11: return;
                        case 14:
                            if (!WidthSeen && (S.Count == 1 || S.Count == 5)) S.RemoveAt(0);
                            WidthSeen = true;
                            Close(); Ended = true; S.Clear(); return;
                        case 12:
                        {
                            int e = d[i++];
                            double[] a = S.ToArray();
                            if (e == 35 && a.Length >= 12) { CurveTo(a[0], a[1], a[2], a[3], a[4], a[5]); CurveTo(a[6], a[7], a[8], a[9], a[10], a[11]); }
                            else if (e == 34 && a.Length >= 7) { double y0 = Y; CurveTo(a[0], 0, a[1], a[2], a[3], 0); CurveTo(a[4], 0, a[5], y0 - Y, a[6], 0); }
                            else if (e == 36 && a.Length >= 9) { double y0 = Y; CurveTo(a[0], a[1], a[2], a[3], a[4], 0); CurveTo(a[5], 0, a[6], a[7], a[8], y0 - Y); }
                            else if (e == 37 && a.Length >= 11)
                            {
                                // flex1: the last point returns to the start on the minor axis
                                double x0 = X, y0 = Y;
                                double dx = a[0] + a[2] + a[4] + a[6] + a[8], dy = a[1] + a[3] + a[5] + a[7] + a[9];
                                CurveTo(a[0], a[1], a[2], a[3], a[4], a[5]);
                                if (Math.Abs(dx) > Math.Abs(dy)) CurveTo(a[6], a[7], a[8], a[9], a[10], -dy);
                                else CurveTo(a[6], a[7], a[8], a[9], -dx, a[10]);
                            }
                            S.Clear(); break;
                        }
                        default: S.Clear(); break;
                    }
                }
            }
        }
    }

    // A Type 3 font: every glyph is a small content stream (paths, strokes or image masks) in the
    // font's own glyph space. Drawn in black, colours ignored.
    internal sealed class Type3Program
    {
        private readonly PdfFile _f;
        private readonly PdfDictionary _procs, _res;
        private readonly Dictionary<int, string> _names = new Dictionary<int, string>();
        public PdfMatrix FontMatrix;
        public string Problem;

        public Type3Program(PdfFile f, PdfDictionary font, double[] fm, PdfDictionary pageResources)
        {
            _f = f;
            FontMatrix = new PdfMatrix(fm[0], fm[1], fm[2], fm[3], fm[4], fm[5]);
            _procs = f.Resolve(font.Get("CharProcs")) as PdfDictionary;
            _res = f.Resolve(font.Get("Resources")) as PdfDictionary ?? pageResources;
            if (_procs == null) Problem = "Type3 font without glyph procedures";
            PdfDictionary enc = f.Resolve(font.Get("Encoding")) as PdfDictionary;
            PdfArray diff = enc == null ? null : f.Resolve(enc.Get("Differences")) as PdfArray;
            if (diff != null)
            {
                int code = 0;
                foreach (PdfObject o in diff.Items)
                {
                    PdfObject it = f.Resolve(o);
                    if (it is PdfNumber) code = ((PdfNumber)it).AsInt;
                    else if (it is PdfName) _names[code++] = ((PdfName)it).Value;
                }
            }
        }

        public void Draw(GreyImage page, int code, PdfMatrix glyphToRaster)
        {
            string name;
            if (_procs == null || !_names.TryGetValue(code, out name)) return;
            PdfStream proc = _f.Resolve(_procs.Get(name)) as PdfStream;
            if (proc == null) return;
            byte[] body;
            try { body = PdfFilters.Decode(proc, _f); } catch (Exception) { return; }
            Run(page, body, _res, glyphToRaster, 0);
        }

        private void Run(GreyImage page, byte[] content, PdfDictionary res, PdfMatrix ctm, int depth)
        {
            if (depth > 6) return;
            PdfLexer lex = new PdfLexer(content);
            PdfParser parser = new PdfParser(content, null);
            List<double> nums = new List<double>();
            PdfName lastName = null;
            Stack<PdfMatrix> saved = new Stack<PdfMatrix>();
            Stack<double> savedWidth = new Stack<double>();
            GlyphPath path = new GlyphPath();
            double lineWidth = 1, cx = 0, cy = 0;
            while (true)
            {
                int before = lex.Position;
                Token t = lex.Next();
                if (t.Type == TokenType.Eof) break;
                if (t.Type != TokenType.Keyword)
                {
                    parser.Position = before;
                    PdfObject o;
                    try { o = parser.ParseObject(); } catch (Exception) { break; }
                    lex.Position = parser.Position;
                    if (o is PdfNumber) nums.Add(((PdfNumber)o).Value);
                    else if (o is PdfName) lastName = (PdfName)o;
                    continue;
                }
                int k = nums.Count;
                switch (t.Text)
                {
                    case "q": saved.Push(ctm); savedWidth.Push(lineWidth); break;
                    case "Q": if (saved.Count > 0) { ctm = saved.Pop(); lineWidth = savedWidth.Pop(); } break;
                    case "cm": if (k >= 6) ctm = PdfMatrix.Multiply(new PdfMatrix(nums[k - 6], nums[k - 5], nums[k - 4], nums[k - 3], nums[k - 2], nums[k - 1]), ctm); break;
                    case "w": if (k >= 1) lineWidth = nums[k - 1]; break;
                    case "m": if (k >= 2) { path.Move(nums[k - 2], nums[k - 1]); cx = nums[k - 2]; cy = nums[k - 1]; } break;
                    case "l": if (k >= 2) { path.Line(nums[k - 2], nums[k - 1]); cx = nums[k - 2]; cy = nums[k - 1]; } break;
                    case "c": if (k >= 6) { path.Cubic(nums[k - 6], nums[k - 5], nums[k - 4], nums[k - 3], nums[k - 2], nums[k - 1]); cx = nums[k - 2]; cy = nums[k - 1]; } break;
                    case "v": if (k >= 4) { path.Cubic(cx, cy, nums[k - 4], nums[k - 3], nums[k - 2], nums[k - 1]); cx = nums[k - 2]; cy = nums[k - 1]; } break;
                    case "y": if (k >= 4) { path.Cubic(nums[k - 4], nums[k - 3], nums[k - 2], nums[k - 1], nums[k - 2], nums[k - 1]); cx = nums[k - 2]; cy = nums[k - 1]; } break;
                    case "re":
                        if (k >= 4)
                        {
                            double x = nums[k - 4], y = nums[k - 3], w = nums[k - 2], h = nums[k - 1];
                            path.Move(x, y); path.Line(x + w, y); path.Line(x + w, y + h); path.Line(x, y + h); path.Line(x, y);
                        }
                        break;
                    case "h": break;                                    // the filler closes every subpath
                    case "f": case "F": case "f*": case "B": case "B*": case "b": case "b*":
                        GlyphRaster.Fill(page, path, ctm); path = new GlyphPath(); break;
                    case "S": case "s":
                        GlyphRaster.Stroke(page, path, ctm, lineWidth); path = new GlyphPath(); break;
                    case "n": path = new GlyphPath(); break;
                    case "Do":
                        if (lastName != null) DoXObject(page, lastName.Value, res, ctm, depth);
                        break;
                    case "BI":
                    {
                        PdfStream img = PdfScanPage.ReadInline(lex, parser);
                        if (img != null) Image(page, img, res, ctm);
                        break;
                    }
                }
                nums.Clear();
                lastName = null;
            }
        }

        private void DoXObject(GreyImage page, string name, PdfDictionary res, PdfMatrix ctm, int depth)
        {
            PdfDictionary xo = res == null ? null : _f.Resolve(res.Get("XObject")) as PdfDictionary;
            PdfStream s = xo == null ? null : _f.Resolve(xo.Get(name)) as PdfStream;
            if (s == null) return;
            PdfName sub = _f.Resolve(s.Dict.Get("Subtype")) as PdfName;
            if (sub != null && sub.Value == "Image") { Image(page, s, res, ctm); return; }
            if (sub == null || sub.Value != "Form") return;
            PdfMatrix inner = ctm;
            PdfArray mx = _f.Resolve(s.Dict.Get("Matrix")) as PdfArray;
            if (mx != null && mx.Count >= 6)
            {
                double[] v = new double[6];
                for (int i = 0; i < 6; i++) { PdfNumber n = _f.Resolve(mx[i]) as PdfNumber; v[i] = n == null ? 0 : n.Value; }
                inner = PdfMatrix.Multiply(new PdfMatrix(v[0], v[1], v[2], v[3], v[4], v[5]), ctm);
            }
            byte[] body;
            try { body = PdfFilters.Decode(s, _f); } catch (Exception) { return; }
            Run(page, body, _f.Resolve(s.Dict.Get("Resources")) as PdfDictionary ?? res, inner, depth + 1);
        }

        private void Image(GreyImage page, PdfStream s, PdfDictionary res, PdfMatrix ctm)
        {
            string why;
            GreyImage g = ImageDecoder.Decode(_f, s, res, out why);
            if (g != null) PdfScanPage.Paint(page, g, ctm);
        }
    }

    // Fills glyph outlines into a grey page: non-zero winding, anti-aliased with 4 sub-scanlines a
    // pixel and exact horizontal coverage.
    internal static class GlyphRaster
    {
        public static void Fill(GreyImage page, GlyphPath path, PdfMatrix m)
        {
            if (path == null || path.Empty) return;
            List<double[]> edges = new List<double[]>();     // x0,y0,x1,y1 in pixels
            double cx = 0, cy = 0, sx = 0, sy = 0;
            int pi = 0;
            double minX = double.MaxValue, minY = double.MaxValue, maxX = double.MinValue, maxY = double.MinValue;
            Action<double, double> to = null;
            to = (x, y) => { edges.Add(new[] { cx, cy, x, y }); cx = x; cy = y; };
            foreach (int op in path.Ops)
            {
                double[] p;
                int n = op == 0 || op == 1 ? 1 : op == 2 ? 2 : 3;
                p = new double[2 * n];
                for (int k = 0; k < n; k++) m.Apply(path.Pts[pi + 2 * k], path.Pts[pi + 2 * k + 1], out p[2 * k], out p[2 * k + 1]);
                pi += 2 * n;
                for (int k = 0; k < n; k++) { minX = Math.Min(minX, p[2 * k]); maxX = Math.Max(maxX, p[2 * k]); minY = Math.Min(minY, p[2 * k + 1]); maxY = Math.Max(maxY, p[2 * k + 1]); }
                if (op == 0) { if (cx != sx || cy != sy) to(sx, sy); cx = sx = p[0]; cy = sy = p[1]; }
                else if (op == 1) to(p[0], p[1]);
                else if (op == 2)
                {
                    double x0 = cx, y0 = cy;
                    int seg = Segments(Math.Abs(p[0] - x0) + Math.Abs(p[1] - y0) + Math.Abs(p[2] - p[0]) + Math.Abs(p[3] - p[1]));
                    for (int s = 1; s <= seg; s++)
                    {
                        double t = (double)s / seg, u = 1 - t;
                        to(u * u * x0 + 2 * u * t * p[0] + t * t * p[2], u * u * y0 + 2 * u * t * p[1] + t * t * p[3]);
                    }
                }
                else
                {
                    double x0 = cx, y0 = cy;
                    int seg = Segments(Math.Abs(p[0] - x0) + Math.Abs(p[1] - y0) + Math.Abs(p[2] - p[0]) + Math.Abs(p[3] - p[1]) + Math.Abs(p[4] - p[2]) + Math.Abs(p[5] - p[3]));
                    for (int s = 1; s <= seg; s++)
                    {
                        double t = (double)s / seg, u = 1 - t;
                        to(u * u * u * x0 + 3 * u * u * t * p[0] + 3 * u * t * t * p[2] + t * t * t * p[4],
                           u * u * u * y0 + 3 * u * u * t * p[1] + 3 * u * t * t * p[3] + t * t * t * p[5]);
                    }
                }
            }
            if (cx != sx || cy != sy) to(sx, sy);
            if (edges.Count == 0) return;
            int x0i = Math.Max(0, (int)Math.Floor(minX)), x1i = Math.Min(page.W - 1, (int)Math.Ceiling(maxX));
            int y0i = Math.Max(0, (int)Math.Floor(minY)), y1i = Math.Min(page.H - 1, (int)Math.Ceiling(maxY));
            if (x0i > x1i || y0i > y1i) return;
            if ((long)(x1i - x0i + 1) * (y1i - y0i + 1) > 40000000L) return;          // absurd size: skip
            int w = x1i - x0i + 2;
            double[] cov = new double[w];
            List<double[]> xs = new List<double[]>();
            const int SUB = 4;
            for (int y = y0i; y <= y1i; y++)
            {
                Array.Clear(cov, 0, w);
                bool any = false;
                for (int s = 0; s < SUB; s++)
                {
                    double yy = y + (s + 0.5) / SUB;
                    xs.Clear();
                    foreach (double[] e in edges)
                    {
                        double ya = e[1], yb = e[3];
                        if (ya == yb) continue;
                        if ((yy < ya) == (yy < yb)) continue;
                        double t = (yy - ya) / (yb - ya);
                        xs.Add(new[] { e[0] + t * (e[2] - e[0]), yb > ya ? 1 : -1 });
                    }
                    if (xs.Count < 2) continue;
                    xs.Sort((a, b) => a[0].CompareTo(b[0]));
                    int wind = 0;
                    for (int k = 0; k + 1 < xs.Count; k++)
                    {
                        wind += (int)xs[k][1];
                        if (wind == 0) continue;
                        double a = Math.Max(xs[k][0], x0i), b = Math.Min(xs[k + 1][0], x1i + 1);
                        if (b <= a) continue;
                        any = true;
                        int ia = (int)Math.Floor(a), ib = (int)Math.Floor(b);
                        if (ia == ib) { cov[ia - x0i] += (b - a) / SUB; continue; }
                        cov[ia - x0i] += (ia + 1 - a) / SUB;
                        for (int q = ia + 1; q < ib; q++) cov[q - x0i] += 1.0 / SUB;
                        if (ib <= x1i) cov[ib - x0i] += (b - ib) / SUB;
                    }
                }
                if (!any) continue;
                int row = y * page.W;
                for (int x = x0i; x <= x1i; x++)
                {
                    double c = cov[x - x0i];
                    if (c <= 0) continue;
                    if (c > 1) c = 1;
                    int v = (int)Math.Round(255 * (1 - c));
                    if (v < page.Px[row + x]) page.Px[row + x] = (byte)v;
                }
            }
        }

        // A stroked path, drawn as a filled band of the line width (at least one pixel) per segment.
        public static void Stroke(GreyImage page, GlyphPath path, PdfMatrix m, double width)
        {
            if (path == null || path.Empty) return;
            double scale = Math.Sqrt(Math.Abs(m.A * m.D - m.B * m.C));
            double half = Math.Max(0.5, width * scale / 2);
            List<double> pts = new List<double>();
            GlyphPath bands = new GlyphPath();
            double cx = 0, cy = 0;
            int pi = 0;
            Action<double, double, double, double> seg = (x0, y0, x1, y1) =>
            {
                double dx = x1 - x0, dy = y1 - y0, len = Math.Sqrt(dx * dx + dy * dy);
                if (len < 1e-9) return;
                double nx = -dy / len * half, ny = dx / len * half;
                bands.Move(x0 + nx, y0 + ny); bands.Line(x1 + nx, y1 + ny); bands.Line(x1 - nx, y1 - ny); bands.Line(x0 - nx, y0 - ny); bands.Line(x0 + nx, y0 + ny);
            };
            foreach (int op in path.Ops)
            {
                int n = op == 0 || op == 1 ? 1 : op == 2 ? 2 : 3;
                double[] p = new double[2 * n];
                for (int k = 0; k < n; k++) m.Apply(path.Pts[pi + 2 * k], path.Pts[pi + 2 * k + 1], out p[2 * k], out p[2 * k + 1]);
                pi += 2 * n;
                if (op == 0) { cx = p[0]; cy = p[1]; continue; }
                double ex = p[2 * n - 2], ey = p[2 * n - 1];
                if (op == 1) seg(cx, cy, ex, ey);
                else
                {
                    const int N = 12;
                    double px = cx, py = cy;
                    for (int s = 1; s <= N; s++)
                    {
                        double t = (double)s / N, u = 1 - t, x, y;
                        if (op == 2) { x = u * u * cx + 2 * u * t * p[0] + t * t * p[2]; y = u * u * cy + 2 * u * t * p[1] + t * t * p[3]; }
                        else { x = u * u * u * cx + 3 * u * u * t * p[0] + 3 * u * t * t * p[2] + t * t * t * p[4]; y = u * u * u * cy + 3 * u * u * t * p[1] + 3 * u * t * t * p[3] + t * t * t * p[5]; }
                        seg(px, py, x, y); px = x; py = y;
                    }
                }
                cx = ex; cy = ey;
            }
            Fill(page, bands, PdfMatrix.Identity);
        }

        private static int Segments(double len) { return Math.Max(1, Math.Min(48, (int)Math.Ceiling(len / 3))); }
    }
}
