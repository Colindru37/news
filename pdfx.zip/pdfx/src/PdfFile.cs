using System;
using System.Collections.Generic;
using System.IO;

namespace Pdfx.Internal
{
    public sealed class PdfFile : IDisposable
    {
        private struct XrefEntry
        {
            public int Type;
            public long Offset;
            public int Gen;
            public int StmNum;
            public int StmIdx;
        }

        private sealed class ObjStm
        {
            public byte[] Data;
            public int[] Nums;
            public int[] Offsets;
            public int First;
        }

        private byte[] _bytes;
        private int _headerOffset;
        private readonly Dictionary<int, XrefEntry> _xref = new Dictionary<int, XrefEntry>();
        private readonly Dictionary<int, PdfObject> _cache = new Dictionary<int, PdfObject>();
        private readonly Dictionary<int, ObjStm> _objStms = new Dictionary<int, ObjStm>();
        private PdfDictionary _trailer = new PdfDictionary();

        public bool WasRepaired;
        public IPdfDecryptor Decryptor;

        private int _encryptObjNum = -1;

        public bool IsEncrypted { get { return _trailer.Get("Encrypt") != null; } }
        public string DecryptionProblem { get; private set; }

        public bool Unlock(string password)
        {
            if (!IsEncrypted) return true;
            if (Decryptor != null) return true;

            string reason;
            PdfStandardSecurity s = PdfStandardSecurity.Create(this, password, out reason);
            DecryptionProblem = reason;
            if (s == null) return false;

            PdfObject keep = null;
            if (_encryptObjNum >= 0) _cache.TryGetValue(_encryptObjNum, out keep);
            _cache.Clear();
            _objStms.Clear();
            if (keep != null) _cache[_encryptObjNum] = keep;

            Decryptor = s;
            return true;
        }

        private PdfFile(byte[] bytes)
        {
            _bytes = bytes;
            Load();
        }

        public static PdfFile Open(string path)
        {
            if (path == null) throw new ArgumentNullException("path");
            if (!File.Exists(path)) throw new PdfException("file not found: " + path);
            return new PdfFile(File.ReadAllBytes(path));
        }

        public static PdfFile Open(byte[] bytes)
        {
            if (bytes == null) throw new ArgumentNullException("bytes");
            return new PdfFile(bytes);
        }

        public byte[] Bytes { get { return _bytes; } }
        public PdfDictionary Trailer { get { return _trailer; } }

        public int MaxObjectNumber
        {
            get
            {
                int max = 0;
                foreach (int k in _xref.Keys) if (k > max) max = k;
                return max;
            }
        }

        public IEnumerable<int> ObjectNumbers
        {
            get
            {
                List<int> nums = new List<int>(_xref.Keys);
                nums.Sort();
                return nums;
            }
        }

        public void Dispose()
        {
            _bytes = null;
            _cache.Clear();
            _objStms.Clear();
            _xref.Clear();
        }

        public PdfObject Resolve(PdfObject o)
        {
            int depth = 0;
            while (o is PdfRef && depth++ < 32)
            {
                PdfRef r = (PdfRef)o;
                o = GetObject(r.Number, r.Generation);
            }
            return o;
        }

        public PdfObject GetObject(int number, int generation)
        {
            PdfObject cached;
            if (_cache.TryGetValue(number, out cached)) return cached;

            XrefEntry e;
            if (!_xref.TryGetValue(number, out e)) return PdfNull.Instance;

            _cache[number] = PdfNull.Instance;
            PdfObject result = PdfNull.Instance;
            try
            {
                if (e.Type == 1)
                {
                    PdfParser p = new PdfParser(_bytes, this);
                    int n, g;
                    PdfObject o = p.ParseIndirectAt((int)(e.Offset + _headerOffset), out n, out g);
                    if (n == number) result = o;
                }
                else if (e.Type == 2)
                {
                    result = GetFromObjStm(e.StmNum, e.StmIdx, number);
                }
            }
            catch
            {
                result = PdfNull.Instance;
            }

            _cache[number] = result;
            return result;
        }

        private PdfObject GetFromObjStm(int stmNum, int idx, int wantNum)
        {
            ObjStm os;
            if (!_objStms.TryGetValue(stmNum, out os))
            {
                PdfStream st = GetObject(stmNum, 0) as PdfStream;
                if (st == null) return PdfNull.Instance;

                byte[] dec = PdfFilters.Decode(st, this);
                int n = IntOf(st.Dict.Get("N"), 0);
                int first = IntOf(st.Dict.Get("First"), 0);
                if (n < 0) n = 0;

                PdfLexer lex = new PdfLexer(dec);
                int[] nums = new int[n];
                int[] offs = new int[n];
                for (int i = 0; i < n; i++)
                {
                    Token a = lex.Next();
                    Token b = lex.Next();
                    if (a.Type != TokenType.Number || b.Type != TokenType.Number) { n = i; break; }
                    nums[i] = (int)a.Number;
                    offs[i] = (int)b.Number;
                }

                os = new ObjStm();
                os.Data = dec;
                os.Nums = nums;
                os.Offsets = offs;
                os.First = first;
                _objStms[stmNum] = os;
            }

            int k = idx;
            if (k < 0 || k >= os.Nums.Length || os.Nums[k] != wantNum)
            {
                k = -1;
                for (int i = 0; i < os.Nums.Length; i++)
                    if (os.Nums[i] == wantNum) { k = i; break; }
                if (k < 0) return PdfNull.Instance;
            }

            PdfParser p = new PdfParser(os.Data, this);
            p.SuppressDecryption = true;
            p.Position = os.First + os.Offsets[k];
            return p.ParseObject();
        }

        private int IntOf(PdfObject o, int fallback)
        {
            PdfNumber n = Resolve(o) as PdfNumber;
            return n != null ? n.AsInt : fallback;
        }

        private void Load()
        {
            _headerOffset = FindHeader();
            try
            {
                int sx = FindStartXref();
                if (sx < 0) throw new PdfException("startxref not found");
                ReadXrefChain(sx);
                if (_trailer.Get("Root") == null) throw new PdfException("no /Root in trailer");
            }
            catch
            {
                Repair();
            }

            PdfRef encRef = _trailer.Get("Encrypt") as PdfRef;
            if (encRef != null) _encryptObjNum = encRef.Number;
            if (IsEncrypted) Unlock(string.Empty);
        }

        private int FindHeader()
        {
            int limit = Math.Min(1024, _bytes.Length);
            for (int i = 0; i <= limit - 5; i++)
                if (PdfParser.Match(_bytes, i, "%PDF-")) return i;
            return 0;
        }

        private int FindStartXref()
        {
            int from = _bytes.Length - 9;
            int limit = Math.Max(0, _bytes.Length - 2048);
            int at = PdfParser.LastIndexOf(_bytes, "startxref", from, limit);
            if (at < 0) return -1;
            PdfLexer lex = new PdfLexer(_bytes);
            lex.Position = at + 9;
            Token t = lex.Next();
            if (t.Type != TokenType.Number) return -1;
            return (int)t.Number;
        }

        private void ReadXrefChain(int firstOffset)
        {
            HashSet<int> seen = new HashSet<int>();
            List<int> queue = new List<int>();
            queue.Add(firstOffset);

            bool any = false;
            while (queue.Count > 0)
            {
                int off = queue[0];
                queue.RemoveAt(0);
                if (off < 0 || !seen.Add(off)) continue;

                PdfDictionary tr;
                try
                {
                    tr = ReadXrefSection(off + _headerOffset);
                }
                catch
                {
                    if (!any) throw;
                    continue;
                }
                any = true;

                MergeTrailer(tr);

                PdfObject stm = tr.Get("XRefStm");
                PdfNumber sn = stm as PdfNumber;
                if (sn != null) queue.Add(sn.AsInt);

                PdfObject prev = tr.Get("Prev");
                PdfNumber pn = prev as PdfNumber;
                if (pn != null) queue.Add(pn.AsInt);
            }

            if (!any) throw new PdfException("no usable xref section");
        }

        private void MergeTrailer(PdfDictionary tr)
        {
            if (tr == null) return;
            foreach (KeyValuePair<string, PdfObject> kv in tr.Map)
                if (!_trailer.Has(kv.Key)) _trailer.Set(kv.Key, kv.Value);
        }

        private PdfDictionary ReadXrefSection(int pos)
        {
            if (pos < 0 || pos >= _bytes.Length)
                throw new PdfException("xref offset out of range: " + pos);

            PdfLexer lex = new PdfLexer(_bytes);
            lex.Position = pos;
            Token t = lex.Next();
            if (t.Type == TokenType.Keyword && t.Text == "xref")
                return ReadXrefTable(lex);

            PdfParser parser = new PdfParser(_bytes, this);
            parser.SuppressDecryption = true;
            int num, gen;
            PdfObject o = parser.ParseIndirectAt(pos, out num, out gen);
            PdfStream st = o as PdfStream;
            if (st == null)
                throw new PdfException("xref section at " + pos + " is neither a table nor a stream");
            ReadXrefStream(st);
            return st.Dict;
        }

        private PdfDictionary ReadXrefTable(PdfLexer lex)
        {
            while (true)
            {
                int save = lex.Position;
                Token a = lex.Next();

                if (a.Type == TokenType.Keyword && a.Text == "trailer")
                {
                    PdfParser p = new PdfParser(_bytes, this);
                    p.SuppressDecryption = true;
                    p.Position = lex.Position;
                    PdfDictionary d = p.ParseObject() as PdfDictionary;
                    return d ?? new PdfDictionary();
                }

                if (a.Type != TokenType.Number) { lex.Position = save; break; }

                Token b = lex.Next();
                if (b.Type != TokenType.Number) break;

                int start = (int)a.Number;
                int count = (int)b.Number;
                if (count < 0 || count > 5000000) break;

                for (int i = 0; i < count; i++)
                {
                    Token o1 = lex.Next();
                    Token o2 = lex.Next();
                    Token o3 = lex.Next();
                    if (o1.Type != TokenType.Number || o2.Type != TokenType.Number)
                        return new PdfDictionary();

                    string ty = o3.Type == TokenType.Keyword ? o3.Text : "n";
                    if (ty == "f") continue;

                    XrefEntry e = new XrefEntry();
                    e.Type = 1;
                    e.Offset = (long)o1.Number;
                    e.Gen = (int)o2.Number;
                    Record(start + i, e);
                }
            }
            return new PdfDictionary();
        }

        private void ReadXrefStream(PdfStream st)
        {
            byte[] data = PdfFilters.Decode(st, this);

            PdfArray w = st.Dict.Get("W") as PdfArray;
            if (w == null || w.Count < 3) throw new PdfException("xref stream has no /W");

            int w0 = IntOf(w[0], 0);
            int w1 = IntOf(w[1], 0);
            int w2 = IntOf(w[2], 0);
            int rowLen = w0 + w1 + w2;
            if (rowLen <= 0) throw new PdfException("xref stream /W is empty");

            List<int> index = new List<int>();
            PdfArray ix = st.Dict.Get("Index") as PdfArray;
            if (ix != null)
            {
                for (int i = 0; i < ix.Count; i++) index.Add(IntOf(ix[i], 0));
            }
            else
            {
                index.Add(0);
                index.Add(IntOf(st.Dict.Get("Size"), 0));
            }

            int pos = 0;
            for (int s = 0; s + 1 < index.Count; s += 2)
            {
                int start = index[s];
                int count = index[s + 1];
                for (int i = 0; i < count && pos + rowLen <= data.Length; i++, pos += rowLen)
                {
                    long f1 = w0 == 0 ? 1 : ReadField(data, pos, w0);
                    long f2 = ReadField(data, pos + w0, w1);
                    long f3 = ReadField(data, pos + w0 + w1, w2);

                    if (f1 == 0) continue;

                    XrefEntry e = new XrefEntry();
                    if (f1 == 1)
                    {
                        e.Type = 1;
                        e.Offset = f2;
                        e.Gen = (int)f3;
                    }
                    else if (f1 == 2)
                    {
                        e.Type = 2;
                        e.StmNum = (int)f2;
                        e.StmIdx = (int)f3;
                    }
                    else continue;

                    Record(start + i, e);
                }
            }
        }

        private static long ReadField(byte[] data, int pos, int width)
        {
            long v = 0;
            for (int i = 0; i < width; i++) v = (v << 8) | data[pos + i];
            return v;
        }

        private void Record(int number, XrefEntry e)
        {
            if (number < 0) return;
            if (_xref.ContainsKey(number)) return;
            _xref[number] = e;
        }

        private void Repair()
        {
            WasRepaired = true;
            _xref.Clear();
            _cache.Clear();
            _objStms.Clear();
            _trailer = new PdfDictionary();

            for (int i = 0; i + 3 < _bytes.Length; i++)
            {
                if (!PdfParser.Match(_bytes, i, "obj")) continue;
                if (i + 3 < _bytes.Length && PdfLexer.IsRegular(_bytes[i + 3])) continue;

                int j = i - 1;
                while (j >= 0 && PdfLexer.IsWhite(_bytes[j])) j--;
                int genEnd = j + 1;
                while (j >= 0 && _bytes[j] >= (byte)'0' && _bytes[j] <= (byte)'9') j--;
                int genStart = j + 1;
                if (genStart == genEnd) continue;

                while (j >= 0 && PdfLexer.IsWhite(_bytes[j])) j--;
                int numEnd = j + 1;
                while (j >= 0 && _bytes[j] >= (byte)'0' && _bytes[j] <= (byte)'9') j--;
                int numStart = j + 1;
                if (numStart == numEnd) continue;
                if (numStart > 0 && PdfLexer.IsRegular(_bytes[numStart - 1])) continue;

                int num = ParseInt(_bytes, numStart, numEnd);
                int gen = ParseInt(_bytes, genStart, genEnd);
                if (num <= 0) continue;

                XrefEntry e = new XrefEntry();
                e.Type = 1;
                e.Offset = numStart - _headerOffset;
                e.Gen = gen;
                _xref[num] = e;
            }

            int tr = PdfParser.LastIndexOf(_bytes, "trailer", _bytes.Length - 7, 0);
            if (tr >= 0)
            {
                PdfParser p = new PdfParser(_bytes, this);
                p.SuppressDecryption = true;
                p.Position = tr + 7;
                PdfDictionary d = p.ParseObject() as PdfDictionary;
                if (d != null) MergeTrailer(d);
            }

            if (_trailer.Get("Root") == null)
            {
                foreach (int n in ObjectNumbers)
                {
                    PdfObject o = GetObject(n, 0);
                    PdfDictionary d = o as PdfDictionary;
                    if (d == null)
                    {
                        PdfStream s = o as PdfStream;
                        if (s != null) d = s.Dict;
                    }
                    if (d == null) continue;
                    PdfName ty = d.Get("Type") as PdfName;
                    if (ty != null && ty.Value == "Catalog")
                    {
                        _trailer.Set("Root", new PdfRef(n, 0));
                        break;
                    }
                }
            }
        }

        private static int ParseInt(byte[] data, int start, int end)
        {
            int v = 0;
            for (int i = start; i < end; i++)
            {
                v = v * 10 + (data[i] - (byte)'0');
                if (v > 100000000) return v;
            }
            return v;
        }
    }
}
