using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;

namespace Pdfx.Internal
{
    // PDF/A-1 has no transparency. Instead of making semi-transparent fills and strokes
    // opaque (a 30% watermark would cover the page), each colour is mixed with white by
    // its opacity at the moment it paints, then restored. Exact on a white page.
    internal sealed partial class PdfaJob
    {
        private readonly Dictionary<PdfDictionary, double[]> _alpha = new Dictionary<PdfDictionary, double[]>();

        private sealed class Paint
        {
            public string FillSpace = "DeviceGray", StrokeSpace = "DeviceGray";
            public double[] Fill = { 0 }, Stroke = { 0 };
            public double Fa = 1, Sa = 1;
            public int Tr;
            public Paint Clone()
            {
                Paint p = (Paint)MemberwiseClone();
                p.Fill = (double[])Fill.Clone();
                p.Stroke = (double[])Stroke.Clone();
                return p;
            }
        }

        private void FlattenAlpha()
        {
            bool any = false;
            foreach (double[] a in _alpha.Values) if (a[0] < 1 || a[1] < 1) any = true;
            if (!any) return;
            bool lost = false;
            foreach (PdfDictionary page in _pages)
            {
                PdfObject c = R(page.Get("Contents"));
                byte[] content = PageContent(page);
                byte[] fixedContent = Flatten(content, _pageRes[page], ref lost);
                if (fixedContent == null) continue;
                PdfDictionary d = new PdfDictionary();
                d.Set("Filter", new PdfName("FlateDecode"));
                page.Set("Contents", new PdfRef(_o.AddObject(new PdfStream(d, PdfaFontFixer.Deflate(fixedContent))), 0));
            }
            for (int i = 1; i <= _o.Count; i++)
            {
                PdfStream x = _o.GetObject(i) as PdfStream;
                if (x == null) continue;
                PdfNumber pt = R(x.Dict.Get("PatternType")) as PdfNumber;
                if (Name(x.Dict.Get("Subtype")) != "Form" && (pt == null || pt.AsInt != 1)) continue;
                byte[] data = Decoded(x);
                byte[] f = data == null ? null : Flatten(data, R(x.Dict.Get("Resources")) as PdfDictionary, ref lost);
                if (f != null) Restore(x, f, false);
            }
            _warn.Add("mixed semi-transparent colours with white (PDF/A-1 has no transparency); exact on a white page");
            if (lost) _warn.Add("semi-transparent images or shadings could not be mixed and are now opaque");
        }

        private byte[] Flatten(byte[] content, PdfDictionary res, ref bool lost)
        {
            PdfaLexer lx = new PdfaLexer(content);
            Stack<Paint> stack = new Stack<Paint>();
            Paint p = new Paint();
            List<PdfaToken> ops = new List<PdfaToken>();
            int operandStart = -1, pathStart = -1, depth = 0;
            SortedDictionary<int, string> inserts = new SortedDictionary<int, string>();
            bool changed = false;

            while (true)
            {
                PdfaToken t = lx.Next();
                if (t.Kind == PdfaTok.Eof) break;
                if (operandStart < 0 && t.Kind != PdfaTok.Operator) operandStart = t.Start;
                if (t.Kind == PdfaTok.ArrayStart || t.Kind == PdfaTok.DictStart) { depth++; continue; }
                if (t.Kind == PdfaTok.ArrayEnd || t.Kind == PdfaTok.DictEnd) { depth--; continue; }
                if (depth > 0) continue;
                if (t.Kind == PdfaTok.InlineImage)
                {
                    if (p.Fa < 1) lost = true;
                    ops.Clear(); operandStart = -1;
                    continue;
                }
                if (t.Kind != PdfaTok.Operator) { ops.Add(t); continue; }
                string op = t.Text;
                int start = operandStart >= 0 ? operandStart : t.Start;
                switch (op)
                {
                    case "q": stack.Push(p.Clone()); break;
                    case "Q": if (stack.Count > 0) p = stack.Pop(); break;
                    case "g": p.FillSpace = "DeviceGray"; p.Fill = Nums(ops); break;
                    case "G": p.StrokeSpace = "DeviceGray"; p.Stroke = Nums(ops); break;
                    case "rg": p.FillSpace = "DeviceRGB"; p.Fill = Nums(ops); break;
                    case "RG": p.StrokeSpace = "DeviceRGB"; p.Stroke = Nums(ops); break;
                    case "k": p.FillSpace = "DeviceCMYK"; p.Fill = Nums(ops); break;
                    case "K": p.StrokeSpace = "DeviceCMYK"; p.Stroke = Nums(ops); break;
                    case "cs": p.FillSpace = LastName(ops) ?? p.FillSpace; p.Fill = new double[0]; break;
                    case "CS": p.StrokeSpace = LastName(ops) ?? p.StrokeSpace; p.Stroke = new double[0]; break;
                    case "sc": case "scn": p.Fill = Nums(ops); if (LastName(ops) != null) p.Fill = null; break;
                    case "SC": case "SCN": p.Stroke = Nums(ops); if (LastName(ops) != null) p.Stroke = null; break;
                    case "Tr": if (ops.Count > 0) p.Tr = (int)ops[0].Number; break;
                    case "gs":
                        {
                            PdfDictionary gsd = R(res == null ? null : res.Get("ExtGState")) as PdfDictionary;
                            PdfDictionary g = gsd == null ? null : R(gsd.Get(LastName(ops) ?? "")) as PdfDictionary;
                            double[] a;
                            if (g != null && _alpha.TryGetValue(g, out a)) { p.Fa = a[0]; p.Sa = a[1]; }
                            break;
                        }
                    case "m": case "re":
                        if (pathStart < 0) pathStart = start;
                        break;
                    case "f": case "F": case "f*": case "S": case "s": case "B": case "B*": case "b": case "b*":
                        {
                            bool fill = op != "S" && op != "s", stroke = op != "f" && op != "F" && op != "f*";
                            if (pathStart >= 0 && Mix(p, fill, stroke, res, pathStart, t.End, inserts)) changed = true;
                            pathStart = -1;
                            break;
                        }
                    case "n": pathStart = -1; break;
                    case "Tj": case "TJ": case "'": case "\"":
                        {
                            int mode = p.Tr & 3;
                            bool fill = mode == 0 || mode == 2, stroke = mode == 1 || mode == 2;
                            if (Mix(p, fill, stroke, res, start, t.End, inserts)) changed = true;
                            break;
                        }
                    case "Do": case "sh":
                        if (p.Fa < 1 && op == "sh") lost = true;
                        if (p.Fa < 1 && op == "Do")
                        {
                            PdfDictionary xo = R(res == null ? null : res.Get("XObject")) as PdfDictionary;
                            PdfStream x = xo == null ? null : R(xo.Get(LastName(ops) ?? "")) as PdfStream;
                            if (x != null && Name(x.Dict.Get("Subtype")) == "Image") lost = true;
                        }
                        break;
                }
                ops.Clear();
                operandStart = -1;
            }
            if (!changed) return null;
            MemoryStream ms = new MemoryStream();
            int at = 0;
            foreach (KeyValuePair<int, string> ins in inserts)
            {
                ms.Write(content, at, ins.Key - at);
                byte[] b = Encoding.ASCII.GetBytes(ins.Value);
                ms.Write(b, 0, b.Length);
                at = ins.Key;
            }
            ms.Write(content, at, content.Length - at);
            return ms.ToArray();
        }

        // Inserts the mixed colour before the paint (before the path, where colour operators
        // are not allowed) and the original colour after it.
        private bool Mix(Paint p, bool fill, bool stroke, PdfDictionary res, int before, int after, SortedDictionary<int, string> inserts)
        {
            StringBuilder pre = new StringBuilder(), post = new StringBuilder();
            if (fill && p.Fa < 1 && p.Fill != null)
            {
                double white;
                if (White(p.FillSpace, res, p.Fill.Length, out white))
                {
                    pre.Append(Colour(p.FillSpace, Blend(p.Fill, p.Fa, white), false));
                    post.Append(Colour(p.FillSpace, p.Fill, false));
                }
            }
            if (stroke && p.Sa < 1 && p.Stroke != null)
            {
                double white;
                if (White(p.StrokeSpace, res, p.Stroke.Length, out white))
                {
                    pre.Append(Colour(p.StrokeSpace, Blend(p.Stroke, p.Sa, white), true));
                    post.Append(Colour(p.StrokeSpace, p.Stroke, true));
                }
            }
            if (pre.Length == 0) return false;
            string old;
            inserts[before] = (inserts.TryGetValue(before, out old) ? old : "") + pre;
            inserts[after] = "\n" + post + (inserts.TryGetValue(after, out old) ? old : "");
            return true;
        }

        private static double[] Blend(double[] c, double a, double white)
        {
            double[] r = new double[c.Length];
            for (int i = 0; i < c.Length; i++) r[i] = c[i] * a + white * (1 - a);
            return r;
        }

        // The component value that means "no ink" in this colour space, if mixing makes sense.
        private bool White(string space, PdfDictionary res, int n, out double white)
        {
            white = 1;
            if (space == "DeviceGray" || space == "DeviceRGB" || space == "G" || space == "RGB") return n > 0;
            if (space == "DeviceCMYK" || space == "CMYK") { white = 0; return n == 4; }
            PdfDictionary csd = R(res == null ? null : res.Get("ColorSpace")) as PdfDictionary;
            PdfArray cs = csd == null ? null : R(csd.Get(space)) as PdfArray;
            string kind = cs == null ? null : Name(R(cs[0]));
            if (kind == "ICCBased")
            {
                PdfStream icc = R(cs[1]) as PdfStream;
                PdfNumber nn = icc == null ? null : R(icc.Dict.Get("N")) as PdfNumber;
                if (nn == null || nn.AsInt != n) return false;
                white = n == 4 ? 0 : 1;
                return true;
            }
            if (kind == "Separation" || kind == "DeviceN") { white = 0; return n > 0; }
            if (kind == "CalRGB" || kind == "CalGray") return n > 0;
            return false;
        }

        private static string Colour(string space, double[] c, bool stroke)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(PdfSerializer.Name(space)).Append(stroke ? " CS " : " cs ");
            foreach (double v in c) sb.Append(Math.Max(0, Math.Min(1, v)).ToString("0.####", CultureInfo.InvariantCulture)).Append(' ');
            sb.Append(stroke ? "SC\n" : "sc\n");
            return sb.ToString();
        }

        private static double[] Nums(List<PdfaToken> ops)
        {
            List<double> r = new List<double>();
            foreach (PdfaToken t in ops) if (t.Kind == PdfaTok.Number) r.Add(t.Number);
            return r.ToArray();
        }

        private static string LastName(List<PdfaToken> ops)
        {
            for (int i = ops.Count - 1; i >= 0; i--) if (ops[i].Kind == PdfaTok.Name) return ops[i].Text;
            return null;
        }
    }
}
