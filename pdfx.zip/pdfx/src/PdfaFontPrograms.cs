using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Pdfx.Internal
{
    // Reads what PDF/A needs out of embedded font programs: glyph names (CharSet),
    // CIDs present (CIDSet), and a TrueType cmap reduced to the one subtable PDF/A-1 allows.
    internal static class PdfaFontPrograms
    {
        // ---- CFF ---------------------------------------------------------------------

        private static string[] _std;

        private static string Std(int sid)
        {
            if (_std == null) _std = PdfaTables.CffStandard.Split(' ');
            return sid >= 0 && sid < _std.Length ? _std[sid] : null;
        }

        private static List<byte[]> Index(byte[] d, ref int p)
        {
            List<byte[]> items = new List<byte[]>();
            int count = d[p] << 8 | d[p + 1];
            p += 2;
            if (count == 0) return items;
            int os = d[p++];
            int[] off = new int[count + 1];
            for (int i = 0; i <= count; i++)
            {
                int v = 0;
                for (int k = 0; k < os; k++) v = v << 8 | d[p++];
                off[i] = v;
            }
            int data = p - 1;
            for (int i = 0; i < count; i++)
            {
                byte[] b = new byte[off[i + 1] - off[i]];
                Buffer.BlockCopy(d, data + off[i], b, 0, b.Length);
                items.Add(b);
            }
            p = data + off[count];
            return items;
        }

        private static Dictionary<int, List<double>> Dict(byte[] d)
        {
            Dictionary<int, List<double>> r = new Dictionary<int, List<double>>();
            List<double> ops = new List<double>();
            int p = 0;
            while (p < d.Length)
            {
                int b = d[p];
                if (b <= 21)
                {
                    int op = b;
                    p++;
                    if (b == 12) op = 1200 + d[p++];
                    r[op] = ops;
                    ops = new List<double>();
                }
                else if (b == 28) { ops.Add((short)(d[p + 1] << 8 | d[p + 2])); p += 3; }
                else if (b == 29) { ops.Add(d[p + 1] << 24 | d[p + 2] << 16 | d[p + 3] << 8 | d[p + 4]); p += 5; }
                else if (b == 30)
                {
                    p++;
                    StringBuilder sb = new StringBuilder();
                    bool done = false;
                    while (!done && p < d.Length)
                    {
                        int x = d[p++];
                        for (int h = 0; h < 2 && !done; h++)
                        {
                            int n = h == 0 ? x >> 4 : x & 15;
                            if (n <= 9) sb.Append((char)('0' + n));
                            else if (n == 10) sb.Append('.');
                            else if (n == 11) sb.Append('E');
                            else if (n == 12) sb.Append("E-");
                            else if (n == 14) sb.Append('-');
                            else if (n == 15) done = true;
                        }
                    }
                    double v;
                    double.TryParse(sb.ToString(), System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out v);
                    ops.Add(v);
                }
                else if (b >= 32 && b <= 246) { ops.Add(b - 139); p++; }
                else if (b >= 247 && b <= 250) { ops.Add((b - 247) * 256 + d[p + 1] + 108); p += 2; }
                else if (b >= 251 && b <= 254) { ops.Add(-(b - 251) * 256 - d[p + 1] - 108); p += 2; }
                else p++;
            }
            return r;
        }

        // Glyph names in GID order (name-keyed fonts), or CIDs (CID-keyed fonts).
        public static void CffGlyphs(byte[] d, out List<string> names, out List<int> cids)
        {
            names = null; cids = null;
            int p = d[2];
            Index(d, ref p);
            List<byte[]> top = Index(d, ref p);
            List<byte[]> strings = Index(d, ref p);
            if (top.Count == 0) return;
            Dictionary<int, List<double>> td = Dict(top[0]);
            if (!td.ContainsKey(17)) return;
            int cs = (int)td[17][0];
            List<byte[]> charStrings = Index(d, ref cs);
            int n = charStrings.Count;
            bool isCid = td.ContainsKey(1230);
            int charset = td.ContainsKey(15) ? (int)td[15][0] : 0;
            List<int> sids = new List<int>();
            sids.Add(0);
            if (charset == 0 && !isCid) { for (int g = 1; g < n; g++) sids.Add(g <= 228 ? g : 0); }
            else if (charset > 2)
            {
                int q = charset;
                int fmt = d[q++];
                while (sids.Count < n && q < d.Length)
                {
                    if (fmt == 0) { sids.Add(d[q] << 8 | d[q + 1]); q += 2; }
                    else
                    {
                        int first = d[q] << 8 | d[q + 1];
                        int left = fmt == 1 ? d[q + 2] : d[q + 2] << 8 | d[q + 3];
                        q += fmt == 1 ? 3 : 4;
                        for (int k = 0; k <= left && sids.Count < n; k++) sids.Add(first + k);
                    }
                }
            }
            else
            {
                for (int g = 1; g < n; g++) sids.Add(g);
            }
            if (isCid) { cids = sids; return; }
            names = new List<string>();
            foreach (int sid in sids)
            {
                string s = Std(sid);
                if (s == null && sid - 391 >= 0 && sid - 391 < strings.Count) s = Encoding.ASCII.GetString(strings[sid - 391]);
                names.Add(s ?? ".notdef");
            }
        }

        // ---- Type 1 ------------------------------------------------------------------

        public static List<string> Type1Glyphs(byte[] font, int length1)
        {
            if (length1 <= 0 || length1 >= font.Length) length1 = FindEexec(font);
            if (length1 <= 0) return null;
            byte[] enc = new byte[font.Length - length1];
            Buffer.BlockCopy(font, length1, enc, 0, enc.Length);
            if (IsHex(enc)) enc = FromHex(enc);
            byte[] plain = Eexec(enc, 55665, 4);
            string text = Encoding.GetEncoding(28591).GetString(plain);
            int cs = text.IndexOf("/CharStrings", StringComparison.Ordinal);
            if (cs < 0) return null;
            int p = text.IndexOf("begin", cs, StringComparison.Ordinal);
            if (p < 0) return null;
            p += 5;
            List<string> names = new List<string>();
            while (p < text.Length)
            {
                while (p < text.Length && char.IsWhiteSpace(text[p])) p++;
                if (p >= text.Length || text[p] != '/') break;
                int s = ++p;
                while (p < text.Length && !char.IsWhiteSpace(text[p])) p++;
                names.Add(text.Substring(s, p - s));
                while (p < text.Length && char.IsWhiteSpace(text[p])) p++;
                int ns = p;
                while (p < text.Length && char.IsDigit(text[p])) p++;
                int len;
                if (!int.TryParse(text.Substring(ns, p - ns), out len)) break;
                while (p < text.Length && char.IsWhiteSpace(text[p])) p++;
                while (p < text.Length && !char.IsWhiteSpace(text[p])) p++;
                p += 1 + len;
                while (p < text.Length && char.IsWhiteSpace(text[p])) p++;
                while (p < text.Length && !char.IsWhiteSpace(text[p])) p++;
                if (text.Length - p > 3 && text.Substring(p).TrimStart().StartsWith("end", StringComparison.Ordinal)) break;
            }
            return names;
        }

        private static int FindEexec(byte[] f)
        {
            string s = Encoding.GetEncoding(28591).GetString(f, 0, Math.Min(f.Length, 1 << 20));
            int i = s.IndexOf("eexec", StringComparison.Ordinal);
            if (i < 0) return -1;
            i += 5;
            while (i < s.Length && (s[i] == '\r' || s[i] == '\n' || s[i] == ' ')) i++;
            return i;
        }

        private static bool IsHex(byte[] b)
        {
            for (int i = 0; i < Math.Min(4, b.Length); i++)
            {
                char c = (char)b[i];
                if (!Uri.IsHexDigit(c)) return false;
            }
            return true;
        }

        private static byte[] FromHex(byte[] b)
        {
            List<byte> r = new List<byte>();
            int hi = -1;
            foreach (byte x in b)
            {
                char c = (char)x;
                if (!Uri.IsHexDigit(c)) continue;
                int v = Uri.FromHex(c);
                if (hi < 0) hi = v; else { r.Add((byte)(hi * 16 + v)); hi = -1; }
            }
            return r.ToArray();
        }

        private static byte[] Eexec(byte[] data, int r, int skip)
        {
            byte[] o = new byte[Math.Max(0, data.Length - skip)];
            for (int i = 0; i < data.Length; i++)
            {
                int c = data[i];
                int plain = c ^ (r >> 8);
                r = ((c + r) * 52845 + 22719) & 0xFFFF;
                if (i >= skip) o[i - skip] = (byte)plain;
            }
            return o;
        }

        public static string CharSet(IEnumerable<string> names)
        {
            StringBuilder sb = new StringBuilder();
            foreach (string n in names) if (n != ".notdef") sb.Append('/').Append(n);
            return sb.ToString();
        }

        // ---- TrueType ----------------------------------------------------------------

        // PDF/A-1 lets a symbolic TrueType font carry exactly one cmap subtable. Keeps
        // (3,0) if present (that is what viewers read for symbolic fonts), else (1,0).
        public static byte[] KeepOneCmap(byte[] font)
        {
            if (font.Length < 12) return null;
            int n = U16(font, 4);
            SortedDictionary<string, byte[]> tables = new SortedDictionary<string, byte[]>(StringComparer.Ordinal);
            for (int i = 0; i < n; i++)
            {
                int r = 12 + 16 * i;
                string tag = Encoding.ASCII.GetString(font, r, 4);
                int off = (int)U32(font, r + 8), len = (int)U32(font, r + 12);
                if (off < 0 || len < 0 || off + len > font.Length) return null;
                byte[] t = new byte[len];
                Buffer.BlockCopy(font, off, t, 0, len);
                tables[tag] = t;
            }
            byte[] cmap;
            if (!tables.TryGetValue("cmap", out cmap) || !tables.ContainsKey("head")) return null;
            int count = U16(cmap, 2);
            if (count <= 1) return null;
            int pick = -1, pickRank = -1;
            for (int i = 0; i < count; i++)
            {
                int plat = U16(cmap, 4 + 8 * i), enc = U16(cmap, 6 + 8 * i);
                int rank = plat == 3 && enc == 0 ? 3 : plat == 1 && enc == 0 ? 2 : plat == 3 && enc == 1 ? 1 : 0;
                if (rank > pickRank) { pickRank = rank; pick = i; }
            }
            int so = (int)U32(cmap, 8 + 8 * pick);
            int fmt = U16(cmap, so);
            int sl = fmt >= 8 && fmt != 14 ? (int)U32(cmap, so + 4) : U16(cmap, so + 2);
            if (so + sl > cmap.Length) return null;
            byte[] nc = new byte[12 + sl];
            nc[3] = 1;
            nc[4] = cmap[4 + 8 * pick]; nc[5] = cmap[5 + 8 * pick]; nc[6] = cmap[6 + 8 * pick]; nc[7] = cmap[7 + 8 * pick];
            nc[11] = 12;
            Buffer.BlockCopy(cmap, so, nc, 12, sl);
            tables["cmap"] = nc;
            return PdfaTrueType.WriteTables(tables);
        }

        // CIDSet for a CIDFontType2: bit c is set when CID c maps to a glyph the program has.
        public static byte[] CidSetTrueType(byte[] font, byte[] cidToGid)
        {
            PdfaTrueType t;
            try { t = PdfaTrueType.Parse(font, 0); } catch { return null; }
            int maxCid = cidToGid == null ? t.NumGlyphs - 1 : cidToGid.Length / 2 - 1;
            byte[] bits = new byte[maxCid / 8 + 1];
            for (int c = 0; c <= maxCid; c++)
            {
                int gid = cidToGid == null ? c : cidToGid[2 * c] << 8 | cidToGid[2 * c + 1];
                if (gid < t.NumGlyphs && (c == 0 || gid != 0)) bits[c / 8] |= (byte)(0x80 >> (c % 8));
            }
            return bits;
        }

        public static byte[] CidSetFromCids(List<int> cids)
        {
            int max = 0;
            foreach (int c in cids) if (c > max) max = c;
            byte[] bits = new byte[max / 8 + 1];
            foreach (int c in cids) bits[c / 8] |= (byte)(0x80 >> (c % 8));
            return bits;
        }

        private static uint U32(byte[] d, int o) { return (uint)(d[o] << 24 | d[o + 1] << 16 | d[o + 2] << 8 | d[o + 3]); }
        private static int U16(byte[] d, int o) { return d[o] << 8 | d[o + 1]; }
    }
}
