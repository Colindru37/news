using System.Reflection;

// The one place the version lives. PdfHelp.Version reads it, and a self-test checks the two agree.
// Bump the minor number when actions or methods are added, the patch number for fixes. Existing
// actions, methods, inputs and outputs keep their names, types and behaviour across versions.
[assembly: AssemblyTitle("Pdfx")]
[assembly: AssemblyProduct("Pdfx")]
[assembly: AssemblyDescription("Dependency-free PDF library for .NET Framework 4.8")]
[assembly: AssemblyVersion("1.2.0.0")]
[assembly: AssemblyFileVersion("1.2.0.0")]
[assembly: AssemblyInformationalVersion("1.2.0")]
