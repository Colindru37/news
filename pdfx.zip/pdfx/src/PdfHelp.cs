using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

namespace Pdfx
{
    // Built-in manual. From a code stage:  Output = Pdfx.PdfHelp.Show()            (overview)
    //                                      Output = Pdfx.PdfHelp.Show("split")     (one topic)
    //                                      Output = Pdfx.PdfHelp.All()             (everything)
    // Examples are VB.NET, the usual language of automation code stages.
    public static class PdfHelp
    {
        // The library version, e.g. "1.1.0". Log it from a process so a run can be tied to a build.
        // Also stamped on the DLL (right-click, Details). New features add methods and actions
        // and raise the minor number; existing ones keep their names, parameters and behaviour.
        public const string Version = "1.2.0";

        private sealed class Topic
        {
            public string Name, Summary, Keywords, Body;
            public Topic(string name, string summary, string keywords, string body) { Name = name; Summary = summary; Keywords = keywords; Body = body; }
        }

        private static readonly Topic[] All_ =
        {
            new Topic("start", "how to use the library, errors, paths", "start begin intro using reference error exception path quote folder page index zero",
@"Add Pdfx.dll to the object's External References, and Pdfx to its Namespace Imports.
Every action below is one line; most take a file in and write a file out.

Pages are numbered from 0 in the API (page 1 of the document is index 0).
Paths may be wrapped in quotes (Explorer's ""Copy as path""). Output folders are created.
PdfHelp.Version gives the library version (""1.2.0""); log it so a run can be tied to a build.
JPEG and PNG files are accepted wherever a PDF is, as one-page documents.

Errors:
PdfException = the document itself (not a PDF, wrong password, page out of range, damaged
image). Its Message says what to do.
ArgumentException = a bad argument (empty path, unknown PDF/A level, 45-degree rotation).

  Try
      PdfStandardsConverter.ConvertFile(inPath, outPath, ""2B"")
  Catch ex As PdfException
      errorText = ex.Message
  End Try

If a code stage says the DLL cannot be loaded ""from a network location"", the file still has
Windows' downloaded-from-internet mark: run   Get-ChildItem -Recurse | Unblock-File
in its folder."),

            new Topic("pdfa", "convert to PDF/A (archiving): levels 1A 1B 2A 2B 2U 3A 3B 3U", "pdfa pdf/a archive archival convert conversion level iso 19005 standard declared conformance 1a 1b 2a 2b 2u 3a 3b 3u",
@"PDF/A is the archiving form of PDF: fonts embedded, colours defined, nothing that needs
the internet or a script. Which level:
2B = the usual choice: looks exactly the same, forever.
2A = 2B plus tags (headings, paragraphs, reading order) for accessibility.
2U = 2B plus guaranteed searchable/copyable text.
3B, 3A, 3U = as 2, and files may be attached (e.g. the XML of an e-invoice).
1B, 1A = only when a recipient demands PDF/A-1; transparency gets flattened.

  PdfStandardsConverter.ConvertFile(inPath, outPath, ""2B"")
  PdfStandardsConverter.ConvertFile(inPath, outPath, ""2B"", password)
  Dim level As String = PdfStandardsConverter.GetDeclaredLevel(inPath)   ' ""2B"", or Nothing

The level may be written ""2B"", ""2b"", ""PDF/A-2b"" or ""pdfa2b"".
GetDeclaredLevel reads what a file claims; it does not validate the claim.

Several levels from one read, and what the conversion changed:
  Dim c As New PdfStandardsConverter(inPath)
  c.ToPdfA2B(outA)
  c.ToPdfA2A(outB)
  Dim notes As String = String.Join(Environment.NewLine, c.Warnings)

A PDF/A file must not be password-protected; open it with its password and the result is
unprotected. A signed file is refused unless c.Options.AllowSignatureRemoval = True
(conversion would break the signature anyway)."),

            new Topic("merge", "combine PDFs and images into one file", "merge combine join append concatenate bookmark",
@"  PdfComposer.Merge(New String() {a, b, c}, outPath)
  PdfComposer.Merge(New String() {a, b, c}, outPath, True)    ' + one bookmark per file

Inputs may be PDFs, JPEGs or PNGs, in any mix. Bookmarks and attachments of the inputs are
kept. If one input fails, the message names it: ""input 3 (x.pdf): ..."".
PdfComposer.ImagesToPdf is the same call under the name people look for."),

            new Topic("split", "one file per page, every N pages, at a keyword, by pattern, by bookmark", "split separate divide burst break chunk keyword marker pattern regex bookmark client extract",
@"Each returns the paths it wrote (a String array).
  PdfComposer.SplitToPages(inPath, folder, ""page"")              ' page0001.pdf, page0002.pdf ...
  PdfComposer.SplitEvery(inPath, folder, 2, ""form"")             ' every 2 pages
  PdfComposer.SplitByText(inPath, folder, ""Extras de cont"", ""stmt"")
      ' a new file at every page containing the text (case and spacing ignored)
  PdfComposer.SplitByPattern(inPath, folder, ""Client no\.?\s*(\d+)"")
      ' a new file at every page matching; named after the match: 4711.pdf, 815.pdf ...
      ' pages before the first match go to _start.pdf; repeated names get "" (2)""
  PdfComposer.SplitByBookmarks(inPath, folder)                   ' one file per top bookmark
  PdfComposer.Extract(inPath, New Integer() {0, 2}, outPath)     ' chosen pages, 0-based"),

            new Topic("pages", "count, delete, rotate, reorder, extract, resize to A4", "pages page count delete remove rotate turn move reorder extract number resize paper size a4 a3 letter scale fit",
@"  PdfComposer.ResizePages(inPath, outPath, ""A4"")        ' every page on A4, content scaled to fit
  PdfComposer.ResizePages(inPath, outPath, ""A4 portrait"") ' A3, A5, Letter, Legal, 210x297mm, 8.5x11in
  Dim n As Integer = PdfComposer.GetPageCount(inPath)
  PdfComposer.DeletePages(inPath, New Integer() {0}, outPath)
  PdfComposer.RotatePages(inPath, New Integer() {0, 1}, 90, outPath)    ' 90, 180, 270, -90
  PdfComposer.Extract(inPath, New Integer() {0, 2}, outPath)

In a document:
  Using d As PdfDocument = PdfDocument.Open(inPath)
      d.MovePage(3, 0)
      d.RemovePage(1)
      d.Save(outPath)
  End Using

Resizing keeps the look (nothing is cropped), the text, links and form fields. A landscape page
gets the paper in landscape unless "" portrait"" is added. Pages already of that size are left as
they are. Tags for accessibility are lost; convert to PDF/A-2A afterwards to rebuild them."),

            new Topic("text", "read text: whole file, one page, a region, search; export as text, Markdown or HTML", "text read extract scrape search find region area word line html markdown md content export convert",
@"  PdfComposer.ConvertToText(inPath, ""out.md"")      ' Markdown: headings, paragraphs, tables
  PdfComposer.ConvertToText(inPath, ""out.txt"")     ' plain text; .html gives HTML

  Using d As PdfDocument = PdfDocument.Open(inPath)
      Dim md As String = d.ToMarkdown()
      Dim all As String = d.ToText()
      Dim first As String = PdfText.Extract(d.GetPage(0))
      ' A rectangle in points from the bottom-left corner (72 points = 1 inch):
      Dim box As String = PdfText.ExtractRegion(d.GetPage(0), 300, 600, 560, 700)
      Dim hits As Integer = PdfText.FindText(d.GetPage(0), ""IBAN"").Count
      Dim html As String = d.ToHtml()
  End Using

Text comes in reading order: columns are read one after the other, table rows left to right.
A scanned page has no text (it is a picture): read it with PdfOcr (topic ""ocr"").
Typed Arabic or Hebrew comes out in drawing order here; PdfOcr returns it in reading order."),

            new Topic("create", "make a PDF from images (JPEG, PNG, TIFF, GIF, BMP) or from text", "create make new image images jpeg jpg png tiff tif fax gif bmp photo scan scanner picture text txt email body log",
@"  PdfComposer.ImagesToPdf(New String() {""scan1.jpg"", ""scan2.png"", ""fax.tif""}, outPath)
  PdfComposer.TextToPdf(""Extras de cont"" & vbCrLf & ""Titular: ..."", outPath)
  PdfComposer.TextToPdf(text, outPath, True)          ' fixed-width font, for tables/logs
  PdfComposer.TextFileToPdf(""log.txt"", outPath)

Images: a scan keeps its paper size; a photo is fitted on A4 and turned upright. A multi-page
TIFF gives one page per frame; fax-compressed pages stay small. HEIC and WebP are refused.
Text: A4, 10 pt; diacritics are kept; characters the font lacks (emoji, Chinese) print as ?.
To archive the result, convert it:  PdfStandardsConverter.ConvertFile(outPath, final, ""2B"")"),

            new Topic("stamp", "add text, a watermark or a picture to a page", "stamp watermark text image logo picture copy confidential approved overlay",
@"  PdfComposer.AddWatermark(inPath, outPath, ""COPIE"", Nothing)       ' every page, one line

  Using d As PdfDocument = PdfDocument.Open(inPath)
      Dim o As New PdfStampOptions()
      o.FontSize = 14 : o.Red = 0.8
      PdfStamp.AddText(d.GetPage(0), ""COPIE CONFORMA CU ORIGINALUL"", 72, 40, o)
      PdfStamp.AddWatermark(d.GetPage(0), ""CONFIDENTIAL"", Nothing)
      PdfStamp.AddJpeg(d.GetPage(0), System.IO.File.ReadAllBytes(""logo.jpg""), 450, 760, 100, 50)
      d.Save(outPath)
  End Using

Positions are points from the bottom-left corner of the page as it is displayed.
Text with diacritics (a, s, t with marks) gets an embedded font automatically."),

            new Topic("numbers", "page numbers (Page 1 of 9) and Bates numbers", "page numbers numbering footer header bates counter sequence legal",
@"  PdfComposer.AddPageNumbers(inPath, outPath)                     ' ""Page 1 of 9"", bottom centre
  Dim o As New PdfPageNumberOptions()
  o.Format = ""Pagina {page} din {total}""
  o.Position = ""bottom-right""     ' bottom-/top- + left, center, right
  o.SkipFirstPages = 1            ' no number on a cover page (it still counts)
  PdfComposer.AddPageNumbers(inPath, outPath, o)

  ' Bates: prefix + 6-digit counter; returns the next number, to continue on the next file.
  Dim nextNo As Integer = PdfComposer.AddBates(inPath, outPath, ""ACME"", 1)
  nextNo = PdfComposer.AddBates(otherPath, otherOut, ""ACME"", nextNo, 6, ""bottom-right"")"),

            new Topic("forms", "read, fill and flatten form fields", "form forms field fields fill acroform checkbox flatten value",
@"  Using d As PdfDocument = PdfDocument.Open(inPath)
      If Not PdfForm.HasForm(d) Then Return
      For Each f As PdfFormField In PdfForm.Fields(d)
          ' f.FullName, f.Type (Text, Checkbox, Radio, PushButton, Choice, Signature), f.Value
      Next
      PdfForm.SetValue(d, ""name"", ""Ion Popescu"")
      PdfForm.SetValue(d, ""agree"", ""Yes"")
      PdfForm.Flatten(d)           ' fields become plain page content
      d.Save(outPath)
  End Using"),

            new Topic("passwords", "protect a file, open protected files, check, remove a password", "password passwords protect protected encrypted encrypt decrypt unlock lock secure security permissions print copy aes",
@"  PdfComposer.AddPassword(inPath, outPath, ""open-pw"", ""owner-pw"")
  Dim locked As Boolean = PdfComposer.NeedsPassword(inPath)
  PdfComposer.RemovePassword(inPath, password, outPath)
  Using d As PdfDocument = PdfDocument.Open(inPath, password)
      ' ...
  End Using

With permissions (the owner password lifts them):
  Dim o As New PdfPasswordOptions(""open-pw"", ""owner-pw"")
  o.AllowPrinting = False : o.AllowCopying = False
  PdfComposer.AddPassword(inPath, outPath, o)

The open password may be empty: the file then opens freely but printing/copying follow the
permissions. AES-256 by default; o.Aes128 = True for readers older than 2010. RC4, AES-128 and
AES-256 files open. A wrong password raises PdfException. A PDF/A file loses its PDF/A status
when protected (the standard forbids encryption); protect it last."),

            new Topic("attachments", "embed files in a PDF, or extract them", "attachment attachments attach embed embedded paperclip file files extract xml invoice factur-x zugferd",
@"  PdfComposer.AddAttachments(inPath, New String() {""invoice.xml""}, outPath)
  PdfComposer.AddAttachments(inPath, New String() {""invoice.xml""}, outPath, ""Data"")
  Dim saved As String() = PdfComposer.ExtractAttachments(inPath, folder)

To keep an attachment in an archived file, use level 3:
  PdfStandardsConverter.ConvertFile(outPath, final, ""3B"")
The relationship (Source, Data, Alternative, Supplement) tells a PDF/A-3 reader what the file
is; an e-invoice's XML is ""Data"" or ""Alternative"".

In a document:
  Using d As PdfDocument = PdfDocument.Open(inPath)
      For Each a As PdfAttachment In d.Attachments
          ' a.FileName, a.Size, a.GetData(), a.SaveToFolder(folder)
      Next
      d.AddAttachment(""notes.txt"")
      d.Save(outPath)
  End Using
Extracted names are made safe: an attachment cannot write outside the folder."),

            new Topic("bookmarks", "read and create bookmarks (the outline panel)", "bookmark bookmarks outline outlines toc contents navigation",
@"  Using d As PdfDocument = PdfDocument.Open(inPath)
      For Each b As PdfBookmark In d.Bookmarks
          ' b.Title, b.PageIndex (0-based, -1 if it points nowhere), b.Children
      Next
      Dim chapter As PdfBookmark = d.AddBookmark(""Statement"", 0)
      chapter.AddChild(""Transactions"", 1)
      d.Save(outPath)
  End Using

Bookmarks follow their pages through merge, move and delete; one whose page is deleted is
dropped. See also: merge (one bookmark per file) and split (by bookmarks)."),

            new Topic("compress", "make a file smaller", "compress compression reduce shrink size smaller optimise optimize email limit dpi quality",
@"  Dim newSize As Long = PdfComposer.Compress(inPath, outPath)
  Dim o As New PdfCompressOptions()
  o.MaxDpi = 120 : o.ImageQuality = 60
  newSize = PdfComposer.Compress(inPath, outPath, o)

Photos and scans drawn finer than MaxDpi are scaled down and re-encoded as JPEG; nothing
else changes (text, fonts, forms, bookmarks, attachments and PDF/A status are kept).
A file with no large images will not shrink much; the original is written when nothing helps."),

            new Topic("metadata", "title, author and other document properties", "metadata properties title author subject keywords creator producer info",
@"  Using d As PdfDocument = PdfDocument.Open(inPath)
      Dim t As String = d.Title
      d.Title = ""Extras de cont 2026-10""
      d.Author = ""Back office""
      d.Save(outPath)
  End Using"),

            new Topic("ocr", "text from scanned pages through Tesseract (Arabic too)", "ocr tesseract scan scanned picture image arabic hebrew rtl right left language fax tiff recognise recognize traineddata tessdata rubbish garbage type3 t3font font force",
@"Reads the text of scanned PDFs and of TIFF, JPEG and PNG scans, page by page, with Tesseract,
which must already be on the machine. Looked for: a Tesseract folder beside the running program
(where automation platforms keep their bundled copy, e.g. tesseract-4.0.0.exe), then a
standalone install, then PATH. Pages that carry typed text are read directly, without OCR.

  Dim text As String = PdfOcr.ExtractText(inPath)

  Dim o As New PdfOcrOptions()
  o.Language = ""ara+eng""         ' Tesseract language codes joined with +
  o.Password = password            ' for a protected PDF
  o.TesseractPath = """"            ' or the full path of tesseract.exe, or its folder
  o.TessdataFolder = """"           ' folder of the *.traineddata files, if not beside tesseract
  o.ForceOcr = False               ' True: read every page with Tesseract, typed ones too
  Dim both As String = PdfOcr.ExtractText(inPath, o)

  For Each pg As PdfOcrPage In PdfOcr.ReadPages(inPath, o)
      Console.WriteLine(pg.Number & "": "" & pg.Method & "" "" & pg.Note)
  Next
  Dim exe As String = PdfOcr.FindTesseract()   ' Nothing when there is none

Pages are separated by a form feed (character 12), as in ToText.
Method per page: ocr (scan read by Tesseract), text (typed text), text+ocr (both on one page),
none (nothing to read), failed (Note says why, e.g. a JBIG2 or JPEG 2000 scan).
Every language needs its file in the tessdata folder (ara.traineddata, deu.traineddata...), in
the version matching the Tesseract on the machine (4.0 files for Tesseract 4.0).
Typed Arabic and Hebrew come back in reading order, with ordinary letters.
Typed text whose characters cannot be read (it pastes as rubbish: fonts named T3Font_0, fonts
without a character map) is drawn from the PDF's own fonts and read by Tesseract; the page's
Note says so. ForceOcr does that for every page, for text that only looks readable.
Tesseract runs once per document, hidden; page images go to the temp folder and are deleted.
How well a scan reads is Tesseract's part: 300 dpi, straight and clean scans read best."),

            new Topic("limits", "what the library does not do", "limits limitation unsupported cannot not supported missing print render image word excel tiff",
@"Not supported:
- OCR without Tesseract: PdfOcr needs it on the machine (topic ""ocr"")
- scans compressed as JBIG2 or JPEG 2000 cannot be OCRed yet (the page reports it)
- printing, or turning pages into pictures
- Word, Excel or Outlook to PDF (Office does this: Word's ""Save as PDF"")
- HEIC and WebP images (TIFF, GIF and BMP are fine)
- right-to-left scripts and Chinese/Japanese/Korean in TextToPdf
Saving a changed document does not keep a PDF/A claim; convert it again afterwards.
- A4 resizing drops accessibility tags (PDF/A-2A conversion rebuilds them)."),
        };

        // The overview: what the library does and the list of topics.
        public static string Show()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Pdfx " + Version + " - PDF library for .NET Framework 4.8 (no installation, no internet).").Append(Environment.NewLine);
            sb.Append("Ask for a topic with PdfHelp.Show(\"topic\") or a word, e.g. PdfHelp.Show(\"split\").").Append(Environment.NewLine);
            sb.Append("PdfHelp.All() returns every topic.").Append(Environment.NewLine).Append(Environment.NewLine);
            foreach (Topic t in All_) sb.Append("  ").Append(t.Name.PadRight(12)).Append(t.Summary).Append(Environment.NewLine);
            sb.Append("  ").Append("reference".PadRight(12)).Append("every public class and method, with parameters").Append(Environment.NewLine);
            return sb.ToString();
        }

        // One topic by name, or every topic mentioning the word (e.g. "password", "bates", "xml").
        public static string Show(string topic)
        {
            if (topic == null || topic.Trim().Length == 0) return Show();
            string q = topic.Trim().ToLowerInvariant();
            if (q == "reference" || q == "api") return Reference();
            List<Topic> found = new List<Topic>();
            foreach (Topic t in All_) if (t.Name == q) found.Add(t);
            if (found.Count == 0)
                foreach (Topic t in All_)
                    if ((" " + t.Keywords + " ").Contains(" " + q + " ") || t.Name.StartsWith(q, StringComparison.Ordinal)) found.Add(t);
            if (found.Count == 0)
                foreach (Topic t in All_)
                    if (t.Body.ToLowerInvariant().Contains(q) || t.Keywords.Contains(q)) found.Add(t);
            if (found.Count == 0)
                return "No help topic matches \"" + topic + "\"." + Environment.NewLine + Environment.NewLine + Show();
            StringBuilder sb = new StringBuilder();
            foreach (Topic t in found) Write(sb, t);
            return sb.ToString();
        }

        public static string All()
        {
            StringBuilder sb = new StringBuilder(Show());
            foreach (Topic t in All_) { sb.Append(Environment.NewLine); Write(sb, t); }
            sb.Append(Environment.NewLine).Append(Reference());
            return sb.ToString();
        }

        public static string[] Topics()
        {
            string[] r = new string[All_.Length];
            for (int i = 0; i < r.Length; i++) r[i] = All_[i].Name;
            return r;
        }

        // Read from the assembly itself, so it can never fall behind the code.
        public static string Reference()
        {
            StringBuilder sb = new StringBuilder("== reference: every public class and method ==" + Environment.NewLine);
            List<Type> types = new List<Type>();
            foreach (Type t in typeof(PdfHelp).Assembly.GetExportedTypes()) if (t.Namespace == "Pdfx") types.Add(t);
            types.Sort((a, b) => string.CompareOrdinal(a.Name, b.Name));
            foreach (Type t in types)
            {
                sb.Append(Environment.NewLine).Append(t.Name).Append(Environment.NewLine);
                List<string> lines = new List<string>();
                const BindingFlags all = BindingFlags.Public | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly;
                foreach (ConstructorInfo c in t.GetConstructors()) lines.Add("  New " + t.Name + Params(c.GetParameters()));
                foreach (FieldInfo f in t.GetFields(all)) lines.Add("  " + f.Name + " As " + Vb(f.FieldType));
                foreach (PropertyInfo p in t.GetProperties(all))
                    lines.Add("  " + p.Name + " As " + Vb(p.PropertyType) + (p.CanWrite && p.GetSetMethod() != null ? "" : "   (read-only)"));
                foreach (MethodInfo m in t.GetMethods(all))
                {
                    if (m.IsSpecialName || m.Name == "Equals" || m.Name == "GetHashCode" || m.Name == "ToString" || m.Name == "Dispose") continue;
                    lines.Add("  " + (m.IsStatic ? t.Name + "." : ".") + m.Name + Params(m.GetParameters()) + (m.ReturnType == typeof(void) ? "" : " As " + Vb(m.ReturnType)));
                }
                lines.Sort(StringComparer.Ordinal);
                foreach (string l in lines) sb.Append(l).Append(Environment.NewLine);
            }
            return sb.ToString();
        }

        private static string Params(ParameterInfo[] ps)
        {
            List<string> p = new List<string>();
            foreach (ParameterInfo x in ps) p.Add(x.Name + " As " + Vb(x.ParameterType));
            return "(" + string.Join(", ", p.ToArray()) + ")";
        }

        private static string Vb(Type t)
        {
            if (t.IsArray) return Vb(t.GetElementType()) + "()";
            if (t.IsGenericType)
            {
                List<string> a = new List<string>();
                foreach (Type g in t.GetGenericArguments()) a.Add(Vb(g));
                string n = t.Name.Substring(0, t.Name.IndexOf('`'));
                if (n == "Nullable") return a[0] + "?";
                return n + "(Of " + string.Join(", ", a.ToArray()) + ")";
            }
            switch (t.FullName)
            {
                case "System.String": return "String";
                case "System.Int32": return "Integer";
                case "System.Int64": return "Long";
                case "System.Double": return "Double";
                case "System.Boolean": return "Boolean";
                case "System.Byte": return "Byte";
                case "System.Char": return "Char";
                case "System.Object": return "Object";
            }
            return t.Name;
        }

        private static void Write(StringBuilder sb, Topic t)
        {
            sb.Append("== ").Append(t.Name).Append(": ").Append(t.Summary).Append(" ==").Append(Environment.NewLine);
            sb.Append(t.Body.Replace("\r\n", "\n").Replace("\n", Environment.NewLine)).Append(Environment.NewLine).Append(Environment.NewLine);
        }
    }
}
