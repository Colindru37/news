using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Pdfx.Internal
{
    public struct PdfMatrix
    {
        public double A, B, C, D, E, F;

        public static readonly PdfMatrix Identity = new PdfMatrix(1, 0, 0, 1, 0, 0);

        public PdfMatrix(double a, double b, double c, double d, double e, double f)
        {
            A = a; B = b; C = c; D = d; E = e; F = f;
        }

        public static PdfMatrix Multiply(PdfMatrix m, PdfMatrix n)
        {
            return new PdfMatrix(
                m.A * n.A + m.B * n.C,
                m.A * n.B + m.B * n.D,
                m.C * n.A + m.D * n.C,
                m.C * n.B + m.D * n.D,
                m.E * n.A + m.F * n.C + n.E,
                m.E * n.B + m.F * n.D + n.F);
        }

        public void Apply(double x, double y, out double ox, out double oy)
        {
            ox = A * x + C * y + E;
            oy = B * x + D * y + F;
        }

        public double ScaleY
        {
            get { return Math.Sqrt(Math.Abs(A * D - B * C)); }
        }
    }

    public struct PdfGlyph
    {
        public string Text;
        public double X;
        public double Y;
        public double Width;
        public double FontSize;
        public string FontName;
        public int Rotation;
        public int RenderMode;      // 3 and 7 draw nothing: an OCR layer under a scan
        // Filled only by Extract(page, true), for drawing the glyph:
        public int Code;
        public PdfFontInfo Font;
        public PdfMatrix Trm;       // text space (before the font's own matrix) -> user space
        public bool Trusted;        // Text is known, not a guess
    }

    public static class PdfContentReader
    {
        private sealed class State
        {
            public PdfMatrix Ctm = PdfMatrix.Identity;
            public PdfFontInfo Font;
            public string FontName = "";
            public double FontSize;
            public double CharSpacing;
            public double WordSpacing;
            public double HorizontalScale = 1;
            public double Leading;
            public double Rise;
            public int RenderMode;
            public bool Exact;          // every glyph, Type 3 widths from FontMatrix, drawing data

            public State Clone()
            {
                State s = new State();
                s.Ctm = Ctm; s.Font = Font; s.FontName = FontName; s.FontSize = FontSize;
                s.CharSpacing = CharSpacing; s.WordSpacing = WordSpacing;
                s.HorizontalScale = HorizontalScale; s.Leading = Leading;
                s.Rise = Rise; s.RenderMode = RenderMode; s.Exact = Exact;
                return s;
            }
        }

        public static List<PdfGlyph> Extract(PdfPage page)
        {
            return Extract(page, false);
        }

        // exact: also glyphs without text, Type 3 advances from the font matrix, and what is needed
        // to draw each glyph. The plain form is unchanged, so text extraction stays as it was.
        internal static List<PdfGlyph> Extract(PdfPage page, bool exact)
        {
            List<PdfGlyph> outp = new List<PdfGlyph>();
            if (page == null || page.SourceFile == null) return outp;

            PdfFile f = page.SourceFile;
            byte[] content = ContentBytes(f, page.Dictionary.Get("Contents"));
            PdfDictionary res = f.Resolve(page.Dictionary.Get("Resources")) as PdfDictionary;

            State s = new State();
            s.Ctm = PdfMatrix.Identity;
            s.Exact = exact;
            Run(f, content, res, s, outp, 0, new Dictionary<string, PdfFontInfo>());
            return outp;
        }

        public static byte[] ContentBytes(PdfFile f, PdfObject contents)
        {
            PdfObject r = f.Resolve(contents);
            PdfStream one = r as PdfStream;
            if (one != null) return Safe(f, one);

            PdfArray arr = r as PdfArray;
            if (arr == null) return new byte[0];

            MemoryStream ms = new MemoryStream();
            for (int i = 0; i < arr.Count; i++)
            {
                PdfStream st = f.Resolve(arr[i]) as PdfStream;
                if (st == null) continue;
                byte[] b = Safe(f, st);
                ms.Write(b, 0, b.Length);
                ms.WriteByte((byte)'\n');
            }
            return ms.ToArray();
        }

        private static byte[] Safe(PdfFile f, PdfStream s)
        {
            try { return PdfFilters.Decode(s, f); }
            catch { return new byte[0]; }
        }

        private static void Run(PdfFile f, byte[] content, PdfDictionary resources,
                                State state, List<PdfGlyph> outp, int depth,
                                Dictionary<string, PdfFontInfo> fontCache)
        {
            if (depth > 8) return;

            PdfLexer lex = new PdfLexer(content);
            List<PdfObject> stack = new List<PdfObject>();
            Stack<State> saved = new Stack<State>();
            PdfParser parser = new PdfParser(content, null);

            PdfMatrix tm = PdfMatrix.Identity;
            PdfMatrix tlm = PdfMatrix.Identity;
            List<int> codes = new List<int>();

            while (true)
            {
                int before = lex.Position;
                Token t = lex.Next();
                if (t.Type == TokenType.Eof) break;

                if (t.Type != TokenType.Keyword)
                {
                    parser.Position = before;
                    PdfObject o = parser.ParseObject();
                    lex.Position = parser.Position;
                    stack.Add(o);
                    if (stack.Count > 64) stack.RemoveAt(0);
                    continue;
                }

                string op = t.Text;

                switch (op)
                {
                    case "q":
                        saved.Push(state.Clone());
                        break;

                    case "Q":
                        if (saved.Count > 0) state = saved.Pop();
                        break;

                    case "cm":
                        if (stack.Count >= 6)
                            state.Ctm = PdfMatrix.Multiply(MatrixFrom(stack, stack.Count - 6), state.Ctm);
                        break;

                    case "BT":
                        tm = PdfMatrix.Identity;
                        tlm = PdfMatrix.Identity;
                        break;

                    case "ET":
                        break;

                    case "Tf":
                        if (stack.Count >= 2)
                        {
                            PdfName fn = stack[stack.Count - 2] as PdfName;
                            state.FontSize = Num(stack, stack.Count - 1);
                            state.FontName = fn == null ? "" : fn.Value;
                            state.Font = LookupFont(f, resources, state.FontName, fontCache);
                        }
                        break;

                    case "Tc": state.CharSpacing = Num(stack, stack.Count - 1); break;
                    case "Tw": state.WordSpacing = Num(stack, stack.Count - 1); break;
                    case "Tz": state.HorizontalScale = Num(stack, stack.Count - 1) / 100.0; break;
                    case "TL": state.Leading = Num(stack, stack.Count - 1); break;
                    case "Ts": state.Rise = Num(stack, stack.Count - 1); break;
                    case "Tr": state.RenderMode = (int)Num(stack, stack.Count - 1); break;

                    case "Td":
                        if (stack.Count >= 2)
                        {
                            tlm = PdfMatrix.Multiply(
                                new PdfMatrix(1, 0, 0, 1, Num(stack, stack.Count - 2), Num(stack, stack.Count - 1)),
                                tlm);
                            tm = tlm;
                        }
                        break;

                    case "TD":
                        if (stack.Count >= 2)
                        {
                            state.Leading = -Num(stack, stack.Count - 1);
                            tlm = PdfMatrix.Multiply(
                                new PdfMatrix(1, 0, 0, 1, Num(stack, stack.Count - 2), Num(stack, stack.Count - 1)),
                                tlm);
                            tm = tlm;
                        }
                        break;

                    case "Tm":
                        if (stack.Count >= 6)
                        {
                            tlm = MatrixFrom(stack, stack.Count - 6);
                            tm = tlm;
                        }
                        break;

                    case "T*":
                        tlm = PdfMatrix.Multiply(new PdfMatrix(1, 0, 0, 1, 0, -state.Leading), tlm);
                        tm = tlm;
                        break;

                    case "Tj":
                        if (stack.Count >= 1)
                            Show(state, StringAt(stack, stack.Count - 1), ref tm, outp, codes);
                        break;

                    case "'":
                        tlm = PdfMatrix.Multiply(new PdfMatrix(1, 0, 0, 1, 0, -state.Leading), tlm);
                        tm = tlm;
                        if (stack.Count >= 1)
                            Show(state, StringAt(stack, stack.Count - 1), ref tm, outp, codes);
                        break;

                    case "\"":
                        if (stack.Count >= 3)
                        {
                            state.WordSpacing = Num(stack, stack.Count - 3);
                            state.CharSpacing = Num(stack, stack.Count - 2);
                            tlm = PdfMatrix.Multiply(new PdfMatrix(1, 0, 0, 1, 0, -state.Leading), tlm);
                            tm = tlm;
                            Show(state, StringAt(stack, stack.Count - 1), ref tm, outp, codes);
                        }
                        break;

                    case "TJ":
                        if (stack.Count >= 1)
                        {
                            PdfArray arr = stack[stack.Count - 1] as PdfArray;
                            if (arr != null)
                            {
                                for (int i = 0; i < arr.Count; i++)
                                {
                                    PdfString ps = arr[i] as PdfString;
                                    if (ps != null) { Show(state, ps.Bytes, ref tm, outp, codes); continue; }
                                    PdfNumber pn = arr[i] as PdfNumber;
                                    if (pn != null)
                                    {
                                        double shift = -pn.Value / 1000.0 * state.FontSize * state.HorizontalScale;
                                        tm = PdfMatrix.Multiply(new PdfMatrix(1, 0, 0, 1, shift, 0), tm);
                                    }
                                }
                            }
                        }
                        break;

                    case "Do":
                        if (stack.Count >= 1)
                        {
                            PdfName xn = stack[stack.Count - 1] as PdfName;
                            if (xn != null)
                                RunForm(f, resources, xn.Value, state, outp, depth, fontCache);
                        }
                        break;

                    case "BI":
                        SkipInlineImage(lex);
                        break;
                }

                if (op != "BI") stack.Clear();
            }
        }

        private static void RunForm(PdfFile f, PdfDictionary resources, string name,
                                    State state, List<PdfGlyph> outp, int depth,
                                    Dictionary<string, PdfFontInfo> fontCache)
        {
            PdfDictionary xobjects = resources == null
                ? null : f.Resolve(resources.Get("XObject")) as PdfDictionary;
            if (xobjects == null) return;

            PdfStream form = f.Resolve(xobjects.Get(name)) as PdfStream;
            if (form == null) return;

            PdfName sub = f.Resolve(form.Dict.Get("Subtype")) as PdfName;
            if (sub == null || sub.Value != "Form") return;

            State inner = state.Clone();
            PdfArray mx = f.Resolve(form.Dict.Get("Matrix")) as PdfArray;
            if (mx != null && mx.Count >= 6)
            {
                PdfMatrix m = new PdfMatrix(
                    NumOf(f, mx[0]), NumOf(f, mx[1]), NumOf(f, mx[2]),
                    NumOf(f, mx[3]), NumOf(f, mx[4]), NumOf(f, mx[5]));
                inner.Ctm = PdfMatrix.Multiply(m, state.Ctm);
            }

            PdfDictionary formRes = f.Resolve(form.Dict.Get("Resources")) as PdfDictionary;
            byte[] body = Safe(f, form);
            Run(f, body, formRes ?? resources, inner, outp, depth + 1,
                new Dictionary<string, PdfFontInfo>());
        }

        private static void SkipInlineImage(PdfLexer lex)
        {
            byte[] d = lex.Data;
            int i = lex.Position;
            while (i + 1 < d.Length)
            {
                if (d[i] == (byte)'E' && d[i + 1] == (byte)'I'
                    && (i == 0 || PdfLexer.IsWhite(d[i - 1]))
                    && (i + 2 >= d.Length || PdfLexer.IsWhite(d[i + 2])))
                {
                    lex.Position = i + 2;
                    return;
                }
                i++;
            }
            lex.Position = d.Length;
        }

        private static PdfFontInfo LookupFont(PdfFile f, PdfDictionary resources, string name,
                                              Dictionary<string, PdfFontInfo> cache)
        {
            PdfFontInfo info;
            if (cache.TryGetValue(name, out info)) return info;

            PdfDictionary fonts = resources == null
                ? null : f.Resolve(resources.Get("Font")) as PdfDictionary;
            PdfDictionary font = fonts == null ? null : f.Resolve(fonts.Get(name)) as PdfDictionary;

            info = PdfFontInfo.Build(f, font);
            cache[name] = info;
            return info;
        }

        private static void Show(State s, byte[] raw, ref PdfMatrix tm,
                                 List<PdfGlyph> outp, List<int> codes)
        {
            if (raw == null || raw.Length == 0) return;
            PdfFontInfo font = s.Font;
            if (font == null) font = PdfFontInfo.Build(null, null);

            font.Decode(raw, codes);

            for (int i = 0; i < codes.Count; i++)
            {
                int code = codes[i];
                double w0 = s.Exact ? font.ExactWidth(code) : font.WidthOf(code);

                PdfMatrix trm = PdfMatrix.Multiply(
                    new PdfMatrix(s.FontSize * s.HorizontalScale, 0, 0, s.FontSize, 0, s.Rise),
                    PdfMatrix.Multiply(tm, s.Ctm));

                string text = Printable(font.TextFor(code));
                if (text.Length > 0 || s.Exact)
                {
                    double x, y;
                    trm.Apply(0, 0, out x, out y);
                    double scale = PdfMatrix.Multiply(tm, s.Ctm).ScaleY;

                    PdfGlyph g = new PdfGlyph();
                    g.Text = text;
                    g.X = x;
                    g.Y = y;
                    g.FontSize = Math.Abs(s.FontSize) * scale;
                    g.Width = w0 * s.FontSize * s.HorizontalScale * scale;
                    g.FontName = s.FontName;
                    g.RenderMode = s.RenderMode;
                    if (s.Exact) { g.Code = code; g.Font = font; g.Trm = trm; g.Trusted = font.Trusted(code); }

                    PdfMatrix dir = PdfMatrix.Multiply(tm, s.Ctm);
                    double deg = Math.Atan2(dir.B, dir.A) * 180.0 / Math.PI;
                    int q = ((int)Math.Round(deg / 90.0) * 90) % 360;
                    if (q < 0) q += 360;
                    g.Rotation = q;

                    outp.Add(g);
                }

                bool isSpaceByte = !font.IsCid && code == 32;
                double advance = (w0 * s.FontSize + s.CharSpacing
                                  + (isSpaceByte ? s.WordSpacing : 0)) * s.HorizontalScale;
                tm = PdfMatrix.Multiply(new PdfMatrix(1, 0, 0, 1, advance, 0), tm);
            }
        }

        private static string Printable(string text)
        {
            if (string.IsNullOrEmpty(text)) return string.Empty;
            bool clean = true;
            for (int i = 0; i < text.Length; i++)
                if (text[i] == '\u0000' || text[i] == '\uFEFF') { clean = false; break; }
            if (clean) return text;

            StringBuilder sb = new StringBuilder(text.Length);
            for (int i = 0; i < text.Length; i++)
                if (text[i] != '\u0000' && text[i] != '\uFEFF') sb.Append(text[i]);
            return sb.ToString();
        }

        private static PdfMatrix MatrixFrom(List<PdfObject> stack, int at)
        {
            return new PdfMatrix(
                Num(stack, at), Num(stack, at + 1), Num(stack, at + 2),
                Num(stack, at + 3), Num(stack, at + 4), Num(stack, at + 5));
        }

        private static double Num(List<PdfObject> stack, int at)
        {
            if (at < 0 || at >= stack.Count) return 0;
            PdfNumber n = stack[at] as PdfNumber;
            return n == null ? 0 : n.Value;
        }

        private static double NumOf(PdfFile f, PdfObject o)
        {
            PdfNumber n = f.Resolve(o) as PdfNumber;
            return n == null ? 0 : n.Value;
        }

        private static byte[] StringAt(List<PdfObject> stack, int at)
        {
            if (at < 0 || at >= stack.Count) return null;
            PdfString s = stack[at] as PdfString;
            return s == null ? null : s.Bytes;
        }
    }
}
