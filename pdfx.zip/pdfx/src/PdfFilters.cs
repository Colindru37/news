using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;

namespace Pdfx.Internal
{
    public static class PdfFilters
    {
        public static byte[] Decode(PdfStream s, PdfFile file)
        {
            if (file != null && file.IsEncrypted && file.Decryptor == null)
                throw new PdfException(
                    "document is encrypted and no decryptor is set; decoding would return rubbish");

            byte[] data = s.RawData;

            PdfObject f = s.Dict.Get("Filter");
            if (f == null) f = s.Dict.Get("F");
            if (file != null) f = file.Resolve(f);
            if (f == null || f is PdfNull) return data;

            List<string> names = new List<string>();
            PdfName single = f as PdfName;
            if (single != null) names.Add(single.Value);
            else
            {
                PdfArray arr = f as PdfArray;
                if (arr != null)
                {
                    for (int i = 0; i < arr.Count; i++)
                    {
                        PdfObject it = file != null ? file.Resolve(arr[i]) : arr[i];
                        PdfName n = it as PdfName;
                        if (n != null) names.Add(n.Value);
                    }
                }
            }

            PdfObject dp = s.Dict.Get("DecodeParms");
            if (dp == null) dp = s.Dict.Get("DP");
            if (file != null) dp = file.Resolve(dp);

            for (int i = 0; i < names.Count; i++)
            {
                PdfDictionary parms = null;
                PdfDictionary dpd = dp as PdfDictionary;
                if (dpd != null && i == 0) parms = dpd;
                else
                {
                    PdfArray dpa = dp as PdfArray;
                    if (dpa != null)
                    {
                        PdfObject it = file != null ? file.Resolve(dpa[i]) : dpa[i];
                        parms = it as PdfDictionary;
                    }
                }

                string nm = names[i];
                if (nm == "FlateDecode" || nm == "Fl")
                {
                    byte[] before = data;
                    data = FlateDecode(data);
                    if (data.Length == 0 && before.Length > 0)
                        throw new PdfException("FlateDecode produced nothing from "
                            + before.Length + " bytes: the stream is corrupt or still encrypted");
                }
                else if (nm == "LZWDecode" || nm == "LZW") data = LzwDecode(data, GetInt(parms, file, "EarlyChange", 1));
                else if (nm == "ASCII85Decode" || nm == "A85") data = Ascii85Decode(data);
                else if (nm == "ASCIIHexDecode" || nm == "AHx") data = AsciiHexDecode(data);
                else if (nm == "RunLengthDecode" || nm == "RL") data = RunLengthDecode(data);
                else return data;

                int pred = GetInt(parms, file, "Predictor", 1);
                if (pred > 1)
                    data = ApplyPredictor(data, pred,
                        GetInt(parms, file, "Colors", 1),
                        GetInt(parms, file, "BitsPerComponent", 8),
                        GetInt(parms, file, "Columns", 1));
            }

            return data;
        }

        private static int GetInt(PdfDictionary d, PdfFile file, string key, int fallback)
        {
            if (d == null) return fallback;
            PdfObject o = d.Get(key);
            if (file != null) o = file.Resolve(o);
            PdfNumber n = o as PdfNumber;
            return n != null ? n.AsInt : fallback;
        }

        public static byte[] FlateDecode(byte[] data)
        {
            byte[] a = Inflate(data, 2);
            if (a.Length > 0) return a;
            byte[] b = Inflate(data, 0);
            return b.Length > 0 ? b : a;
        }

        private static byte[] Inflate(byte[] data, int skip)
        {
            if (data == null || data.Length <= skip) return new byte[0];
            MemoryStream outMs = new MemoryStream();
            try
            {
                using (MemoryStream ms = new MemoryStream(data, skip, data.Length - skip))
                using (DeflateStream ds = new DeflateStream(ms, CompressionMode.Decompress))
                {
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = ds.Read(buf, 0, buf.Length)) > 0) outMs.Write(buf, 0, n);
                }
            }
            catch
            {
            }
            return outMs.ToArray();
        }

        public static byte[] AsciiHexDecode(byte[] data)
        {
            List<byte> outp = new List<byte>();
            int hi = -1;
            for (int i = 0; i < data.Length; i++)
            {
                byte c = data[i];
                if (c == (byte)'>') break;
                int v;
                if (c >= (byte)'0' && c <= (byte)'9') v = c - (byte)'0';
                else if (c >= (byte)'a' && c <= (byte)'f') v = c - (byte)'a' + 10;
                else if (c >= (byte)'A' && c <= (byte)'F') v = c - (byte)'A' + 10;
                else continue;
                if (hi < 0) hi = v;
                else { outp.Add((byte)(hi * 16 + v)); hi = -1; }
            }
            if (hi >= 0) outp.Add((byte)(hi * 16));
            return outp.ToArray();
        }

        public static byte[] Ascii85Decode(byte[] data)
        {
            List<byte> outp = new List<byte>();
            int i = 0;
            if (data.Length >= 2 && data[0] == (byte)'<' && data[1] == (byte)'~') i = 2;

            uint tuple = 0;
            int count = 0;
            for (; i < data.Length; i++)
            {
                byte c = data[i];
                if (c == (byte)'~') break;
                if (PdfLexer.IsWhite(c)) continue;
                if (c == (byte)'z' && count == 0)
                {
                    outp.Add(0); outp.Add(0); outp.Add(0); outp.Add(0);
                    continue;
                }
                if (c < (byte)'!' || c > (byte)'u') continue;
                tuple = tuple * 85 + (uint)(c - (byte)'!');
                count++;
                if (count == 5)
                {
                    outp.Add((byte)(tuple >> 24));
                    outp.Add((byte)(tuple >> 16));
                    outp.Add((byte)(tuple >> 8));
                    outp.Add((byte)tuple);
                    tuple = 0;
                    count = 0;
                }
            }
            if (count > 0)
            {
                for (int k = count; k < 5; k++) tuple = tuple * 85 + 84;
                for (int k = 0; k < count - 1; k++)
                    outp.Add((byte)(tuple >> (24 - 8 * k)));
            }
            return outp.ToArray();
        }

        public static byte[] RunLengthDecode(byte[] data)
        {
            List<byte> outp = new List<byte>();
            int i = 0;
            while (i < data.Length)
            {
                int n = data[i++];
                if (n == 128) break;
                if (n < 128)
                {
                    for (int k = 0; k <= n && i < data.Length; k++) outp.Add(data[i++]);
                }
                else
                {
                    if (i >= data.Length) break;
                    byte v = data[i++];
                    for (int k = 0; k < 257 - n; k++) outp.Add(v);
                }
            }
            return outp.ToArray();
        }

        public static byte[] LzwDecode(byte[] data, int earlyChange)
        {
            List<byte> outp = new List<byte>();
            byte[][] table = new byte[4096][];
            for (int i = 0; i < 256; i++) table[i] = new byte[] { (byte)i };
            int next = 258;
            int codeBits = 9;
            byte[] prev = null;

            int bitPos = 0;
            int totalBits = data.Length * 8;

            while (bitPos + codeBits <= totalBits)
            {
                int code = 0;
                for (int k = 0; k < codeBits; k++)
                {
                    int bi = bitPos + k;
                    int bit = (data[bi >> 3] >> (7 - (bi & 7))) & 1;
                    code = (code << 1) | bit;
                }
                bitPos += codeBits;

                if (code == 256)
                {
                    next = 258;
                    codeBits = 9;
                    prev = null;
                    continue;
                }
                if (code == 257) break;

                byte[] entry;
                if (code < next && table[code] != null) entry = table[code];
                else if (prev != null)
                {
                    entry = new byte[prev.Length + 1];
                    Buffer.BlockCopy(prev, 0, entry, 0, prev.Length);
                    entry[prev.Length] = prev[0];
                }
                else break;

                outp.AddRange(entry);

                if (prev != null && next < 4096)
                {
                    byte[] added = new byte[prev.Length + 1];
                    Buffer.BlockCopy(prev, 0, added, 0, prev.Length);
                    added[prev.Length] = entry[0];
                    table[next++] = added;
                }

                prev = entry;

                int limit = next + (earlyChange != 0 ? 1 : 0);
                if (limit >= 512 && codeBits == 9) codeBits = 10;
                else if (limit >= 1024 && codeBits == 10) codeBits = 11;
                else if (limit >= 2048 && codeBits == 11) codeBits = 12;
            }

            return outp.ToArray();
        }

        public static byte[] ApplyPredictor(byte[] data, int predictor, int colors, int bpc, int columns)
        {
            if (predictor < 2) return data;
            if (colors < 1) colors = 1;
            if (bpc < 1) bpc = 8;
            if (columns < 1) columns = 1;

            int rowLength = (columns * colors * bpc + 7) / 8;
            int bpp = Math.Max(1, (colors * bpc + 7) / 8);

            if (predictor == 2)
            {
                if (bpc != 8) return data;
                int rows2 = data.Length / rowLength;
                for (int r = 0; r < rows2; r++)
                {
                    int off = r * rowLength;
                    for (int i = bpp; i < rowLength; i++)
                        data[off + i] = (byte)(data[off + i] + data[off + i - bpp]);
                }
                return data;
            }

            int stride = rowLength + 1;
            int rows = data.Length / stride;
            byte[] outp = new byte[rows * rowLength];
            byte[] prior = new byte[rowLength];
            byte[] cur = new byte[rowLength];

            for (int r = 0; r < rows; r++)
            {
                int off = r * stride;
                int ft = data[off];
                Buffer.BlockCopy(data, off + 1, cur, 0, rowLength);

                for (int i = 0; i < rowLength; i++)
                {
                    int left = i >= bpp ? cur[i - bpp] : 0;
                    int up = prior[i];
                    int upLeft = i >= bpp ? prior[i - bpp] : 0;
                    int v = cur[i];
                    switch (ft)
                    {
                        case 0: break;
                        case 1: v = v + left; break;
                        case 2: v = v + up; break;
                        case 3: v = v + ((left + up) >> 1); break;
                        case 4: v = v + Paeth(left, up, upLeft); break;
                        default: break;
                    }
                    cur[i] = (byte)v;
                }

                Buffer.BlockCopy(cur, 0, outp, r * rowLength, rowLength);
                Buffer.BlockCopy(cur, 0, prior, 0, rowLength);
            }

            return outp;
        }

        private static int Paeth(int a, int b, int c)
        {
            int p = a + b - c;
            int pa = Math.Abs(p - a);
            int pb = Math.Abs(p - b);
            int pc = Math.Abs(p - c);
            if (pa <= pb && pa <= pc) return a;
            if (pb <= pc) return b;
            return c;
        }
    }
}
