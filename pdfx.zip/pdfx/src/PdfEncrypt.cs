using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using Pdfx.Internal;

namespace Pdfx
{
    // How a saved file is protected. The user password opens it; the owner password lifts the
    // permissions. Either may be empty, not both.
    public sealed class PdfPasswordOptions
    {
        public string UserPassword;
        public string OwnerPassword;
        public bool AllowPrinting = true;
        public bool AllowCopying = true;
        public bool AllowEditing;
        public bool AllowAnnotations;
        public bool AllowFormFilling = true;
        public bool AllowAssembly;
        // AES-128 for readers older than 2010; AES-256 otherwise.
        public bool Aes128;

        public PdfPasswordOptions() { }

        public PdfPasswordOptions(string userPassword, string ownerPassword)
        {
            UserPassword = userPassword;
            OwnerPassword = ownerPassword;
        }

        // Permission bits as the PDF standard lays them out (bits 1-2 clear, 7-8 and 13-32 set).
        internal int Permissions
        {
            get
            {
                uint p = 0xFFFFF0C0;
                if (AllowPrinting) p |= 4 | 2048;
                if (AllowEditing) p |= 8;
                if (AllowCopying) p |= 16;
                if (AllowAnnotations) p |= 32;
                if (AllowFormFilling) p |= 256;
                p |= 512;                                    // extraction for accessibility: always
                if (AllowAssembly) p |= 1024;
                return unchecked((int)p);
            }
        }
    }

    public static partial class PdfComposer
    {
        public static void AddPassword(string input, string output, string userPassword, string ownerPassword)
        {
            AddPassword(input, output, new PdfPasswordOptions(userPassword, ownerPassword));
        }

        // Protects a file. A PDF/A file loses its PDF/A status: the standard forbids encryption.
        public static void AddPassword(string input, string output, PdfPasswordOptions options)
        {
            if (options == null) throw new ArgumentNullException("options");
            using (PdfDocument d = PdfDocument.Open(ReadInput(input))) d.Save(output, options);
        }
    }

    public sealed partial class PdfDocument
    {
        public void Save(string path, PdfPasswordOptions protection)
        {
            PdfComposer.WriteOutput(path, ToBytes(protection));
        }

        public void Save(Stream target, PdfPasswordOptions protection)
        {
            byte[] b = ToBytes(protection);
            target.Write(b, 0, b.Length);
        }

        public byte[] ToBytes(PdfPasswordOptions protection)
        {
            if (protection == null) return ToBytes();
            if (string.IsNullOrEmpty(protection.UserPassword) && string.IsNullOrEmpty(protection.OwnerPassword))
                throw new ArgumentException("no password given: set UserPassword (to open) or OwnerPassword (to change permissions), or both", "protection");
            return Build(new PdfEncryptor(protection));
        }
    }
}

namespace Pdfx.Internal
{
    // Standard security handler, writing side: AESV3 (R6, 256-bit) or AESV2 (R4, 128-bit).
    internal sealed class PdfEncryptor
    {
        private readonly byte[] _key;
        private readonly bool _aes256;
        public readonly PdfDictionary Dictionary = new PdfDictionary();
        public readonly byte[] FileId;

        public PdfEncryptor(PdfPasswordOptions o)
        {
            string user = o.UserPassword ?? "", owner = string.IsNullOrEmpty(o.OwnerPassword) ? user : o.OwnerPassword;
            int p = o.Permissions;
            FileId = Random(16);
            _aes256 = !o.Aes128;
            Dictionary.Set("Filter", new PdfName("Standard"));
            PdfDictionary cf = new PdfDictionary(), std = new PdfDictionary();
            std.Set("Type", new PdfName("CryptFilter"));
            std.Set("AuthEvent", new PdfName("DocOpen"));
            cf.Set("StdCF", std);
            Dictionary.Set("CF", cf);
            Dictionary.Set("StmF", new PdfName("StdCF"));
            Dictionary.Set("StrF", new PdfName("StdCF"));
            Dictionary.Set("P", new PdfNumber(p, true));

            if (_aes256)
            {
                _key = Random(32);
                byte[] upw = Utf8(user), opw = Utf8(owner);
                byte[] uvs = Random(8), uks = Random(8), ovs = Random(8), oks = Random(8);
                byte[] u = Concat(PdfStandardSecurity.Hash2B(upw, uvs, new byte[0]), uvs, uks);
                byte[] ue = AesCbc.Encrypt(PdfStandardSecurity.Hash2B(upw, uks, new byte[0]), new byte[16], _key);
                byte[] oo = Concat(PdfStandardSecurity.Hash2B(opw, ovs, u), ovs, oks);
                byte[] oe = AesCbc.Encrypt(PdfStandardSecurity.Hash2B(opw, oks, u), new byte[16], _key);
                byte[] perms = new byte[16];
                perms[0] = (byte)p; perms[1] = (byte)(p >> 8); perms[2] = (byte)(p >> 16); perms[3] = (byte)(p >> 24);
                perms[4] = perms[5] = perms[6] = perms[7] = 0xFF;
                perms[8] = (byte)'T'; perms[9] = (byte)'a'; perms[10] = (byte)'d'; perms[11] = (byte)'b';
                Buffer.BlockCopy(Random(4), 0, perms, 12, 4);
                Dictionary.Set("V", new PdfNumber(5, true));
                Dictionary.Set("R", new PdfNumber(6, true));
                Dictionary.Set("Length", new PdfNumber(256, true));
                std.Set("CFM", new PdfName("AESV3"));
                std.Set("Length", new PdfNumber(32, true));
                Dictionary.Set("U", new PdfString(u, true));
                Dictionary.Set("UE", new PdfString(ue, true));
                Dictionary.Set("O", new PdfString(oo, true));
                Dictionary.Set("OE", new PdfString(oe, true));
                Dictionary.Set("Perms", new PdfString(AesCbc.Encrypt(_key, new byte[16], perms), true));
            }
            else
            {
                // Algorithms 3.3 (O), 3.2 (key) and 3.5 (U) of the PDF 1.7 standard, revision 4.
                byte[] opad = PdfStandardSecurity.PadPassword(owner), upad = PdfStandardSecurity.PadPassword(user);
                byte[] okey = PdfStandardSecurity.Md5(opad);
                for (int i = 0; i < 50; i++) okey = PdfStandardSecurity.Md5(Slice(okey, 0, 16));
                okey = Slice(okey, 0, 16);
                byte[] oo = Rc4.Apply(okey, upad);
                for (int i = 1; i <= 19; i++) oo = Rc4.Apply(Xor(okey, i), oo);
                _key = PdfStandardSecurity.ComputeKeyRaw(upad, oo, p, FileId, 4, 16, true);
                byte[] u = Rc4.Apply(_key, PdfStandardSecurity.Md5(Concat(PdfStandardSecurity.Pad, FileId)));
                for (int i = 1; i <= 19; i++) u = Rc4.Apply(Xor(_key, i), u);
                u = Concat(u, new byte[16]);
                Dictionary.Set("V", new PdfNumber(4, true));
                Dictionary.Set("R", new PdfNumber(4, true));
                Dictionary.Set("Length", new PdfNumber(128, true));
                std.Set("CFM", new PdfName("AESV2"));
                std.Set("Length", new PdfNumber(16, true));
                Dictionary.Set("U", new PdfString(u, true));
                Dictionary.Set("O", new PdfString(oo, true));
            }
        }

        public byte[] Encrypt(byte[] data, int num, int gen)
        {
            byte[] key = _aes256 ? _key : ObjectKey(num, gen);
            byte[] iv = Random(16);
            int pad = 16 - data.Length % 16;
            byte[] padded = new byte[data.Length + pad];
            Buffer.BlockCopy(data, 0, padded, 0, data.Length);
            for (int i = data.Length; i < padded.Length; i++) padded[i] = (byte)pad;
            return Concat(iv, AesCbc.Encrypt(key, iv, padded));
        }

        private byte[] ObjectKey(int num, int gen)
        {
            byte[] salt = { (byte)num, (byte)(num >> 8), (byte)(num >> 16), (byte)gen, (byte)(gen >> 8), 0x73, 0x41, 0x6C, 0x54 };
            return Slice(PdfStandardSecurity.Md5(Concat(_key, salt)), 0, 16);
        }

        private static byte[] Utf8(string s)
        {
            byte[] b = Encoding.UTF8.GetBytes(s ?? "");
            return b.Length > 127 ? Slice(b, 0, 127) : b;
        }

        private static byte[] Xor(byte[] key, int i)
        {
            byte[] k = new byte[key.Length];
            for (int j = 0; j < key.Length; j++) k[j] = (byte)(key[j] ^ i);
            return k;
        }

        private static byte[] Random(int n)
        {
            byte[] b = new byte[n];
            using (RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider()) rng.GetBytes(b);
            return b;
        }

        private static byte[] Slice(byte[] s, int from, int n)
        {
            byte[] r = new byte[n];
            Buffer.BlockCopy(s, from, r, 0, n);
            return r;
        }

        private static byte[] Concat(params byte[][] parts)
        {
            int n = 0;
            foreach (byte[] p in parts) n += p.Length;
            byte[] r = new byte[n];
            int at = 0;
            foreach (byte[] p in parts) { Buffer.BlockCopy(p, 0, r, at, p.Length); at += p.Length; }
            return r;
        }
    }
}
