using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using Pdfx.Internal;

namespace Pdfx
{
    public static partial class PdfComposer
    {
        // Every page onto one paper size: "A4", "A3", "A5", "Letter", "Legal", or "210x297mm" /
        // "8.5x11in". Content is scaled to fit and centred, never cropped. A landscape page gets
        // the paper in landscape; add " portrait" or " landscape" to force one.
        public static void ResizePages(string input, string output, string paper)
        {
            ResizePages(input, output, paper, null);
        }

        public static void ResizePages(string input, string output, string paper, string password)
        {
            using (PdfDocument d = PdfDocument.Open(ReadInput(input), password))
            {
                d.ResizePages(paper);
                d.Save(output);
            }
        }
    }

    public sealed partial class PdfDocument
    {
        public void ResizePages(string paper)
        {
            double w, h;
            string orient;
            PdfPaper.Parse(paper, out w, out h, out orient);
            foreach (PdfPage p in _pages) p.FitTo = PdfPaper.Oriented(p, w, h, orient);
        }

        // Width and height in points (72 per inch), applied to every page as given.
        public void ResizePages(double width, double height)
        {
            if (width < 72 || height < 72 || width > 14400 || height > 14400)
                throw new ArgumentException("the page size must be between 1 and 200 inches a side (given in points)");
            foreach (PdfPage p in _pages) p.FitTo = new double[] { width, height };
        }
    }
}

namespace Pdfx.Internal
{
    internal static class PdfPaper
    {
        public static void Parse(string paper, out double w, out double h, out string orient)
        {
            string t = (paper ?? "").Trim().ToLowerInvariant();
            orient = null;
            foreach (string o in new[] { "landscape", "portrait" })
                if (t.EndsWith(o, StringComparison.Ordinal)) { orient = o; t = t.Substring(0, t.Length - o.Length).Trim().TrimEnd('-', '_'); }
            switch (t)
            {
                case "a3": w = 841.89; h = 1190.55; return;
                case "a4": w = 595.276; h = 841.89; return;
                case "a5": w = 419.53; h = 595.276; return;
                case "letter": w = 612; h = 792; return;
                case "legal": w = 612; h = 1008; return;
                case "tabloid": case "ledger": w = 792; h = 1224; return;
            }
            // "210x297", "210x297mm", "8.5x11in", "8.5 x 11 inch"
            double unit = 72 / 25.4;
            if (t.EndsWith("mm", StringComparison.Ordinal)) t = t.Substring(0, t.Length - 2);
            else if (t.EndsWith("cm", StringComparison.Ordinal)) { unit = 72 / 2.54; t = t.Substring(0, t.Length - 2); }
            else if (t.EndsWith("inch", StringComparison.Ordinal)) { unit = 72; t = t.Substring(0, t.Length - 4); }
            else if (t.EndsWith("in", StringComparison.Ordinal)) { unit = 72; t = t.Substring(0, t.Length - 2); }
            else if (t.EndsWith("pt", StringComparison.Ordinal)) { unit = 1; t = t.Substring(0, t.Length - 2); }
            string[] parts = t.Replace(" ", "").Split('x');
            double a, b;
            if (parts.Length == 2 && double.TryParse(parts[0].Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out a)
                && double.TryParse(parts[1].Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out b) && a > 0 && b > 0)
            {
                w = a * unit; h = b * unit;
                if (w >= 72 && h >= 72 && w <= 14400 && h <= 14400) return;
            }
            throw new ArgumentException("unknown paper size '" + paper + "'; use A3, A4, A5, Letter, Legal, or a size like 210x297mm or 8.5x11in", "paper");
        }

        public static double[] Oriented(PdfPage p, double w, double h, string orient)
        {
            bool landscape = orient == "landscape" || (orient == null && p.VisibleWidth > p.VisibleHeight);
            double a = Math.Min(w, h), b = Math.Max(w, h);
            return landscape ? new double[] { b, a } : new double[] { a, b };
        }
    }

    // Puts a page's content inside a form and draws it scaled and centred on a new page of the
    // wanted size. Annotations move with it; structure tags do not survive (convert to PDF/A-2A
    // afterwards to get them back).
    internal static class PdfResizer
    {
        public static PdfDictionary Wrap(PdfOutput o, PdfPage p, double W, double H, int pageNum)
        {
            double[] box = p.VisibleBox;
            double bw = box[2] - box[0], bh = box[3] - box[1];
            int rot = p.Rotation;
            bool turned = rot == 90 || rot == 270;
            double vw = turned ? bh : bw, vh = turned ? bw : bh;
            double s = Math.Min(W / vw, H / vh);
            double tx = (W - vw * s) / 2, ty = (H - vh * s) / 2;

            double[] m = { 1, 0, 0, 1, -box[0], -box[1] };
            double[] r;
            switch (rot)
            {
                case 90: r = new double[] { 0, -1, 1, 0, 0, bw }; break;
                case 180: r = new double[] { -1, 0, 0, -1, bw, bh }; break;
                case 270: r = new double[] { 0, 1, -1, 0, bh, 0 }; break;
                default: r = new double[] { 1, 0, 0, 1, 0, 0 }; break;
            }
            m = Mul(Mul(m, r), new double[] { s, 0, 0, s, tx, ty });

            PdfFile src = p.Source;
            byte[] inner;
            if (src != null) inner = PdfContentReader.ContentBytes(src, p.Dict.Get("Contents"));
            else
            {
                MemoryStream ms = new MemoryStream();
                PdfObject c = p.Dict.Get("Contents");
                List<PdfObject> parts = c is PdfArray ? ((PdfArray)c).Items : new List<PdfObject> { c };
                foreach (PdfObject part in parts)
                {
                    PdfStream st = part as PdfStream;
                    if (st == null) continue;
                    byte[] b = PdfaDecode.Decode(st, o) ?? new byte[0];
                    ms.Write(b, 0, b.Length);
                    ms.WriteByte((byte)'\n');
                }
                inner = ms.ToArray();
            }

            PdfDictionary fd = new PdfDictionary();
            fd.Set("Type", new PdfName("XObject"));
            fd.Set("Subtype", new PdfName("Form"));
            fd.Set("FormType", new PdfNumber(1, true));
            fd.Set("BBox", Nums(box));
            PdfObject res = p.Dict.Get("Resources");
            fd.Set("Resources", res == null ? new PdfDictionary() : Carry(o, src, res));
            if (p.Dict.Has("Group")) fd.Set("Group", Carry(o, src, p.Dict.Get("Group")));
            fd.Set("Filter", new PdfName("FlateDecode"));
            PdfStream form = new PdfStream(fd, PdfaFontFixer.Deflate(inner));

            PdfDictionary xo = new PdfDictionary();
            xo.Set("Fm1", form);
            PdfDictionary pres = new PdfDictionary();
            pres.Set("XObject", xo);
            PdfDictionary page = new PdfDictionary();
            page.Set("Type", new PdfName("Page"));
            page.Set("MediaBox", Nums(new double[] { 0, 0, W, H }));
            page.Set("Resources", pres);
            string cm = string.Join(" ", new[] { N(m[0]), N(m[1]), N(m[2]), N(m[3]), N(m[4]), N(m[5]) });
            page.Set("Contents", new PdfStream(new PdfDictionary(), Encoding.ASCII.GetBytes("q " + cm + " cm /Fm1 Do Q\n")));
            if (p.Dict.Has("Group")) page.Set("Group", Carry(o, src, p.Dict.Get("Group")));
            foreach (string k in new[] { "Tabs", "Dur", "Trans", "UserUnit" }) if (p.Dict.Has(k)) page.Set(k, Carry(o, src, p.Dict.Get(k)));

            PdfObject annotsObj = src != null ? src.Resolve(p.Dict.Get("Annots")) : p.Dict.Get("Annots");
            PdfArray annots = annotsObj as PdfArray;
            if (annots != null && annots.Count > 0)
            {
                // An annotation's /P names the old page; mapped ahead, it lands on the new one
                // instead of dragging the old page (and through /Parent, the whole old tree) along.
                if (src != null) o.PreMap(src, p.SourceNumber, pageNum);
                PdfArray moved = new PdfArray();
                foreach (PdfObject a in annots.Items)
                {
                    PdfObject imported = Carry(o, src, a);
                    PdfDictionary ad = imported as PdfDictionary;
                    PdfRef ar = imported as PdfRef;
                    if (ar != null) ad = o.GetObject(ar.Number) as PdfDictionary;
                    if (ad == null) continue;
                    Transform(o, ad, "Rect", m, true);
                    Transform(o, ad, "QuadPoints", m, false);
                    if (ad.Has("P")) ad.Set("P", new PdfRef(pageNum, 0));
                    moved.Items.Add(imported);
                }
                page.Set("Annots", moved);
            }
            return page;
        }

        private static PdfObject Carry(PdfOutput o, PdfFile src, PdfObject x)
        {
            return src != null ? o.Import(src, x) : o.CopyDirect(x);
        }

        private static void Transform(PdfOutput o, PdfDictionary d, string key, double[] m, bool asBox)
        {
            PdfObject v = d.Get(key);
            PdfRef r = v as PdfRef;
            if (r != null) v = o.GetObject(r.Number);
            PdfArray a = v as PdfArray;
            if (a == null || a.Count < 4 || a.Count % 2 != 0) return;
            double[] pts = new double[a.Count];
            for (int i = 0; i < a.Count; i++)
            {
                PdfObject it = a[i] is PdfRef ? o.GetObject(((PdfRef)a[i]).Number) : a[i];
                PdfNumber n = it as PdfNumber;
                if (n == null) return;
                pts[i] = n.Value;
            }
            if (asBox)
            {
                double x0 = Math.Min(pts[0], pts[2]), y0 = Math.Min(pts[1], pts[3]), x1 = Math.Max(pts[0], pts[2]), y1 = Math.Max(pts[1], pts[3]);
                double[] xs = new double[4], ys = new double[4];
                Apply(m, x0, y0, out xs[0], out ys[0]); Apply(m, x1, y0, out xs[1], out ys[1]);
                Apply(m, x0, y1, out xs[2], out ys[2]); Apply(m, x1, y1, out xs[3], out ys[3]);
                pts = new double[] { Min(xs), Min(ys), Max(xs), Max(ys) };
            }
            else
                for (int i = 0; i + 1 < pts.Length; i += 2)
                {
                    double x, y;
                    Apply(m, pts[i], pts[i + 1], out x, out y);
                    pts[i] = x; pts[i + 1] = y;
                }
            d.Set(key, Nums(pts));
        }

        private static double Min(double[] v) { double r = v[0]; foreach (double x in v) r = Math.Min(r, x); return r; }
        private static double Max(double[] v) { double r = v[0]; foreach (double x in v) r = Math.Max(r, x); return r; }

        private static void Apply(double[] m, double x, double y, out double ox, out double oy)
        {
            ox = m[0] * x + m[2] * y + m[4];
            oy = m[1] * x + m[3] * y + m[5];
        }

        private static double[] Mul(double[] a, double[] b)
        {
            return new double[]
            {
                a[0] * b[0] + a[1] * b[2], a[0] * b[1] + a[1] * b[3],
                a[2] * b[0] + a[3] * b[2], a[2] * b[1] + a[3] * b[3],
                a[4] * b[0] + a[5] * b[2] + b[4], a[4] * b[1] + a[5] * b[3] + b[5]
            };
        }

        private static PdfArray Nums(double[] v)
        {
            PdfArray a = new PdfArray();
            foreach (double x in v) a.Items.Add(new PdfNumber(Math.Round(x, 4), false));
            return a;
        }

        private static string N(double v) { return PdfSerializer.Number(Math.Round(v, 6), false); }
    }
}
