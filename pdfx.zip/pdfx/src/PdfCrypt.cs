using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace Pdfx.Internal
{
    public static class Rc4
    {
        public static byte[] Apply(byte[] key, byte[] data)
        {
            byte[] s = new byte[256];
            for (int i = 0; i < 256; i++) s[i] = (byte)i;

            int j = 0;
            for (int i = 0; i < 256; i++)
            {
                j = (j + s[i] + key[i % key.Length]) & 0xFF;
                byte t = s[i]; s[i] = s[j]; s[j] = t;
            }

            byte[] outp = new byte[data.Length];
            int a = 0, b = 0;
            for (int k = 0; k < data.Length; k++)
            {
                a = (a + 1) & 0xFF;
                b = (b + s[a]) & 0xFF;
                byte t = s[a]; s[a] = s[b]; s[b] = t;
                outp[k] = (byte)(data[k] ^ s[(s[a] + s[b]) & 0xFF]);
            }
            return outp;
        }
    }

    public static class AesCbc
    {
        public static byte[] Decrypt(byte[] key, byte[] iv, byte[] data, bool stripPadding)
        {
            if (data.Length == 0) return new byte[0];
            int usable = data.Length - (data.Length % 16);
            if (usable == 0) return new byte[0];

            using (Aes aes = Aes.Create())
            {
                aes.KeySize = key.Length * 8;
                aes.BlockSize = 128;
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.None;
                aes.Key = key;
                aes.IV = iv;
                using (ICryptoTransform t = aes.CreateDecryptor())
                {
                    byte[] plain = t.TransformFinalBlock(data, 0, usable);
                    if (!stripPadding || plain.Length == 0) return plain;
                    int pad = plain[plain.Length - 1];
                    if (pad < 1 || pad > 16 || pad > plain.Length) return plain;
                    byte[] r = new byte[plain.Length - pad];
                    Buffer.BlockCopy(plain, 0, r, 0, r.Length);
                    return r;
                }
            }
        }

        public static byte[] Encrypt(byte[] key, byte[] iv, byte[] data)
        {
            using (Aes aes = Aes.Create())
            {
                aes.KeySize = key.Length * 8;
                aes.BlockSize = 128;
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.None;
                aes.Key = key;
                aes.IV = iv;
                using (ICryptoTransform t = aes.CreateEncryptor())
                    return t.TransformFinalBlock(data, 0, data.Length);
            }
        }
    }

    public sealed class PdfStandardSecurity : IPdfDecryptor
    {
        internal static readonly byte[] Pad =
        {
            0x28,0xBF,0x4E,0x5E,0x4E,0x75,0x8A,0x41,0x64,0x00,0x4E,0x56,
            0xFF,0xFA,0x01,0x08,0x2E,0x2E,0x00,0xB6,0xD0,0x68,0x3E,0x80,
            0x2F,0x0C,0xA9,0xFE,0x64,0x53,0x69,0x7A
        };

        private byte[] _key;
        private bool _aes;
        private bool _identityStrings;
        private bool _identityStreams;
        private int _revision;

        public bool UsedOwnerPassword { get; private set; }

        public static PdfStandardSecurity Create(PdfFile file, string password, out string reason)
        {
            reason = null;
            PdfDictionary enc = file.Resolve(file.Trailer.Get("Encrypt")) as PdfDictionary;
            if (enc == null) { reason = "no /Encrypt dictionary"; return null; }

            PdfName filter = file.Resolve(enc.Get("Filter")) as PdfName;
            if (filter == null || filter.Value != "Standard")
            {
                reason = "unsupported security handler /" + (filter == null ? "?" : filter.Value)
                       + "; only the standard handler is supported";
                return null;
            }

            int v = Int(file, enc, "V", 0);
            int r = Int(file, enc, "R", v < 2 ? 2 : 3);
            int lengthBits = Int(file, enc, "Length", 40);
            byte[] o = Str(file, enc, "O");
            byte[] u = Str(file, enc, "U");
            byte[] ue = Str(file, enc, "UE");
            byte[] oe = Str(file, enc, "OE");
            int p = Int(file, enc, "P", -1);
            bool encryptMetadata = Bool(file, enc, "EncryptMetadata", true);

            if (o == null || u == null) { reason = "/Encrypt is missing /O or /U"; return null; }

            PdfStandardSecurity s = new PdfStandardSecurity();
            s._revision = r;

            if (v == 4 || v == 5)
            {
                string stmf = NameOf(file, enc, "StmF", "Identity");
                string strf = NameOf(file, enc, "StrF", "Identity");
                s._identityStreams = stmf == "Identity";
                s._identityStrings = strf == "Identity";

                PdfDictionary cf = file.Resolve(enc.Get("CF")) as PdfDictionary;
                string method = "V2";
                string want = stmf != "Identity" ? stmf : strf;
                if (cf != null && want != "Identity")
                {
                    PdfDictionary f = file.Resolve(cf.Get(want)) as PdfDictionary;
                    if (f != null)
                    {
                        PdfName cfm = file.Resolve(f.Get("CFM")) as PdfName;
                        if (cfm != null) method = cfm.Value;
                        int cfl = Int(file, f, "Length", 0);
                        if (cfl > 0) lengthBits = cfl <= 40 ? cfl * 8 : cfl;
                    }
                }
                s._aes = method == "AESV2" || method == "AESV3";
                if (method == "None") { s._identityStreams = true; s._identityStrings = true; }
            }

            byte[] id0 = FirstId(file);

            if (v == 5 || r >= 5)
            {
                s._aes = true;
                byte[] key = DeriveV5(password, u, ue, o, oe, r, out reason);
                if (key == null) return null;
                s._key = key;
                return s;
            }

            int lengthBytes = Math.Max(5, Math.Min(16, lengthBits / 8));
            if (v == 1) lengthBytes = 5;

            byte[] userKey = ComputeKey(password, o, p, id0, r, lengthBytes, encryptMetadata);
            if (CheckUser(userKey, u, id0, r))
            {
                s._key = userKey;
                return s;
            }

            byte[] recovered = RecoverUserPassword(password, o, r, lengthBytes);
            if (recovered != null)
            {
                byte[] k2 = ComputeKeyRaw(recovered, o, p, id0, r, lengthBytes, encryptMetadata);
                if (CheckUser(k2, u, id0, r))
                {
                    s._key = k2;
                    s.UsedOwnerPassword = true;
                    return s;
                }
            }

            reason = password.Length == 0
                ? "the document needs a password"
                : "the supplied password is not correct";
            return null;
        }

        private static byte[] DeriveV5(string password, byte[] u, byte[] ue, byte[] o, byte[] oe,
                                       int r, out string reason)
        {
            reason = null;
            if (u.Length < 48) { reason = "/U is too short for a version 5 document"; return null; }

            byte[] pw = Encoding.UTF8.GetBytes(password ?? string.Empty);
            if (pw.Length > 127) { byte[] t = new byte[127]; Buffer.BlockCopy(pw, 0, t, 0, 127); pw = t; }

            byte[] vSalt = Slice(u, 32, 8);
            byte[] kSalt = Slice(u, 40, 8);

            byte[] check = r == 5 ? Sha256(Concat(pw, vSalt)) : Hash2B(pw, vSalt, new byte[0]);
            if (Same(check, Slice(u, 0, 32)))
            {
                byte[] inter = r == 5 ? Sha256(Concat(pw, kSalt)) : Hash2B(pw, kSalt, new byte[0]);
                if (ue == null || ue.Length < 32) { reason = "/UE is missing"; return null; }
                return AesCbc.Decrypt(inter, new byte[16], Slice(ue, 0, 32), false);
            }

            if (o != null && o.Length >= 48 && oe != null && oe.Length >= 32)
            {
                byte[] u48 = Slice(u, 0, 48);
                byte[] ovSalt = Slice(o, 32, 8);
                byte[] okSalt = Slice(o, 40, 8);
                byte[] ocheck = r == 5 ? Sha256(Concat(pw, ovSalt, u48)) : Hash2B(pw, ovSalt, u48);
                if (Same(ocheck, Slice(o, 0, 32)))
                {
                    byte[] inter = r == 5 ? Sha256(Concat(pw, okSalt, u48)) : Hash2B(pw, okSalt, u48);
                    return AesCbc.Decrypt(inter, new byte[16], Slice(oe, 0, 32), false);
                }
            }

            reason = (password ?? string.Empty).Length == 0
                ? "the document needs a password"
                : "the supplied password is not correct";
            return null;
        }

        internal static byte[] Hash2B(byte[] pw, byte[] salt, byte[] udata)
        {
            byte[] k = Sha256(Concat(pw, salt, udata));
            int i = 0;
            while (true)
            {
                byte[] one = Concat(pw, k, udata);
                byte[] k1 = new byte[one.Length * 64];
                for (int c = 0; c < 64; c++) Buffer.BlockCopy(one, 0, k1, c * one.Length, one.Length);

                byte[] e = AesCbc.Encrypt(Slice(k, 0, 16), Slice(k, 16, 16), k1);

                int mod = 0;
                for (int c = 0; c < 16; c++) mod += e[c];
                mod %= 3;

                if (mod == 0) k = Sha256(e);
                else if (mod == 1) k = Hash(new SHA384CryptoServiceProvider(), e);
                else k = Hash(new SHA512CryptoServiceProvider(), e);

                i++;
                if (i >= 64 && (e[e.Length - 1] & 0xFF) <= i - 32) break;
            }
            return Slice(k, 0, 32);
        }

        private static byte[] ComputeKey(string password, byte[] o, int p, byte[] id0,
                                         int r, int lengthBytes, bool encryptMetadata)
        {
            return ComputeKeyRaw(PadPassword(password), o, p, id0, r, lengthBytes, encryptMetadata);
        }

        internal static byte[] ComputeKeyRaw(byte[] padded, byte[] o, int p, byte[] id0,
                                            int r, int lengthBytes, bool encryptMetadata)
        {
            MemoryStream ms = new MemoryStream();
            ms.Write(padded, 0, padded.Length);
            ms.Write(o, 0, Math.Min(32, o.Length));
            ms.WriteByte((byte)(p & 0xFF));
            ms.WriteByte((byte)((p >> 8) & 0xFF));
            ms.WriteByte((byte)((p >> 16) & 0xFF));
            ms.WriteByte((byte)((p >> 24) & 0xFF));
            if (id0 != null) ms.Write(id0, 0, id0.Length);
            if (r >= 4 && !encryptMetadata) ms.Write(new byte[] { 0xFF, 0xFF, 0xFF, 0xFF }, 0, 4);

            byte[] digest = Md5(ms.ToArray());
            if (r >= 3)
                for (int i = 0; i < 50; i++) digest = Md5(Slice(digest, 0, lengthBytes));

            return Slice(digest, 0, lengthBytes);
        }

        private static bool CheckUser(byte[] key, byte[] u, byte[] id0, int r)
        {
            if (r == 2) return Same(Rc4.Apply(key, Pad), Slice(u, 0, Math.Min(32, u.Length)));

            byte[] x = Md5(Concat(Pad, id0 ?? new byte[0]));
            byte[] test = Rc4.Apply(key, x);
            for (int i = 1; i <= 19; i++)
            {
                byte[] k = new byte[key.Length];
                for (int j = 0; j < key.Length; j++) k[j] = (byte)(key[j] ^ i);
                test = Rc4.Apply(k, test);
            }
            return u.Length >= 16 && Same(Slice(test, 0, 16), Slice(u, 0, 16));
        }

        private static byte[] RecoverUserPassword(string ownerPassword, byte[] o, int r, int lengthBytes)
        {
            if (o == null || o.Length < 32) return null;

            byte[] digest = Md5(PadPassword(ownerPassword));
            if (r >= 3)
                for (int i = 0; i < 50; i++) digest = Md5(digest);
            byte[] key = Slice(digest, 0, r == 2 ? 5 : lengthBytes);

            byte[] userPad = Slice(o, 0, 32);
            if (r == 2) return Rc4.Apply(key, userPad);

            for (int i = 19; i >= 0; i--)
            {
                byte[] k = new byte[key.Length];
                for (int j = 0; j < key.Length; j++) k[j] = (byte)(key[j] ^ i);
                userPad = Rc4.Apply(k, userPad);
            }
            return userPad;
        }

        private byte[] ObjectKey(int num, int gen)
        {
            if (_revision >= 5) return _key;

            MemoryStream ms = new MemoryStream();
            ms.Write(_key, 0, _key.Length);
            ms.WriteByte((byte)(num & 0xFF));
            ms.WriteByte((byte)((num >> 8) & 0xFF));
            ms.WriteByte((byte)((num >> 16) & 0xFF));
            ms.WriteByte((byte)(gen & 0xFF));
            ms.WriteByte((byte)((gen >> 8) & 0xFF));
            if (_aes) ms.Write(new byte[] { 0x73, 0x41, 0x6C, 0x54 }, 0, 4);

            byte[] digest = Md5(ms.ToArray());
            return Slice(digest, 0, Math.Min(_key.Length + 5, 16));
        }

        private byte[] Apply(byte[] data, int num, int gen, bool identity)
        {
            if (data == null || data.Length == 0) return data;
            if (identity) return data;

            byte[] key = ObjectKey(num, gen);
            if (!_aes) return Rc4.Apply(key, data);
            if (data.Length <= 16) return new byte[0];

            byte[] iv = Slice(data, 0, 16);
            byte[] body = Slice(data, 16, data.Length - 16);
            return AesCbc.Decrypt(key, iv, body, true);
        }

        public byte[] DecryptString(byte[] data, int objNumber, int generation)
        {
            return Apply(data, objNumber, generation, _identityStrings);
        }

        public byte[] DecryptStream(byte[] data, int objNumber, int generation)
        {
            return Apply(data, objNumber, generation, _identityStreams);
        }

        internal static byte[] PadPassword(string password)
        {
            byte[] pw = password == null ? new byte[0] : Latin1(password);
            byte[] r = new byte[32];
            int n = Math.Min(32, pw.Length);
            Buffer.BlockCopy(pw, 0, r, 0, n);
            Buffer.BlockCopy(Pad, 0, r, n, 32 - n);
            return r;
        }

        private static byte[] Latin1(string s)
        {
            byte[] b = new byte[s.Length];
            for (int i = 0; i < s.Length; i++) b[i] = (byte)s[i];
            return b;
        }

        private static byte[] FirstId(PdfFile f)
        {
            PdfArray id = f.Resolve(f.Trailer.Get("ID")) as PdfArray;
            if (id == null || id.Count == 0) return new byte[0];
            PdfString s = f.Resolve(id[0]) as PdfString;
            return s == null ? new byte[0] : s.Bytes;
        }

        private static int Int(PdfFile f, PdfDictionary d, string key, int fallback)
        {
            PdfNumber n = f.Resolve(d.Get(key)) as PdfNumber;
            return n == null ? fallback : n.AsInt;
        }

        private static bool Bool(PdfFile f, PdfDictionary d, string key, bool fallback)
        {
            PdfBool b = f.Resolve(d.Get(key)) as PdfBool;
            return b == null ? fallback : b.Value;
        }

        private static string NameOf(PdfFile f, PdfDictionary d, string key, string fallback)
        {
            PdfName n = f.Resolve(d.Get(key)) as PdfName;
            return n == null ? fallback : n.Value;
        }

        private static byte[] Str(PdfFile f, PdfDictionary d, string key)
        {
            PdfString s = f.Resolve(d.Get(key)) as PdfString;
            return s == null ? null : s.Bytes;
        }

        // MD5 is computed here rather than by MD5.Create(): under the Windows FIPS policy the
        // framework refuses MD5 outright, and PDF's standard security handler (revisions 2-4)
        // cannot open a file without it. It is key derivation mandated by the format, not a
        // security decision of ours. The SHA-2 family goes to the FIPS-validated CSP classes
        // (SHA256.Create() returns SHA256Managed on .NET Framework, which FIPS also refuses).
        internal static byte[] Md5(byte[] data)
        {
            return Md5Hash.Compute(data);
        }

        private static byte[] Sha256(byte[] data)
        {
            using (SHA256CryptoServiceProvider h = new SHA256CryptoServiceProvider()) return h.ComputeHash(data);
        }

        private static byte[] Hash(HashAlgorithm h, byte[] data)
        {
            using (h) return h.ComputeHash(data);
        }

        private static byte[] Slice(byte[] src, int from, int count)
        {
            if (src == null) return new byte[0];
            if (from >= src.Length) return new byte[0];
            int n = Math.Min(count, src.Length - from);
            byte[] r = new byte[n];
            Buffer.BlockCopy(src, from, r, 0, n);
            return r;
        }

        private static byte[] Concat(params byte[][] parts)
        {
            int n = 0;
            for (int i = 0; i < parts.Length; i++) n += parts[i].Length;
            byte[] r = new byte[n];
            int p = 0;
            for (int i = 0; i < parts.Length; i++)
            {
                Buffer.BlockCopy(parts[i], 0, r, p, parts[i].Length);
                p += parts[i].Length;
            }
            return r;
        }

        private static bool Same(byte[] a, byte[] b)
        {
            if (a == null || b == null || a.Length != b.Length) return false;
            for (int i = 0; i < a.Length; i++) if (a[i] != b[i]) return false;
            return true;
        }
    }
}
