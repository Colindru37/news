// bpshapes: every XML SHAPE a release (or a single export) uses, as a short text report, and what gumball itself
// makes of that file. Structure and counts only: element names, attribute NAMES, the values of Blue Prism's own closed
// vocabularies (stage types, data types, action ids ...). Never a name, an expression, a value, a path or a GUID,
// so the report can leave the machine as a photo.   node gumball.js shapes <release.bprelease | export.xml>
'use strict';
const D = require('./bpdraw.js'), E = require('./bpedit.js');

const KNOWN = 'Start End Action Decision Calculation MultipleCalculation SubSheet Code Data Collection Exception Recover Resume Anchor LoopStart LoopEnd Note Block ChoiceStart ChoiceEnd WaitStart WaitEnd Navigate Read Write ProcessInfo SubSheetInfo Alert Process Skill'.split(' ');
const DATATYPES = 'text number flag date datetime time timespan password collection binary image unknown'.split(' ');
const local = n => n.replace(/^.*:/, '');

// ---------- a small XML reader: elements, attributes, text; enough for an export, no entities resolved ----------
function parse(text) {
  const root = { name: '#root', attrs: {}, kids: [], text: '' }, stack = [root];
  const re = /<!--[\s\S]*?-->|<!\[CDATA\[([\s\S]*?)\]\]>|<\?[\s\S]*?\?>|<!DOCTYPE[^>]*>|<\/([\w:.-]+)\s*>|<([\w:.-]+)((?:\s+[\w:.-]+\s*=\s*(?:"[^"]*"|'[^']*'))*)\s*(\/?)>/g;
  let m, last = 0, bad = 0;
  while ((m = re.exec(text))) {
    const top = stack[stack.length - 1];
    if (m.index > last) top.text += text.slice(last, m.index);
    last = re.lastIndex;
    if (m[1] !== undefined) { top.text += m[1]; top.cdata = true; continue; }
    if (m[2]) { if (stack.length > 1 && stack[stack.length - 1].name === m[2]) stack.pop(); else { const i = stack.map(s => s.name).lastIndexOf(m[2]); if (i > 0) stack.length = i; else bad++; } continue; }
    if (!m[3]) continue;
    const el = { name: m[3], attrs: {}, kids: [], text: '', self: !!m[5] };
    const ra = /([\w:.-]+)\s*=\s*(?:"([^"]*)"|'([^']*)')/g; let a;
    while ((a = ra.exec(m[4]))) el.attrs[a[1]] = a[2] !== undefined ? a[2] : a[3];
    top.kids.push(el); if (!m[5]) stack.push(el);
  }
  root.unclosed = stack.length - 1; root.bad = bad;
  return root;
}
const kid = (el, n) => el.kids.find(k => local(k.name) === n);
const kids = (el, n) => el.kids.filter(k => local(k.name) === n);
const txt = el => (el ? el.text.trim() : '');
function walk(el, fn, depth) { fn(el, depth || 0); for (const k of el.kids) walk(k, fn, (depth || 0) + 1); }
function all(el, n, out) { out = out || []; for (const k of el.kids) { if (local(k.name) === n) out.push(k); all(k, n, out); } return out; }

// ---------- counting ----------
class Tally { constructor() { this.m = new Map(); } add(k, n) { this.m.set(k, (this.m.get(k) || 0) + (n == null ? 1 : n)); } get size() { return this.m.size; }
  list() { return [...this.m.entries()].sort((a, b) => b[1] - a[1] || String(a[0]).localeCompare(String(b[0]))); }
  text(sep) { return this.list().map(e => e[0] + ' x' + e[1]).join(sep || ', ') || '(none)'; } }
// a value is printed only when it looks like one of Blue Prism's own identifiers; anything else is counted as "other"
const ident = v => /^[A-Za-z][A-Za-z0-9_.]{0,40}$/.test(v);
const safe = (v, re) => ((re || { test: ident }).test(v) ? v : '(other)');

function report(text, opts) {
  opts = opts || {};
  const out = [], W = 150;
  const say = s => { s = String(s); if (s.length <= W) { out.push(s); return; }
    let rest = s, first = true; while (rest.length) { const lim = first ? W : W - 4; let cut = rest.length <= lim ? rest.length : rest.lastIndexOf(' ', lim); if (cut <= 0) cut = lim;
      out.push((first ? '' : '    ') + rest.slice(0, cut)); rest = rest.slice(cut).replace(/^ /, ''); first = false; } };
  const head = (n, t) => say('== ' + n + '. ' + t);
  let root; try { root = parse(text); } catch (e) { return 'could not read the file: ' + e.name + '\n'; }

  // the members: every <process> element that holds stages itself
  const procs = []; walk(root, el => { if (local(el.name) === 'process' && el.kids.some(k => local(k.name) === 'stage')) procs.push(el); });
  const stages = []; for (const p of procs) for (const s of kids(p, 'stage')) stages.push(s);
  const nObj = procs.filter(p => p.attrs.type === 'object').length;

  // ---- 1
  head(1, 'Release contents');
  const cont = all(root, 'contents')[0];
  if (cont) { const t = new Map(); for (const k of cont.kids) { const n = local(k.name), e = t.get(n) || { n: 0, a: new Set() }; e.n++; Object.keys(k.attrs).forEach(a => e.a.add(a)); t.set(n, e); }
    say([...t.entries()].map(e => e[0] + ' x' + e[1].n + ' [' + [...e[1].a].join(',') + ']').join(' | ')); }
  else say('not a release: a single export');
  say(procs.length + ' members with stages: ' + (procs.length - nObj) + ' processes, ' + nObj + ' objects; ' + stages.length + ' stages; XML left unclosed: ' + root.unclosed + ', stray closing tags: ' + root.bad);

  // ---- 2
  head(2, 'Stage tags (attribute names on <stage>)');
  const byType = new Map();
  for (const s of stages) { const t = s.attrs.type || '(no type)'; if (!byType.has(t)) byType.set(t, []); byType.get(t).push(s); }
  const types = [...byType.keys()].sort((a, b) => byType.get(b).length - byType.get(a).length);
  for (const t of types) { const sets = new Tally(); for (const s of byType.get(t)) sets.add('[' + Object.keys(s.attrs).join(',') + ']');
    say((KNOWN.indexOf(t) < 0 ? 'NEW ' : '') + safe(t) + ' ' + byType.get(t).length + ': ' + sets.list().map(e => e[0] + ' ' + e[1]).join(' | ')); }

  // ---- 3
  head(3, 'Shapes per stage type (path [attribute names] = stages that have it)');
  const COMMON = /^(display|displayx|displayy|displaywidth|displayheight|font|narrative|subsheetid)$/;   // in nearly every stage: left out of the lists, section 8 counts the display form
  say('(left out of every list: display / displayx.., font, narrative, subsheetid)');
  const EMPTYABLE = ['narrative', 'initialvalue', 'loopdata', 'inputs', 'outputs', 'choices', 'steps', 'code', 'note'];
  for (const t of types) {
    const paths = new Tally(), empty = new Tally(); let preserve = 0;
    for (const s of byType.get(t)) { const seen = new Set(); let pres = false;
      const rec = (el, path, d) => { for (const k of el.kids) { const n = local(k.name), an = Object.keys(k.attrs); if (an.some(a => a === 'xml:space')) pres = true;
        const p = (path ? path + '/' : '') + n + (an.length ? '[' + an.join(',') + ']' : ''); if (!(d === 1 && COMMON.test(n))) seen.add(p);
        if (d === 1 && k.self && EMPTYABLE.indexOf(n) >= 0) seen.add('~' + n);
        if (d < 5) rec(k, p, d + 1); } };
      rec(s, '', 1);
      for (const p of seen) { if (p[0] === '~') empty.add(p.slice(1)); else paths.add(p); } if (pres) preserve++; }
    const cap = /^(Data|Collection)$/.test(t) ? 40 : 70, list = paths.list();
    say(safe(t) + ' (' + byType.get(t).length + '): ' + list.slice(0, cap).map(e => e[0] + ' ' + e[1]).join('; ') + (list.length > cap ? '; +' + (list.length - cap) + ' more paths cut' : ''));
    if (empty.size || preserve) say('    self-closing: ' + empty.text() + (preserve ? '; xml:space on a child: ' + preserve : ''));
  }

  // ---- 4
  head(4, 'Closed vocabularies (value x count)');
  const V = {}; const T = k => (V[k] = V[k] || new Tally());
  const argIds = new Map(), funcs = new Tally(), internal = new Tally(), others = new Set(); let otherCalls = 0, replyOther = 0;
  const scanExpr = v => { if (!v) return; const bare = String(v).replace(/&quot;[\s\S]*?&quot;/g, '""').replace(/"[^"]*"/g, '""'); const rf = /([A-Za-z_][A-Za-z0-9_]*)\s*\(/g; let f; while ((f = rf.exec(bare))) funcs.add(f[1]); };
  const INTERNAL = ['work queues', 'credentials', 'environment locking', 'calendars', 'collections', 'encryption', 'data gateways', 'windows credentials', 'radio buttons'];
  for (const s of stages) { const t = s.attrs.type;
    walk(s, (el) => { const n = local(el.name);
      if (n === 'datatype') T('a. datatype').add(safe(txt(el)));
      if ((n === 'input' || n === 'output' || n === 'field') && el.attrs.type) T('a. type= on input/output/field').add(safe(el.attrs.type));
      if (n === 'exposure') T('b. exposure').add(safe(txt(el)));
      if (n === 'looptype') T('c. looptype').add(safe(txt(el)));
      if (n === 'comparetype' || n === 'comparisontype') T('d. ' + n).add(safe(txt(el)));
      if (n === 'exception' && el.attrs.type !== undefined) T('e. exception type').add(/^(System|Business|Runtime|Internal|Validation) Exception$/.test(el.attrs.type) ? el.attrs.type : el.attrs.type === '' ? '(empty)' : '(other)');
      if (n === 'exception') T('e. exception attribute names').add('[' + Object.keys(el.attrs).join(',') + ']');
      if (n === 'action' && kid(el, 'id')) { const id = safe(txt(kid(el, 'id'))); T('f. action ids in ' + t).add(id);
        for (const a of all(el, 'argument')) { const ai = kid(a, 'id'); const k = id; if (!argIds.has(k)) argIds.set(k, new Tally()); argIds.get(k).add(ai ? safe(txt(ai)) : '[' + Object.keys(a.attrs).join(',') + ']'); } }
      if (n === 'condition' && kid(el, 'id')) T('h. wait condition ids').add(safe(txt(kid(el, 'id'))));
      if (n === 'choice' && el.attrs.reply !== undefined) { if (/^(True|False)$/i.test(el.attrs.reply)) T('i. choice reply').add(el.attrs.reply); else replyOther++; }
      if (n === 'loginhibit') T('k. loginhibit').add(Object.keys(el.attrs).length ? '[' + Object.keys(el.attrs).map(a => a + (/^(true|false)$/i.test(el.attrs[a]) ? '=' + el.attrs[a] : '')).join(',') + ']' : '<loginhibit />');
      if (n === 'language') T('l. code language').add(safe(txt(el)));
      if (n === 'reference') T('l. referenced dlls').add(safe(txt(el).replace(/^.*[\\/]/, ''), /^[A-Za-z0-9_.\-]{1,80}$/));
      if (n === 'import') T('l. namespaces').add(safe(txt(el)));
      for (const a of ['expr', 'expression']) if (el.attrs[a]) scanExpr(el.attrs[a]);
      if (n === 'timeout' || n === 'expression') scanExpr(txt(el));
      if (n === 'exception' && el.attrs.detail) scanExpr(el.attrs.detail);
      if (n === 'resource' && el.attrs.object !== undefined) { const o = el.attrs.object, act = el.attrs.action || '';
        if (/^blueprism\./i.test(o) || INTERNAL.indexOf(o.toLowerCase()) >= 0) internal.add(safe(o, /^[A-Za-z0-9_. ]{1,90}$/) + ' / ' + safe(act, /^[A-Za-z0-9_ ]{1,60}$/)); else { others.add(o); otherCalls++; } }
    });
    if (!kid(s, 'loginhibit') && !/^(Data|Collection|Note|Block|SubSheetInfo|ProcessInfo)$/.test(t)) T('k. loginhibit').add('(absent)');
  }
  for (const p of procs) { for (const ss of kids(p, 'subsheet')) T('j. subsheet type/published').add(safe(ss.attrs.type || '-') + '/' + safe(ss.attrs.published || '-'));
    T('m. <process> attribute names').add('[' + Object.keys(p.attrs).join(',') + ']'); T('m. bpversion').add(safe(p.attrs.bpversion || '(none)', /^[0-9.]{1,20}$/)); T('m. byrefcollection').add(safe(p.attrs.byrefcollection || '(none)')); }
  for (const k of Object.keys(V).sort()) say(k + ': ' + V[k].text());
  if (replyOther) say('i. choice reply other than True/False: ' + replyOther);
  say('g. argument ids per action: ' + ([...argIds.entries()].map(e => e[0] + '(' + e[1].list().map(x => x[0]).join(',') + ')').join(' ') || '(none)'));
  const badDt = V['a. datatype'] ? V['a. datatype'].list().filter(e => DATATYPES.indexOf(e[0]) < 0).map(e => e[0]) : [];
  if (badDt.length) say('data types gumball does not list: ' + badDt.join(', '));

  // ---- 5
  head(5, 'Functions used in expressions');
  say(funcs.text());

  // ---- 6
  head(6, 'Internal object calls');
  say(internal.text('; '));
  say('all other objects: ' + others.size + ' distinct, ' + otherCalls + ' calls');

  // ---- 7
  head(7, 'Application model');
  const A = {}; const TA = k => (A[k] = A[k] || new Tally()); let elN = 0, elBare = 0; const appParams = new Map();
  for (const p of procs) for (const ad of kids(p, 'appdef')) walk(ad, el => { const n = local(el.name);
    if (n === 'element') { elN++; if (!all(el, 'attribute').length && !kids(el, 'element').length) elBare++; for (const k of ['type', 'basetype', 'datatype']) if (kid(el, k)) TA('element ' + k).add(safe(txt(kid(el, k)))); TA('element attribute names').add('[' + Object.keys(el.attrs).join(',') + ']'); }
    if (n === 'attribute') { TA('attribute names').add(safe(el.attrs.name || '', /^[A-Za-z0-9_ ]{1,40}$/)); TA('attribute tag attributes').add('[' + Object.keys(el.attrs).join(',') + ']'); const ct = kid(el, 'comparisontype'); if (ct) TA('attribute comparisontype').add(safe(txt(ct))); }
    if (n === 'ProcessValue') { TA('ProcessValue datatype').add(safe(el.attrs.datatype || '-')); TA('ProcessValue attribute names').add('[' + Object.keys(el.attrs).join(',') + ']'); }
    if (n === 'apptypeinfo') { const id = safe(txt(kid(el, 'id'))); TA('apptypeinfo id').add(id); if (!appParams.has(id)) appParams.set(id, new Set()); for (const pr of all(el, 'parameter')) appParams.get(id).add(safe(txt(kid(pr, 'name')), /^[A-Za-z0-9_ ]{1,40}$/)); }
  });
  say('elements: ' + elN + ', with no attributes and no children: ' + elBare);
  for (const k of Object.keys(A)) say(k + ': ' + A[k].text());
  if (appParams.size) say('launch parameters: ' + [...appParams.entries()].map(e => e[0] + '(' + [...e[1]].join(',') + ')').join(' '));

  // ---- 8
  head(8, 'Unusual');
  let bp = 0, noDisp = 0, dAttr = 0, dEl = 0, extra = 0; const under = new Tally();
  for (const s of stages) { if (all(s, 'breakpoint').length) bp++; const a = !!kid(s, 'display'), b = !!kid(s, 'displayx'); if (a) dAttr++; if (b) dEl++; if (!a && !b) noDisp++;
    const ks = Object.keys(s.attrs); if (ks.some(k => ['stageid', 'name', 'type'].indexOf(k) < 0) || ks.slice(0, 3).join() !== 'stageid,name,type') extra++; }
  for (const p of procs) for (const k of p.kids) { const n = local(k.name); if (['stage', 'subsheet', 'appdef', 'view', 'preconditions', 'endpoint', 'name'].indexOf(n) < 0) under.add(safe(n)); }
  say('breakpoints left in: ' + bp + '; display as attributes: ' + dAttr + ', as displayx elements: ' + dEl + ', neither: ' + noDisp + '; stage tags that are not exactly stageid,name,type: ' + extra);
  say('other elements directly under <process>: ' + under.text());

  // ---- 9: what gumball itself does with every member (the check that would have caught a stage it cannot see)
  head(9, 'gumball on this file (members by number, never by name)');
  let lost = 0, notSame = 0, rowDiff = 0, rowN = 0, drawFail = 0, pagesN = 0; const lostTypes = new Tally(), notes = [], noLook = new Tally();
  const raw = text.match(/<process\b[^>]*>(?:(?!<process\b)[\s\S])*?<\/process>/g) || [];
  raw.filter(x => /<stage /.test(x)).forEach((x, i) => {
    const inFile = (x.match(/<stage\s/g) || []).length; let m;
    try { m = E.modelFrom(x); } catch (e) { notes.push('member ' + (i + 1) + ': not read (' + e.name + ')'); return; }
    if (m.stages.length !== inFile) { lost += inFile - m.stages.length; const seen = new Set(m.stages.map(s => s.id)); const rs = /<stage\s[^>]*>/g; let r; while ((r = rs.exec(x))) { const sid = (/\sstageid="([^"]*)"/.exec(r[0]) || [])[1], ty = (/\stype="([^"]*)"/.exec(r[0]) || [])[1] || '(no type)'; if (!seen.has(sid)) lostTypes.add(safe(ty)); } }
    try { if (E.serialize(m) !== x) { notSame++; notes.push('member ' + (i + 1) + ': written back differently although nothing was edited'); } } catch (e) { notes.push('member ' + (i + 1) + ': cannot be written back (' + e.name + ')'); }
    for (const st of m.stages) { const b = st.orig.body; if (KNOWN.indexOf(st.type) < 0) noLook.add(safe(st.type));
      const chk = (key, rows) => { if (!rows.length) return; rowN++; try { E.setField(st, key, rows); const nb = E.stageBody(st); if (nb.replace(/\s+/g, '') !== b.replace(/\s+/g, '')) { rowDiff++; lostTypes.add('rows:' + safe(st.type)); } } catch (e) { rowDiff++; } delete st.edits[key]; };
      if (/^(Navigate|Read|Write)$/.test(st.type)) chk('steps', E.stepsOf(b));
      if (/^(WaitStart|ChoiceStart)$/.test(st.type)) chk('choices', E.choicesOf(b));
      if (/^(Start|End)$/.test(st.type)) chk('params', E.paramsOf(b, st.type)); }
    const bpm = E.bpOf(m);
    for (const pg of E.pagesOf(m)) { pagesN++; try { const svg = D.renderPage(bpm, pg, { pages: {}, changed: new Set() }) || ''; const want = m.stages.filter(s => s.page === pg && !/^(SubSheetInfo|ProcessInfo|Block)$/.test(s.type)).length, got = (svg.match(/<g class="st"/g) || []).length; if (got < want) { drawFail++; notes.push('member ' + (i + 1) + ': a page draws ' + got + ' of ' + want + ' stages'); } }
      catch (e) { drawFail++; notes.push('member ' + (i + 1) + ': a page failed to draw (' + e.name + ')'); } }
  });
  say('stages gumball does not see: ' + lost + (lostTypes.size ? ' (' + lostTypes.text() + ')' : '') + '; members not written back byte for byte: ' + notSame + '; step/branch/parameter rows re-written: ' + rowN + ', changed by it: ' + rowDiff);
  say('pages drawn: ' + pagesN + ', with a problem: ' + drawFail + '; stage types gumball has no shape for: ' + noLook.text());
  notes.slice(0, 25).forEach(say); if (notes.length > 25) say('+' + (notes.length - 25) + ' more notes');

  // ---- self-check
  const plain = (text.match(/<stage\s/g) || []).length;
  say('== check: stages counted ' + stages.length + ', "<stage " in the file ' + plain + ' -> ' + (stages.length === plain ? 'OK' : 'MISMATCH'));
  const leak = []; out.forEach((l, i) => { if (/[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-/.test(l) || /"[^"]{41,}"/.test(l)) leak.push(i + 1); });
  say('== privacy check: ' + (leak.length ? 'LOOK AT LINES ' + leak.join(',') : 'OK (no GUID, no long quoted text)'));
  say('TOTAL LINES: ' + (out.length + 1));
  return out.join('\n') + '\n';
}

module.exports = { report, parse };
