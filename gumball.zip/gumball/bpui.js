// bpui: the browser side of gumball. Draws every page from the model, lets you move stages, draw links,
// delete, edit a stage's properties in the sheet, checks the estate rules live, and saves the next version.
// Expects globals: BW_XML (string), BW_BASE (name), BW_VER (number), BW_DIFF (json or null), BW_INCIDENT (json or null).
(function () {
'use strict';
var D = window.BPDRAW, E = window.BPEDIT;
// A draft = the page as it was last changed, kept in this browser until Save makes it a version (or Revert drops it).
// It comes back when the page is opened again, so going to another object and back loses nothing.
var DRAFT_PRE = 'gumball:draft:' + ((window.BW_SERVE && window.BW_SERVE.rel) || '') + '|', DRAFT_KEY = DRAFT_PRE + BW_BASE, dirty = false, draftKept = true, selLink = null, draggedAt = 0;
var START_XML = BW_XML;
try { var d0 = JSON.parse(localStorage.getItem(DRAFT_KEY) || 'null'); if (d0 && d0.ver === BW_VER && d0.xml && d0.xml !== BW_XML) { START_XML = d0.xml; dirty = true; } else if (d0) localStorage.removeItem(DRAFT_KEY); } catch (e) { }
var M = E.modelFrom(START_XML), mode = 'select', sel = null, linkFrom = null, scale = 1, undo = [], cur = 0;
if (dirty) { try { E.modelFrom(START_XML).stages.length; } catch (e) { M = E.modelFrom(BW_XML); dirty = false; } }
var OBJ = (typeof BW_OBJECTS !== 'undefined' && BW_OBJECTS) || [], place = null, multi = [];
if (window.BW_SERVE && window.BW_SERVE.catalog && window.BW_SERVE.catalog.length) {   // the project's objects as they are now: they replace the copy written into the page
  var liveNames = {}; window.BW_SERVE.catalog.forEach(function (o) { liveNames[String(o.object).toLowerCase()] = 1; });
  OBJ = OBJ.filter(function (o) { return !liveNames[String(o.object).toLowerCase()]; }).concat(window.BW_SERVE.catalog).sort(function (a, b) { return String(a.object).localeCompare(String(b.object)); });
}
var ov = { pages: {}, changed: new Set(BW_DIFF ? BW_DIFF.changedIds : []) };
if (BW_INCIDENT) { var o2 = D.overlayFrom(BW_INCIDENT); ov.pages = o2.pages; }
function $(id) { return document.getElementById(id); }
function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }

// ---------- pages ----------
function label(pg) { return pg === 'Main Page' && M.type === 'object' ? 'Initialise' : pg; }
function pages() { return E.pagesOf(M).sort(function (a, b) { return (a === 'Main Page' ? 0 : 1) - (b === 'Main Page' ? 0 : 1) || a.localeCompare(b); }); }
function renderAll() {
  var pg = pages(), list = '', panes = '';
  for (var i = 0; i < pg.length; i++) {
    ov.studio = !document.body.classList.contains('dark');
    var svg = D.renderPage(E.bpOf(M), pg[i], ov) || '<p>(empty page)</p>';
    list += '<li data-i="' + i + '" class="' + (i === cur ? 'on' : '') + '">' + esc(label(pg[i])) + '</li>';
    panes += '<section id="p' + i + '"' + (i === cur ? '' : ' hidden') + '><h2>' + esc(M.name) + ' / ' + esc(pg[i]) + '</h2>' + svg + '</section>';
  }
  $('pages').innerHTML = list; $('panes').innerHTML = panes; palette();
  [].forEach.call(document.querySelectorAll('#pages li'), function (li) { li.onclick = function () { cur = +li.dataset.i; multi = []; sel = null; selLink = null; closeSheet(); renderAll(); }; });
  applyScale(); rules(); if (sel) highlight(sel); markLink(); dirtyMark();
}
function renderPage() { ov.studio = !document.body.classList.contains('dark'); var pg = pages()[cur]; var sec = $('p' + cur); sec.innerHTML = '<h2>' + esc(M.name) + ' / ' + esc(label(pg)) + '</h2>' + (D.renderPage(E.bpOf(M), pg, ov) || ''); applyScale(); rules(); if (sel) highlight(sel); markLink(); }
function applyScale() { [].forEach.call(document.querySelectorAll('svg'), function (s) { s.style.transform = 'scale(' + scale + ')'; }); }
window.z = function (f) { scale = f ? Math.min(3, Math.max(0.25, scale * f)) : 1; applyScale(); };
document.addEventListener('wheel', function (e) { if (!e.ctrlKey) return; var m = e.target.closest && e.target.closest('main'); if (!m) return; e.preventDefault(); window.z(e.deltaY < 0 ? 1.1 : 0.9); }, { passive: false });
function highlight(id) { [].forEach.call(document.querySelectorAll('g.st.on,g.blk.on'), function (g) { g.classList.remove('on'); }); var ids = id ? [id] : []; ids = ids.concat(multi); ids.forEach(function (i) { [].forEach.call(document.querySelectorAll('[data-sid="' + i + '"]'), function (g) { g.classList.add('on'); }); }); }

// ---------- undo ----------
// One state = which stages exist (by reference), each stage's changeable fields (copied), and the page lists.
// Undo and redo both restore a whole state, so added/removed stages and pages come back either way.
var redo = [];
function capture() {
  return { stages: M.stages.slice(), fields: JSON.stringify(M.stages.map(function (s) { return { x: s.x, y: s.y, w: s.w, h: s.h, name: s.name, deleted: s.deleted, edits: s.edits }; })),
           pages: JSON.stringify(M.pages), added: JSON.stringify(M.addedPages || []), removed: JSON.stringify(M.removedPages || []), appdef: M.appdef == null ? null : M.appdef };
}
function restore(st) {
  var f = JSON.parse(st.fields); M.stages = st.stages.slice(); M.byId = {};
  for (var i = 0; i < M.stages.length; i++) { var s = M.stages[i], v = f[i]; s.x = v.x; s.y = v.y; s.w = v.w; s.h = v.h; s.name = v.name; s.deleted = v.deleted; s.edits = v.edits; M.byId[s.id] = s; }
  M.pages = JSON.parse(st.pages); M.addedPages = JSON.parse(st.added); M.removedPages = JSON.parse(st.removed);
  if ((st.appdef == null ? null : st.appdef) !== (M.appdef == null ? null : M.appdef)) { M.appdef = st.appdef; if (typeof moSync === 'function') moSync(); }
  if (sel && (!M.byId[sel] || M.byId[sel].deleted)) { sel = null; closeSheet(); } multi = [];
  if (cur >= pages().length) cur = 0; renderAll(); if (sel) openSheet(sel);
}
function snap() { undo.push(capture()); if (undo.length > 50) undo.shift(); redo = []; draftSoon(); }   // a new change ends the redo line
var draftT = null;
function draftSoon() { clearTimeout(draftT); draftT = setTimeout(draftNow, 250); }
function draftNow() {
  clearTimeout(draftT); var xml; try { xml = E.serialize(M); } catch (e) { return; }
  dirty = xml !== BW_XML;
  try { if (dirty) localStorage.setItem(DRAFT_KEY, JSON.stringify({ ver: BW_VER, xml: xml })); else localStorage.removeItem(DRAFT_KEY); draftKept = true; }
  catch (e) { if (draftKept) toast('this draft is too big for the browser to keep: press Save before leaving the page'); draftKept = false; }
  dirtyMark();
}
function dirtyMark() { var b = $('save'); if (b) b.classList.toggle('dirty', dirty); var r = $('revb'); if (r) r.hidden = !dirty; }
window.revertDraft = function () { if (!confirm('Drop every change since v' + BW_VER + ' was saved?')) return; clearTimeout(draftT); try { localStorage.removeItem(DRAFT_KEY); } catch (e) { } location.reload(); };
window.addEventListener('beforeunload', function () { if (draftT) draftNow(); });
window.doUndo = function () { if (!undo.length) { toast('nothing to undo'); return; } redo.push(capture()); restore(undo.pop()); draftSoon(); toast(undo.length ? 'undone (' + undo.length + ' more, Ctrl+Y redoes)' : 'undone (Ctrl+Y redoes)'); };
window.doRedo = function () { if (!redo.length) { toast('nothing to redo'); return; } undo.push(capture()); restore(redo.pop()); draftSoon(); toast(redo.length ? 'redone (' + redo.length + ' more)' : 'redone'); };

// ---------- palette: add a stage (click a kind, then click the canvas), add a page ----------
var NICE = { Action: 'Action', Decision: 'Decision', Calculation: 'Calc', MultipleCalculation: 'Multi Calc', SubSheet: 'Page call', Code: 'Code', Data: 'Data', Collection: 'Collection', Exception: 'Exception', Recover: 'Recover', Resume: 'Resume', Anchor: 'Anchor', Process: 'Process', LoopStart: 'Loop start', LoopEnd: 'Loop end', Note: 'Note', Block: 'Block', Start: 'Start', End: 'End', Navigate: 'Navigate', Read: 'Read', Write: 'Write', Alert: 'Alert', WaitStart: 'Wait', WaitEnd: 'Time out', ChoiceStart: 'Choice', ChoiceEnd: 'Otherwise' };
function palette() {
  var el = $('palette'); if (!el) return;
  var kinds = E.PALETTE.filter(function (k) { return !(M.type === 'process' && /^(Code|Navigate|Read|Write)$/.test(k)) && !(M.type !== 'process' && k === 'Process'); });   // a process has no code and no application
  el.innerHTML = kinds.map(function (k) { return '<button data-k="' + k + '" class="' + (place === k ? 'on' : '') + '">' + esc(NICE[k] || k) + '</button>'; }).join('');
  [].forEach.call(el.querySelectorAll('button'), function (b) { b.onclick = function () { startPlace(b.dataset.k); }; });
}
function startPlace(k) { place = place === k ? null : k; palette(); linkFrom = null; if (place) toast('click on the page where the ' + (NICE[place] || place) + ' goes'); document.body.classList.toggle('placing', !!place); }
function svgPoint(svg, e, raw) { var pt = svg.createSVGPoint(); pt.x = e.clientX; pt.y = e.clientY; var p = pt.matrixTransform(svg.getScreenCTM().inverse()); return raw ? { x: p.x, y: p.y } : { x: Math.round(p.x / 15) * 15, y: Math.round(p.y / 15) * 15 }; }
window.removePage = function () {
  var pg = pages()[cur]; if (pg === 'Main Page' || M.stages.some(function (s) { return !s.deleted && s.page === pg && s.type === 'ProcessInfo'; })) { toast('the main page stays'); return; }
  if (!confirm('Remove the page "' + pg + '" and everything on it?')) return;
  snap(); E.removePage(M, pg); cur = 0; multi = []; closeSheet(); renderAll(); toast('page removed - page calls to it are flagged in Checks');
};
window.toggleHelp = function () { $('help').hidden = !$('help').hidden; };
window.addPage = function (given) {
  var name = given || prompt('Name of the new page'); if (!name) return; name = name.trim(); if (!name) return;
  if (pages().indexOf(name) >= 0) { toast('there is a page called that already'); return; }
  snap(); E.addPage(M, name); cur = pages().indexOf(name); renderAll(); toast('page "' + name + '" added with Start and End');
};

// ---------- modes ----------
window.setMode = function (m) { var was = mode; mode = m; linkFrom = null; if (place) { place = null; palette(); document.body.classList.remove('placing'); } [].forEach.call(document.querySelectorAll('.tb button[data-mode]'), function (b) { b.classList.toggle('on', b.dataset.mode === m); }); if (m !== was && m !== 'select') toast({ link: 'click the stage the link leaves, then where it goes', delete: 'click a stage to remove it' }[m]); };

// ---------- mouse: drag / link / delete ----------
var drag = null;
var band = null;
function gOf(id) { return document.querySelector('section:not([hidden]) [data-sid="' + id + '"]'); }
function groupFor(st) {   // what moves with a stage: the multi selection if it is in it, a block's members, a pair's partner
  var ids = multi.indexOf(st.id) >= 0 ? multi.slice() : [st.id];
  var out = {}; ids.forEach(function (i) { out[i] = 1; var s = M.byId[i]; if (!s) return; if (s.type === 'Block') E.membersOf(M, s).forEach(function (q) { out[q.id] = 1; }); });
  return Object.keys(out);
}
document.addEventListener('mousedown', function (e) {
  if (mode !== 'select' || place || e.button !== 0) return;
  var h = e.target.closest && e.target.closest('.rsz');
  if (h) { var rs = M.byId[h.getAttribute('data-sid')]; if (rs) { drag = { resize: rs, x0: e.clientX, y0: e.clientY, moved: false, w0: rs.w, h0: rs.h }; e.preventDefault(); } return; }
  var g = e.target.closest && e.target.closest('g.st,g.blk');
  if (!g) { var svg = e.target.closest && e.target.closest('svg'); if (!svg) return; var p0 = svgPoint(svg, e, true); band = { svg: svg, x0: p0.x, y0: p0.y, el: null }; e.preventDefault(); return; }
  var st = M.byId[g.getAttribute('data-sid')]; if (!st) return;
  if (e.shiftKey) { var i = multi.indexOf(st.id); if (i >= 0) multi.splice(i, 1); else multi.push(st.id); sel = null; highlight(null); e.preventDefault(); return; }
  if (multi.indexOf(st.id) < 0) { multi = []; }
  drag = { st: st, ids: groupFor(st), x0: e.clientX, y0: e.clientY, moved: false }; e.preventDefault();
});
document.addEventListener('mousemove', function (e) {
  if (band) { var p = svgPoint(band.svg, e, true); if (!band.el) { band.el = document.createElementNS('http://www.w3.org/2000/svg', 'rect'); band.el.setAttribute('class', 'band'); band.svg.appendChild(band.el); } band.el.setAttribute('x', Math.min(p.x, band.x0)); band.el.setAttribute('y', Math.min(p.y, band.y0)); band.el.setAttribute('width', Math.abs(p.x - band.x0)); band.el.setAttribute('height', Math.abs(p.y - band.y0)); return; }
  if (!drag) return; var dx = (e.clientX - drag.x0) / scale, dy = (e.clientY - drag.y0) / scale;
  if (Math.abs(dx) + Math.abs(dy) > 2) drag.moved = true;
  if (drag.resize) { var r = gOf(drag.resize.id).querySelector('rect.shape,rect.blkr'); if (r) { r.setAttribute('width', Math.max(30, drag.w0 + dx)); r.setAttribute('height', Math.max(20, drag.h0 + dy)); } return; }
  drag.ids.forEach(function (i) { var g = gOf(i); if (g) g.setAttribute('transform', 'translate(' + dx + ',' + dy + ')'); });
});
document.addEventListener('mouseup', function (e) {
  if (band) { var b = band; band = null;
    var x = b.el ? +b.el.getAttribute('x') : 0, y = b.el ? +b.el.getAttribute('y') : 0, w = b.el ? +b.el.getAttribute('width') : 0, h = b.el ? +b.el.getAttribute('height') : 0; if (b.el) b.el.remove();
    if (w < 4 && h < 4) {   // a plain click on empty space: nothing stays selected
      if (!(e.target.closest && e.target.closest('.lnkhit'))) { selLink = null; if (multi.length || sel) { multi = []; closeSheet(); highlight(null); } markLink(); }
      return; }
    var pg = pages()[cur]; multi = M.stages.filter(function (s) { return !s.deleted && s.page === pg && s.type !== 'Block' && s.x >= x && s.x <= x + w && s.y >= y && s.y <= y + h; }).map(function (s) { return s.id; });
    sel = null; closeSheet(); highlight(null); if (multi.length) toast(multi.length + ' selected - drag them together, Del removes them'); return; }
  if (!drag) return; var d = drag; drag = null;
  var dx = (e.clientX - d.x0) / scale, dy = (e.clientY - d.y0) / scale;
  if (!d.moved) return;
  draggedAt = Date.now();
  snap();
  if (d.resize) { E.resize(d.resize, Math.max(30, Math.round((d.w0 + dx) / 15) * 15), Math.max(20, Math.round((d.h0 + dy) / 15) * 15)); renderPage(); return; }
  var snapG = document.body.classList.contains('grid') ? function (v) { return Math.round(v / 15) * 15; } : function (v) { return v; };
  d.ids.forEach(function (i) { var s = M.byId[i]; E.move(s, snapG(s.x + dx), snapG(s.y + dy)); });
  if (d.ids.length === 1) sel = d.st.id; renderPage();
});
document.addEventListener('click', function (e) {
  if (place) {
    var svg = e.target.closest && e.target.closest('svg'); if (!svg) return;
    var p = svgPoint(svg, e), k = place;
    if (k === 'Start' && M.stages.some(function (s) { return !s.deleted && s.page === pages()[cur] && s.type === 'Start'; })) { toast('this page already has a Start: Blue Prism allows exactly one'); place = null; palette(); document.body.classList.remove('placing'); setMode('select'); return; }
    snap();
    var st = E.addStage(M, k, pages()[cur], p.x, p.y);
    if (k === 'Action' && OBJ.length && OBJ[0].actions.length) E.setResource(st, OBJ[0].object, OBJ[0].actions[0].name, OBJ[0].actions[0].inputs, OBJ[0].actions[0].outputs);
    if (k === 'SubSheet') { var other = pages().filter(function (q) { return q !== pages()[cur]; })[0]; if (other) { E.rename(st, other); E.setPageCall(M, st, other); } }
    if (k === 'LoopStart') { var gid = /<groupid>([^<]*)</.exec(st.orig.body)[1]; var le = E.addStage(M, 'LoopEnd', pages()[cur], p.x, p.y + 120, { groupid: gid }); E.setLink(st, 'onsuccess', le.id); }
    if (k === 'WaitStart' || k === 'ChoiceStart') { var gid2 = /<groupid>([^<]*)</.exec(st.orig.body)[1]; E.addStage(M, k === 'WaitStart' ? 'WaitEnd' : 'ChoiceEnd', pages()[cur], p.x + 180, p.y, { groupid: gid2 }); }   // the pair: branches sit on the line between them, the end is the time-out / otherwise path
    if (k === 'LoopEnd') { var open = M.stages.filter(function (s) { return !s.deleted && s.page === pages()[cur] && s.type === 'LoopStart' && !E.partnerOf(M, s); })[0]; if (open) { st.orig.body = st.orig.body.replace(/<groupid>[^<]*<\/groupid>/, '<groupid>' + /<groupid>([^<]*)</.exec(open.orig.body)[1] + '</groupid>'); } else { toast('place the Loop start first'); } }
    var onLink = e.target.closest && e.target.closest('.lnkhit'), spliced = onLink && E.insertOnLink(M, st, onLink.getAttribute('data-from'), onLink.getAttribute('data-kind'));
    place = null; palette(); document.body.classList.remove('placing'); setMode('select'); sel = st.id; renderPage(); openSheet(st.id); if (spliced) { toast(NICE[k] + ' added on the link: wired in between'); return; } toast(NICE[k] + ' added' + (/^(WaitStart|ChoiceStart)$/.test(k) ? ' with its ' + (k === 'WaitStart' ? 'time-out' : 'otherwise') + ' end: add the branches in the sheet, wire each with L' : /^(Data|Collection|Note|Block|End|LoopEnd)$/.test(k) ? '' : ' - wire it with L')); return;
  }
  if (Date.now() - draggedAt < 350) { draggedAt = 0; return; }   // the click that ends a drag is not a click
  var lk = e.target.closest && e.target.closest('.lnkhit');
  if (lk) {
    var lf = M.byId[lk.getAttribute('data-from')], kd = lk.getAttribute('data-kind'); if (!lf) return;
    if (mode === 'delete') { snap(); E.setLink(lf, kd, null); selLink = null; renderPage(); toast('link removed'); return; }
    if (mode === 'select') { selLink = { from: lf.id, kind: kd }; multi = []; closeSheet(); highlight(null); markLink(); toast('link from "' + lf.name + '" selected: Del removes it; a new stage placed on a link is wired in between'); }
    return;
  }
  var g = e.target.closest && e.target.closest('g.st,g.blk'); if (!g) return;
  var id = g.getAttribute('data-sid'), st = M.byId[id]; if (!st) return;
  if (e.shiftKey && mode === 'select') return;   // Shift+click only changes the selection (done on mouse down)
  selLink = null; markLink();
  if (mode === 'delete') { if (/^(Start|End)$/.test(st.type)) { toast('Start and End stay'); return; } snap(); removeWithPartner(st); sel = null; closeSheet(); renderPage(); return; }
  if (mode === 'link') {
    if (!linkFrom) { linkFrom = st; highlight(id); toast('now click where "' + st.name + '" goes'); return; }
    if (/^(WaitStart|ChoiceStart)$/.test(linkFrom.type)) {   // one link per branch; the time-out / otherwise path leaves from the pair's end stage
      var brs = E.choicesOf(E.stageBody(linkFrom));
      if (!brs.length) { toast('"' + linkFrom.name + '" has no branch yet: click it in Select mode and add a row first'); linkFrom = null; setMode('link'); return; }
      var pickN = brs.length === 1 ? '1' : prompt('Which branch of "' + linkFrom.name + '" goes to "' + st.name + '"?\n' + brs.map(function (r, i) { return (i + 1) + ': ' + (r.name || '(no name)'); }).join('\n'), '1'), ix = parseInt(pickN, 10) - 1;
      if (ix >= 0 && ix < brs.length) { snap(); E.setChoiceTarget(linkFrom, ix, st.id); }
      linkFrom = null; setMode('link'); renderPage(); return;
    }
    if (linkFrom.type === 'Decision') { askYesNo(function (kind) { snap(); E.setLink(linkFrom, kind, st.id); linkFrom = null; setMode('link'); renderPage(); }); return; }
    if (/^(End|Exception|Note|Data|Collection|Block)$/.test(linkFrom.type)) { toast(linkFrom.type + ' has no outgoing link'); linkFrom = null; setMode('link'); return; }
    snap(); E.setLink(linkFrom, 'onsuccess', st.id); linkFrom = null; setMode('link'); renderPage(); return;
  }
  multi = []; sel = id; highlight(id); openSheet(id);
});
function markLink() {
  [].forEach.call(document.querySelectorAll('.lnkhit.on'), function (x) { x.classList.remove('on'); });
  if (!selLink) return;
  [].forEach.call(document.querySelectorAll('section:not([hidden]) .lnkhit'), function (x) { if (x.getAttribute('data-from') === selLink.from && x.getAttribute('data-kind') === selLink.kind) x.classList.add('on'); });
}
// ---------- copy / cut / paste / select all ----------
var CLIP_KEY = 'gumball:clip', pasteN = 0;
document.addEventListener('keydown', function (e) {
  if (!(e.ctrlKey || e.metaKey) || e.altKey || e.shiftKey) return;
  if (/^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement.tagName)) return;
  var k = e.key.toLowerCase(); if ('cvxa'.indexOf(k) < 0 || k.length !== 1) return;
  if (k !== 'v' && k !== 'a' && String(window.getSelection && window.getSelection()).length) return;   // text is selected (the run log, a check): the browser copies that
  var pg = pages()[cur];
  if (k === 'a') { e.preventDefault(); multi = M.stages.filter(function (s) { return !s.deleted && s.page === pg && !/^(Block|SubSheetInfo|ProcessInfo)$/.test(s.type); }).map(function (s) { return s.id; }); sel = null; closeSheet(); highlight(null); toast(multi.length + ' selected'); return; }
  if (k === 'c' || k === 'x') {
    var ids = multi.length ? multi.slice() : sel ? [sel] : []; if (!ids.length) return;
    var text = E.copyStages(M, ids), n = JSON.parse(text).stages.length; if (!n) { toast('Start and the page information box are not copied'); return; }
    e.preventDefault(); pasteN = 0;
    try { localStorage.setItem(CLIP_KEY, text); } catch (er) { toast('too big to copy'); return; }
    if (k === 'x') { snap(); ids.forEach(function (i) { var s = M.byId[i]; if (s && !/^(Start|End|SubSheetInfo|ProcessInfo)$/.test(s.type)) E.remove(M, s); }); multi = []; sel = null; closeSheet(); renderPage(); }
    toast(n + ' stage' + (n === 1 ? '' : 's') + (k === 'x' ? ' cut' : ' copied') + ': Ctrl+V pastes on any page, also in another object'); return;
  }
  var clip = null; try { clip = localStorage.getItem(CLIP_KEY); } catch (er) { }
  if (!clip) { toast('nothing copied yet'); return; }
  e.preventDefault(); snap(); pasteN++;
  var made = E.pasteStages(M, clip, pg, 30 * pasteN, 30 * pasteN);
  if (!made.length) { undo.pop(); toast('nothing to paste here'); return; }
  multi = made.map(function (s) { return s.id; }); sel = null; closeSheet(); renderPage(); highlight(null);
  toast(made.length + ' pasted and selected: drag them where they go');
});
document.addEventListener('keydown', function (e) { var typing = /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement.tagName); if ((e.ctrlKey || e.metaKey) && !typing && (e.key.toLowerCase() === 'y' || (e.shiftKey && e.key.toLowerCase() === 'z'))) { e.preventDefault(); doRedo(); return; }
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z' && !typing) { e.preventDefault(); doUndo(); return; } if (!typing && !e.ctrlKey && !e.altKey) { if (e.shiftKey) { if (e.key === 'L') { toggleTheme(); return; } } else { var km = { v: 'select', l: 'link', d: 'delete' }[e.key.toLowerCase()]; if (km) { setMode(km); return; } if (e.key.toLowerCase() === 'a') { startPlace('Action'); return; } if (e.key.toLowerCase() === 'g') { toggleGrid(); return; } } } if (e.key === 'Delete' && !typing) { if (selLink && M.byId[selLink.from]) { snap(); E.setLink(M.byId[selLink.from], selLink.kind, null); selLink = null; renderPage(); toast('link removed'); return; } if (multi.length) { snap(); multi.forEach(function (i) { var s = M.byId[i]; if (s && !/^(Start|End)$/.test(s.type)) removeWithPartner(s); }); multi = []; closeSheet(); renderPage(); return; } if (sel) { var st = M.byId[sel]; if (st && !/^(Start|End)$/.test(st.type)) { snap(); removeWithPartner(st); sel = null; closeSheet(); renderPage(); } } } if (e.key === 'Escape') { linkFrom = null; if (place) startPlace(place); else closeSheet(); } });
function removeWithPartner(st) { var p = E.partnerOf(M, st); E.remove(M, st); if (p) { E.remove(M, p); toast(st.type + ' and ' + p.type + ' removed together'); } }
function askYesNo(cb) { var d = $('yesno'); d.hidden = false; d.querySelector('.y').onclick = function () { d.hidden = true; cb('ontrue'); }; d.querySelector('.n').onclick = function () { d.hidden = true; cb('onfalse'); }; }
function toast(t) { var el = $('toast'); el.textContent = t; el.hidden = false; clearTimeout(el._t); el._t = setTimeout(function () { el.hidden = true; }, 2200); }

// ---------- sheet (editable) ----------
function field(label, id, value, kind) { return '<dt>' + esc(label) + '</dt><dd>' + (kind === 'area' ? '<textarea data-f="' + id + '">' + esc(value) + '</textarea>' : '<input data-f="' + id + '" value="' + esc(value) + '">') + '</dd>'; }
function openSheet(id) {
  var st = M.byId[id]; if (!st || st.deleted) return; sheetId = id;
  if (typeof selEl !== 'undefined' && selEl) { selEl = null; if (typeof moTree === 'function') moTree(); }
  var bp = E.bpOf(M), idName = {}; for (var i = 0; i < bp.stages.length; i++) idName[bp.stages[i].id] = bp.stages[i].name;
  var cur = bp.stages.filter(function (s) { return s.id === id; })[0]; var info = D.stageInfo(cur, bp, idName);
  $('sh-type').textContent = st.type; $('sh-name').textContent = st.name;
  var h = '<h4>Stage</h4><dl>' + (st.type === 'SubSheetInfo' || st.type === 'ProcessInfo' ? '<dt>Name</dt><dd>' + esc(st.name) + '</dd>' : field('Name', 'name', st.name)) + field('Description', 'narrative', info.desc, 'area') + '<dt>Page</dt><dd>' + esc(st.page) + '</dd>';
  var b = cur.body;
  if (st.type === 'Action') {
    var r = /<resource object="([^"]*)" action="([^"]*)"/.exec(b), ro = r ? D.unx(r[1]) : '', ra = r ? D.unx(r[2]) : '';
    if (OBJ.length) {
      ro = objAlias(ro); var known = OBJ.some(function (o) { return o.object === ro; });
      h += '<dt>Business Object</dt><dd><select id="pick-obj" onchange="pickAction(\'' + id + '\')">' + (known ? '' : '<option selected>' + esc(ro || '(choose)') + '</option>') + OBJ.map(function (o) { return '<option' + (o.object === ro ? ' selected' : '') + '>' + esc(o.object) + '</option>'; }).join('') + '</select></dd>';
      var acts = (OBJ.filter(function (o) { return o.object === ro; })[0] || { actions: [] }).actions, knownA = acts.some(function (a) { return a.name === ra; });
      h += '<dt>Action</dt><dd><select id="pick-act" onchange="pickAction(\'' + id + '\')">' + (knownA ? '' : '<option selected>' + esc(ra || '(choose)') + '</option>') + acts.map(function (a) { return '<option' + (a.name === ra ? ' selected' : '') + '>' + esc(a.name) + '</option>'; }).join('') + '</select></dd>';
    } else h += '<dt>Business Object</dt><dd>' + esc(ro) + '</dd><dt>Action</dt><dd>' + esc(ra) + ' <span class="muted">(drop the object exports next to the xml and re-render to pick actions)</span></dd>';
    var ourl = objUrl(ro, ra);
    if (ourl) h += '<dt></dt><dd><a class="jump" href="' + esc(ourl) + '" onclick="return leaveOk()">Open ' + esc(ro) + ' / ' + esc(ra) + ' &#8599;</a></dd>';
    else if (ro) h += '<dt></dt><dd><span class="muted">' + esc(ro) + (MEMBERS.length ? ' is not in this release' : ' is not open in gumball: drop its export in the inbox to open it from here') + '</span></dd>';
  }
  if (st.type === 'SubSheet') { var tgt = M.pages[D.tag(b, 'processid')] || ''; h += '<dt>Page called</dt><dd><select id="pick-page" onchange="pickPage(\'' + id + '\')">' + (tgt ? '' : '<option selected>(choose)</option>') + pages().filter(function (q) { return q !== st.page; }).map(function (q) { return '<option' + (q === tgt ? ' selected' : '') + '>' + esc(q) + '</option>'; }).join('') + '</select></dd>'; }
  if (st.type === 'Decision') h += field('Expression', 'decision', D.attr((/<decision ([^>]*)\/>/.exec(b) || ['', ''])[1], 'expression')) + '<dt>Yes</dt><dd>' + esc(idName[E.linkOf(st, 'ontrue')] || '-') + '</dd><dt>No</dt><dd>' + esc(idName[E.linkOf(st, 'onfalse')] || '-') + '</dd>';
  if (st.type === 'Exception') { var ex = (/<exception ([^>]*)\/>/.exec(b) || ['', ''])[1]; h += '<dt>Type</dt><dd><input data-f="ex.type" list="dl-extype" value="' + esc(D.attr(ex, 'type')) + '"><datalist id="dl-extype"><option value="System Exception"><option value="Business Exception"><option value="Runtime Exception"></datalist></dd>' + field('Detail', 'ex.detail', D.attr(ex, 'detail'))
      + (/\busecurrent="(yes|true)"/i.test(ex) ? '<dt></dt><dd class="muted">re-throws the current exception (Preserve): type and detail are not used</dd>' : '') + (/\bsavescreencapture="(yes|true)"/i.test(ex) ? '<dt></dt><dd class="muted">saves a screen capture</dd>' : ''); }
  if (st.type === 'Data') h += '<dt>Data Type</dt><dd><select data-f="datatype">' + ['text', 'number', 'flag', 'date', 'datetime', 'time', 'timespan', 'password', 'binary', 'image'].concat(/^(text|number|flag|date|datetime|time|timespan|password|binary|image)$/.test(D.tag(b, 'datatype')) ? [] : [D.tag(b, 'datatype')]).map(function (t) { return '<option' + (t === D.tag(b, 'datatype') ? ' selected' : '') + '>' + esc(t) + '</option>'; }).join('') + '</select></dd>' + field('Initial Value', 'initialvalue', D.unx(D.tag(b, 'initialvalue'))) + '<dt>Exposure</dt><dd>' + esc(D.tag(b, 'exposure') || 'none') + '</dd>';
  if (st.type === 'ProcessInfo') {
    var lang = D.tag(b, 'language'), refs = (b.match(/<reference>[^<]*<\/reference>/g) || []).map(function (r) { return D.unx(r.slice(11, -12)); }), imps = (b.match(/<import>[^<]*<\/import>/g) || []).map(function (r) { return D.unx(r.slice(8, -9)); });
    h += '<dt>Language</dt><dd><select data-f="language"><option value="csharp"' + (lang === 'csharp' ? ' selected' : '') + '>C#</option><option value="visualbasic"' + (lang === 'visualbasic' ? ' selected' : '') + '>VB.NET</option>' + (/^(csharp|visualbasic)$/.test(lang) ? '' : '<option value="' + esc(lang) + '" selected>' + esc(lang || '(not set: Visual Basic)') + '</option>') + '</select></dd>';
    h += '<dt>References</dt><dd><textarea data-f="references" title="one .dll per line">' + esc(refs.join('\n')) + '</textarea></dd><dt>Namespaces</dt><dd><textarea data-f="imports" title="one namespace per line">' + esc(imps.join('\n')) + '</textarea></dd>';
  }
  if (st.type === 'Alert') h += field('Alert text (expression)', 'alert', D.attr((/<alert\b[^>]*>/.exec(b) || [''])[0], 'expression'));
  if (st.type === 'LoopStart') h += field('Collection', 'loopdata', D.unx(D.tag(b, 'loopdata'))) + '<dt>Loop end</dt><dd>' + esc((E.partnerOf(M, st) || {}).name || '(missing)') + '</dd>';
  if (st.type === 'Block') h += '<dt>Holds</dt><dd>' + esc(E.membersOf(M, st).map(function (q) { return q.name; }).join(', ') || '(nothing: drag stages inside)') + '</dd>';
  if (!/^(Decision|Start|End|Data|Collection|Note|Block|SubSheetInfo|ProcessInfo)$/.test(st.type)) h += '<dt>Next</dt><dd>' + esc(idName[E.linkOf(st, 'onsuccess')] || '-') + '</dd>';
  var isInfo = /^(SubSheetInfo|ProcessInfo|Block|Note|Data|Collection)$/.test(st.type);
  var li = /<loginhibit\s*\/>/.test(b) ? 'off' : /<loginhibit onsuccess="true"/.test(b) ? 'error' : 'on';
  if (!isInfo) h += '<dt>Parameters</dt><dd><select data-f="logparams"><option value="on"' + (/<loginhibitparameters\b/.test(b) ? '' : ' selected') + '>Logged with the stage</option><option value="off"' + (/<loginhibitparameters\b/.test(b) ? ' selected' : '') + '>Don\'t log parameters</option></select></dd>';
  if (isInfo) h += '</dl>'; else h += '<dt>Logging</dt><dd><select data-f="loginhibit"><option value="on"' + (li === 'on' ? ' selected' : '') + '>Logged</option><option value="error"' + (li === 'error' ? ' selected' : '') + '>Log only on error</option><option value="off"' + (li === 'off' ? ' selected' : '') + '>Don\'t log this stage</option></select></dd></dl>';
  if (st.type === 'Calculation' || st.type === 'MultipleCalculation') {
    var rows = []; var re = /<calculation expression="([^"]*)" stage="([^"]*)"/g, m; while ((m = re.exec(b))) rows.push([D.unx(m[1]), D.unx(m[2])]);
    if (st.type === 'MultipleCalculation') rows.push(['', '']);
    h += '<h4>Calculations</h4><table id="calcs"><tr><th>Expression</th><th>Store In</th></tr>' + rows.map(function (r) { return '<tr><td><input value="' + esc(r[0]) + '"></td><td><input value="' + esc(r[1]) + '"></td></tr>'; }).join('') + '</table>';
  }
  // the rows a person edits: steps of an application stage, branches of a Wait / Choice, a page's parameters
  sheetRows = {}; var TYPES = ['text', 'number', 'flag', 'date', 'datetime', 'time', 'timespan', 'password', 'collection', 'binary', 'image'];
  var goes = function (r) { return idName[r.target] || '(not wired: Link mode, click this stage then the target)'; };
  if (st.type === 'Navigate') h += editTable('steps', 'Steps', [{ key: 'element', label: 'Element', kind: 'element' }, { key: 'action', label: 'Action', kind: 'list', list: 'dl-act' }], E.stepsOf(b), 'done in this order');
  if (st.type === 'Read') h += editTable('steps', 'Steps', [{ key: 'element', label: 'Element', kind: 'element' }, { key: 'action', label: 'Read', kind: 'list', list: 'dl-act' }, { key: 'stage', label: 'Store In' }], E.stepsOf(b));
  if (st.type === 'Write') h += editTable('steps', 'Steps', [{ key: 'expr', label: 'Value' }, { key: 'element', label: 'Element', kind: 'element' }, { key: 'action', label: 'Action (browser elements only)', kind: 'list', list: 'dl-act' }], E.stepsOf(b));
  if (sheetRows.steps && sheetRows.steps.rows.length) { var flat = []; sheetRows.steps.rows.forEach(function (r, i) { (r.args || []).forEach(function (a) { flat.push({ step: String(i + 1), id: a.id, value: a.value }); }); });
    h += editTable('args', 'Action arguments', [{ key: 'step', label: 'Step', kind: 'pick', options: sheetRows.steps.rows.map(function (r, i) { return String(i + 1); }) }, { key: 'id', label: 'Argument', kind: 'list', list: 'dl-arg' }, { key: 'value', label: 'Value (expression)' }], flat, 'what a step\'s action is given: the window title of an Attach, the text of a Send Keys, a position ..') + '<datalist id="dl-arg">' + E.VOCAB.Args.map(function (v) { return '<option value="' + esc(v) + '">'; }).join('') + '</datalist>'; }
  if (st.type === 'Collection') h += editTable('fields', 'Columns', [{ key: 'name', label: 'Name' }, { key: 'type', label: 'Type', kind: 'pick', options: TYPES }, { key: 'description', label: 'Description' }, { key: 'nested', label: '', kind: 'ro', show: function (r) { return r.nested ? r.nested + ' column' + (r.nested === 1 ? '' : 's') + ' inside (kept)' : ''; } }], E.fieldsOf(b), 'no rows = an undefined collection: it takes whatever columns it is given');
  if (st.type === 'Process') { var pid = D.tag(b, 'processid').trim().toLowerCase(), procs = MEMBERS.filter(function (q) { return q.type === 'process' && q.id; }), knownP = procs.some(function (q) { return String(q.id).toLowerCase() === pid; });
    h += '<dl><dt>Process to run</dt><dd><select data-f="processid">' + (knownP ? '' : '<option value="' + esc(pid) + '" selected>' + (pid ? '(a process that is not in this release)' : '(choose)') + '</option>') + procs.map(function (q) { return '<option value="' + esc(q.id) + '"' + (String(q.id).toLowerCase() === pid ? ' selected' : '') + '>' + esc(q.name) + '</option>'; }).join('') + '</select></dd></dl>'
      + editTable('ioinput', 'Inputs', [{ key: 'name', label: 'Name' }, { key: 'type', label: 'Type', kind: 'pick', options: TYPES }, { key: 'expr', label: 'Value' }], E.ioOf(b, 'input'), 'the names must be the inputs of that process\'s Main Page Start stage')
      + editTable('iooutput', 'Outputs', [{ key: 'name', label: 'Name' }, { key: 'type', label: 'Type', kind: 'pick', options: TYPES }, { key: 'stage', label: 'Store In' }], E.ioOf(b, 'output')); }
  if (st.type === 'WaitStart') h += '<dl>' + field('Timeout (seconds or expression)', 'timeout', D.unx(D.tag(b, 'timeout'))) + '</dl>' + editTable('choices', 'Wait for', [{ key: 'name', label: 'Name' }, { key: 'element', label: 'Element', kind: 'element' }, { key: 'condition', label: 'Condition', kind: 'list', list: 'dl-cond' }, { key: 'compare', label: 'Compare', kind: 'pick', options: ['Equal', 'NotEqual', 'LessThan', 'GreaterThan', 'LessThanOrEqual', 'GreaterThanOrEqual'] }, { key: 'reply', label: 'Value' }, { key: 'target', label: 'Goes to', kind: 'ro', show: goes }], E.choicesOf(b), 'no rows = a plain pause for the timeout; the time-out path leaves from "' + ((E.partnerOf(M, st) || {}).name || 'the wait end') + '"');
  if (st.type === 'ChoiceStart') h += editTable('choices', 'Branches', [{ key: 'name', label: 'Name' }, { key: 'expression', label: 'Expression' }, { key: 'target', label: 'Goes to', kind: 'ro', show: goes }], E.choicesOf(b), 'checked top to bottom, the first true one is taken; none true = the path from "' + ((E.partnerOf(M, st) || {}).name || 'the choice end') + '"');
  if (st.type === 'Start' && st.page !== 'Main Page' || st.type === 'Start' && M.type === 'process') h += editTable('params', 'Page inputs', [{ key: 'name', label: 'Name' }, { key: 'type', label: 'Type', kind: 'pick', options: TYPES }, { key: 'stage', label: 'Store In' }], E.paramsOf(b, 'Start'));
  if (st.type === 'End' && (st.page !== 'Main Page' || M.type === 'process')) h += editTable('params', 'Page outputs', [{ key: 'name', label: 'Name' }, { key: 'type', label: 'Type', kind: 'pick', options: TYPES }, { key: 'stage', label: 'From' }], E.paramsOf(b, 'End'));
  if (sheetRows.steps || sheetRows.choices) { var voc = vocab(); h += '<datalist id="dl-act">' + voc.act.map(function (v) { return '<option value="' + esc(v) + '">'; }).join('') + '</datalist><datalist id="dl-cond">' + voc.cond.map(function (v) { return '<option value="' + esc(v) + '">'; }).join('') + '</datalist>'; }
  var ins = []; var rin = /<input ([^>]*)\/>/g; while ((m = rin.exec(b))) ins.push([D.attr(m[1], 'name'), D.attr(m[1], 'type'), D.attr(m[1], 'expr')]);
  var outs = []; var rout = /<output ([^>]*)\/>/g; while ((m = rout.exec(b))) outs.push([D.attr(m[1], 'name'), D.attr(m[1], 'type'), D.attr(m[1], 'stage')]);
  if (ins.length && st.type !== 'Start' && st.type !== 'End' && st.type !== 'Process') h += '<h4>Inputs</h4><table><tr><th>Name</th><th>Type</th><th>Value</th></tr>' + ins.map(function (r) { return '<tr><td>' + esc(r[0]) + '</td><td>' + esc(r[1]) + '</td><td><input data-f="in:' + esc(r[0]) + '" value="' + esc(r[2]) + '"></td></tr>'; }).join('') + '</table>';
  if (outs.length && st.type !== 'End' && st.type !== 'Start' && st.type !== 'Process') h += '<h4>Outputs</h4><table><tr><th>Name</th><th>Type</th><th>Store In</th></tr>' + outs.map(function (r) { return '<tr><td>' + esc(r[0]) + '</td><td>' + esc(r[1]) + '</td><td><input data-f="out:' + esc(r[0]) + '" value="' + esc(r[2]) + '"></td></tr>'; }).join('') + '</table>';
  for (var t = 0; t < info.tables.length; t++) { var tb = info.tables[t]; if (/^(Inputs|Outputs|Calculations)$/.test(tb.title) || (sheetRows.params && /^Page (inputs|outputs)$/.test(tb.title)) || (sheetRows.choices && /^(Conditions|Choices|Branches)$/.test(tb.title))) continue; if (tb.title === 'Steps' && sheetRows.steps) { if (!tb.rows.length) continue; tb = { title: 'Step details (arguments, what the spy found)', cols: tb.cols, rows: tb.rows }; } h += '<h4>' + esc(tb.title) + '</h4><table><tr>' + tb.cols.map(function (c) { return '<th>' + esc(c) + '</th>'; }).join('') + '</tr>' + tb.rows.map(function (r) { return '<tr>' + r.map(function (c) { return '<td>' + esc(c) + '</td>'; }).join('') + '</tr>'; }).join('') + '</table>'; }
  if (st.type === 'Code') h += '<h4>Code</h4><textarea data-f="code" class="code">' + esc(info.code) + '</textarea>';
  if (st.type === 'ProcessInfo') h += '<h4>Shared code</h4><p class="muted">fields and helpers every code stage of this object can use (Blue Prism keeps them in the Code Options stage)</p><textarea data-f="code" class="code">' + esc(D.tag(b, 'code').replace(/^\s*<!\[CDATA\[|\]\]>\s*$/g, '')) + '</textarea>';
  h += '<p class="apply"><button onclick="applySheet(\'' + id + '\')">Apply</button></p>';
  $('sh-body').innerHTML = h; $('sheet').hidden = false;
  [].forEach.call($('sh-body').querySelectorAll('[data-f]'), function (el) { el._v0 = el.value; });   // only a field somebody changed is written back
  if ($('calcs')) $('calcs')._v0 = JSON.stringify([].map.call($('calcs').querySelectorAll('input'), function (i) { return i.value; }));
  [].forEach.call($('sh-body').querySelectorAll('input'), function (i) { i.onkeydown = function (e) { if (e.key === 'Enter') applySheet(id); }; });
}
// ---------- editable rows in the sheet ----------
var sheetRows = {};
function vocab() {   // action / condition ids: the ones this file already uses first (they are right for its application), then the common ones
  var act = {}, cond = {}, m, ra = /<action>\s*<id>([^<]+)<\/id>/g, rc = /<condition>\s*<id>([^<]+)<\/id>/g;
  while ((m = ra.exec(M.xml))) act[m[1]] = 1; while ((m = rc.exec(M.xml))) cond[m[1]] = 1;
  var st = M.byId[sheetId], mine = st && E.VOCAB[st.type] ? E.VOCAB[st.type] : E.VOCAB.Navigate.concat(E.VOCAB.Read);
  var used = Object.keys(act).filter(function (k) { return !st || !E.VOCAB[st.type] || mine.indexOf(k) >= 0; }), usedC = Object.keys(cond);
  return { act: used.concat(mine.filter(function (k) { return !act[k]; })), cond: usedC.concat(E.VOCAB.Wait.filter(function (k) { return !cond[k]; })) };
}
function editTable(key, title, cols, rows, hint) {
  sheetRows[key] = { cols: cols, rows: rows };
  var els = Object.keys(M.elements || {}).map(function (id) { return [id, M.elements[id].name]; }).sort(function (a, b) { return a[1].localeCompare(b[1]); });
  var cell = function (c, r) {
    var v = r[c.key] == null ? '' : r[c.key];
    if (c.kind === 'ro') return '<span class="muted">' + esc(c.show(r)) + '</span>';
    if (c.kind === 'element') return '<select data-c="' + c.key + '">' + (els.some(function (e) { return e[0] === v; }) ? '' : '<option value="' + esc(v) + '" selected>' + (v ? '(unknown element)' : '(choose)') + '</option>') + els.map(function (e) { return '<option value="' + esc(e[0]) + '"' + (e[0] === v ? ' selected' : '') + '>' + esc(e[1]) + '</option>'; }).join('') + '</select>';
    if (c.kind === 'pick') return '<select data-c="' + c.key + '">' + (c.options.indexOf(v) >= 0 ? '' : '<option selected>' + esc(v) + '</option>') + c.options.map(function (o) { return '<option' + (o === v ? ' selected' : '') + '>' + esc(o) + '</option>'; }).join('') + '</select>';
    return '<input data-c="' + c.key + '" value="' + esc(v) + '"' + (c.kind === 'list' ? ' list="' + c.list + '"' : '') + '>';
  };
  var h = '<h4>' + esc(title) + '</h4>' + (hint ? '<p class="muted">' + esc(hint) + '</p>' : '') + '<table data-t="' + key + '"><tr>' + cols.map(function (c) { return '<th>' + esc(c.label) + '</th>'; }).join('') + '<th></th></tr>';
  rows.forEach(function (r, i) { h += '<tr data-i="' + i + '">' + cols.map(function (c) { return '<td>' + cell(c, r) + '</td>'; }).join('') + '<td><button class="rowx" onclick="sheetRow(\'' + key + '\',' + i + ')" title="remove this row">&times;</button></td></tr>'; });
  return h + '</table><p><button onclick="sheetRow(\'' + key + '\',-1)">+ row</button>' + (key === 'steps' && !els.length ? ' <span class="muted">this object has no Application Modeller elements yet</span>' : '') + '</p>';
}
function stepsWithArgs(steps, args) {   // the arguments table folded back into the steps they belong to
  var base = (steps || sheetRows.steps.rows).map(function (r) { return Object.assign({}, r, { args: [] }); });
  args.forEach(function (a) { var s = base[+a.step - 1]; if (s && a.id) s.args.push({ id: a.id, value: a.value || '' }); });
  return base;
}
function readTables() {   // the rows as they stand in the sheet; null for a table nobody touched
  var out = {};
  [].forEach.call($('sh-body').querySelectorAll('table[data-t]'), function (tb) {
    var key = tb.getAttribute('data-t'), src = sheetRows[key]; if (!src) return; var changed = false;
    var rows = [].map.call(tb.querySelectorAll('tr[data-i]'), function (tr) { var o = Object.assign({}, src.rows[+tr.getAttribute('data-i')]);
      [].forEach.call(tr.querySelectorAll('[data-c]'), function (el) { var k = el.getAttribute('data-c'); if ((o[k] == null ? '' : o[k]) !== el.value) { o[k] = el.value; changed = true; } }); return o; });
    out[key] = changed ? rows : null;
  });
  return out;
}
window.sheetRow = function (key, i) {   // remove row i, or add one at the end (i = -1)
  var id = sheetId, st = M.byId[id], src = sheetRows[key]; if (!st || !src) return; snap();
  var all = readTables(), now = all[key] || src.rows.slice();
  if (i >= 0) now.splice(i, 1); else now.push(key === 'params' ? { name: 'New ' + (st.type === 'Start' ? 'Input' : 'Output'), type: 'text', stage: '' } : key === 'fields' ? { name: 'New Column', type: 'text' } : key === 'ioinput' || key === 'iooutput' ? { name: 'New ' + (key === 'ioinput' ? 'Input' : 'Output'), type: 'text' } : key === 'args' ? { step: '1', id: 'newtext', value: '' } : {});
  if (key === 'args') { E.setField(st, 'steps', stepsWithArgs(all.steps, now)); if (all.steps === null) { } }
  else { if (key === 'steps' && all.args) now = stepsWithArgs(now, all.args); E.setField(st, key, now); }
  renderPage(); openSheet(id);
};
$('sh-body').addEventListener('change', function (e) {   // a field that changed is applied at once: no Apply needed
  var t = e.target; if (!sheetId || !t || !(t.matches('[data-f]') || (t.closest && (t.closest('#calcs') || t.closest('table[data-t]'))))) return;
  applySheet(sheetId, true);
});
var sheetId = null;
window.applySheet = function (id, quiet) {
  var st = M.byId[id]; if (!st) return; snap();
  var ex = {};
  [].forEach.call($('sh-body').querySelectorAll('[data-f]'), function (el) {
    var f = el.dataset.f, v = el.value;
    if (el._v0 === v) return; el._v0 = v;   // untouched: the XML keeps what Blue Prism wrote, byte for byte
    if (f === 'name') { if (v !== st.name) E.rename(st, v); }
    else if (f === 'ex.type' || f === 'ex.detail') { ex.type = $('sh-body').querySelector('[data-f="ex.type"]').value; ex.detail = $('sh-body').querySelector('[data-f="ex.detail"]').value; }
    else if (f === 'narrative') { if (v !== D.unx(D.tag(st.orig.body, 'narrative'))) E.setField(st, 'narrative', v); }
    else if (f === 'references' || f === 'imports') E.setField(st, f, v.split(/\r?\n/).map(function (x) { return x.trim(); }).filter(Boolean));
    else E.setField(st, f, v);
  });
  if (ex.type !== undefined) E.setField(st, 'exception', ex);
  var tabs = readTables(); if (tabs.args) { sheetRows.args.rows = tabs.args; tabs.steps = stepsWithArgs(tabs.steps, tabs.args); } delete tabs.args;
  Object.keys(tabs).forEach(function (k) { if (tabs[k]) { E.setField(st, k, tabs[k]); sheetRows[k].rows = tabs[k]; } });
  var calcs = $('calcs'), calcNow = calcs ? JSON.stringify([].map.call(calcs.querySelectorAll('input'), function (i) { return i.value; })) : ''; if (calcs && calcs._v0 === calcNow) calcs = null; else if (calcs) calcs._v0 = calcNow;
  if (calcs) E.setField(st, 'calcs', [].map.call(calcs.querySelectorAll('tr'), function (tr) { var i = tr.querySelectorAll('input'); return i.length ? [i[0].value, i[1].value] : null; }).filter(Boolean));
  if (quiet) { renderPage(); $('sh-name').textContent = st.name; return; }   // the sheet stays as it is: the next field keeps the focus
  renderPage(); openSheet(id); toast('applied');
};
window.pickAction = function (id) {
  var st = M.byId[id]; if (!st) return; var o = $('pick-obj').value, acts = (OBJ.filter(function (x) { return x.object === o; })[0] || { actions: [] }).actions;
  var cur = $('pick-act').value, a = acts.filter(function (x) { return x.name === cur; })[0] || acts[0]; if (!a) return;
  snap(); for (var k in st.edits) if (/^(in|out):/.test(k)) delete st.edits[k]; E.setResource(st, o, a.name, a.inputs, a.outputs); renderPage(); openSheet(id);
};
window.pickPage = function (id) { var st = M.byId[id]; if (!st) return; var q = $('pick-page').value; if (pages().indexOf(q) < 0) return; snap(); for (var k in st.edits) if (/^(in|out):/.test(k)) delete st.edits[k]; E.setPageCall(M, st, q); renderPage(); openSheet(id); };
window.closeSheet = function () { $('sheet').hidden = true; sel = null; sheetId = null; if (typeof selEl !== 'undefined' && selEl) { selEl = null; if (typeof moTree === 'function') moTree(); } [].forEach.call(document.querySelectorAll('g.st.on,g.blk.on'), function (g) { g.classList.remove('on'); }); };

// ---------- rules + save ----------
function rules() {
  var r = E.checkRules(M), errs = r.filter(function (x) { return x.level === 'error'; }), warns = r.filter(function (x) { return x.level === 'warn'; });
  $('rules').innerHTML = (r.length ? r.map(function (x) { return '<li class="' + x.level + '">' + esc(x.page ? x.page + ' / ' : '') + (x.stage ? '<b>' + esc(x.stage) + '</b>: ' : '') + esc(x.msg) + '</li>'; }).join('') : '<li class="ok">all rules pass</li>');
  $('rulecount').textContent = errs.length ? errs.length + ' problem' + (errs.length === 1 ? '' : 's') + (warns.length ? ', ' + warns.length + ' warning' + (warns.length === 1 ? '' : 's') : '') : warns.length ? 'ok, ' + warns.length + ' warning' + (warns.length === 1 ? '' : 's') : 'all rules pass';
  var liveErrs = errs.length;   // what Save asks about: errors of the drawing as it is now, not the report made when this version was opened
  var stat = (typeof BW_STATIC !== 'undefined' && BW_STATIC) || {}; if (stat.compile === false) { $('rulecount').textContent += ' - code does not compile'; errs.push(1); } else if (stat.validate === false) { $('rulecount').textContent += ' - validate found problems'; errs.push(1); }
  $('checks').className = errs.length ? 'bad' : warns.length ? 'meh' : 'good';
  lastErrs = liveErrs; $('save').disabled = false; $('save').title = (window.BW_SERVE ? 'save as ' : 'download ') + nextName() + (liveErrs ? ' - ' + liveErrs + ' error' + (liveErrs === 1 ? '' : 's') + ' in the live checks, Save asks first' : '');
}
function nextName() { return BW_BASE + '.v' + (BW_VER + 1) + '.xml'; }
var lastErrs = 0;
window.saveXml = function () {
  // the checks never refuse a save: a real object rarely passes every house rule, and a half-done one still has to be kept
  if (lastErrs && !confirm(lastErrs + ' error' + (lastErrs === 1 ? '' : 's') + ' in the live checks (a stage without a link, a missing End ..: the panel next to Run lists them).\n\nSave this version anyway?')) return;
  var xml = E.serialize(M);
  if (window.BW_SERVE) {   // served by gumball: the next version goes straight into the project folder and opens with its diff
    try { localStorage.setItem('gumball:' + BW_BASE, xml); } catch (e) { }
    toast('saving...');
    fetch('/save?base=' + encodeURIComponent(window.BW_SERVE.base) + (window.BW_SERVE.rel ? '&rel=' + encodeURIComponent(window.BW_SERVE.rel) : ''), { method: 'POST', body: xml }).then(function (r) { return r.json(); })
      .then(function (j) { if (j.error) { toast('save failed: ' + j.error); return; } clearTimeout(draftT); draftT = null; try { localStorage.removeItem(DRAFT_KEY); } catch (e) { } toast('saved ' + j.name); location.href = j.url; }, function (e) { toast('save failed: is gumball still running? ' + e); });
    return;
  } var blob = new Blob([xml], { type: 'text/xml' }); var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = nextName(); document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
  try { localStorage.setItem('gumball:' + BW_BASE, xml); } catch (e) { }
  toast('downloaded ' + nextName() + ' - drop it next to this file and run gumball render on it');
};
window.copyXml = function () { var xml = E.serialize(M); if (navigator.clipboard) navigator.clipboard.writeText(xml).then(function () { toast('XML copied'); }, function () { toast('copy refused'); }); };
window.toggleGrid = function () { var g = document.body.classList.toggle('grid'); try { localStorage.setItem('gumball:grid', g ? '1' : '0'); } catch (e) { } $('gridb').classList.toggle('on', g); toast(g ? 'grid on: stages snap to the 15px Studio grid' : 'grid off: free placement'); };
window.toggleTheme = function () { var d = document.body.classList.toggle('dark'); try { localStorage.setItem('gumball:theme', d ? 'dark' : 'light'); } catch (e) { } renderAll(); toast(d ? 'dark' : 'light: Blue Prism Studio look'); };
window.openSheet = openSheet;
window.toggleChecks = function () { $('checkpanel').hidden = !$('checkpanel').hidden; };
window.toggleDiff = function () { $('diff').hidden = !$('diff').hidden; };

// ---------- search ----------
$('q').onkeydown = function (e) { if (e.key !== 'Enter') return; var q = this.value.toLowerCase(); if (!q) return; var pg = pages(); for (var i = 0; i < pg.length; i++) { var hit = M.stages.some(function (s) { return !s.deleted && s.page === pg[i] && s.name.toLowerCase().indexOf(q) >= 0; }); if (hit) { cur = i; renderAll(); return; } } toast('no stage named like that'); };

// ---------- release navigation (served releases): every member one click away; Action stages jump to their object's action ----------
var SERVED = !!window.BW_SERVE, LINKS = (typeof BW_LINKS !== 'undefined' && BW_LINKS) || {};
var MEMBERS = (SERVED && window.BW_SERVE.members) || (typeof BW_MEMBERS !== 'undefined' && BW_MEMBERS) || [];
var RELNAME = (SERVED && window.BW_SERVE.relName) || (typeof BW_RELNAME !== 'undefined' && BW_RELNAME) || '';
function objUrl(name, pageName) {   // address of an object's page, on the page of one action. Served: through gumball; from the folder: the neighbour's file
  if (!name) return null; var k = '~' + String(name).replace(/\s+/g, ' ').trim().toLowerCase();
  var so = SERVED && window.BW_SERVE.objects, u = (so && (so[name] || so[k])) || LINKS[name] || LINKS[k]; if (!u) return null;
  return u + (pageName ? '#page=' + encodeURIComponent(pageName) : '');
}
function actionsOf(name) { for (var i = 0; i < OBJ.length; i++) if (OBJ[i].object === name) return OBJ[i].actions; return null; }
function actionsText(acts) { return acts.length + ' published action' + (acts.length === 1 ? '' : 's') + (acts.length ? ': ' + acts.map(function (a) { return a.name; }).slice(0, 14).join(', ') + (acts.length > 14 ? ', ...' : '') : ''); }
window.leaveOk = function () { if (draftT) draftNow(); return !dirty || draftKept || confirm('These changes could not be kept as a draft. Leave this page anyway?'); };
function miniList(boxId, title, items, onRender) {
  var box = $(boxId); if (!box) return;
  var openKey = 'gumball:open:' + boxId, isOpen = true; try { isOpen = localStorage.getItem(openKey) !== '0'; } catch (e) { }
  box.innerHTML = '<details' + (isOpen ? ' open' : '') + '><summary class="navh">' + title + '</summary><div class="mini"><input placeholder="filter"><ul></ul></div></details>';
  var det = box.querySelector('details'), inp = box.querySelector('input'), ul = box.querySelector('ul');
  det.ontoggle = function () { try { localStorage.setItem(openKey, det.open ? '1' : '0'); } catch (e) { } };
  var draw = function () {
    var q = inp.value.toLowerCase(), hit = items.filter(function (it) { return it.text.toLowerCase().indexOf(q) >= 0; });
    ul.innerHTML = hit.slice(0, 300).map(function (it, i) { return '<li class="' + (it.on ? 'on' : '') + '" title="' + esc(it.title || it.text) + '" data-i="' + items.indexOf(it) + '"><b>' + esc(it.tag || '') + '</b>' + esc(it.text) + '</li>'; }).join('') + (hit.length > 300 ? '<li class="more">' + (hit.length - 300) + ' more: filter</li>' : '') + (hit.length ? '' : '<li class="more">nothing matches</li>');
    [].forEach.call(ul.querySelectorAll('li[data-i]'), function (li) { li.onclick = function () { onRender(items[+li.dataset.i]); }; });
  };
  inp.oninput = draw; draw();
}
// one list: inside a release, the Release list is the list (objects show their actions on hover);
// "Objects known" only shows objects that are NOT members, and on pages outside a release.
var memberNames = {};
if (MEMBERS.length) {
  for (var mi = 0; mi < MEMBERS.length; mi++) memberNames[MEMBERS[mi].name] = 1;
  miniList('relnav', 'Release <span class="muted">' + esc(RELNAME) + ' (' + MEMBERS.length + ')</span>',
    MEMBERS.map(function (m) { var acts = m.type === 'object' ? actionsOf(m.name) : null; return { text: m.name, tag: m.type === 'object' ? 'O' : 'P', title: (m.type === 'object' ? 'object: ' : 'process: ') + m.name + (acts ? ' - ' + actionsText(acts) : ''), on: m.base === BW_BASE, url: m.url }; }),
    function (it) { if (!it.on && leaveOk()) location.href = it.url; });
}
var others = OBJ.filter(function (o) { return !(MEMBERS.length && (memberNames[o.object] || objUrl(o.object))); });
if (others.length) {
  miniList('objknown', (MEMBERS.length ? 'Other objects known' : 'Objects known') + ' <span class="muted">(' + others.length + ')</span>',
    others.map(function (o) { var u = objUrl(o.object); return { text: o.object, tag: o.internal ? 'I' : u ? 'O' : '', title: o.object + ' - ' + (o.internal ? 'Blue Prism internal object (' + (o.verified ? 'verified list' : 'seed list, see internal/README.txt') + ') - ' : '') + actionsText(o.actions) + (o.internal ? '' : u ? ' - click to open it' : MEMBERS.length ? ' - not in this release' : ' - not open in gumball'), url: u }; }),
    function (it) { if (it.url) { if (leaveOk()) location.href = it.url; } else toast(it.title); });
}
// ---------- mordecai: the Application Modeller (objects only) ----------
var MO = window.MORDECAI, selEl = null, MOTAG = { win32: 'W32', aa: 'AA', uia: 'UIA', web: 'WEB', html: 'HTML', sap: 'SAP', region: 'RGN', application: 'APP', none: '' };
function moText() { if (M.appdef != null) return M.appdef; var f = MO && MO.find(M.xml); return f ? M.xml.slice(f.start, f.end) : null; }
function moUsed() { var out = {}, st = E.bpOf(M).stages; for (var i = 0; i < st.length; i++) { var re = /<element id="([^"]+)"/g, m, seen = {}; while ((m = re.exec(st[i].body))) { if (seen[m[1]]) continue; seen[m[1]] = 1; (out[m[1]] = out[m[1]] || []).push(st[i].name); } } return out; }
function moSync() {   // after any change of the model: what stages show for an element, the tree, the open sheet
  var t = moText(); if (!t) return; var p = MO.parse(t); M.elements = {};
  for (var i = 0; i < p.list.length; i++) { var e = p.list[i]; if (e.id) M.elements[e.id] = { name: e.name, type: e.type, attrs: e.attrs.filter(function (a) { return a.inuse; }).map(function (a) { return a.name + '=' + a.value; }) }; }
  moTree(); if (selEl) { if (p.byId[selEl]) openElement(selEl); else { selEl = null; $('sheet').hidden = true; } }
}
function moApply(fn) { try { var t = fn(moText()); snap(); M.appdef = typeof t === 'string' ? t : t.appdef; if (t && t.id) selEl = t.id; moSync(); renderPage(); return true; } catch (e) { toast(e.message); return false; } }
function moTree() {
  var box = $('appmodel'), t = moText(); if (!box) return;
  if (!t) {   // an object that never had an Application Modeller (made by hand or by the generator): offer one
    if (M.type !== 'object' && M.type !== 'Object' && !/object/i.test(String(M.type || ''))) { box.innerHTML = ''; return; }
    box.innerHTML = '<details open><summary class="navh">Application Modeller <span class="muted">(none)</span></summary><div class="mini" style="padding:4px 10px"><button onclick="moCreate()" title="give this object an application model: a root element, then pick how the application starts">+ Application Modeller</button></div></details>'; return;
  }
  var p = MO.parse(t), used = moUsed();
  var spied = p.list.filter(function (e) { return e.attrs.length; }).length, key = 'gumball:open:appmodel', isOpen = true; try { isOpen = localStorage.getItem(key) !== '0'; } catch (e) { }
  var q = (box.querySelector('input') || {}).value || '';
  box.innerHTML = '<details' + (isOpen ? ' open' : '') + '><summary class="navh">Application Modeller <span class="muted">(' + spied + ' spied' + (p.app.mode ? ', ' + esc(p.app.mode) : '') + ')</span></summary><div class="mini"><input placeholder="filter"><ul></ul></div></details>';
  var det = box.querySelector('details'), inp = box.querySelector('input'), ul = box.querySelector('ul'); inp.value = q;
  det.ontoggle = function () { try { localStorage.setItem(key, det.open ? '1' : '0'); } catch (e) { } };
  var draw = function () {
    var f = inp.value.toLowerCase(), hit = p.list.filter(function (e) { return !f || e.name.toLowerCase().indexOf(f) >= 0; });
    ul.innerHTML = hit.map(function (e) { var u = used[e.id]; return '<li class="el' + (e.id === selEl ? ' on' : '') + (e.kind !== 'application' && !u ? ' unused' : '') + '" data-id="' + esc(e.id) + '" style="padding-left:' + (6 + (f ? 0 : e.depth * 10)) + 'px" title="' + esc(e.name + ' - ' + (MO.KINDS[e.kind] ? MO.KINDS[e.kind].label : e.kind) + (u ? ' - used by ' + u.length + ' stage' + (u.length === 1 ? '' : 's') : e.kind === 'application' ? '' : ' - no stage uses it')) + '">' + (MOTAG[e.kind] ? '<i>' + MOTAG[e.kind] + '</i>' : '') + esc(e.name) + '</li>'; }).join('') || '<li class="more">nothing matches</li>';
    [].forEach.call(ul.querySelectorAll('li.el'), function (li) { li.onclick = function () { openElement(li.dataset.id); }; });
  };
  inp.oninput = draw; draw();
}
function openElement(id) {
  var t = moText(); if (!t) return; var p = MO.parse(t), e = p.byId[id]; if (!e) return;
  sel = null; sheetId = null; highlight(null); selEl = id; var used = moUsed()[id] || [], K = MO.KINDS[e.kind];
  $('sh-type').textContent = K ? K.label : e.kind === 'application' ? 'Application' : 'Element'; $('sh-name').textContent = e.name;
  var h = '<h4>Element</h4><dl><dt>Name</dt><dd><input value="' + esc(e.name) + '" onchange="moRename(this.value)"></dd><dt>Type</dt><dd>' + esc(e.type || e.base) + (e.base && e.base !== e.type ? ' (' + esc(e.base) + ')' : '') + (e.dtype ? ', ' + esc(e.dtype) : '') + '</dd>'
    + '<dt>Used by</dt><dd>' + (used.length ? used.map(esc).join(', ') : '<span class="muted">no stage</span>') + '</dd></dl>';
  if (e.kind === 'application') {
    var modes = Object.keys(MO.MODES); if (p.app.mode && modes.indexOf(p.app.mode) < 0) modes.push(p.app.mode);
    h += '<h4>Application</h4><dl><dt>Mode</dt><dd><select onchange="moSetMode(this.value)"><option value=""' + (p.app.mode ? '' : ' selected') + '>(not set: pick how the application starts)</option>' + modes.map(function (k) { return '<option value="' + esc(k) + '"' + (k === p.app.mode ? ' selected' : '') + '>' + esc(k) + (MO.MODES[k] ? ' - ' + MO.MODES[k].label : '') + '</option>'; }).join('') + '</select></dd>'
      + p.app.params.map(function (x) { return '<dt>' + esc(x.name) + '</dt><dd><input value="' + esc(x.value) + '" onchange="moSetParam(\'' + esc(x.name) + '\',this.value)"></dd>'; }).join('') + '</dl>'
      + (p.app.mode && MO.MODES[p.app.mode] && !MO.MODES[p.app.mode].verified ? '<div class="muted">The parameter list of ' + esc(p.app.mode) + ' was not read off a real export yet: compare with one Studio wrote before relying on it.</div>' : '')
      + (!p.app.mode ? '<div class="muted">Without a mode Studio shows the wizard on open. Win32Launch starts the program at Path; Attach modes hook a window already open; SAP is Win32Launch of the SAP GUI (saplgpad).</div>' : '');
  }
  var row = function (a) {
    var long = a.value.length > 300, cmps = MO.COMPARISONS.indexOf(a.cmp || 'Equal') >= 0 ? MO.COMPARISONS : MO.COMPARISONS.concat([a.cmp]);
    return '<tr><td><input type="checkbox"' + (a.inuse ? ' checked' : '') + ' onchange="moSet(\'' + esc(a.name) + '\',{inuse:this.checked})" title="match on this attribute"></td><td class="n">' + esc(a.name) + '</td><td><select onchange="moSet(\'' + esc(a.name) + '\',{cmp:this.value})">' + cmps.map(function (c) { return '<option' + ((a.cmp || 'Equal') === c ? ' selected' : '') + '>' + esc(c) + '</option>'; }).join('') + '</select></td><td>'
      + (long ? '<span class="muted">' + esc(a.value.slice(0, 40)) + '... (' + a.value.length + ' chars, kept as is)</span>' : '<input value="' + esc(a.value) + '" onchange="moSet(\'' + esc(a.name) + '\',{value:this.value})">') + '</td></tr>';
  };
  if (e.attrs.length) {
    var on = e.attrs.filter(function (a) { return a.inuse; }), off = e.attrs.filter(function (a) { return !a.inuse; });
    h += '<h4>Matched on (' + on.length + ')</h4>' + (on.length ? '<table class="mo">' + on.map(row).join('') + '</table>' : '<div class="muted">nothing ticked: Blue Prism would match the first element it finds</div>');
    h += '<details' + (window._moOpen ? ' open' : '') + ' ontoggle="window._moOpen=this.open"><summary><h4 style="display:inline-block;cursor:pointer">Recorded, not matched (' + off.length + ')</h4></summary><table class="mo">' + off.map(row).join('') + '</table></details>';
  }
  h += '<h4>Model</h4><div class="mobtn">' + (e.attrs.length ? '<button onclick="moAddLike()" title="a new element next to this one with the same type, attributes and match ticks">+ one like this</button>' : '')
    + '<select id="mo-kind">' + Object.keys(MO.KINDS).map(function (k) { return '<option value="' + k + '"' + (k === e.kind ? ' selected' : '') + '>' + esc(MO.KINDS[k].label) + '</option>'; }).join('') + '</select><button onclick="moAddBlank()" title="a new, empty element of that spy mode under this one">+ blank child</button>'
    + (e.attrs.length ? '<button onclick="moFill()" title="paste the JSON a spy printed for this element: its values go into the attributes, ticks stay">fill from spy</button>' : '')
    + (SERVED && MO.KINDS[e.kind] ? '<button onclick="moSpy(false)" style="background:#2f5f9e;color:#fff;border-color:#2f5f9e" title="5 seconds to switch to the application and put the mouse on the control (a region: its two corners, one after the other); the values then fill this element">Spy this element</button>' : '')
    + (SERVED ? '<button onclick="moSpy(true)" title="spy a control (mode from the list on the left) and add it as a new element: inside this window, or next to this control">Spy a new element</button>' : '')
    + (SERVED && e.kind === 'application' ? '<button onclick="moLaunch()" title="start the application from the Path in this model (the last saved version)">Launch application</button>' : '')
    + (e.parent ? '<button onclick="moRemove()" style="margin-left:auto;color:#c62828">remove</button>' : '') + '</div><div class="muted">Values typed here are what Blue Prism will look for. "fill from spy" takes the JSON of a spied element (docs: copilot_mordecai_spy_handoff.md).</div>';
  $('sh-body').innerHTML = h; $('sheet').hidden = false; moTree();
}
// an Action stage names a Blue Prism internal object by its class (Blueprism.Automate.clsWorkQueuesActions): show it under its display name
function objAlias(name) { for (var i = 0; i < OBJ.length; i++) if ((OBJ[i].classes || []).indexOf(name) >= 0 || OBJ[i].cls === name) return OBJ[i].object; return name; }
window.moCreate = function () { var n = prompt('Name of the application (the root element):', M.name || 'Application'); if (!n) return; snap(); M.appdef = MO.create(n); moSync(); renderPage(); var p = MO.parse(M.appdef); openElement(p.list[0].id); };
window.moSetMode = function (mode) { moApply(function (t) { var cur = MO.parse(t).app, keep = {}; cur.params.forEach(function (x) { keep[x.name] = x.value; });
  if (!mode) { var a = t.indexOf('<apptypeinfo'), b = a < 0 ? -1 : t.indexOf('</apptypeinfo>', a); return a >= 0 && b >= 0 ? t.slice(0, a) + t.slice(b + '</apptypeinfo>'.length) : t; }
  var params = (MO.MODES[mode] ? MO.MODES[mode].params : cur.params.map(function (x) { return [x.name, x.value]; })).map(function (q) { return [q[0], keep[q[0]] != null ? keep[q[0]] : q[1]]; });
  return MO.setApp(t, mode, params); }); };
window.moSetParam = function (name, value) { moApply(function (t) { var cur = MO.parse(t).app; return MO.setApp(t, cur.mode, cur.params.map(function (x) { return [x.name, x.name === name ? value : x.value]; })); }); };
window.moSet = function (name, patch) { var id = selEl; moApply(function (t) { return MO.setAttribute(t, id, name, patch); }); };
window.moRename = function (name) { var id = selEl; moApply(function (t) { return MO.rename(t, id, name); }); };
window.moAddLike = function () { var id = selEl, e = MO.parse(moText()).byId[id], n = prompt('Name of the new element:', e.name + ' 2'); if (!n) return; moApply(function (t) { return MO.add(t, e.parent ? e.parent.id : id, n, { like: id }); }); };
window.moAddBlank = function () { var id = selEl, k = $('mo-kind').value, n = prompt('Name of the new ' + MO.KINDS[k].label + ' element:', ''); if (!n) return; moApply(function (t) { return MO.add(t, id, n, { kind: k }); }); };
window.moFill = function () { var id = selEl, raw = prompt('Paste the spy JSON for this element ({"attrs": {...}} or just {name: value}):', ''); if (!raw) return; var j; try { j = JSON.parse(raw); } catch (e) { return toast('not JSON: ' + e.message); }
  var res = null; if (moApply(function (t) { res = MO.fill(t, id, j.attrs || j); return res.appdef; })) toast(res.set.length + ' value(s) set' + (res.skipped.length ? ', ' + res.skipped.length + ' not in this element' : '')); };
// the spy, run by gumball: countdown here, the reading happens in PowerShell, the result lands in the element
var SPY_HINT = { sap: 'the SAP field', html: 'the element in the page (IE mode)', web: 'the element in the Edge page', region: 'the corner' };
function spyCall(mode, secs, say, extra) {   // one run of the spy with a countdown; resolves with its JSON
  var t = $('toast'), left = secs, tick = function () { t.hidden = false; clearTimeout(t._t); t.textContent = left > 0 ? say + ' ... ' + left : 'reading: keep the mouse there until this message changes'; };
  tick(); var iv = setInterval(function () { left--; tick(); if (left <= 0) clearInterval(iv); }, 1000);
  return fetch('/spy?mode=' + mode + '&seconds=' + secs + (extra || ''), { method: 'POST' }).then(function (r) { return r.json(); }).then(function (r) { clearInterval(iv); t.hidden = true; if (r.error) throw new Error(r.error); return r.spy; }, function (e) { clearInterval(iv); t.hidden = true; throw e; });
}
function spyRegion() {   // two corners, each held under the mouse, then the rectangle is captured
  var a;
  return spyCall('point', 5, 'REGION 1/2: switch to the application and hold the mouse on the TOP-LEFT corner').then(function (p1) { a = p1.point;
    return spyCall('point', 4, 'REGION 2/2: now hold the mouse on the BOTTOM-RIGHT corner'); }).then(function (p2) { var b = p2.point;
    if (!a || !b || b.x <= a.x || b.y <= a.y) throw new Error('the second corner has to be below and to the right of the first (got ' + JSON.stringify(a) + ' then ' + JSON.stringify(b) + ')');
    return spyCall('region', 0, 'capturing', '&x1=' + a.x + '&y1=' + a.y + '&x2=' + b.x + '&y2=' + b.y); });
}
window.moSpy = function (asNew) {
  var id = selEl, e = MO.parse(moText()).byId[id], pick = $('mo-kind') ? $('mo-kind').value : 'uia', ok = function (k) { return !!MO.KINDS[k]; };
  var mode = asNew ? (ok(pick) ? pick : ok(e.kind) ? e.kind : 'uia') : e.kind;
  var run = mode === 'region' ? spyRegion() : spyCall(mode, 5, 'SPY (' + MO.KINDS[mode].label + '): switch to the application and hold the mouse on ' + (SPY_HINT[mode] || 'the control'));
  run.then(function (j) {
    var n = Object.keys(j.attrs || {}).length, extra = mode === 'sap' ? ['SubType'] : [];
    if (!n) { alert('The spy found nothing readable there' + (j.errors ? ':\n' + j.errors.join('\n') : '.')); return; }
    var what = 'Found: ' + (j.name || '(no name)') + ' [' + (j.base || mode) + ']' + (j.errors && j.errors.length ? '\nNotes: ' + j.errors.join('; ') : '');
    if (asNew) {
      var name = prompt(what + '\nName of the new element:', j.name || ''); if (!name) return;
      var under = (e.kind === 'application' || e.children.length || /Window$/.test(e.base) || !e.parent) ? id : e.parent.id;   // next to a control, inside a window
      moApply(function (x) { var a = MO.add(x, under, name, { kind: mode, base: j.base || undefined }); var f = MO.fill(a.appdef, a.id, j.attrs, { addMissing: extra }); return { appdef: f.appdef, id: a.id }; });
      toast('added "' + name + '" with ' + n + ' values');
    } else {
      if (!confirm(what + '\n\nPut its ' + n + ' values into "' + e.name + '"? (ticks and comparison types stay; Ctrl+Z undoes it)')) return;
      var res = null; if (moApply(function (x) { res = MO.fill(x, id, j.attrs, { addMissing: extra }); return res.appdef; })) toast(res.set.length + ' value(s) changed' + (res.skipped.length ? ', ' + res.skipped.length + ' not in this element' : ''));
    }
    var un = Object.keys(j.unconfirmed || {}); if (un.length) console.log('spy, unconfirmed values (not used):', j.unconfirmed);
  }, function (err) { alert('Spy failed:\n\n' + (err && err.message || err)); });
};
window.moLaunch = function () {
  if (undo.length && !confirm('The application is started from the last SAVED version of this object. Continue?')) return;
  fetch('/launch?base=' + encodeURIComponent(BW_BASE) + (window.BW_SERVE.rel ? '&rel=' + encodeURIComponent(window.BW_SERVE.rel) : ''), { method: 'POST' }).then(function (r) { return r.json(); }).then(function (r) { if (r.error) alert(r.error); else toast('started ' + r.started); });
};
window.moRemove = function () { var id = selEl, e = MO.parse(moText()).byId[id], u = moUsed(), hit = []; (function walk(x) { if (u[x.id]) hit = hit.concat(u[x.id]); x.children.forEach(walk); })(e);
  if (!confirm('Remove "' + e.name + '"' + (e.children.length ? ' and the ' + e.children.length + ' element(s) under it' : '') + '?' + (hit.length ? '\n\nStill used by: ' + hit.slice(0, 12).join(', ') + (hit.length > 12 ? ', ...' : '') + '\nThose stages will point at nothing.' : ''))) return;
  selEl = null; $('sheet').hidden = true; moApply(function (t) { return MO.remove(t, id); }); };
if (MO && M.type === 'object' && moText()) moTree();
if (SERVED && window.BW_SERVE.problem) toast(window.BW_SERVE.problem);
// ---------- Run (served only): bprun executes the flow, the trace lands on the drawing like a Radar incident ----------
if (SERVED && $('runb')) $('runb').hidden = false;
function startInputs(pageName) {   // the Start stage's inputs of a page: [{name, type}]
  var bp = E.bpOf(M), st = bp.stages.filter(function (s) { return s.type === 'Start' && s.page === pageName; })[0], out = [];
  if (!st) return out; var re = /<input ([^>]*)\/>/g, m; while ((m = re.exec(st.body))) out.push({ name: D.attr(m[1], 'name'), type: D.attr(m[1], 'type') });
  return out;
}
var RUN_KEY = 'gumball:lastrun';   // the last run stays on every page it touched (the process and the objects it called) until Clear
window.clearRun = function () { ov.pages = {}; $('runpanel').hidden = true; $('runb').classList.remove('on'); try { localStorage.removeItem(RUN_KEY); } catch (e) { } renderAll(); };
function showRun(s, from) {
  $('runpanel').hidden = false; $('run-status').textContent = (from ? '(run of ' + from + ') ' : '') + s.status; $('run-sum').textContent = s.sum; $('run-log').textContent = s.log;
  if (s.incident) { var o2 = D.overlayFrom(s.incident); ov.pages = o2.pages; }
}
function restoreRun() {
  if (!SERVED || !$('runpanel') || BW_INCIDENT) return; var s = null;
  try { s = JSON.parse(localStorage.getItem(RUN_KEY) || 'null'); } catch (e) { }
  if (!s || !s.incident) return;
  var mine = String(M.name || '').trim().toLowerCase() + '|', touched = Object.keys(D.overlayFrom(s.incident).pages).some(function (k) { return k.indexOf(mine) === 0; });
  if (touched) showRun(s, s.base === BW_BASE ? '' : s.name || s.base);
}
window.runFlow = function () {
  if (!SERVED) return toast('Run works from the served page (gumball.cmd)');
  // Run takes the page as it is on screen, saved or not, and the drafts of the other objects of this project / release
  if (draftT) draftNow();
  var o = { xml: E.serialize(M), drafts: [] }, pg = pages()[cur];
  try { for (var di = 0; di < localStorage.length; di++) { var dk = localStorage.key(di); if (dk.indexOf(DRAFT_PRE) !== 0 || dk === DRAFT_KEY) continue; var dv = JSON.parse(localStorage.getItem(dk)); if (dv && dv.xml) o.drafts.push({ base: dk.slice(DRAFT_PRE.length), ver: dv.ver, xml: dv.xml }); } } catch (e) { }
  if (M.type === 'object') {
    // the page that is open is the action that runs; on Initialise there is nothing to pick from the drawing, so ask
    var act = pg === 'Main Page' ? prompt('Action to run (a page of this object):', pages()[1] || '') : pg; if (!act) return; o.action = act;
    var ins = startInputs(act), inputs = {};
    for (var i = 0; i < ins.length; i++) { var v = prompt('Input "' + ins[i].name + '" (' + ins[i].type + '):', ''); if (v === null) return; inputs[ins[i].name] = ins[i].type === 'flag' ? /^true$/i.test(v) : ins[i].type === 'number' ? Number(v || 0) : ins[i].type === 'collection' ? { columns: [], rows: [] } : v; }
    o.inputs = inputs;
  } else {
    var only = pg !== 'Main Page' && confirm('Run only the page "' + pg + '"?\n\nOK = this page alone, from its Start\nCancel = the whole process, from Main Page');
    if (only) o.action = pg;
    var pins = startInputs(only ? pg : 'Main Page'), pin = {};
    for (var k = 0; k < pins.length; k++) { var pv = prompt('Process input "' + pins[k].name + '" (' + pins[k].type + '):', ''); if (pv === null) return; pin[pins[k].name] = pins[k].type === 'flag' ? /^true$/i.test(pv) : pins[k].type === 'number' ? Number(pv || 0) : pv; }
    if (pins.length) o.inputs = pin;
  }
  var panel = $('runpanel'); panel.hidden = false; $('run-status').textContent = 'running...'; $('run-sum').textContent = ''; $('run-log').textContent = ''; $('runb').classList.add('on');
  var url = '/run?base=' + encodeURIComponent(BW_BASE) + (window.BW_SERVE.rel ? '&rel=' + encodeURIComponent(window.BW_SERVE.rel) : '');
  fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(o) }).then(function (r) { return r.json(); }).then(function (r) {
    $('runb').classList.remove('on');
    if (r.error) { $('run-status').textContent = 'could not run'; $('run-log').textContent = r.error; return; }
    $('run-status').textContent = (r.ok ? 'finished' : 'FAILED') + ' after ' + r.stages + ' stages' + (r.exception ? ': ' + r.exception.type + ' at "' + r.exception.stage + '": ' + r.exception.detail : '');
    var sum = [];
    if (r.host) sum.push(r.host.used ? 'code stages ran (' + r.host.code_objects + ' objects with code)' : 'code stages skipped: ' + (r.host.note || 'no stage host'));
    if (r.host && r.host.problems && r.host.problems.length) sum.push(r.host.problems.join('; '));
    if (r.skipped.length) sum.push(r.skipped.length + ' code stage calls skipped');
    var qn = Object.keys(r.queues || {}); if (qn.length) sum.push('queues: ' + qn.map(function (q) { var it = r.queues[q]; return q + ' ' + it.length + ' item' + (it.length === 1 ? '' : 's') + (it.length ? ' (' + it.filter(function (x) { return x.status === 'Completed'; }).length + ' completed, ' + it.filter(function (x) { return x.status === 'Exception'; }).length + ' exception)' : ''); }).join(', '));
    var on = Object.keys(r.outputs || {}); if (on.length) sum.push('outputs: ' + on.map(function (k) { return k + ' = ' + JSON.stringify(r.outputs[k]); }).join(', '));
    sum.push('run folder: ' + r.dir);
    $('run-sum').textContent = sum.join('  |  ');
    $('run-log').textContent = (r.log || []).join('\n') + (r.stderr ? '\n--- stderr ---\n' + r.stderr : '');
    if (r.incident) { var o2 = D.overlayFrom(r.incident); ov.pages = o2.pages; renderAll(); }
    try { localStorage.setItem(RUN_KEY, JSON.stringify({ base: BW_BASE, name: r.name, status: $('run-status').textContent, sum: $('run-sum').textContent, log: $('run-log').textContent, incident: r.incident })); } catch (e) { }
    toast(r.ok ? 'run finished: the path is on the drawing' : 'run failed at "' + (r.exception && r.exception.stage) + '"');
  }, function (e) { $('runb').classList.remove('on'); $('run-status').textContent = 'failed: ' + e; });
};
restoreRun();
// arriving from an Action stage: open the page that implements the action
(function () { var m = /[#&]page=([^&]+)/.exec(location.hash || ''); if (!m) return; var want = decodeURIComponent(m[1]), pg = pages(); for (var i = 0; i < pg.length; i++) if (pg[i] === want || label(pg[i]) === want) { cur = i; return; } toast('no page "' + want + '" in this object'); })();

// ---------- go ----------
if (BW_DIFF) {
  var d = BW_DIFF, parts = [];
  if (d.added.length) parts.push('<b>added</b> ' + d.added.map(esc).join(', '));
  if (d.removed.length) parts.push('<b>removed</b> ' + d.removed.map(esc).join(', '));
  if (d.renamed.length) parts.push('<b>renamed</b> ' + d.renamed.map(function (r) { return esc(r[0]) + ' &rarr; ' + esc(r[1]); }).join(', '));
  if (d.changed.length) parts.push('<b>changed</b> ' + d.changed.map(esc).join(', '));
  if (d.moved.length) parts.push('<b>moved</b> ' + d.moved.length + ' stage' + (d.moved.length === 1 ? '' : 's'));
  $('diff').innerHTML = parts.length ? 'v' + (BW_VER - 1) + ' &rarr; v' + BW_VER + ': ' + parts.join(' &middot; ') : 'v' + BW_VER + ': no changes against v' + (BW_VER - 1);
}
if (window.BW_SERVE) { var br = document.querySelector('.tb .brand'); if (br) { br.style.cursor = 'pointer'; br.title = window.BW_SERVE.home ? 'back to the release' : 'back to the inbox and projects'; br.onclick = function () { location.href = window.BW_SERVE.home || '/'; }; } }
setMode('select'); renderAll(); $('gridb').classList.toggle('on', document.body.classList.contains('grid'));
window.bw = { snap: snap, multi: function (ids) { multi = ids; highlight(null); }, model: M, redraw: renderAll, place: startPlace, open: openSheet, pages: pages, current: function () { return cur; } };   // for scripts and tests
})();
