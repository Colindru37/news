"""gumball's Run: extract every object's code-stage class, start a stage host when one can be built here, run bprun.

python bprun_run.py --xml <dir> [<dir>...] --run "<process>" [--action <name> --inputs '<json>'] [--env env.json] --json out.json [--bp <Blue Prism folder>]

Stage host, in this order: Windows -> stage_host.ps1 (Add-Type, in-process, nothing written to disk but .cs files);
elsewhere with mcs + mono -> a host built in the run folder; neither -> no host, bprun skips Code stages and says so.
"""
import sys, os, re, json, glob, shutil, subprocess, argparse
import xml.etree.ElementTree as ET
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import compile_check as cc
import bprun


def extract(xml_dirs, out, ref_dirs):
    """One .cs per object/process with code; returns (count, refs, problems)."""
    os.makedirs(out, exist_ok=True)
    refs, problems, n, seen = set(), [], 0, set()
    for d in xml_dirs:
        for p in sorted(glob.glob(os.path.join(d, '*.xml'))):
            try:
                root = bprun.parse_xml(p)
            except ET.ParseError as e:
                problems.append(f'{os.path.basename(p)}: {e}'); continue
            cc.strip_ns(root)
            name = root.get('name') or os.path.basename(p)
            if name in seen:
                continue           # two copies of one object (a release can carry both): the first one hosts the code
            seen.add(name)
            src, lang, cnt, _ = cc.build_source(root, name)
            if src is None:
                continue
            if lang not in ('csharp', 'vb'):
                problems.append(f'{name}: {lang} code stages cannot be hosted (C# and Visual Basic only)'); continue
            r, missing = cc.resolve_refs(root, ref_dirs)
            refs.update(r)
            for m in missing:
                problems.append(f'{name}: reference {m} not found (code stages that need it will fail)')
            with open(os.path.join(out, f'{n:02d}_{cc.ident(name)}.' + ('vb' if lang == 'vb' else 'cs')), 'w', encoding='utf-8') as f:
                f.write(src)
            n += 1
    return n, sorted(refs), problems


def _objname(path):
    """'02_MS_Excel_VBO.vb' -> 'MS Excel VBO' (as close as the file name allows)."""
    return re.sub(r'^\d+_', '', os.path.splitext(os.path.basename(path))[0]).replace('___', ' - ').replace('_', ' ')


def host_for(srcdir, refs, workdir):
    """A command list for the stage host, or (None, why)."""
    shutil.copy(os.path.join(HERE, 'StageServer.cs'), os.path.join(srcdir, 'zz_StageServer.cs'))
    reffile = os.path.join(workdir, 'refs.txt')
    with open(reffile, 'w', encoding='utf-8') as f:
        f.write('\n'.join(refs))
    if os.name == 'nt':
        ps = shutil.which('powershell') or shutil.which('pwsh')
        if not ps:
            return None, 'PowerShell not found'
        return [ps, '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', os.path.join(HERE, 'stage_host.ps1'), srcdir, reffile], ''
    mcs, mono = shutil.which('mcs'), shutil.which('mono')
    if not (mcs and mono):
        return None, 'no C# compiler here (mcs + mono): code stages skipped'
    out = os.path.join(workdir, 'stage_host.bin')
    vbs = sorted(glob.glob(os.path.join(srcdir, '*.vb'))); vb_note = ''
    if vbs:       # Visual Basic objects: one library next to the host, which loads it at start
        vbc = shutil.which('vbc')
        lib = os.path.join(workdir, 'stage_vb.dll')
        # off Windows there is usually no Microsoft.VisualBasic.dll to run against: -vbruntime* embeds the runtime's core (operators,
        # conversions). Code that calls its library functions (Len, Mid, MsgBox ..) will not compile here; on Windows the full runtime is used.
        def vb(files, to):
            return subprocess.run([vbc, '-nologo', '-target:library', '-optionstrict-', '-nowarn', '-vbruntime*', '-out:' + to] + ['-r:' + r for r in sorted(set(refs) | {'System.dll', 'System.Core.dll', 'System.Data.dll', 'System.Xml.dll', 'System.Drawing.dll'})] + files, capture_output=True, text=True)
        rv = vb(vbs, lib) if vbc else None
        if rv is None:
            vb_note = 'no Visual Basic compiler here (vbc): the Visual Basic code stages are skipped'
        elif rv.returncode != 0:      # one object that does not compile must not cost the others: find which, build the rest
            first = (rv.stdout + rv.stderr).strip()
            good = [f for f in vbs if vb([f], lib + '.try').returncode == 0]
            bad = [_objname(f) for f in vbs if f not in good]
            if os.path.exists(lib + '.try'):
                os.remove(lib + '.try')
            if os.path.exists(lib):
                os.remove(lib)
            if good and vb(good, lib).returncode != 0 and os.path.exists(lib):
                os.remove(lib)
            vb_note = 'Visual Basic code stages of ' + (', '.join(bad) or 'some objects') + ' did not compile here, they are skipped:\n' + first[:1200]
    cmd = [mcs, '-langversion:5', '-nowarn:0162,0168,0219,0414,0649', '-target:exe', '-out:' + out] + ['-r:' + r for r in sorted(set(refs) | {'System.Web.Extensions.dll'})] + sorted(glob.glob(os.path.join(srcdir, '*.cs')))   # the host itself needs that reference (stage_host.ps1 always passes it)
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:             # the same for C#: leave out the objects that do not compile on their own, keep the rest
        first = (r.stdout + r.stderr).strip()
        cs = sorted(glob.glob(os.path.join(srcdir, '*.cs'))); core = [f for f in cs if os.path.basename(f).startswith('zz_')]
        objs = [f for f in cs if f not in core]
        rf = ['-r:' + x for x in sorted(set(refs) | {'System.Web.Extensions.dll'})]
        good = [f for f in objs if subprocess.run([mcs, '-langversion:5', '-nowarn:0162,0168,0219,0414,0649', '-target:library', '-out:' + out + '.try'] + rf + [f], capture_output=True, text=True).returncode == 0]
        if os.path.exists(out + '.try'):
            os.remove(out + '.try')
        bad = [_objname(f) for f in objs if f not in good]
        r = subprocess.run([mcs, '-langversion:5', '-nowarn:0162,0168,0219,0414,0649', '-target:exe', '-out:' + out] + rf + good + core, capture_output=True, text=True) if bad else r
        if r.returncode != 0:
            return None, 'stage host did not compile:\n' + first[:2000]
        vb_note = (vb_note + '\n' if vb_note else '') + 'C# code stages of ' + ', '.join(bad) + ' did not compile, they are skipped:\n' + first[:1200]
    return [mono, out], vb_note


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--xml', nargs='+', required=True)
    ap.add_argument('--run', required=True)
    ap.add_argument('--action')
    ap.add_argument('--inputs')
    ap.add_argument('--env')
    ap.add_argument('--json', required=True)
    ap.add_argument('--bp', help='Blue Prism install folder (for referenced DLLs)')
    ap.add_argument('--fail')
    ap.add_argument('--no-host', action='store_true', help='skip code stages even if a host could be built')
    a = ap.parse_args()
    work = os.path.dirname(os.path.abspath(a.json))
    srcdir = os.path.join(work, 'src')
    ref_dirs = [a.bp] if a.bp and os.path.isdir(a.bp) else []
    n, refs, problems = extract(a.xml, srcdir, ref_dirs)
    host, why = (None, 'code stages skipped on request') if a.no_host else ((None, 'no code stages') if n == 0 else host_for(srcdir, refs, work))
    if host and why:              # the host runs, with a remark (Visual Basic objects left out)
        problems.append(why); why = ''
    cmd = [sys.executable, '-I', os.path.join(HERE, 'bprun.py'), '--xml'] + a.xml + ['--run', a.run, '--json', a.json]
    if a.action:
        cmd += ['--action', a.action]
    if a.inputs:
        cmd += ['--inputs', a.inputs]
    if a.env:
        cmd += ['--env', a.env]
    if a.fail:
        cmd += ['--fail', a.fail]
    if host:
        cmd += ['--server-cmd', json.dumps(host)]
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=1800)
    try:
        with open(a.json, encoding='utf-8') as f:
            res = json.load(f)
    except Exception:
        res = {'ok': False, 'exception': {'type': 'bprun', 'detail': (r.stdout + r.stderr).strip()[-3000:], 'stage': ''}, 'log': []}
    res['host'] = {'code_objects': n, 'used': bool(host), 'note': why, 'problems': problems}
    if r.stderr.strip() and not res.get('ok'):
        res['stderr'] = r.stderr.strip()[-3000:]
    with open(a.json, 'w', encoding='utf-8') as f:
        json.dump(res, f, indent=1, ensure_ascii=False)   # one field per line: it gets opened in Notepad
    print('HOST:', 'yes' if host else 'no (' + why + ')', '| RESULT:', 'ok' if res.get('ok') else 'failed')
    sys.exit(0)


if __name__ == '__main__':
    main()
