// Darwin: Gumball's link to GitHub Copilot. Gumball (a local web page) cannot reach a model; this extension can, through the
// VS Code Language Model API (vscode.lm), the same door Sheriff uses. It is deliberately dumb: Gumball writes a question as
// <jobs>/<id>/prompt.md, this asks Copilot and writes <jobs>/<id>/answer.md (or error.txt). What to ask, what to do with the
// answer, and every rule about it live in Gumball. Nothing outside the jobs folder is read or written.
'use strict';
const vscode = require('vscode');
const fs = require('fs');
const os = require('os');
const path = require('path');

let out, status, timer, paused = false, busy = false, ctx;
function cfg() { return vscode.workspace.getConfiguration('darwin'); }
function log(s) { out.appendLine(new Date().toISOString().slice(11, 19) + ' ' + s); }
function setStatus(t) { status.text = '$(beaker) Darwin: ' + t; status.show(); }
function jobsDir() {
  const set = cfg().get('jobs'); if (set) return set;
  try { return JSON.parse(fs.readFileSync(path.join(os.tmpdir(), 'gumball-darwin.json'), 'utf8')).jobs || ''; } catch (e) { return ''; }
}

function activate(context) {
  ctx = context;
  out = vscode.window.createOutputChannel('Darwin');
  status = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 49);
  status.command = 'darwin.showLog';
  context.subscriptions.push(out, status);
  context.subscriptions.push(vscode.commands.registerCommand('darwin.scanNow', () => scan(true)));
  context.subscriptions.push(vscode.commands.registerCommand('darwin.showLog', () => out.show(true)));
  context.subscriptions.push(vscode.commands.registerCommand('darwin.pause', () => { paused = !paused; log(paused ? 'paused' : 'resumed'); setStatus(paused ? 'paused' : 'waiting'); }));
  context.subscriptions.push(vscode.workspace.onDidChangeConfiguration(e => { if (e.affectsConfiguration('darwin')) restart(); }));
  log('started; jobs folder: ' + (jobsDir() || '(none yet: start Gumball once, or set darwin.jobs)'));
  listModels(); restart(); setStatus('waiting');
}
function restart() {
  if (timer) clearInterval(timer);
  timer = setInterval(() => scan(false), Math.max(1, Number(cfg().get('pollSeconds')) || 3) * 1000);
  ctx.subscriptions.push({ dispose: () => clearInterval(timer) });
}
async function listModels() {
  try { const m = await vscode.lm.selectChatModels({ vendor: 'copilot' }); log('copilot models available: ' + (m.length ? m.map(x => x.family + ' (' + x.name + ')').join('; ') : 'NONE (is GitHub Copilot Chat installed and signed in?)')); }
  catch (e) { log('listing models failed: ' + e.message); }
}
// a question is open when it has a prompt and neither an answer nor an error; "taken" keeps a second window from asking twice
function openJobs(dir) {
  let ids = []; try { ids = fs.readdirSync(dir); } catch (e) { return []; }
  return ids.filter(id => { const d = path.join(dir, id); try { if (!fs.existsSync(path.join(d, 'prompt.md')) || fs.existsSync(path.join(d, 'answer.md')) || fs.existsSync(path.join(d, 'error.txt'))) return false; const t = path.join(d, 'taken'); return !fs.existsSync(t) || Date.now() - fs.statSync(t).mtimeMs > 6 * 60 * 1000; } catch (e) { return false; } }).sort();
}
async function scan(manual) {
  if (busy || (paused && !manual)) return;
  const dir = jobsDir(); if (!dir) { if (manual) vscode.window.showWarningMessage('Darwin: no jobs folder. Start Gumball once, or set darwin.jobs.'); return; }
  const ids = openJobs(dir); if (!ids.length) { if (manual) log('nothing to answer in ' + dir); return; }
  busy = true;
  try {
    for (const id of ids) {
      const d = path.join(dir, id); fs.writeFileSync(path.join(d, 'taken'), new Date().toISOString());
      setStatus('asking'); log('question ' + id);
      try {
        const prompt = fs.readFileSync(path.join(d, 'prompt.md'), 'utf8');
        const r = cfg().get('backend') === 'dry' ? { text: 'DRY RUN: the pipe works. The question was ' + prompt.length + ' characters long. No model was asked.', model: 'dry' } : await askCopilot(prompt);
        fs.writeFileSync(path.join(d, 'model.txt'), r.model, 'utf8');
        fs.writeFileSync(path.join(d, 'answer.md'), r.text, 'utf8');
        log('answered ' + id + ' (' + r.model + ', ' + r.text.length + ' characters)');
      } catch (e) { fs.writeFileSync(path.join(d, 'error.txt'), String(e.message || e), 'utf8'); log('failed ' + id + ': ' + e.message); }
    }
  } finally { busy = false; setStatus(paused ? 'paused' : 'waiting'); }
}
async function askCopilot(prompt) {
  const fam = cfg().get('modelFamily');
  let models = await vscode.lm.selectChatModels(fam ? { vendor: 'copilot', family: fam } : { vendor: 'copilot' });
  if (!models.length && fam) { log('model family "' + fam + '" not available, using the first Copilot model'); models = await vscode.lm.selectChatModels({ vendor: 'copilot' }); }
  if (!models.length) throw new Error('no Copilot chat model available (Copilot Chat signed in? org policy allows extension access to models?)');
  const model = models[0]; log('asking ' + model.family + ' (' + model.name + ')');
  const cts = new vscode.CancellationTokenSource(), t = setTimeout(() => cts.cancel(), 240000);
  try { const resp = await model.sendRequest([vscode.LanguageModelChatMessage.User(prompt)], {}, cts.token); let text = ''; for await (const chunk of resp.text) text += chunk; return { text, model: model.family }; }
  catch (e) { if (e instanceof vscode.LanguageModelError) throw new Error('LanguageModelError ' + e.code + ': ' + e.message + ' (NoPermissions = not consented yet or blocked by the organisation; Blocked = content filter)'); throw e; }
  finally { clearTimeout(t); }
}
function deactivate() { if (timer) clearInterval(timer); }
module.exports = { activate, deactivate, openJobs };
