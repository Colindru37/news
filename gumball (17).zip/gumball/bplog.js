// A Blue Prism session log (the CSV the Control Room exports) read into the rows the walk steps through.
//
// Layout it reads (the "BPA Partial Session Log" seen on the bank machine, 2026-10-22): one line per stage with the columns
//   LogNumber, StageID, StageName, StageType, Process, Page, Object, Action, Result, ResultType, Resource Start, Resource End,
//   ..., Direction, Name, Type, Value
// A stage inside an object has Object and Action filled and Process empty. In an Errors Only log the last four columns are
// empty. The complete export ("BPA Complete Session Log", seen 2026-11-18) has the same columns with the parameters filled: each
// parameter is one more line that repeats the LogNumber, and a collection parameter is one line per cell (columns Field, Row).
// A full log (seen 2026-11-18, exported with the columns StageName, StageType, Result, Direction, Name, Type, Value):
// the stage is one line, each of its parameters is one more line under it with the first columns empty and Direction
// (IN / OUT), Name, Type, Value filled; values are HTML-escaped. An Action's line carries its inputs AND its outputs, and
// the stages that ran inside the action follow it.
//
// That export has no Process / Page / Object columns. Then the place of every line is worked out by following the XML from
// the process the log belongs to: an Action line leads into the page of the object it names, an End line leads back.
//
// A log says what went in and out of a STAGE. Which DATA ITEM that changed is in the XML (an output is stored in an item, a
// calculation has a Store In). So with the XML a row gets `set` like a Run's rows; without it the row is marked `unknown`
// and only carries its parameters.
'use strict';
const D = require('./bpdraw');

function parseCsv(text) {
  text = String(text || '').replace(/^﻿/, '');
  const first = text.slice(0, text.search(/\r?\n|$/)), sep = (first.match(/;/g) || []).length > (first.match(/,/g) || []).length ? ';' : (first.match(/\t/g) || []).length > (first.match(/,/g) || []).length ? '\t' : ',';
  const rows = []; let row = [], cell = '', q = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) { if (c === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else q = false; } else cell += c; }
    else if (c === '"') q = true;
    else if (c === sep) { row.push(cell); cell = ''; }
    else if (c === '\n' || c === '\r') { if (c === '\r' && text[i + 1] === '\n') i++; row.push(cell); cell = ''; if (row.length > 1 || row[0] !== '') rows.push(row); row = []; }
    else cell += c;
  }
  row.push(cell); if (row.length > 1 || row[0] !== '') rows.push(row);
  if (!rows.length) return [];
  const key = h => String(h || '').toLowerCase().replace(/[^a-z]/g, ''), head = rows[0].map(key);
  return rows.slice(1).map(r => { const o = {}; head.forEach((h, i) => { if (h && !(h in o)) o[h] = r[i] == null ? '' : r[i]; }); return o; });
}
const norm = n => String(n == null ? '' : n).replace(/\s+/g, ' ').trim().toLowerCase();
function paramsOf(line) { const d = String(line.direction || '').trim(); return d && line.name ? { dir: /^o/i.test(d) ? 'out' : 'in', name: line.name, type: String(line.type || '').toLowerCase(), value: D.unx(line.value == null ? '' : line.value) } : null; }   // the export writes < as &lt;
function when(s) { const t = Date.parse(String(s || '').replace(/^(\d{2})[./](\d{2})[./](\d{4})/, '$3-$2-$1')); return isNaN(t) ? null : t; }
const TYPES = { 'sub sheet': 'SubSheet', 'sub-sheet': 'SubSheet', subsheet: 'SubSheet', page: 'SubSheet', 'multiple calculation': 'MultipleCalculation', multicalc: 'MultipleCalculation', 'loop start': 'LoopStart', 'loop end': 'LoopEnd', 'choice start': 'ChoiceStart', 'choice end': 'ChoiceEnd', 'wait start': 'WaitStart', 'wait end': 'WaitEnd', wait: 'WaitStart', choice: 'ChoiceStart' };
function typeName(t) { const k = norm(t); return TYPES[k] || String(t || '').replace(/\s+/g, '') || 'Undefined'; }

// lines of the CSV -> one record per stage, with its parameters
function stagesOf(lines) {
  const out = []; let cur = null;
  for (const l of lines) {
    const p = paramsOf(l), sameStage = cur && !!l.lognumber && l.lognumber === cur.lognumber, bare = !l.stagename && !l.stagetype;
    if (!cur || !(sameStage || bare)) { if (!l.stagename && !l.stagetype && !p) continue; cur = Object.assign({}, l, { params: [] }); out.push(cur); }
    if (p) {
      // a collection parameter is spread over one line per cell (columns Field and Row): gathered back into one parameter
      const cellOf = String(l.field || '').trim() !== '' || String(l.row || '').trim() !== '';
      if (cellOf) { let c = cur.params.find(x => x.cells && x.dir === p.dir && x.name === p.name); if (!c) { c = { dir: p.dir, name: p.name, type: 'collection', cells: [] }; cur.params.push(c); } c.cells.push({ row: String(l.row || '').trim(), field: String(l.field || '').trim(), value: p.value }); }
      else cur.params.push(p);
    }
  }
  for (const st of out) for (const p of st.params) if (p.cells) {
    const rows = []; for (const c of p.cells) { let r = rows.find(x => x.k === c.row); if (!r) { r = { k: c.row, v: {} }; rows.push(r); } r.v[c.field] = c.value; }
    const head = JSON.stringify(rows.slice(0, 3).map(r => r.v)); p.value = rows.length + ' row' + (rows.length === 1 ? '' : 's') + ': ' + (head.length <= 400 ? head : head.slice(0, 400) + '..'); delete p.cells;
  }
  return out;
}

// Where each line ran, for a log without location columns: follow the XML. `stages` are the stage lines in order, `bpOf` gives
// the parsed XML of a name, `root` is the process the log is of. Fills s.object / s.action or s.process / s.page.
function locate(stages, bpOf, root) {
  const rootBp = bpOf(root); if (!rootBp) return false;
  const stack = [{ name: rootBp.name, bp: rootBp, page: 'Main Page', object: rootBp.type === 'object' }]; let pending = null;
  const find = (fr, s) => { if (!fr.bp) return null; const t = typeName(s.stagetype), on = fr.bp.stages.filter(x => norm(x.page) === norm(fr.page)); return on.find(x => x.name === s.stagename && x.type === t) || on.find(x => x.name === s.stagename) || (t === 'Code' ? on.find(x => x.type === 'Code' && 'Run ' + x.name === s.stagename) : null) || null; };
  const put = (s, fr) => { if (fr.object) { s.object = fr.name; s.action = fr.page; } else { s.process = fr.name; s.page = fr.page; } };
  for (let i = 0; i < stages.length; i++) {
    const s = stages[i], t = typeName(s.stagetype); if (t === 'Undefined') continue;
    let top = stack[stack.length - 1], st = null;
    if (t === 'Start' && pending) {
      // a Start right after an Action line: the called page begins. A "Start, End, Start" run is the object's Initialise page first.
      const n1 = stages[i + 1], n2 = stages[i + 2], pre = pending.kind === 'object' && !!n1 && typeName(n1.stagetype) === 'End' && !!n2 && typeName(n2.stagetype) === 'Start';
      const bp = pending.kind === 'page' ? top.bp : bpOf(pending.name);
      const fr = { name: pending.kind === 'page' ? top.name : (bp ? bp.name : pending.name), bp, page: pre ? 'Main Page' : pending.page, object: pending.kind === 'page' ? top.object : pending.kind === 'object', pre };
      stack.push(fr); if (!pre) pending = null; top = fr; st = find(fr, s);
    } else {
      st = find(top, s);
      // Inside an object we have no XML for, nothing can be matched: its lines stay there until its own End (pages it calls in
      // turn are counted by their Start / End), or until a Recover of a caller shows that an exception left it.
      if (!top.bp) { if (t === 'Start') top.depth = (top.depth || 0) + 1; }
      if (!st && (top.bp || t === 'Recover')) for (let d = stack.length - 2; d >= 0; d--) {   // not on this page: the run went back up (inner stages not logged, or an exception unwound)
        const hit = find(stack[d], s); if (hit) { stack.length = d + 1; top = stack[d]; st = hit; pending = null; break; }
      }
    }
    put(s, top);
    if (st && st.type === 'Action') { const r = /<resource [^>]*>/.exec(st.body); pending = r ? { kind: 'object', name: D.unx(D.attr(r[0], 'object') || ''), page: D.unx(D.attr(r[0], 'action') || '') } : null; }
    else if (st && st.type === 'SubSheet') { const id = D.tag(st.body, 'processid'); pending = { kind: 'page', page: (top.bp.pages && top.bp.pages[id]) || id }; }
    else if (st && st.type !== 'Start' && st.type !== 'End') pending = null;
    if (t === 'End' && stack.length > 1) { if (top.bp) { if (st) stack.pop(); } else if (top.depth > 0) top.depth--; else stack.pop(); }
  }
  return true;
}

// xmlFor(name) -> the XML of the process / object of that name, or null. `root`: the process the log is of (needed when the
// log has no Process / Object columns). Returns { rows, missing: [names], known: [names], located: 'columns' | 'followed' | null }.
function rowsFrom(text, xmlFor, root, isInternal) {   // isInternal(name): one of Blue Prism's built-in objects (Work Queues, Collections ..): it has no pages, nothing to draw or rebuild
  const all = stagesOf(parseCsv(text)), hasPlace = all.some(s => String(s.process || '').trim() || String(s.object || '').trim());
  const rows = [], bps = {}, missing = new Set(), known = new Set();
  const internal = new Set(), builtIn = name => /\bcls\w+(Actions|BusinessObject)$/.test(String(name)) || !!(isInternal && isInternal(name));
  const bpOf = name => { const k = norm(name); if (!(k in bps)) { let x = null; if (!builtIn(name)) try { x = xmlFor(name); } catch (e) { }   /* a built-in object is never looked up: an old rebuilt copy of one must not stand in for it */ bps[k] = x ? D.parseBp(x) : null; if (k) { if (bps[k]) known.add(name); else if (builtIn(name)) internal.add(name); else missing.add(name); } } return bps[k]; };
  let located = hasPlace ? 'columns' : null;
  if (!hasPlace && root && locate(all, bpOf, root)) located = 'followed';
  const stages = all.filter(s => String(s.process || '').trim() || String(s.object || '').trim());
  const frames = {}; let fseq = 0, n = 0;
  for (const s of stages) {
    const inObject = !!String(s.object || '').trim(), process = inObject ? s.object.trim() : String(s.process || '').trim(), page = (inObject ? (s.action || s.page) : s.page) || 'Main Page';
    const type = typeName(s.stagetype), key = norm(process) + '|' + norm(page);
    if (type === 'Start' || !(key in frames)) frames[key] = ++fseq;
    const t0 = when(s.resourcestart), t1 = when(s.resourceend), result = String(s.result || '');
    const row = { n: ++n, f: frames[key], process, page: page === 'Initialise' ? 'Main Page' : page, stage: s.stagename, type, ms: t0 != null && t1 != null ? Math.max(0, t1 - t0) : 0, at: s.resourcestart || '' };
    if (/^\s*ERROR\b/i.test(result)) row.error = result.replace(/^\s*ERROR:?\s*/i, '');
    if (s.params.length) row.params = s.params;
    const bp = process ? bpOf(process) : null, lid = String(s.stageid || '').trim().toLowerCase(), st = bp && ((lid && bp.stages.find(x => String(x.xmlId || x.id).toLowerCase() === lid && norm(x.page) === norm(row.page))) || bp.stages.find(x => x.name === s.stagename && norm(x.page) === norm(row.page) && x.type === type) || bp.stages.find(x => x.name === s.stagename && norm(x.page) === norm(row.page)));
    if (st) row.sid = st.id;                 // the log's Stage ID: two stages of one name on a page are told apart by it
    if (!st) row.unknown = bp ? 'stage' : internal.has(process) ? 'internal' : 'object';        // no XML for it (object), or the XML has no such stage on that page (stage)
    else {
      const set = {}, outs = s.params.filter(p => p.dir === 'out'), ins = s.params.filter(p => p.dir === 'in');
      const map = (tagName, list) => { const re = new RegExp('<' + tagName + ' ([^>]*)/?>', 'g'); let m; while ((m = re.exec(st.body))) { const nm = D.unx(D.attr(m[1], 'name') || ''), to = D.unx(D.attr(m[1], 'stage') || ''), p = list.find(x => norm(x.name) === norm(nm)); if (p && to) set[to] = p.value; } };
      if (type === 'Calculation' && !row.error) { const c = /<calculation ([^>]*)\/?>/.exec(st.body), to = c ? D.unx(D.attr(c[1], 'stage') || '') : ''; if (to && result !== '') set[to] = result; }
      else if (type === 'Start') map('input', ins);
      else if (!row.error) map('output', outs);
      if (Object.keys(set).length) row.set = set;
    }
    if (result && !row.error && (type === 'Decision' || type === 'Calculation')) row.result = result;
    rows.push(row);
  }
  return { rows, missing: [...missing], known: [...known], internal: [...internal], located };
}
// ---------------- Darwin: an object the log went through but gumball has no XML for, rebuilt from the log ----------------
// Only what the log shows: the pages that ran, on each page the stages that ran (once each, in the order first seen), linked the
// way the run went from one to the next, and data items for the values that went in and out. Branches the run did not take, the
// expressions, the code and the application model are NOT in a log and are not invented. The process tag carries
// gumball="reconstructed": the studio draws such an object dashed and says so.
const XTYPES = new Set(['Start', 'End', 'Action', 'Calculation', 'MultipleCalculation', 'Decision', 'Code', 'SubSheet', 'Exception', 'Recover', 'Resume', 'LoopStart', 'LoopEnd', 'Anchor', 'Note', 'Navigate', 'Read', 'Write', 'WaitStart', 'WaitEnd', 'ChoiceStart', 'ChoiceEnd', 'Alert', 'Process']);
function reconstruct(name, rows, when) {
  const X = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const crypto = require('crypto'), id = () => crypto.randomUUID(), dt = t => (/^(text|number|flag|date|datetime|time|timespan|password|collection|image|binary)$/.test(t) ? t : 'text');
  const pages = new Map(), page = p => { if (!pages.has(p)) pages.set(p, { id: id(), stages: new Map(), items: new Map() }); return pages.get(p); };
  page('Main Page');
  const last = {};                                     // per execution of a page: the stage the run was on
  for (const r of rows) {
    const pg = page(r.page), type = XTYPES.has(r.type) ? r.type : 'Note', key = type + '|' + r.stage;
    if (!pg.stages.has(key)) pg.stages.set(key, { id: id(), name: r.stage, type, ins: new Map(), outs: new Map(), next: new Map(), t: null, f: null });
    const st = pg.stages.get(key);
    for (const p of r.params || []) { (p.dir === 'in' ? st.ins : st.outs).set(p.name, dt(p.type)); if ((type === 'Start' && p.dir === 'in') || (type !== 'Start' && type !== 'Code' && p.dir === 'out')) pg.items.set(p.name, dt(p.type)); }
    const prev = last[r.f];
    if (prev && prev.key !== key && !prev.error && !r.again && type !== 'Recover') {   // the run went from prev to this stage; a Recover is only ever reached by an exception, never by a link
      const from = pg.stages.get(prev.key);
      if (from) { if (from.type === 'Decision' && /^true$/i.test(prev.result || '')) from.t = from.t || st.id; else if (from.type === 'Decision' && /^false$/i.test(prev.result || '')) from.f = from.f || st.id; else from.next.set(st.id, (from.next.get(st.id) || 0) + 1); }
    }
    last[r.f] = { key, error: !!r.error, result: r.result };
  }
  const out = ['<process name="' + X(name) + '" version="1.0" bpversion="7.2.1.15451" narrative="RECONSTRUCTED by gumball from a session log' + (when ? ' on ' + X(when) : '') + '. It holds only what that log shows: the stages that ran, in the order they ran. Branches not taken, expressions, code and the application model are missing. Not the real object: do not import it into Blue Prism." byrefcollection="true" type="object" runmode="Exclusive" gumball="reconstructed">'];
  for (const [pn, pg] of pages) if (pn !== 'Main Page') out.push('<subsheet subsheetid="' + pg.id + '" type="Normal" published="True"><name>' + X(pn) + '</name><view><camerax>0</camerax><cameray>0</cameray><zoom version="2">1.25</zoom></view></subsheet>');
  for (const [pn, pg] of pages) {
    const ss = pn === 'Main Page' ? '' : '<subsheetid>' + pg.id + '</subsheetid>';
    if (![...pg.stages.values()].some(s => s.type === 'Start')) { const a = id(), b = id(); out.push('<stage stageid="' + a + '" name="Start" type="Start">' + ss + '<display x="15" y="-105" w="60" h="30" /><onsuccess>' + b + '</onsuccess></stage>', '<stage stageid="' + b + '" name="End" type="End">' + ss + '<display x="15" y="-45" w="60" h="30" /></stage>'); }
    let y = -105;
    for (const st of pg.stages.values()) {
      const nx = [...st.next.entries()].sort((a, b) => b[1] - a[1]).map(e => e[0]), io = (m, tag, to) => m.size ? '<' + tag + 's>' + [...m].map(([n, t]) => '<' + tag + ' type="' + t + '" name="' + X(n) + '" ' + (to ? 'stage="' + X(n) + '"' : 'expr=""') + ' />').join('') + '</' + tag + 's>' : '';
      let inner = '';
      if (st.type === 'Start') inner = io(st.ins, 'input', true);
      else if (st.type === 'End') inner = io(st.outs, 'output', true);
      else if (st.type === 'Action') inner = '<resource object="" action="" />' + io(st.ins, 'input', false) + io(st.outs, 'output', true);
      else if (st.type === 'Decision') inner = '<decision expression="" />';
      else if (st.type === 'Calculation') inner = '<calculation expression="" stage="" />';
      else if (st.type === 'Exception') inner = '<exception localized="yes" type="" detail="" />';
      else if (st.type === 'Note') inner = '<narrative>' + X('in the log as stage type: ' + st.type) + '</narrative>';
      const links = st.type === 'Decision' ? (st.t ? '<ontrue>' + st.t + '</ontrue>' : '') + (st.f ? '<onfalse>' + st.f + '</onfalse>' : '') : (nx[0] && st.type !== 'End' && st.type !== 'Exception' ? '<onsuccess>' + nx[0] + '</onsuccess>' : '');
      out.push('<stage stageid="' + st.id + '" name="' + X(st.name) + '" type="' + st.type + '">' + ss + '<loginhibit onsuccess="true" /><display x="15" y="' + y + '" w="' + (st.type === 'Start' || st.type === 'End' ? 60 : 120) + '" h="30" />' + inner + links + '</stage>');
      y += 60;
    }
    let iy = -105;
    for (const [n, t] of pg.items) { out.push('<stage stageid="' + id() + '" name="' + X(n) + '" type="' + (t === 'collection' ? 'Collection' : 'Data') + '">' + ss + '<display x="255" y="' + iy + '" w="120" h="30" /><datatype>' + t + '</datatype><initialvalue /><private /><alwaysinit /></stage>'); iy += 45; }
  }
  out.push('</process>');
  return out.join('\n');
}
module.exports = { parseCsv, stagesOf, rowsFrom, reconstruct };
