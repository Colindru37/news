// Darwin, Gumball's side: what to ask the model, where the question goes, what is done with the answer.
// The model is reached by the Darwin VS Code extension (darwin-ext/), which only carries prompt.md to Copilot and brings
// answer.md back. Everything here is plain files under <gumball>/darwin/jobs/<id>/ so it can be read, tested and checked by hand.
'use strict';
const fs = require('fs'), os = require('os'), path = require('path');
const D = require('./bpdraw');

const jobsDir = here => path.join(here, 'darwin', 'jobs');
// the running Gumball says where its jobs are, so the extension needs no setting
function announce(here) { try { fs.mkdirSync(jobsDir(here), { recursive: true }); fs.writeFileSync(path.join(os.tmpdir(), 'gumball-darwin.json'), JSON.stringify({ jobs: jobsDir(here), at: new Date().toISOString() }), 'utf8'); } catch (e) { } }

// What must not leave the machine in a question: account numbers, personal numbers, mail addresses, anything typed as a password.
function scrub(text) {
  return String(text == null ? '' : text)
    .replace(/\b[A-Z]{2}\d{2}(?:[ ]?[A-Z0-9]{4}){2,7}(?:[ ]?[A-Z0-9]{1,4})?\b/g, '[IBAN]')
    .replace(/\b[1-9]\d{12}\b/g, '[CNP]')
    .replace(/\b\d{12,19}\b/g, '[NUMBER]')
    .replace(/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g, '[EMAIL]');
}
const short = (v, n) => { v = String(v == null ? '' : v).replace(/\s+/g, ' '); return v.length > n ? v.slice(0, n) + '..' : v; };
function rowLine(r) {
  const ps = (r.params || []).map(p => p.dir + ' ' + p.name + '=' + (p.type === 'password' ? '[PASSWORD]' : short(p.value, 160))).join('; ');
  const set = Object.keys(r.set || {}).map(k => k + '=' + short(r.set[k], 160)).join('; ');
  return [r.n + (r.at ? ' @' + String(r.at).replace(/^.*[ T]/, '') : ''), r.process + ' / ' + r.page, r.type, r.stage, ps ? 'params: ' + ps : '', set ? 'sets: ' + set : '', r.result ? 'result: ' + short(r.result, 120) : '', r.error ? 'ERROR: ' + short(r.error, 400) : ''].filter(x => x !== '').join(' | ');
}
// one line per stage of a page: what the XML says the stage does
function pageLines(bp, page) {
  const idName = {}; for (const s of bp.stages) idName[s.id] = s.name;
  return bp.stages.filter(s => s.page === page && !/^(SubSheetInfo|ProcessInfo|Block|Note)$/.test(s.type)).map(s => { let d = ''; try { d = D.describe(s, bp, idName); } catch (e) { } return '- ' + s.type + ' "' + s.name + '"' + (d ? ': ' + short(d, 300) : ''); });
}

const RULES = `You are helping a Blue Prism developer. Rules:
- Use only what is given below. If something is not in it, say it is not known; do not invent stage names, values or causes.
- Name stages exactly as they are written, as page / stage.
- Be short and concrete. No preamble.`;

// "what went wrong here": a walk (a Run or a loaded log) at row i
function promptExplain(o) {
  const rows = o.rows || [], i = Math.max(0, Math.min(rows.length - 1, o.i == null ? rows.length - 1 : o.i)), at = rows[i] || {};
  const firstErr = rows.findIndex(r => r.error), from = Math.max(0, (firstErr >= 0 ? Math.min(firstErr, i) : i) - 40), upto = Math.min(rows.length, Math.max(i, firstErr) + 12);
  const after = rows.length - 1 - i; let lastErr = -1; for (let x = rows.length - 1; x >= 0; x--) if (rows[x].error) { lastErr = x; break; }
  const seen = new Set(), pagesTxt = [];
  for (const r of [at].concat(rows.filter(x => x.error)).concat(rows.slice(Math.max(0, i - 6), i))) {
    const k = r.process + '|' + r.page; if (!r.process || seen.has(k) || seen.size >= 6) continue; seen.add(k);
    const bp = o.bpFor(r.process); if (!bp) { pagesTxt.push('### ' + r.process + ' / ' + r.page + '\n(no XML available)'); continue; }
    pagesTxt.push('### ' + r.process + ' / ' + r.page + (bp.reconstructed ? '  (REBUILT FROM A LOG: only the stages that ran, no expressions)' : '') + '\n' + pageLines(bp, r.page).join('\n'));
  }
  return scrub([RULES, '',
    '# Task', 'A run of the Blue Prism process "' + o.name + '" is frozen at the stage below. Say what went wrong, why (the chain from the first cause to the failure), and what to change to fix it. If the cause is outside the process (the application, the input data, the environment), say so. End with the one check you would do first to confirm.',
    '', '# The stage the walk stands on', rowLine(at),
    '', '# The run, in order (stage number and start time | where | type | stage | what went in and out | values it set | error)', rows.slice(from, upto).map(rowLine).join('\n'),
    firstErr >= 0 ? '\nThe first error in the run is stage number ' + rows[firstErr].n + '.' : '\nNo stage reported an error.',
    at.error && after ? '\nThe run did not end at the stage the walk stands on: ' + after + ' more stage' + (after === 1 ? '' : 's') + ' ran after it' + (lastErr > i ? ', and the last error is stage number ' + rows[lastErr].n + '. Say whether the error asked about was recovered from and whether it is connected to the later one.' : ', none with an error. Say whether it was recovered from.') : '',
    '\nEach line is one execution. The same stage name on the same page appearing again is the same stage executed again (a retry or a loop), not a second stage: do not suggest comparing the two.' + (rows.some(r => r.at) ? ' The time after @ is when the stage started: use the gaps between times as evidence.' : ''),
    '', '# The pages involved, one line per stage', pagesTxt.join('\n\n'),
    o.notes ? '\n# The developer\'s notes about this process\n' + o.notes : '',
    '', '# Answer format', 'Plain text with these headings: What happened / Why / Fix / First check.'].join('\n'));
}

// "fill the gaps": an object rebuilt from a log; the model proposes what each stage is for and what is probably missing
function promptFill(o) {
  const bp = D.parseBp(o.xml), pages = [...new Set(bp.stages.map(s => s.page))];
  const mine = (o.rows || []).filter(r => String(r.process).trim().toLowerCase() === bp.name.trim().toLowerCase());
  return scrub([RULES, '',
    '# Task', 'The Blue Prism object "' + bp.name + '" is not available. The skeleton below was rebuilt from a session log: it has only the stages that ran, in the order they ran, with no expressions, no code and no branches that were not taken. For every stage say in one sentence what it most probably does, judging from its name, type, and the values that went in and out. For every page say what it is for and which branches or error handling a real object would have that the log did not show. Mark each statement with how sure you are: high, medium or low.',
    '', '# The skeleton, page by page', pages.map(p => '### ' + p + '\n' + pageLines(bp, p).join('\n')).join('\n\n'),
    '', '# What the log recorded for this object', mine.length ? mine.slice(0, 400).map(rowLine).join('\n') : '(no log lines available)',
    (o.callers || []).length ? '\n# How it is called from objects and processes that ARE available\n' + o.callers.slice(0, 40).join('\n') : '',
    o.notes ? '\n# The developer\'s notes\n' + o.notes : '',
    '', '# Answer format', 'Only JSON, no other text, in this shape:', '{"pages":[{"page":"<page name>","purpose":"..","missing":"..","stages":[{"stage":"<stage name>","type":"<type>","does":"..","sure":"high|medium|low"}]}]}'].join('\n'));
}

function newJob(here, kind, meta, prompt) {
  const id = new Date().toISOString().replace(/[-:T.Z]/g, '').slice(0, 17) + '_' + kind + '_' + Math.random().toString(36).slice(2, 6), dir = path.join(jobsDir(here), id);
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, 'job.json'), JSON.stringify(Object.assign({ id, kind, created: new Date().toISOString() }, meta), null, 1), 'utf8');
  fs.writeFileSync(path.join(dir, 'prompt.md'), prompt, 'utf8');
  prune(here);
  return { id, dir, chars: prompt.length };
}
function jobState(here, id) {
  if (!/^[\w]+$/.test(String(id || ''))) return { state: 'unknown' };
  const dir = path.join(jobsDir(here), id), rd = f => { try { return fs.readFileSync(path.join(dir, f), 'utf8'); } catch (e) { return null; } };
  if (!fs.existsSync(path.join(dir, 'prompt.md'))) return { state: 'unknown' };
  let job = {}; try { job = JSON.parse(rd('job.json') || '{}'); } catch (e) { }
  const answer = rd('answer.md'), error = rd('error.txt');
  if (answer != null) return { state: 'done', kind: job.kind, answer, model: rd('model.txt') || '', dir, meta: job };
  if (error != null) return { state: 'failed', kind: job.kind, error, dir, meta: job };
  return { state: fs.existsSync(path.join(dir, 'taken')) ? 'asking' : 'waiting', kind: job.kind, dir, meta: job };
}
function prune(here) { try { const d = jobsDir(here), all = fs.readdirSync(d).sort(); for (const x of all.slice(0, Math.max(0, all.length - 30))) fs.rmSync(path.join(d, x), { recursive: true, force: true }); } catch (e) { } }

// The model's guesses go into the rebuilt object as stage descriptions, every one marked as a guess with how sure it was.
// The page's own description (its SubSheetInfo does not exist in a rebuilt object) is kept in the process narrative.
function applyFill(xml, answer) {
  const m = /\{[\s\S]*\}/.exec(String(answer || '')); if (!m) throw new Error('the answer holds no JSON');
  let j; try { j = JSON.parse(m[0]); } catch (e) { throw new Error('the answer is not valid JSON: ' + e.message); }
  const X = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const bp = D.parseBp(xml); let n = 0, out = xml; const pagesNote = [];
  for (const pg of j.pages || []) {
    if (pg.purpose || pg.missing) pagesNote.push(String(pg.page) + ': ' + [pg.purpose, pg.missing ? 'probably missing: ' + pg.missing : ''].filter(Boolean).join(' | '));
    for (const g of pg.stages || []) {
      const st = bp.stages.find(s => s.page === (pg.page === 'Initialise' ? 'Main Page' : pg.page) && s.name === g.stage && (!g.type || s.type === g.type)) || bp.stages.find(s => s.page === (pg.page === 'Initialise' ? 'Main Page' : pg.page) && s.name === g.stage);
      if (!st || !g.does) continue;
      const note = '<narrative>' + X('GUESS by the model (' + (/^(high|medium|low)$/.test(g.sure) ? g.sure : 'unrated') + '): ' + String(g.does).replace(/\s+/g, ' ').slice(0, 500)) + '</narrative>';
      const open = '<stage stageid="' + st.xmlId + '"', a = out.indexOf(open); if (a < 0) continue; const b = out.indexOf('</stage>', a); let body = out.slice(a, b);
      body = /<narrative>[\s\S]*?<\/narrative>|<narrative\s*\/>/.test(body) ? body.replace(/<narrative>[\s\S]*?<\/narrative>|<narrative\s*\/>/, () => note) : body.replace(/(<stage [^>]*>)/, (x, h) => h + note);
      out = out.slice(0, a) + body + out.slice(b); n++;
    }
  }
  if (!n) throw new Error('none of the stages the answer names is in this object');
  if (pagesNote.length) out = out.replace(/(<process [^>]*\bnarrative=")([^"]*)"/, (x, h, old) => h + old.replace(/ \|\| GUESSES by the model per page:[\s\S]*$/, '') + ' || GUESSES by the model per page: ' + X(pagesNote.join(' ;; ')).replace(/"/g, '&quot;') + '"');
  return { xml: out, stages: n, pages: pagesNote.length };
}

module.exports = { jobsDir, announce, scrub, rowLine, pageLines, promptExplain, promptFill, newJob, jobState, applyFill };
