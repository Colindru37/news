// bpui: the browser side of gumball. Draws every page from the model, lets you move stages, draw links,
// delete, edit a stage's properties in the sheet, checks the estate rules live, and saves the next version.
// Expects globals: BW_XML (string), BW_BASE (name), BW_VER (number), BW_DIFF (json or null), BW_INCIDENT (json or null).
(function () {
'use strict';
var D = window.BPDRAW, E = window.BPEDIT;
// A draft = the page as it was last changed, kept in this browser until Save makes it a version (or Revert drops it).
// It comes back when the page is opened again, so going to another object and back loses nothing.
var DRAFT_PRE = 'gumball:draft:' + ((window.BW_SERVE && window.BW_SERVE.rel) || '') + '|', DRAFT_KEY = DRAFT_PRE + BW_BASE, dirty = false, draftKept = true, selLink = null, draggedAt = 0;
var START_XML = BW_XML;
// A draft is restored only onto the file it was made on. A file replaced by hand (deleted and imported again) keeps its
// name and version number, so a draft of the old copy would otherwise hide the new file for good.
var SRC = (typeof BW_SRC !== 'undefined' && BW_SRC) || '';
try { var d0 = JSON.parse(localStorage.getItem(DRAFT_KEY) || 'null');
  if (d0 && d0.ver === BW_VER && d0.xml && d0.xml !== BW_XML) {
    if (d0.src === SRC || !confirm('This browser holds unsaved changes to ' + BW_BASE + ' that were made on a different copy than the file now in the projects folder (it was replaced or imported again).\n\nOK = open the file as it is now and drop those changes.\nCancel = keep the old changes on top of it.')) { START_XML = d0.xml; dirty = true; }
    else localStorage.removeItem(DRAFT_KEY);
  } else if (d0) localStorage.removeItem(DRAFT_KEY); } catch (e) { }
var M = E.modelFrom(START_XML), mode = 'select', sel = null, linkFrom = null, scale = 1, undo = [], cur = 0;
if (dirty) { try { E.modelFrom(START_XML).stages.length; } catch (e) { M = E.modelFrom(BW_XML); dirty = false; } }
var OBJ = (typeof BW_OBJECTS !== 'undefined' && BW_OBJECTS) || [], place = null, multi = [];
if (window.BW_SERVE && window.BW_SERVE.catalog && window.BW_SERVE.catalog.length) {   // the project's objects as they are now: they replace the copy written into the page
  var liveNames = {}; window.BW_SERVE.catalog.forEach(function (o) { liveNames[String(o.object).toLowerCase()] = 1; });
  OBJ = OBJ.filter(function (o) { return !liveNames[String(o.object).toLowerCase()]; }).concat(window.BW_SERVE.catalog).sort(function (a, b) { return String(a.object).localeCompare(String(b.object)); });
}
var ov = { pages: {}, changed: new Set(BW_DIFF ? BW_DIFF.changedIds : []) };
if (BW_INCIDENT) { var o2 = D.overlayFrom(BW_INCIDENT); ov.pages = o2.pages; }
function $(id) { return document.getElementById(id); }
function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }

// ---------- pages ----------
function label(pg) { return pg === 'Main Page' && M.type === 'object' ? 'Initialise' : pg; }
function pages() { return E.pagesOf(M).sort(function (a, b) { return (a === 'Main Page' ? 0 : 1) - (b === 'Main Page' ? 0 : 1) || a.localeCompare(b); }); }
function reconBadge() { return (M.reconstructed ? ' <span class="reconb" title="only what the log shows: the stages that ran, in the order they ran; branches not taken, expressions and code are missing">rebuilt from a log, not the real object</span>' : ''); }   // an object Darwin rebuilt from a log says so next to its name
function renderAll() {
  var pg = pages(), list = '', panes = '';
  for (var i = 0; i < pg.length; i++) {
    ov.studio = !document.body.classList.contains('dark');
    var svg = D.renderPage(E.bpOf(M), pg[i], ov) || '<p>(empty page)</p>';
    list += '<li data-i="' + i + '" class="' + (i === cur ? 'on' : '') + '">' + esc(label(pg[i])) + '</li>';
    panes += '<section id="p' + i + '"' + (i === cur ? '' : ' hidden') + '><h2>' + esc(M.name) + ' / ' + esc(pg[i]) + reconBadge() + '</h2>' + svg + '</section>';
  }
  $('pages').innerHTML = list; $('panes').innerHTML = panes; palette();
  [].forEach.call(document.querySelectorAll('#pages li'), function (li) { li.onclick = function () { cur = +li.dataset.i; multi = []; sel = null; selLink = null; closeSheet(); renderAll(); }; });
  applyScale(); rules(); if (sel) highlight(sel); markLink(); dirtyMark();
}
function renderPage() { ov.studio = !document.body.classList.contains('dark'); var pg = pages()[cur]; var sec = $('p' + cur); sec.innerHTML = '<h2>' + esc(M.name) + ' / ' + esc(label(pg)) + reconBadge() + '</h2>' + (D.renderPage(E.bpOf(M), pg, ov) || ''); applyScale(); rules(); if (sel) highlight(sel); markLink(); }
function applyScale() { [].forEach.call(document.querySelectorAll('svg'), function (s) { s.style.transform = 'scale(' + scale + ')'; }); }
window.z = function (f) { scale = f ? Math.min(3, Math.max(0.25, scale * f)) : 1; applyScale(); };
document.addEventListener('wheel', function (e) { if (!e.ctrlKey) return; var m = e.target.closest && e.target.closest('main'); if (!m) return; e.preventDefault(); window.z(e.deltaY < 0 ? 1.1 : 0.9); }, { passive: false });
function highlight(id) { [].forEach.call(document.querySelectorAll('g.st.on,g.blk.on'), function (g) { g.classList.remove('on'); }); var ids = id ? [id] : []; ids = ids.concat(multi); ids.forEach(function (i) { [].forEach.call(document.querySelectorAll('[data-sid="' + i + '"]'), function (g) { g.classList.add('on'); }); }); }

// ---------- undo ----------
// One state = which stages exist (by reference), each stage's changeable fields (copied), and the page lists.
// Undo and redo both restore a whole state, so added/removed stages and pages come back either way.
var redo = [];
function capture() {
  return { stages: M.stages.slice(), fields: JSON.stringify(M.stages.map(function (s) { return { x: s.x, y: s.y, w: s.w, h: s.h, name: s.name, deleted: s.deleted, edits: s.edits }; })),
           pages: JSON.stringify(M.pages), added: JSON.stringify(M.addedPages || []), removed: JSON.stringify(M.removedPages || []), appdef: M.appdef == null ? null : M.appdef };
}
function restore(st) {
  var f = JSON.parse(st.fields); M.stages = st.stages.slice(); M.byId = {};
  for (var i = 0; i < M.stages.length; i++) { var s = M.stages[i], v = f[i]; s.x = v.x; s.y = v.y; s.w = v.w; s.h = v.h; s.name = v.name; s.deleted = v.deleted; s.edits = v.edits; M.byId[s.id] = s; }
  M.pages = JSON.parse(st.pages); M.addedPages = JSON.parse(st.added); M.removedPages = JSON.parse(st.removed);
  if ((st.appdef == null ? null : st.appdef) !== (M.appdef == null ? null : M.appdef)) { M.appdef = st.appdef; if (typeof moSync === 'function') moSync(); }
  if (sel && (!M.byId[sel] || M.byId[sel].deleted)) { sel = null; closeSheet(); } multi = [];
  if (cur >= pages().length) cur = 0; renderAll(); if (sel) openSheet(sel);
}
function snap() { if (photo) { toast('the run is frozen: leave the walk (Esc) to edit'); throw new Error('frozen'); } undo.push(capture()); if (undo.length > 50) undo.shift(); redo = []; draftSoon(); }   // a new change ends the redo line
var draftT = null;
function draftSoon() { clearTimeout(draftT); draftT = setTimeout(draftNow, 250); }
function draftNow() {
  clearTimeout(draftT); var xml; try { xml = E.serialize(M); } catch (e) { return; }
  dirty = xml !== BW_XML;
  try { if (dirty) localStorage.setItem(DRAFT_KEY, JSON.stringify({ ver: BW_VER, src: SRC, xml: xml })); else localStorage.removeItem(DRAFT_KEY); draftKept = true; }
  catch (e) { if (draftKept) toast('this draft is too big for the browser to keep: press Save before leaving the page'); draftKept = false; }
  dirtyMark();
}
// a value shown in a line of the Run panel: a long one (a PDF's whole text) is cut, its length said, so the drawing stays on screen
function shortVal(v) { var t = JSON.stringify(v); if (t === undefined) t = String(v); return t.length <= 300 ? t : t.slice(0, 300) + '... (' + t.length + ' characters: the copy button takes it whole)'; }
function copyText(t, what) {   // the clipboard where the browser allows it (localhost does), else a box to copy from
  var done = function () { toast('copied ' + what + ' (' + t.length + ' characters)'); }, box = function () { var ta = document.createElement('textarea'); ta.value = t; ta.style.cssText = 'position:fixed;left:-9999px'; document.body.appendChild(ta); ta.select(); try { document.execCommand('copy'); done(); } catch (e) { toast('could not copy'); } ta.remove(); };
  try { navigator.clipboard.writeText(t).then(done, box); } catch (e) { box(); }
}
function dirtyMark() { var b = $('save'); if (b) b.classList.toggle('dirty', dirty); var r = $('revb'); if (r) r.hidden = !dirty; }
window.revertDraft = function () { if (!confirm('Drop every change since v' + BW_VER + ' was saved?')) return; clearTimeout(draftT); draftT = null; reverting = true; try { localStorage.removeItem(DRAFT_KEY); } catch (e) { } location.reload(); };
var reverting = false;   // leaving the page writes the draft one last time; after Revert that would put the changes straight back
window.addEventListener('beforeunload', function () { if (draftT && !reverting) draftNow(); });
window.doUndo = function () { if (!undo.length) { toast('nothing to undo'); return; } redo.push(capture()); restore(undo.pop()); draftSoon(); toast(undo.length ? 'undone (' + undo.length + ' more, Ctrl+Y redoes)' : 'undone (Ctrl+Y redoes)'); };
window.doRedo = function () { if (!redo.length) { toast('nothing to redo'); return; } undo.push(capture()); restore(redo.pop()); draftSoon(); toast(redo.length ? 'redone (' + redo.length + ' more)' : 'redone'); };

// ---------- palette: add a stage (click a kind, then click the canvas), add a page ----------
var NICE = { Action: 'Action', Decision: 'Decision', Calculation: 'Calc', MultipleCalculation: 'Multi Calc', SubSheet: 'Page call', Code: 'Code', Data: 'Data', Collection: 'Collection', Exception: 'Exception', Recover: 'Recover', Resume: 'Resume', Anchor: 'Anchor', Process: 'Process', LoopStart: 'Loop start', LoopEnd: 'Loop end', Note: 'Note', Block: 'Block', Start: 'Start', End: 'End', Navigate: 'Navigate', Read: 'Read', Write: 'Write', Alert: 'Alert', WaitStart: 'Wait', WaitEnd: 'Time out', ChoiceStart: 'Choice', ChoiceEnd: 'Otherwise' };
function palette() {
  var el = $('palette'); if (!el) return;
  var kinds = E.PALETTE.filter(function (k) { return !(M.type === 'process' && /^(Code|Navigate|Read|Write)$/.test(k)) && !(M.type !== 'process' && k === 'Process'); });   // a process has no code and no application
  el.innerHTML = kinds.map(function (k) { return '<button data-k="' + k + '" class="' + (place === k ? 'on' : '') + '">' + esc(NICE[k] || k) + '</button>'; }).join('');
  [].forEach.call(el.querySelectorAll('button'), function (b) { b.onclick = function () { startPlace(b.dataset.k); }; });
}
function startPlace(k) { place = place === k ? null : k; palette(); linkFrom = null; if (place) toast('click on the page where the ' + (NICE[place] || place) + ' goes'); document.body.classList.toggle('placing', !!place); }
function svgPoint(svg, e, raw) { var pt = svg.createSVGPoint(); pt.x = e.clientX; pt.y = e.clientY; var p = pt.matrixTransform(svg.getScreenCTM().inverse()); return raw ? { x: p.x, y: p.y } : { x: Math.round(p.x / 15) * 15, y: Math.round(p.y / 15) * 15 }; }
window.removePage = function () {
  var pg = pages()[cur]; if (pg === 'Main Page' || M.stages.some(function (s) { return !s.deleted && s.page === pg && s.type === 'ProcessInfo'; })) { toast('the main page stays'); return; }
  if (!confirm('Remove the page "' + pg + '" and everything on it?')) return;
  snap(); E.removePage(M, pg); cur = 0; multi = []; closeSheet(); renderAll(); toast('page removed - page calls to it are flagged in Checks');
};
window.toggleHelp = function () { $('help').hidden = !$('help').hidden; };
window.addPage = function (given) {
  var name = given || prompt('Name of the new page'); if (!name) return; name = name.trim(); if (!name) return;
  if (pages().indexOf(name) >= 0) { toast('there is a page called that already'); return; }
  snap(); E.addPage(M, name); cur = pages().indexOf(name); renderAll(); toast('page "' + name + '" added with Start and End');
};

// ---------- modes ----------
window.setMode = function (m) { var was = mode; mode = m; linkFrom = null; if (place) { place = null; palette(); document.body.classList.remove('placing'); } [].forEach.call(document.querySelectorAll('.tb button[data-mode]'), function (b) { b.classList.toggle('on', b.dataset.mode === m); }); if (m !== was && m !== 'select') toast({ link: 'click the stage the link leaves, then where it goes', delete: 'click a stage to remove it' }[m]); };

// ---------- mouse: drag / link / delete ----------
var drag = null;
var band = null;
function gOf(id) { return document.querySelector('section:not([hidden]) [data-sid="' + id + '"]'); }
// A block holds the stages whose centre lies inside it (Blue Prism decides this by position, nothing in the XML says it), and a
// Recover in a block covers exactly those. So a move or a resize can change what is covered without touching a link: say so.
function blockMembers() { var pg = pages()[cur], out = {}; M.stages.forEach(function (b) { if (b.deleted || b.type !== 'Block' || b.page !== pg) return; var ms = E.membersOf(M, b); ms.forEach(function (q) { out[b.id + '|' + q.id] = { b: b, s: q, rec: ms.some(function (x) { return x.type === 'Recover'; }) }; }); }); return out; }
function blockChange(before) {
  var after = blockMembers(), msg = [], k;
  for (k in before) if (!after[k] && !before[k].s.deleted && !before[k].b.deleted) msg.push('"' + before[k].s.name + '" is no longer in block "' + before[k].b.name + '"' + (before[k].rec && before[k].s.type !== 'Recover' ? ' (its Recover does not cover it now)' : ''));
  for (k in after) if (!before[k]) msg.push('"' + after[k].s.name + '" is now in block "' + after[k].b.name + '"' + (after[k].rec && after[k].s.type !== 'Recover' ? ' (covered by its Recover)' : ''));
  if (msg.length) toast(msg.slice(0, 3).join('; ') + (msg.length > 3 ? '; and ' + (msg.length - 3) + ' more' : ''), 7000);
  return msg;
}
function groupFor(st) {   // what moves with a stage: the multi selection if it is in it, a block's members, a pair's partner
  var ids = multi.indexOf(st.id) >= 0 ? multi.slice() : [st.id];
  var out = {}; ids.forEach(function (i) { out[i] = 1; var s = M.byId[i]; if (!s) return; if (s.type === 'Block') E.membersOf(M, s).forEach(function (q) { out[q.id] = 1; }); });
  return Object.keys(out);
}
document.addEventListener('mousedown', function (e) {
  if (mode !== 'select' || place || e.button !== 0) return;
  var h = e.target.closest && e.target.closest('.rsz');
  if (h) { var rs = M.byId[h.getAttribute('data-sid')]; if (rs) { drag = { resize: rs, x0: e.clientX, y0: e.clientY, moved: false, w0: rs.w, h0: rs.h }; e.preventDefault(); } return; }
  var g = e.target.closest && e.target.closest('g.st,g.blk');
  if (!g) { var svg = e.target.closest && e.target.closest('svg'); if (!svg) return; var p0 = svgPoint(svg, e, true); band = { svg: svg, x0: p0.x, y0: p0.y, el: null }; e.preventDefault(); return; }
  var st = M.byId[g.getAttribute('data-sid')]; if (!st) return;
  if (e.shiftKey) { var i = multi.indexOf(st.id); if (i >= 0) multi.splice(i, 1); else multi.push(st.id); sel = null; highlight(null); e.preventDefault(); return; }
  if (multi.indexOf(st.id) < 0) { multi = []; }
  drag = { st: st, ids: groupFor(st), x0: e.clientX, y0: e.clientY, moved: false }; e.preventDefault();
});
document.addEventListener('mousemove', function (e) {
  if (band) { var p = svgPoint(band.svg, e, true); if (!band.el) { band.el = document.createElementNS('http://www.w3.org/2000/svg', 'rect'); band.el.setAttribute('class', 'band'); band.svg.appendChild(band.el); } band.el.setAttribute('x', Math.min(p.x, band.x0)); band.el.setAttribute('y', Math.min(p.y, band.y0)); band.el.setAttribute('width', Math.abs(p.x - band.x0)); band.el.setAttribute('height', Math.abs(p.y - band.y0)); return; }
  if (!drag) return; var dx = (e.clientX - drag.x0) / scale, dy = (e.clientY - drag.y0) / scale;
  if (Math.abs(dx) + Math.abs(dy) > 2) drag.moved = true;
  if (drag.resize) { var r = gOf(drag.resize.id).querySelector('rect.shape,rect.blkr'); if (r) { r.setAttribute('width', Math.max(30, drag.w0 + dx)); r.setAttribute('height', Math.max(20, drag.h0 + dy)); } return; }
  drag.ids.forEach(function (i) { var g = gOf(i); if (g) g.setAttribute('transform', 'translate(' + dx + ',' + dy + ')'); });
});
document.addEventListener('mouseup', function (e) {
  if (band) { var b = band; band = null;
    var x = b.el ? +b.el.getAttribute('x') : 0, y = b.el ? +b.el.getAttribute('y') : 0, w = b.el ? +b.el.getAttribute('width') : 0, h = b.el ? +b.el.getAttribute('height') : 0; if (b.el) b.el.remove();
    if (w < 4 && h < 4) {   // a plain click on empty space: nothing stays selected
      if (!(e.target.closest && e.target.closest('.lnkhit'))) { selLink = null; if (multi.length || sel) { multi = []; closeSheet(); highlight(null); } markLink(); }
      return; }
    var pg = pages()[cur]; multi = M.stages.filter(function (s) { return !s.deleted && s.page === pg && s.type !== 'Block' && s.x >= x && s.x <= x + w && s.y >= y && s.y <= y + h; }).map(function (s) { return s.id; });
    sel = null; closeSheet(); highlight(null); if (multi.length) toast(multi.length + ' selected - drag them together, Del removes them'); return; }
  if (!drag) return; var d = drag; drag = null;
  var dx = (e.clientX - d.x0) / scale, dy = (e.clientY - d.y0) / scale;
  if (!d.moved) return;
  draggedAt = Date.now();
  snap();
  var memb0 = blockMembers();
  if (d.resize) { E.resize(d.resize, Math.max(30, Math.round((d.w0 + dx) / 15) * 15), Math.max(20, Math.round((d.h0 + dy) / 15) * 15)); renderPage(); blockChange(memb0); return; }
  var snapG = document.body.classList.contains('grid') ? function (v) { return Math.round(v / 15) * 15; } : function (v) { return v; };
  d.ids.forEach(function (i) { var s = M.byId[i]; E.move(s, snapG(s.x + dx), snapG(s.y + dy)); });
  setTimeout(function () { blockChange(memb0); }, 0);
  if (d.ids.length === 1) sel = d.st.id; renderPage();
});
document.addEventListener('click', function (e) {
  if (place) {
    var svg = e.target.closest && e.target.closest('svg'); if (!svg) return;
    var p = svgPoint(svg, e), k = place;
    if (k === 'Start' && M.stages.some(function (s) { return !s.deleted && s.page === pages()[cur] && s.type === 'Start'; })) { toast('this page already has a Start: Blue Prism allows exactly one'); place = null; palette(); document.body.classList.remove('placing'); setMode('select'); return; }
    snap();
    var st = E.addStage(M, k, pages()[cur], p.x, p.y);
    if (k === 'Action' && OBJ.length && OBJ[0].actions.length) E.setResource(st, OBJ[0].object, OBJ[0].actions[0].name, OBJ[0].actions[0].inputs, OBJ[0].actions[0].outputs);
    if (k === 'SubSheet') { var other = pages().filter(function (q) { return q !== pages()[cur]; })[0]; if (other) { E.rename(st, other); E.setPageCall(M, st, other); } }
    if (k === 'LoopStart') { var gid = /<groupid>([^<]*)</.exec(st.orig.body)[1]; var le = E.addStage(M, 'LoopEnd', pages()[cur], p.x, p.y + 120, { groupid: gid }); E.setLink(st, 'onsuccess', le.id); }
    if (k === 'WaitStart' || k === 'ChoiceStart') { var gid2 = /<groupid>([^<]*)</.exec(st.orig.body)[1]; E.addStage(M, k === 'WaitStart' ? 'WaitEnd' : 'ChoiceEnd', pages()[cur], p.x + 180, p.y, { groupid: gid2 }); }   // the pair: branches sit on the line between them, the end is the time-out / otherwise path
    if (k === 'LoopEnd') { var open = M.stages.filter(function (s) { return !s.deleted && s.page === pages()[cur] && s.type === 'LoopStart' && !E.partnerOf(M, s); })[0]; if (open) { st.orig.body = st.orig.body.replace(/<groupid>[^<]*<\/groupid>/, '<groupid>' + /<groupid>([^<]*)</.exec(open.orig.body)[1] + '</groupid>'); } else { toast('place the Loop start first'); } }
    var onLink = e.target.closest && e.target.closest('.lnkhit'), spliced = onLink && E.insertOnLink(M, st, onLink.getAttribute('data-from'), onLink.getAttribute('data-kind'));
    place = null; palette(); document.body.classList.remove('placing'); setMode('select'); sel = st.id; renderPage(); openSheet(st.id); if (spliced) { toast(NICE[k] + ' added on the link: wired in between'); return; } toast(NICE[k] + ' added' + (/^(WaitStart|ChoiceStart)$/.test(k) ? ' with its ' + (k === 'WaitStart' ? 'time-out' : 'otherwise') + ' end: add the branches in the sheet, wire each with L' : /^(Data|Collection|Note|Block|End|LoopEnd)$/.test(k) ? '' : ' - wire it with L')); return;
  }
  if (Date.now() - draggedAt < 350) { draggedAt = 0; return; }   // the click that ends a drag is not a click
  var lk = e.target.closest && e.target.closest('.lnkhit');
  if (lk) {
    var lf = M.byId[lk.getAttribute('data-from')], kd = lk.getAttribute('data-kind'); if (!lf) return;
    if (mode === 'delete') { snap(); E.setLink(lf, kd, null); selLink = null; renderPage(); toast('link removed'); return; }
    if (mode === 'select') { selLink = { from: lf.id, kind: kd }; multi = []; closeSheet(); highlight(null); markLink(); toast('link from "' + lf.name + '" selected: Del removes it; a new stage placed on a link is wired in between'); }
    return;
  }
  var g = e.target.closest && e.target.closest('g.st,g.blk'); if (!g) return;
  var id = g.getAttribute('data-sid'), st = M.byId[id]; if (!st) return;
  if (e.shiftKey && mode === 'select') return;   // Shift+click only changes the selection (done on mouse down)
  selLink = null; markLink();
  if (mode === 'delete') { if (/^(Start|End)$/.test(st.type)) { toast('Start and End stay'); return; } snap(); removeWithPartner(st); sel = null; closeSheet(); renderPage(); return; }
  if (mode === 'link') {
    if (!linkFrom) { linkFrom = st; highlight(id); toast('now click where "' + st.name + '" goes'); return; }
    if (/^(WaitStart|ChoiceStart)$/.test(linkFrom.type)) {   // one link per branch; the time-out / otherwise path leaves from the pair's end stage
      var brs = E.choicesOf(E.stageBody(linkFrom));
      if (!brs.length) { toast('"' + linkFrom.name + '" has no branch yet: click it in Select mode and add a row first'); linkFrom = null; setMode('link'); return; }
      var pickN = brs.length === 1 ? '1' : prompt('Which branch of "' + linkFrom.name + '" goes to "' + st.name + '"?\n' + brs.map(function (r, i) { return (i + 1) + ': ' + (r.name || '(no name)'); }).join('\n'), '1'), ix = parseInt(pickN, 10) - 1;
      if (ix >= 0 && ix < brs.length) { snap(); E.setChoiceTarget(linkFrom, ix, st.id); }
      linkFrom = null; setMode('link'); renderPage(); return;
    }
    if (linkFrom.type === 'Decision') { askYesNo(function (kind) { snap(); E.setLink(linkFrom, kind, st.id); linkFrom = null; setMode('link'); renderPage(); }); return; }
    if (/^(End|Exception|Note|Data|Collection|Block)$/.test(linkFrom.type)) { toast(linkFrom.type + ' has no outgoing link'); linkFrom = null; setMode('link'); return; }
    snap(); E.setLink(linkFrom, 'onsuccess', st.id); linkFrom = null; setMode('link'); renderPage(); return;
  }
  multi = []; sel = id; highlight(id); openSheet(id);
});
function markLink() {
  [].forEach.call(document.querySelectorAll('.lnkhit.on'), function (x) { x.classList.remove('on'); });
  if (!selLink) return;
  [].forEach.call(document.querySelectorAll('section:not([hidden]) .lnkhit'), function (x) { if (x.getAttribute('data-from') === selLink.from && x.getAttribute('data-kind') === selLink.kind) x.classList.add('on'); });
}
// ---------- copy / cut / paste / select all ----------
var CLIP_KEY = 'gumball:clip', pasteN = 0;
document.addEventListener('keydown', function (e) {
  if ((e.ctrlKey || e.metaKey) && e.shiftKey && !e.altKey && e.key.toLowerCase() === 'c' && !/^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement.tagName)) { e.preventDefault(); copyXml(); return; }
  if (!(e.ctrlKey || e.metaKey) || e.altKey || e.shiftKey) return;
  if (/^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement.tagName)) return;
  var k = e.key.toLowerCase(); if ('cvxa'.indexOf(k) < 0 || k.length !== 1) return;
  if (k !== 'v' && k !== 'a' && String(window.getSelection && window.getSelection()).length) return;   // text is selected (the run log, a check): the browser copies that
  var pg = pages()[cur];
  if (k === 'a') { e.preventDefault(); multi = M.stages.filter(function (s) { return !s.deleted && s.page === pg && !/^(Block|SubSheetInfo|ProcessInfo)$/.test(s.type); }).map(function (s) { return s.id; }); sel = null; closeSheet(); highlight(null); toast(multi.length + ' selected'); return; }
  if (k === 'c' || k === 'x') {
    var ids = multi.length ? multi.slice() : sel ? [sel] : []; if (!ids.length) return;
    var text = E.copyStages(M, ids), n = JSON.parse(text).stages.length; if (!n) { toast('Start and the page information box are not copied'); return; }
    e.preventDefault(); pasteN = 0;
    try { localStorage.setItem(CLIP_KEY, text); } catch (er) { toast('too big to copy'); return; }
    if (k === 'x') { snap(); ids.forEach(function (i) { var s = M.byId[i]; if (s && !/^(Start|End|SubSheetInfo|ProcessInfo)$/.test(s.type)) E.remove(M, s); }); multi = []; sel = null; closeSheet(); renderPage(); }
    toast(n + ' stage' + (n === 1 ? '' : 's') + (k === 'x' ? ' cut' : ' copied') + ': Ctrl+V pastes on any page, also in another object'); return;
  }
  var clip = null; try { clip = localStorage.getItem(CLIP_KEY); } catch (er) { }
  if (!clip) { toast('nothing copied yet'); return; }
  e.preventDefault(); snap(); pasteN++;
  var made = E.pasteStages(M, clip, pg, 30 * pasteN, 30 * pasteN);
  if (!made.length) { undo.pop(); toast('nothing to paste here'); return; }
  multi = made.map(function (s) { return s.id; }); sel = null; closeSheet(); renderPage(); highlight(null);
  toast(made.length + ' pasted and selected: drag them where they go');
});
document.addEventListener('keydown', function (e) { var typing = /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement.tagName); if ((e.ctrlKey || e.metaKey) && !typing && (e.key.toLowerCase() === 'y' || (e.shiftKey && e.key.toLowerCase() === 'z'))) { e.preventDefault(); doRedo(); return; }
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z' && !typing) { e.preventDefault(); doUndo(); return; } if (!typing && !e.ctrlKey && !e.altKey) { if (e.shiftKey) { if (e.key === 'L') { toggleTheme(); return; } } else { var km = { v: 'select', l: 'link', d: 'delete' }[e.key.toLowerCase()]; if (km) { setMode(km); return; } if (e.key.toLowerCase() === 'a') { startPlace('Action'); return; } if (e.key.toLowerCase() === 'g') { toggleGrid(); return; } } } if (e.key === 'Delete' && !typing) { if (selLink && M.byId[selLink.from]) { snap(); E.setLink(M.byId[selLink.from], selLink.kind, null); selLink = null; renderPage(); toast('link removed'); return; } if (multi.length) { snap(); multi.forEach(function (i) { var s = M.byId[i]; if (s && !/^(Start|End)$/.test(s.type)) removeWithPartner(s); }); multi = []; closeSheet(); renderPage(); return; } if (sel) { var st = M.byId[sel]; if (st && !/^(Start|End)$/.test(st.type)) { snap(); removeWithPartner(st); sel = null; closeSheet(); renderPage(); } } } if (e.key === 'Escape') { linkFrom = null; if (place) startPlace(place); else closeSheet(); } });
function removeWithPartner(st) { var p = E.partnerOf(M, st); E.remove(M, st); if (p) { E.remove(M, p); toast(st.type + ' and ' + p.type + ' removed together'); } }
function askYesNo(cb) { var d = $('yesno'); d.hidden = false; d.querySelector('.y').onclick = function () { d.hidden = true; cb('ontrue'); }; d.querySelector('.n').onclick = function () { d.hidden = true; cb('onfalse'); }; }
function toast(t, ms) { var el = $('toast'); el.textContent = t; el.hidden = false; clearTimeout(el._t); el._t = setTimeout(function () { el.hidden = true; }, ms || 2200); }

// ---------- sheet (editable) ----------
function field(label, id, value, kind) { return '<dt>' + esc(label) + '</dt><dd>' + (kind === 'area' ? '<textarea data-f="' + id + '">' + esc(value) + '</textarea>' : '<input data-f="' + id + '" value="' + esc(value) + '">') + '</dd>'; }
function openSheet(id) {
  var st = M.byId[id]; if (!st || st.deleted) return; sheetId = id;
  if (typeof selEl !== 'undefined' && selEl) { selEl = null; if (typeof moTree === 'function') moTree(); }
  var bp = E.bpOf(M), idName = {}; for (var i = 0; i < bp.stages.length; i++) idName[bp.stages[i].id] = bp.stages[i].name;
  var cur = bp.stages.filter(function (s) { return s.id === id; })[0]; var info = D.stageInfo(cur, bp, idName);
  $('sh-type').textContent = st.type; $('sh-name').textContent = st.name;
  var h = '<h4>Stage</h4><dl>' + (st.type === 'SubSheetInfo' || st.type === 'ProcessInfo' ? '<dt>Name</dt><dd>' + esc(st.name) + '</dd>' : field('Name', 'name', st.name)) + field('Description', 'narrative', info.desc, 'area') + '<dt>Page</dt><dd>' + esc(st.page) + '</dd>';
  var b = cur.body;
  if (st.type === 'Action') {
    var r = /<resource object="([^"]*)" action="([^"]*)"/.exec(b), ro = r ? D.unx(r[1]) : '', ra = r ? D.unx(r[2]) : '';
    if (OBJ.length) {
      ro = objAlias(ro); var known = OBJ.some(function (o) { return o.object === ro; });
      h += '<dt>Business Object</dt><dd><select id="pick-obj" onchange="pickAction(\'' + id + '\')">' + (known ? '' : '<option selected>' + esc(ro || '(choose)') + '</option>') + OBJ.map(function (o) { return '<option' + (o.object === ro ? ' selected' : '') + '>' + esc(o.object) + '</option>'; }).join('') + '</select></dd>';
      var acts = (OBJ.filter(function (o) { return o.object === ro; })[0] || { actions: [] }).actions, knownA = acts.some(function (a) { return a.name === ra; });
      h += '<dt>Action</dt><dd><select id="pick-act" onchange="pickAction(\'' + id + '\')">' + (knownA ? '' : '<option selected>' + esc(ra || '(choose)') + '</option>') + acts.map(function (a) { return '<option' + (a.name === ra ? ' selected' : '') + '>' + esc(a.name) + '</option>'; }).join('') + '</select></dd>';
    } else h += '<dt>Business Object</dt><dd>' + esc(ro) + '</dd><dt>Action</dt><dd>' + esc(ra) + ' <span class="muted">(drop the object exports next to the xml and re-render to pick actions)</span></dd>';
    var ourl = objUrl(ro, ra);
    if (ourl) h += '<dt></dt><dd><a class="jump" href="' + esc(ourl) + '" onclick="return leaveOk()">Open ' + esc(ro) + ' / ' + esc(ra) + ' &#8599;</a></dd>';
    else if (ro) h += '<dt></dt><dd><span class="muted">' + esc(ro) + (MEMBERS.length ? ' is not in this release' : ' is not open in gumball: drop its export in the inbox to open it from here') + '</span></dd>';
  }
  if (st.type === 'SubSheet') { var tgt = M.pages[D.tag(b, 'processid')] || ''; h += '<dt>Page called</dt><dd><select id="pick-page" onchange="pickPage(\'' + id + '\')">' + (tgt ? '' : '<option selected>(choose)</option>') + pages().filter(function (q) { return q !== st.page; }).map(function (q) { return '<option' + (q === tgt ? ' selected' : '') + '>' + esc(q) + '</option>'; }).join('') + '</select></dd>'; }
  if (st.type === 'Decision') h += field('Expression', 'decision', D.attr((/<decision ([^>]*)\/>/.exec(b) || ['', ''])[1], 'expression')) + '<dt>Yes</dt><dd>' + esc(idName[E.linkOf(st, 'ontrue')] || '-') + '</dd><dt>No</dt><dd>' + esc(idName[E.linkOf(st, 'onfalse')] || '-') + '</dd>';
  if (st.type === 'Exception') { var ex = (/<exception ([^>]*)\/>/.exec(b) || ['', ''])[1]; h += '<dt>Type</dt><dd><input data-f="ex.type" list="dl-extype" value="' + esc(D.attr(ex, 'type')) + '"><datalist id="dl-extype"><option value="System Exception"><option value="Business Exception"><option value="Runtime Exception"></datalist></dd>' + field('Detail', 'ex.detail', D.attr(ex, 'detail'))
      + (/\busecurrent="(yes|true)"/i.test(ex) ? '<dt></dt><dd class="muted">re-throws the current exception (Preserve): type and detail are not used</dd>' : '') + (/\bsavescreencapture="(yes|true)"/i.test(ex) ? '<dt></dt><dd class="muted">saves a screen capture</dd>' : ''); }
  if (st.type === 'Data') h += '<dt>Data Type</dt><dd><select data-f="datatype">' + ['text', 'number', 'flag', 'date', 'datetime', 'time', 'timespan', 'password', 'binary', 'image'].concat(/^(text|number|flag|date|datetime|time|timespan|password|binary|image)$/.test(D.tag(b, 'datatype')) ? [] : [D.tag(b, 'datatype')]).map(function (t) { return '<option' + (t === D.tag(b, 'datatype') ? ' selected' : '') + '>' + esc(t) + '</option>'; }).join('') + '</select></dd>' + field('Initial Value', 'initialvalue', D.unx(D.tag(b, 'initialvalue'))) + '<dt>Exposure</dt><dd>' + esc(D.tag(b, 'exposure') || 'none') + '</dd>';
  if (st.type === 'ProcessInfo') {
    var lang = D.tag(b, 'language'), refs = (b.match(/<reference>[^<]*<\/reference>/g) || []).map(function (r) { return D.unx(r.slice(11, -12)); }), imps = (b.match(/<import>[^<]*<\/import>/g) || []).map(function (r) { return D.unx(r.slice(8, -9)); });
    h += '<dt>Language</dt><dd><select data-f="language"><option value="csharp"' + (lang === 'csharp' ? ' selected' : '') + '>C#</option><option value="visualbasic"' + (lang === 'visualbasic' ? ' selected' : '') + '>VB.NET</option>' + (/^(csharp|visualbasic)$/.test(lang) ? '' : '<option value="' + esc(lang) + '" selected>' + esc(lang || '(not set: Visual Basic)') + '</option>') + '</select></dd>';
    h += '<dt>References</dt><dd><textarea data-f="references" title="one .dll per line">' + esc(refs.join('\n')) + '</textarea></dd><dt>Namespaces</dt><dd><textarea data-f="imports" title="one namespace per line">' + esc(imps.join('\n')) + '</textarea></dd>';
  }
  if (st.type === 'Alert') h += field('Alert text (expression)', 'alert', D.attr((/<alert\b[^>]*>/.exec(b) || [''])[0], 'expression'));
  if (st.type === 'LoopStart') h += field('Collection', 'loopdata', D.unx(D.tag(b, 'loopdata'))) + '<dt>Loop end</dt><dd>' + esc((E.partnerOf(M, st) || {}).name || '(missing)') + '</dd>';
  if (st.type === 'Block') h += '<dt>Holds</dt><dd>' + esc(E.membersOf(M, st).map(function (q) { return q.name; }).join(', ') || '(nothing: drag stages inside)') + '</dd>';
  if (!/^(Decision|Start|End|Data|Collection|Note|Block|SubSheetInfo|ProcessInfo)$/.test(st.type)) h += '<dt>Next</dt><dd>' + esc(idName[E.linkOf(st, 'onsuccess')] || '-') + '</dd>';
  var isInfo = /^(SubSheetInfo|ProcessInfo|Block|Note|Data|Collection)$/.test(st.type);
  var li = /<loginhibit\s*\/>/.test(b) ? 'off' : /<loginhibit onsuccess="true"/.test(b) ? 'error' : 'on';
  if (!isInfo) h += '<dt>Parameters</dt><dd><select data-f="logparams"><option value="on"' + (/<loginhibitparameters\b/.test(b) ? '' : ' selected') + '>Logged with the stage</option><option value="off"' + (/<loginhibitparameters\b/.test(b) ? ' selected' : '') + '>Don\'t log parameters</option></select></dd>';
  if (isInfo) h += '</dl>'; else h += '<dt>Logging</dt><dd><select data-f="loginhibit"><option value="on"' + (li === 'on' ? ' selected' : '') + '>Logged</option><option value="error"' + (li === 'error' ? ' selected' : '') + '>Log only on error</option><option value="off"' + (li === 'off' ? ' selected' : '') + '>Don\'t log this stage</option></select></dd></dl>';
  if (st.type === 'Calculation' || st.type === 'MultipleCalculation') {
    var rows = []; var re = /<calculation expression="([^"]*)" stage="([^"]*)"/g, m; while ((m = re.exec(b))) rows.push([D.unx(m[1]), D.unx(m[2])]);
    if (st.type === 'MultipleCalculation') rows.push(['', '']);
    h += '<h4>Calculations</h4><table id="calcs"><tr><th>Expression</th><th>Store In</th></tr>' + rows.map(function (r) { return '<tr><td><input value="' + esc(r[0]) + '"></td><td><input value="' + esc(r[1]) + '"></td></tr>'; }).join('') + '</table>';
  }
  // the rows a person edits: steps of an application stage, branches of a Wait / Choice, a page's parameters
  sheetRows = {}; var TYPES = ['text', 'number', 'flag', 'date', 'datetime', 'time', 'timespan', 'password', 'collection', 'binary', 'image'];
  var goes = function (r) { return idName[r.target] || '(not wired: Link mode, click this stage then the target)'; };
  if (st.type === 'Navigate') h += editTable('steps', 'Steps', [{ key: 'element', label: 'Element', kind: 'element' }, { key: 'action', label: 'Action', kind: 'list', list: 'dl-act' }], E.stepsOf(b), 'done in this order');
  if (st.type === 'Read') h += editTable('steps', 'Steps', [{ key: 'element', label: 'Element', kind: 'element' }, { key: 'action', label: 'Read', kind: 'list', list: 'dl-act' }, { key: 'stage', label: 'Store In' }], E.stepsOf(b));
  if (st.type === 'Write') h += editTable('steps', 'Steps', [{ key: 'expr', label: 'Value' }, { key: 'element', label: 'Element', kind: 'element' }, { key: 'action', label: 'Action (browser elements only)', kind: 'list', list: 'dl-act' }], E.stepsOf(b));
  if (sheetRows.steps && sheetRows.steps.rows.length) { var flat = []; sheetRows.steps.rows.forEach(function (r, i) { (r.args || []).forEach(function (a) { flat.push({ step: String(i + 1), id: a.id, value: a.value }); }); });
    h += editTable('args', 'Action arguments', [{ key: 'step', label: 'Step', kind: 'pick', options: sheetRows.steps.rows.map(function (r, i) { return String(i + 1); }) }, { key: 'id', label: 'Argument', kind: 'list', list: 'dl-arg' }, { key: 'value', label: 'Value (expression)' }], flat, 'what a step\'s action is given: the window title of an Attach, the text of a Send Keys, a position ..') + '<datalist id="dl-arg">' + E.VOCAB.Args.map(function (v) { return '<option value="' + esc(v) + '">'; }).join('') + '</datalist>'; }
  if (st.type === 'Collection') h += editTable('fields', 'Columns', [{ key: 'name', label: 'Name' }, { key: 'type', label: 'Type', kind: 'pick', options: TYPES }, { key: 'description', label: 'Description' }, { key: 'nested', label: '', kind: 'ro', show: function (r) { return r.nested ? r.nested + ' column' + (r.nested === 1 ? '' : 's') + ' inside (kept)' : ''; } }], E.fieldsOf(b), 'no rows = an undefined collection: it takes whatever columns it is given');
  if (st.type === 'Process') { var pid = D.tag(b, 'processid').trim().toLowerCase(), procs = MEMBERS.filter(function (q) { return q.type === 'process' && q.id; }), knownP = procs.some(function (q) { return String(q.id).toLowerCase() === pid; });
    h += '<dl><dt>Process to run</dt><dd><select data-f="processid">' + (knownP ? '' : '<option value="' + esc(pid) + '" selected>' + (pid ? '(a process that is not in this release)' : '(choose)') + '</option>') + procs.map(function (q) { return '<option value="' + esc(q.id) + '"' + (String(q.id).toLowerCase() === pid ? ' selected' : '') + '>' + esc(q.name) + '</option>'; }).join('') + '</select></dd></dl>'
      + editTable('ioinput', 'Inputs', [{ key: 'name', label: 'Name' }, { key: 'type', label: 'Type', kind: 'pick', options: TYPES }, { key: 'expr', label: 'Value' }], E.ioOf(b, 'input'), 'the names must be the inputs of that process\'s Main Page Start stage')
      + editTable('iooutput', 'Outputs', [{ key: 'name', label: 'Name' }, { key: 'type', label: 'Type', kind: 'pick', options: TYPES }, { key: 'stage', label: 'Store In' }], E.ioOf(b, 'output')); }
  if (st.type === 'WaitStart') h += '<dl>' + field('Timeout (seconds or expression)', 'timeout', D.unx(D.tag(b, 'timeout'))) + '</dl>' + editTable('choices', 'Wait for', [{ key: 'name', label: 'Name' }, { key: 'element', label: 'Element', kind: 'element' }, { key: 'condition', label: 'Condition', kind: 'list', list: 'dl-cond' }, { key: 'compare', label: 'Compare', kind: 'pick', options: ['Equal', 'NotEqual', 'LessThan', 'GreaterThan', 'LessThanOrEqual', 'GreaterThanOrEqual'] }, { key: 'reply', label: 'Value' }, { key: 'target', label: 'Goes to', kind: 'ro', show: goes }], E.choicesOf(b), 'no rows = a plain pause for the timeout; the time-out path leaves from "' + ((E.partnerOf(M, st) || {}).name || 'the wait end') + '"');
  if (st.type === 'ChoiceStart') h += editTable('choices', 'Branches', [{ key: 'name', label: 'Name' }, { key: 'expression', label: 'Expression' }, { key: 'target', label: 'Goes to', kind: 'ro', show: goes }], E.choicesOf(b), 'checked top to bottom, the first true one is taken; none true = the path from "' + ((E.partnerOf(M, st) || {}).name || 'the choice end') + '"');
  if (st.type === 'Start' && st.page !== 'Main Page' || st.type === 'Start' && M.type === 'process') h += editTable('params', 'Page inputs', [{ key: 'name', label: 'Name' }, { key: 'type', label: 'Type', kind: 'pick', options: TYPES }, { key: 'stage', label: 'Store In' }], E.paramsOf(b, 'Start'));
  if (st.type === 'End' && (st.page !== 'Main Page' || M.type === 'process')) h += editTable('params', 'Page outputs', [{ key: 'name', label: 'Name' }, { key: 'type', label: 'Type', kind: 'pick', options: TYPES }, { key: 'stage', label: 'From' }], E.paramsOf(b, 'End'));
  if (sheetRows.steps || sheetRows.choices) { var voc = vocab(); h += '<datalist id="dl-act">' + voc.act.map(function (v) { return '<option value="' + esc(v) + '">'; }).join('') + '</datalist><datalist id="dl-cond">' + voc.cond.map(function (v) { return '<option value="' + esc(v) + '">'; }).join('') + '</datalist>'; }
  var ins = []; var rin = /<input ([^>]*)\/>/g; while ((m = rin.exec(b))) ins.push([D.attr(m[1], 'name'), D.attr(m[1], 'type'), D.attr(m[1], 'expr')]);
  var outs = []; var rout = /<output ([^>]*)\/>/g; while ((m = rout.exec(b))) outs.push([D.attr(m[1], 'name'), D.attr(m[1], 'type'), D.attr(m[1], 'stage')]);
  if (ins.length && st.type !== 'Start' && st.type !== 'End' && st.type !== 'Process') h += '<h4>Inputs</h4><table><tr><th>Name</th><th>Type</th><th>Value</th></tr>' + ins.map(function (r) { return '<tr><td>' + esc(r[0]) + '</td><td>' + esc(r[1]) + '</td><td><input data-f="in:' + esc(r[0]) + '" value="' + esc(r[2]) + '"></td></tr>'; }).join('') + '</table>';
  if (outs.length && st.type !== 'End' && st.type !== 'Start' && st.type !== 'Process') h += '<h4>Outputs</h4><table><tr><th>Name</th><th>Type</th><th>Store In</th></tr>' + outs.map(function (r) { return '<tr><td>' + esc(r[0]) + '</td><td>' + esc(r[1]) + '</td><td><input data-f="out:' + esc(r[0]) + '" value="' + esc(r[2]) + '"></td></tr>'; }).join('') + '</table>';
  for (var t = 0; t < info.tables.length; t++) { var tb = info.tables[t]; if (/^(Inputs|Outputs|Calculations)$/.test(tb.title) || (sheetRows.params && /^Page (inputs|outputs)$/.test(tb.title)) || (sheetRows.choices && /^(Conditions|Choices|Branches)$/.test(tb.title))) continue; if (tb.title === 'Steps' && sheetRows.steps) { if (!tb.rows.length) continue; tb = { title: 'Step details (arguments, what the spy found)', cols: tb.cols, rows: tb.rows }; } h += '<h4>' + esc(tb.title) + '</h4><table><tr>' + tb.cols.map(function (c) { return '<th>' + esc(c) + '</th>'; }).join('') + '</tr>' + tb.rows.map(function (r) { return '<tr>' + r.map(function (c) { return '<td>' + esc(c) + '</td>'; }).join('') + '</tr>'; }).join('') + '</table>'; }
  if (st.type === 'Code') h += '<h4>Code</h4><textarea data-f="code" class="code">' + esc(info.code) + '</textarea>';
  if (st.type === 'ProcessInfo') h += '<h4>Shared code</h4><p class="muted">fields and helpers every code stage of this object can use (Blue Prism keeps them in the Code Options stage)</p><textarea data-f="code" class="code">' + esc(D.tag(b, 'code').replace(/^\s*<!\[CDATA\[|\]\]>\s*$/g, '')) + '</textarea>';
  h += '<p class="apply"><button onclick="applySheet(\'' + id + '\')">Apply</button></p>';
  $('sh-body').innerHTML = h; $('sheet').hidden = false;
  [].forEach.call($('sh-body').querySelectorAll('[data-f]'), function (el) { el._v0 = el.value; });   // only a field somebody changed is written back
  if ($('calcs')) $('calcs')._v0 = JSON.stringify([].map.call($('calcs').querySelectorAll('input'), function (i) { return i.value; }));
  [].forEach.call($('sh-body').querySelectorAll('input'), function (i) { i.onkeydown = function (e) { if (e.key === 'Enter') applySheet(id); }; });
}
// ---------- editable rows in the sheet ----------
var sheetRows = {};
function vocab() {   // action / condition ids: the ones this file already uses first (they are right for its application), then the common ones
  var act = {}, cond = {}, m, ra = /<action>\s*<id>([^<]+)<\/id>/g, rc = /<condition>\s*<id>([^<]+)<\/id>/g;
  while ((m = ra.exec(M.xml))) act[m[1]] = 1; while ((m = rc.exec(M.xml))) cond[m[1]] = 1;
  var st = M.byId[sheetId], mine = st && E.VOCAB[st.type] ? E.VOCAB[st.type] : E.VOCAB.Navigate.concat(E.VOCAB.Read);
  var used = Object.keys(act).filter(function (k) { return !st || !E.VOCAB[st.type] || mine.indexOf(k) >= 0; }), usedC = Object.keys(cond);
  return { act: used.concat(mine.filter(function (k) { return !act[k]; })), cond: usedC.concat(E.VOCAB.Wait.filter(function (k) { return !cond[k]; })) };
}
function editTable(key, title, cols, rows, hint) {
  sheetRows[key] = { cols: cols, rows: rows };
  var els = Object.keys(M.elements || {}).map(function (id) { return [id, M.elements[id].name]; }).sort(function (a, b) { return a[1].localeCompare(b[1]); });
  var cell = function (c, r) {
    var v = r[c.key] == null ? '' : r[c.key];
    if (c.kind === 'ro') return '<span class="muted">' + esc(c.show(r)) + '</span>';
    if (c.kind === 'element') return '<select data-c="' + c.key + '">' + (els.some(function (e) { return e[0] === v; }) ? '' : '<option value="' + esc(v) + '" selected>' + (v ? '(unknown element)' : '(choose)') + '</option>') + els.map(function (e) { return '<option value="' + esc(e[0]) + '"' + (e[0] === v ? ' selected' : '') + '>' + esc(e[1]) + '</option>'; }).join('') + '</select>';
    if (c.kind === 'pick') return '<select data-c="' + c.key + '">' + (c.options.indexOf(v) >= 0 ? '' : '<option selected>' + esc(v) + '</option>') + c.options.map(function (o) { return '<option' + (o === v ? ' selected' : '') + '>' + esc(o) + '</option>'; }).join('') + '</select>';
    return '<input data-c="' + c.key + '" value="' + esc(v) + '"' + (c.kind === 'list' ? ' list="' + c.list + '"' : '') + '>';
  };
  var h = '<h4>' + esc(title) + '</h4>' + (hint ? '<p class="muted">' + esc(hint) + '</p>' : '') + '<table data-t="' + key + '"><tr>' + cols.map(function (c) { return '<th>' + esc(c.label) + '</th>'; }).join('') + '<th></th></tr>';
  rows.forEach(function (r, i) { h += '<tr data-i="' + i + '">' + cols.map(function (c) { return '<td>' + cell(c, r) + '</td>'; }).join('') + '<td><button class="rowx" onclick="sheetRow(\'' + key + '\',' + i + ')" title="remove this row">&times;</button></td></tr>'; });
  return h + '</table><p><button onclick="sheetRow(\'' + key + '\',-1)">+ row</button>' + (key === 'steps' && !els.length ? ' <span class="muted">this object has no Application Modeller elements yet</span>' : '') + '</p>';
}
function stepsWithArgs(steps, args) {   // the arguments table folded back into the steps they belong to
  var base = (steps || sheetRows.steps.rows).map(function (r) { return Object.assign({}, r, { args: [] }); });
  args.forEach(function (a) { var s = base[+a.step - 1]; if (s && a.id) s.args.push({ id: a.id, value: a.value || '' }); });
  return base;
}
function readTables() {   // the rows as they stand in the sheet; null for a table nobody touched
  var out = {};
  [].forEach.call($('sh-body').querySelectorAll('table[data-t]'), function (tb) {
    var key = tb.getAttribute('data-t'), src = sheetRows[key]; if (!src) return; var changed = false;
    var rows = [].map.call(tb.querySelectorAll('tr[data-i]'), function (tr) { var o = Object.assign({}, src.rows[+tr.getAttribute('data-i')]);
      [].forEach.call(tr.querySelectorAll('[data-c]'), function (el) { var k = el.getAttribute('data-c'); if ((o[k] == null ? '' : o[k]) !== el.value) { o[k] = el.value; changed = true; } }); return o; });
    out[key] = changed ? rows : null;
  });
  return out;
}
window.sheetRow = function (key, i) {   // remove row i, or add one at the end (i = -1)
  var id = sheetId, st = M.byId[id], src = sheetRows[key]; if (!st || !src) return; snap();
  var all = readTables(), now = all[key] || src.rows.slice();
  if (i >= 0) now.splice(i, 1); else now.push(key === 'params' ? { name: 'New ' + (st.type === 'Start' ? 'Input' : 'Output'), type: 'text', stage: '' } : key === 'fields' ? { name: 'New Column', type: 'text' } : key === 'ioinput' || key === 'iooutput' ? { name: 'New ' + (key === 'ioinput' ? 'Input' : 'Output'), type: 'text' } : key === 'args' ? { step: '1', id: 'newtext', value: '' } : {});
  if (key === 'args') { E.setField(st, 'steps', stepsWithArgs(all.steps, now)); if (all.steps === null) { } }
  else { if (key === 'steps' && all.args) now = stepsWithArgs(now, all.args); E.setField(st, key, now); }
  renderPage(); openSheet(id);
};
$('sh-body').addEventListener('change', function (e) {   // a field that changed is applied at once: no Apply needed
  var t = e.target; if (!sheetId || !t || !(t.matches('[data-f]') || (t.closest && (t.closest('#calcs') || t.closest('table[data-t]'))))) return;
  autoFormat(t);
  applySheet(sheetId, true);
});
// A box typed in the wrong form (quotes in a Store In box, bare text in an expression ..) is put in the right one and says so.
// Typing the same thing again keeps it as typed: the correction is an offer, not a rule.
function boxKind(t) {
  var st = M.byId[sheetId], f = t.dataset && t.dataset.f, typeOf = function () { var d = $('sh-body').querySelector('[data-f="datatype"]'); return (d && d.value) || (st && (D.tag(st.orig.body, 'datatype') || D.attr(st.orig.body, 'datatype'))) || 'text'; };
  if (f) {
    if (f === 'decision' || f === 'alert' || f === 'timeout' || f === 'ex.detail') return { kind: 'expr' };
    if (f.indexOf('in:') === 0) { var ty = t.closest('tr') && t.closest('tr').children[1] ? t.closest('tr').children[1].textContent.trim() : ''; return { kind: 'expr', type: ty || null }; }
    if (f.indexOf('out:') === 0 || f === 'loopdata') return { kind: 'store' };
    if (f === 'initialvalue' && st && st.type === 'Data') return { kind: 'value', type: typeOf() };
    return null;
  }
  if (t.tagName !== 'INPUT') return null;
  var tb = t.closest('table[data-t]'), c = t.getAttribute('data-c');
  if (tb) { var key = tb.getAttribute('data-t'); if (c === 'stage') return { kind: 'store' }; if (c === 'expr' || c === 'expression' || (key === 'args' && c === 'value')) return { kind: 'expr' }; return null; }
  if (t.closest('#calcs')) { var ins = t.closest('tr').querySelectorAll('input'); return { kind: ins[0] === t ? 'expr' : 'store' }; }
  return null;
}
function autoFormat(t) {
  var k = boxKind(t); if (!k) return; var raw = t.value;
  if (t._asTyped === raw) return;
  var pg = pages()[cur], names = M.stages.filter(function (s) { return !s.deleted && (s.type === 'Data' || s.type === 'Collection'); }).map(function (s) { return s.name; });
  var fx = E.fixFormat(k.kind, raw, { names: names, type: k.type }); if (!fx || fx.value === raw) return;
  t._asTyped = raw; t.value = fx.value; toast(raw + '  \u2192  ' + fx.value + '   (' + fx.why + '; type it again to keep yours)', 6000);
}
var sheetId = null;
window.applySheet = function (id, quiet) {
  var st = M.byId[id]; if (!st) return; snap();
  var ex = {};
  [].forEach.call($('sh-body').querySelectorAll('[data-f]'), function (el) {
    var f = el.dataset.f, v = el.value;
    if (el._v0 === v) return; el._v0 = v;   // untouched: the XML keeps what Blue Prism wrote, byte for byte
    if (f === 'name') { if (v !== st.name) E.rename(st, v); }
    else if (f === 'ex.type' || f === 'ex.detail') { ex.type = $('sh-body').querySelector('[data-f="ex.type"]').value; ex.detail = $('sh-body').querySelector('[data-f="ex.detail"]').value; }
    else if (f === 'narrative') { if (v !== D.unx(D.tag(st.orig.body, 'narrative'))) E.setField(st, 'narrative', v); }
    else if (f === 'references' || f === 'imports') E.setField(st, f, v.split(/\r?\n/).map(function (x) { return x.trim(); }).filter(Boolean));
    else E.setField(st, f, v);
  });
  if (ex.type !== undefined) E.setField(st, 'exception', ex);
  var tabs = readTables(); if (tabs.args) { sheetRows.args.rows = tabs.args; tabs.steps = stepsWithArgs(tabs.steps, tabs.args); } delete tabs.args;
  Object.keys(tabs).forEach(function (k) { if (tabs[k]) { E.setField(st, k, tabs[k]); sheetRows[k].rows = tabs[k]; } });
  var calcs = $('calcs'), calcNow = calcs ? JSON.stringify([].map.call(calcs.querySelectorAll('input'), function (i) { return i.value; })) : ''; if (calcs && calcs._v0 === calcNow) calcs = null; else if (calcs) calcs._v0 = calcNow;
  if (calcs) E.setField(st, 'calcs', [].map.call(calcs.querySelectorAll('tr'), function (tr) { var i = tr.querySelectorAll('input'); return i.length ? [i[0].value, i[1].value] : null; }).filter(Boolean));
  if (quiet) { renderPage(); $('sh-name').textContent = st.name; return; }   // the sheet stays as it is: the next field keeps the focus
  renderPage(); openSheet(id); toast('applied');
};
window.pickAction = function (id) {
  var st = M.byId[id]; if (!st) return; var o = $('pick-obj').value, acts = (OBJ.filter(function (x) { return x.object === o; })[0] || { actions: [] }).actions;
  var cur = $('pick-act').value, a = acts.filter(function (x) { return x.name === cur; })[0] || acts[0]; if (!a) return;
  snap(); for (var k in st.edits) if (/^(in|out):/.test(k)) delete st.edits[k]; E.setResource(st, o, a.name, a.inputs, a.outputs); renderPage(); openSheet(id);
};
window.pickPage = function (id) { var st = M.byId[id]; if (!st) return; var q = $('pick-page').value; if (pages().indexOf(q) < 0) return; snap(); for (var k in st.edits) if (/^(in|out):/.test(k)) delete st.edits[k]; E.setPageCall(M, st, q); renderPage(); openSheet(id); };
window.closeSheet = function () { $('sheet').hidden = true; sel = null; sheetId = null; if (typeof selEl !== 'undefined' && selEl) { selEl = null; if (typeof moTree === 'function') moTree(); } [].forEach.call(document.querySelectorAll('g.st.on,g.blk.on'), function (g) { g.classList.remove('on'); }); };

// ---------- rules + save ----------
function rules() {
  var r = E.checkRules(M), errs = r.filter(function (x) { return x.level === 'error'; }), warns = r.filter(function (x) { return x.level === 'warn'; });
  $('rules').innerHTML = (r.length ? r.map(function (x) { return '<li class="' + x.level + (x.id ? ' go" data-go="' + esc(x.id) + '" title="click: show this stage' : '') + '">' + esc(x.page ? x.page + ' / ' : '') + (x.stage ? '<b>' + esc(x.stage) + '</b>' + esc(whichOf(x.id)) + ': ' : '') + esc(x.msg) + '</li>'; }).join('') : '<li class="ok">all rules pass</li>');
  $('rulecount').textContent = errs.length ? errs.length + ' problem' + (errs.length === 1 ? '' : 's') + (warns.length ? ', ' + warns.length + ' warning' + (warns.length === 1 ? '' : 's') : '') : warns.length ? 'ok, ' + warns.length + ' warning' + (warns.length === 1 ? '' : 's') : 'all rules pass';
  pbRules();
  var liveErrs = errs.length;   // what Save asks about: errors of the drawing as it is now, not the report made when this version was opened
  var stat = (typeof BW_STATIC !== 'undefined' && BW_STATIC) || {}; if (stat.compile === false) { $('rulecount').textContent += ' - code does not compile'; errs.push(1); } else if (stat.validate === false) { $('rulecount').textContent += ' - validate found problems'; errs.push(1); }
  $('checks').className = errs.length ? 'bad' : warns.length ? 'meh' : 'good';
  lastErrs = liveErrs; $('save').disabled = false; $('save').title = (window.BW_SERVE ? 'save as ' : 'download ') + nextName() + (liveErrs ? ' - ' + liveErrs + ' error' + (liveErrs === 1 ? '' : 's') + ' in the live checks, Save asks first' : '');
}
// the bank's written coding rules: grouped by rule with a count, closed until asked for (a real object has hundreds of naming findings)
var PB_LABEL = { naming: 'Naming', descriptions: 'Descriptions', hardcoded: 'Hardcoded values', waits: 'Fixed-time waits', attach: 'Attaching', code: 'Code stages', globals: 'Global variables', screenshot: 'Screenshot on exception', structure: 'Process structure', queues: 'Work queues', wrappers: 'Wrapper actions', 'sub-process': 'Sub-processes', 'queue item': 'Queue item', 'open and close': 'Opened and not closed', 'no wait after a screen change': 'No wait after a screen change', 'cleared before use': 'Cleared before use', 'element matching': 'Element matching (Application Modeller)' };
function recoveredLine(rows) { var rc = []; try { rc = E.recoveredErrors(rows || []); } catch (e) { } if (!rc.length) return ''; return 'failed and recovered (the run went on): ' + rc.slice(0, 5).map(function (x) { return '"' + x.stage + '"' + (x.n > 1 ? ' x' + x.n : '') + ' at stage ' + x.first + ' (' + x.page + ')'; }).join('; ') + (rc.length > 5 ? '; and ' + (rc.length - 5) + ' more' : ''); }
function pbRules() { groupBox('pbrules', E.codingRules); groupBox('lgrules', function (m) { var r = E.logicChecks(m); try { var ad = typeof moText === 'function' ? moText() : ''; if (ad && window.MORDECAI) r = r.concat(window.MORDECAI.checks(ad, typeof moUsed === 'function' ? moUsed() : {})); } catch (e) { } return r; }); }
// a finding names a stage; several stages of one page can carry that name ("Extract Amount" x3): say which, by where it sits
function whichOf(id) { var st = M.byId[id]; if (!st) return ''; var tw = M.stages.filter(function (s) { return !s.deleted && s.page === st.page && s.name === st.name && s.type !== 'Data' && s.type !== 'Collection'; }); if (tw.length < 2) return '';
  tw.sort(function (a, b) { return a.y - b.y || a.x - b.x; }); return ' (' + (tw.indexOf(st) + 1) + ' of ' + tw.length + ' with this name, from the top)'; }
// show one stage: its page, selected, in view, with its sheet
function goStage(id) { var st = M.byId[id]; if (!st || st.deleted) { toast('that stage is gone'); return false; } var pg = pages(), i = pg.indexOf(st.page); if (i < 0) return false;
  if (photo) { toast('leave the walk (Esc) first'); return false; }
  cur = i; multi = []; sel = id; selLink = null; renderAll(); highlight(id); openSheet(id);
  var g = document.querySelector('section:not([hidden]) [data-sid="' + id + '"]'), box = $('panes');   // the drawing scrolls inside #panes: put the stage in its middle (scrollIntoView does not do it for a shape inside an svg)
  if (g && box) { var r = g.getBoundingClientRect(), b = box.getBoundingClientRect(), sh = $('sheet'), sr = sh && !sh.hidden ? sh.getBoundingClientRect() : null, right = sr && sr.left > b.left && sr.left < b.right ? sr.left : b.right;
    box.scrollTop += r.top + r.height / 2 - (b.top + b.height / 2); box.scrollLeft += r.left + r.width / 2 - (b.left + right) / 2; }
  return true; }
document.addEventListener('click', function (e) { var li = e.target.closest && e.target.closest('[data-go]'); if (!li) return; var ids = li.getAttribute('data-go').split(' '), n = (+li.getAttribute('data-n') || 0) % ids.length; li.setAttribute('data-n', n + 1);
  if (goStage(ids[n]) && ids.length > 1) toast((n + 1) + ' of ' + ids.length + ': ' + M.byId[ids[n]].page); });
function groupBox(id, fn) {
  var box = $(id); if (!box) return; var r = []; try { r = fn(M); } catch (e) { box.textContent = 'could not check: ' + e.message; return; }
  var open = {}; [].forEach.call(box.querySelectorAll('details[open]'), function (d) { open[d.getAttribute('data-r')] = 1; });
  // the same finding about the same name on several pages is one line ("Error Text" on 40 pages), not 40
  var by = {}, order = [], same = {}; r.forEach(function (x) { if (!by[x.rule]) { by[x.rule] = []; order.push(x.rule); } var k = x.rule + '|' + x.stage + '|' + x.msg, s = x.stage ? same[k] : null; if (s) { if (s.pages.indexOf(x.page) < 0) s.pages.push(x.page); return; } s = { stage: x.stage, msg: x.msg, pages: [x.page], ids: [] }; if (x.stage) same[k] = s; by[x.rule].push(s); });
  r.forEach(function (x) { var s = same[x.rule + '|' + x.stage + '|' + x.msg]; if (s && x.id && s.ids.indexOf(x.id) < 0) s.ids.push(x.id); });
  box.innerHTML = order.length ? order.map(function (k) { return '<details data-r="' + esc(k) + '"' + (open[k] || id === 'lgrules' ? ' open' : '') + '><summary>' + esc(PB_LABEL[k] || k) + ' <span class="muted">(' + by[k].length + ')</span></summary><ul>' + by[k].map(function (x) { var n = x.pages.length; var ids = x.ids || []; return '<li' + (ids.length ? ' class="go" data-go="' + esc(ids.join(' ')) + '"' : '') + ' title="' + esc((n > 1 ? x.pages.join(', ') + ' - ' : '') + (ids.length > 1 ? 'click again for the next of ' + ids.length : ids.length ? 'click: show this stage' : '')) + '">' + esc(n > 1 ? n + ' pages / ' : x.pages[0] ? x.pages[0] + ' / ' : '') + (x.stage ? '<b>' + esc(x.stage) + '</b>' + esc(ids.length === 1 ? whichOf(ids[0]) : ids.length > 1 && n === 1 ? ' (' + ids.length + ' stages)' : '') + ': ' : '') + esc(x.msg) + '</li>'; }).join('') + '</ul></details>'; }).join('') : '<span class="muted">nothing found</span>';
}
function nextName() { return BW_BASE + '.v' + (BW_VER + 1) + '.xml'; }
var lastErrs = 0;
window.saveXml = function () {
  // the checks never refuse a save: a real object rarely passes every house rule, and a half-done one still has to be kept
  if (lastErrs && !confirm(lastErrs + ' error' + (lastErrs === 1 ? '' : 's') + ' in the live checks (a stage without a link, a missing End ..: the panel next to Run lists them).\n\nSave this version anyway?')) return;
  var xml = E.serialize(M);
  if (window.BW_SERVE) {   // served by gumball: the next version goes straight into the project folder and opens with its diff
    try { localStorage.setItem('gumball:' + BW_BASE, xml); } catch (e) { }
    toast('saving...');
    fetch('/save?base=' + encodeURIComponent(window.BW_SERVE.base) + (window.BW_SERVE.rel ? '&rel=' + encodeURIComponent(window.BW_SERVE.rel) : ''), { method: 'POST', body: xml }).then(function (r) { return r.json(); })
      .then(function (j) { if (j.error) { toast('save failed: ' + j.error); return; } clearTimeout(draftT); draftT = null; try { localStorage.removeItem(DRAFT_KEY); } catch (e) { } toast('saved ' + j.name); location.href = j.url; }, function (e) { toast('save failed: is gumball still running? ' + e); });
    return;
  } var blob = new Blob([xml], { type: 'text/xml' }); var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = nextName(); document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
  try { localStorage.setItem('gumball:' + BW_BASE, xml); } catch (e) { }
  toast('downloaded ' + nextName() + ' - drop it next to this file and run gumball render on it');
};
window.copyXml = function () { var xml = E.serialize(M); if (navigator.clipboard) navigator.clipboard.writeText(xml).then(function () { toast('XML copied'); }, function () { toast('copy refused'); }); };
window.toggleGrid = function () { var g = document.body.classList.toggle('grid'); try { localStorage.setItem('gumball:grid', g ? '1' : '0'); } catch (e) { } toast(g ? 'grid on: stages snap to the 15px Studio grid' : 'grid off: free placement'); };
window.toggleTheme = function () { var d = document.body.classList.toggle('dark'); try { localStorage.setItem('gumball:theme', d ? 'dark' : 'light'); } catch (e) { } renderAll(); toast(d ? 'dark' : 'light: Blue Prism Studio look'); };
window.openSheet = openSheet;
window.toggleChecks = function () { $('checkpanel').hidden = !$('checkpanel').hidden; };
window.toggleDiff = function () { $('diff').hidden = !$('diff').hidden; };

// ---------- search ----------
// find: Enter goes to the first stage named like that, Enter again to the next (Shift+Enter back), page after page, top to bottom
var findQ = '', findI = -1;
$('q').onkeydown = function (e) { if (e.key !== 'Enter') return; var q = this.value.trim().toLowerCase(); if (!q) return; var pg = pages();
  var hits = M.stages.filter(function (s) { return !s.deleted && !/^(SubSheetInfo|ProcessInfo)$/.test(s.type) && s.name.toLowerCase().indexOf(q) >= 0 && pg.indexOf(s.page) >= 0; })
    .sort(function (a, b) { return pg.indexOf(a.page) - pg.indexOf(b.page) || a.y - b.y || a.x - b.x; });
  if (!hits.length) { toast('no stage named like that'); return; }
  if (q !== findQ) { findQ = q; findI = e.shiftKey ? 0 : -1; }
  findI = (findI + (e.shiftKey ? -1 : 1) + hits.length * 2) % hits.length; if (e.shiftKey && findI < 0) findI = hits.length - 1;
  var st = hits[findI]; if (goStage(st.id)) { toast((findI + 1) + ' of ' + hits.length + ': ' + st.page + ' / ' + st.name + (hits.length > 1 ? '   (Enter: next, Shift+Enter: back)' : ''), 3500); this.focus(); } };

// ---------- release navigation (served releases): every member one click away; Action stages jump to their object's action ----------
var SERVED = !!window.BW_SERVE, LINKS = (typeof BW_LINKS !== 'undefined' && BW_LINKS) || {};
var MEMBERS = (SERVED && window.BW_SERVE.members) || (typeof BW_MEMBERS !== 'undefined' && BW_MEMBERS) || [];
var RELNAME = (SERVED && window.BW_SERVE.relName) || (typeof BW_RELNAME !== 'undefined' && BW_RELNAME) || '';
function objUrl(name, pageName) {   // address of an object's page, on the page of one action. Served: through gumball; from the folder: the neighbour's file
  if (!name) return null; var k = '~' + String(name).replace(/\s+/g, ' ').trim().toLowerCase();
  var so = SERVED && window.BW_SERVE.objects, u = (so && (so[name] || so[k])) || LINKS[name] || LINKS[k]; if (!u) return null;
  return u + (pageName ? '#page=' + encodeURIComponent(pageName) : '');
}
function actionsOf(name) { for (var i = 0; i < OBJ.length; i++) if (OBJ[i].object === name) return OBJ[i].actions; return null; }
function actionsText(acts) { return acts.length + ' published action' + (acts.length === 1 ? '' : 's') + (acts.length ? ': ' + acts.map(function (a) { return a.name; }).slice(0, 14).join(', ') + (acts.length > 14 ? ', ...' : '') : ''); }
window.leaveOk = function () { if (draftT) draftNow(); return !dirty || draftKept || confirm('These changes could not be kept as a draft. Leave this page anyway?'); };
function miniList(boxId, title, items, onRender) {
  var box = $(boxId); if (!box) return;
  var openKey = 'gumball:open:' + boxId, isOpen = true; try { isOpen = localStorage.getItem(openKey) !== '0'; } catch (e) { }
  box.innerHTML = '<details' + (isOpen ? ' open' : '') + '><summary class="navh">' + title + '</summary><div class="mini"><input placeholder="filter"><ul></ul></div></details>';
  var det = box.querySelector('details'), inp = box.querySelector('input'), ul = box.querySelector('ul');
  det.ontoggle = function () { try { localStorage.setItem(openKey, det.open ? '1' : '0'); } catch (e) { } };
  var draw = function () {
    var q = inp.value.toLowerCase(), hit = items.filter(function (it) { return it.text.toLowerCase().indexOf(q) >= 0; });
    ul.innerHTML = hit.slice(0, 300).map(function (it, i) { return '<li class="' + (it.on ? 'on' : '') + '" title="' + esc(it.title || it.text) + '" data-i="' + items.indexOf(it) + '"><b>' + esc(it.tag || '') + '</b>' + esc(it.text) + '</li>'; }).join('') + (hit.length > 300 ? '<li class="more">' + (hit.length - 300) + ' more: filter</li>' : '') + (hit.length ? '' : '<li class="more">nothing matches</li>');
    [].forEach.call(ul.querySelectorAll('li[data-i]'), function (li) { li.onclick = function () { onRender(items[+li.dataset.i]); }; });
  };
  inp.oninput = draw; draw();
}
// one list: inside a release, the Release list is the list (objects show their actions on hover);
// "Objects known" only shows objects that are NOT members, and on pages outside a release.
var memberNames = {};
if (MEMBERS.length) {
  for (var mi = 0; mi < MEMBERS.length; mi++) memberNames[MEMBERS[mi].name] = 1;
  miniList('relnav', 'Release <span class="muted">' + esc(RELNAME) + ' (' + MEMBERS.length + ')</span>',
    MEMBERS.map(function (m) { var acts = m.type === 'object' ? actionsOf(m.name) : null; return { text: m.name, tag: m.type === 'object' ? 'O' : 'P', title: (m.type === 'object' ? 'object: ' : 'process: ') + m.name + (acts ? ' - ' + actionsText(acts) : ''), on: m.base === BW_BASE, url: m.url }; }),
    function (it) { if (!it.on && leaveOk()) location.href = it.url; });
}
var others = OBJ.filter(function (o) { return !(MEMBERS.length && (memberNames[o.object] || objUrl(o.object))); });
if (others.length) {
  miniList('objknown', (MEMBERS.length ? 'Other objects known' : 'Objects known') + ' <span class="muted">(' + others.length + ')</span>',
    others.map(function (o) { var u = objUrl(o.object); return { text: o.object, tag: o.internal ? 'I' : u ? 'O' : '', title: o.object + ' - ' + (o.internal ? 'Blue Prism internal object (' + (o.verified ? 'verified list' : 'seed list, see internal/README.txt') + ') - ' : '') + actionsText(o.actions) + (o.internal ? '' : u ? ' - click to open it' : MEMBERS.length ? ' - not in this release' : ' - not open in gumball'), url: u }; }),
    function (it) { if (it.url) { if (leaveOk()) location.href = it.url; } else toast(it.title); });
}
// ---------- mordecai: the Application Modeller (objects only) ----------
var MO = window.MORDECAI, selEl = null, MOTAG = { win32: 'W32', aa: 'AA', uia: 'UIA', web: 'WEB', html: 'HTML', sap: 'SAP', region: 'RGN', application: 'APP', none: '' };
function moText() { if (M.appdef != null) return M.appdef; var f = MO && MO.find(M.xml); return f ? M.xml.slice(f.start, f.end) : null; }
function moUsed() { var out = {}, st = E.bpOf(M).stages; for (var i = 0; i < st.length; i++) { var re = /<element id="([^"]+)"/g, m, seen = {}; while ((m = re.exec(st[i].body))) { if (seen[m[1]]) continue; seen[m[1]] = 1; (out[m[1]] = out[m[1]] || []).push(st[i].name); } } return out; }
function moSync() {   // after any change of the model: what stages show for an element, the tree, the open sheet
  var t = moText(); if (!t) return; var p = MO.parse(t); M.elements = {};
  for (var i = 0; i < p.list.length; i++) { var e = p.list[i]; if (e.id) M.elements[e.id] = { name: e.name, type: e.type, attrs: e.attrs.filter(function (a) { return a.inuse; }).map(function (a) { return a.name + '=' + a.value; }) }; }
  moTree(); if (selEl) { if (p.byId[selEl]) openElement(selEl); else { selEl = null; $('sheet').hidden = true; } }
}
function moApply(fn) { try { var t = fn(moText()); snap(); M.appdef = typeof t === 'string' ? t : t.appdef; if (t && t.id) selEl = t.id; moSync(); renderPage(); return true; } catch (e) { toast(e.message); return false; } }
function moTree() {
  var box = $('appmodel'), t = moText(); if (!box) return;
  if (!t) {   // an object that never had an Application Modeller (made by hand or by the generator): offer one
    if (M.type !== 'object' && M.type !== 'Object' && !/object/i.test(String(M.type || ''))) { box.innerHTML = ''; return; }
    box.innerHTML = '<details open><summary class="navh">Application Modeller <span class="muted">(none)</span></summary><div class="mini" style="padding:4px 10px"><button onclick="moCreate()" title="give this object an application model: a root element, then pick how the application starts">+ Application Modeller</button></div></details>'; return;
  }
  var p = MO.parse(t), used = moUsed();
  var spied = p.list.filter(function (e) { return e.attrs.length; }).length, key = 'gumball:open:appmodel', isOpen = true; try { isOpen = localStorage.getItem(key) !== '0'; } catch (e) { }
  var q = (box.querySelector('input') || {}).value || '';
  box.innerHTML = '<details' + (isOpen ? ' open' : '') + '><summary class="navh">Application Modeller <span class="muted">(' + spied + ' spied' + (p.app.mode ? ', ' + esc(p.app.mode) : '') + ')</span></summary><div class="mini"><input placeholder="filter"><ul></ul></div></details>';
  var det = box.querySelector('details'), inp = box.querySelector('input'), ul = box.querySelector('ul'); inp.value = q;
  det.ontoggle = function () { try { localStorage.setItem(key, det.open ? '1' : '0'); } catch (e) { } };
  var draw = function () {
    var f = inp.value.toLowerCase(), hit = p.list.filter(function (e) { return !f || e.name.toLowerCase().indexOf(f) >= 0; });
    ul.innerHTML = hit.map(function (e) { var u = used[e.id]; return '<li class="el' + (e.id === selEl ? ' on' : '') + (e.kind !== 'application' && !u ? ' unused' : '') + '" data-id="' + esc(e.id) + '" style="padding-left:' + (6 + (f ? 0 : e.depth * 10)) + 'px" title="' + esc(e.name + ' - ' + (MO.KINDS[e.kind] ? MO.KINDS[e.kind].label : e.kind) + (u ? ' - used by ' + u.length + ' stage' + (u.length === 1 ? '' : 's') : e.kind === 'application' ? '' : ' - no stage uses it')) + '">' + (MOTAG[e.kind] ? '<i>' + MOTAG[e.kind] + '</i>' : '') + esc(e.name) + '</li>'; }).join('') || '<li class="more">nothing matches</li>';
    [].forEach.call(ul.querySelectorAll('li.el'), function (li) { li.onclick = function () { openElement(li.dataset.id); }; });
  };
  inp.oninput = draw; draw();
}
function openElement(id) {
  var t = moText(); if (!t) return; var p = MO.parse(t), e = p.byId[id]; if (!e) return;
  sel = null; sheetId = null; highlight(null); selEl = id; var used = moUsed()[id] || [], K = MO.KINDS[e.kind];
  $('sh-type').textContent = K ? K.label : e.kind === 'application' ? 'Application' : 'Element'; $('sh-name').textContent = e.name;
  var h = '<h4>Element</h4><dl><dt>Name</dt><dd><input value="' + esc(e.name) + '" onchange="moRename(this.value)"></dd><dt>Type</dt><dd>' + esc(e.type || e.base) + (e.base && e.base !== e.type ? ' (' + esc(e.base) + ')' : '') + (e.dtype ? ', ' + esc(e.dtype) : '') + '</dd>'
    + '<dt>Used by</dt><dd>' + (used.length ? used.map(esc).join(', ') : '<span class="muted">no stage</span>') + '</dd></dl>';
  if (e.kind === 'application') {
    var modes = Object.keys(MO.MODES); if (p.app.mode && modes.indexOf(p.app.mode) < 0) modes.push(p.app.mode);
    h += '<h4>Application</h4><dl><dt>Mode</dt><dd><select onchange="moSetMode(this.value)"><option value=""' + (p.app.mode ? '' : ' selected') + '>(not set: pick how the application starts)</option>' + modes.map(function (k) { return '<option value="' + esc(k) + '"' + (k === p.app.mode ? ' selected' : '') + '>' + esc(k) + (MO.MODES[k] ? ' - ' + MO.MODES[k].label : '') + '</option>'; }).join('') + '</select></dd>'
      + p.app.params.map(function (x) { return '<dt>' + esc(x.name) + '</dt><dd><input value="' + esc(x.value) + '" onchange="moSetParam(\'' + esc(x.name) + '\',this.value)"></dd>'; }).join('') + '</dl>'
      + (p.app.mode && MO.MODES[p.app.mode] && !MO.MODES[p.app.mode].verified ? '<div class="muted">The parameter list of ' + esc(p.app.mode) + ' was not read off a real export yet: compare with one Studio wrote before relying on it.</div>' : '')
      + (!p.app.mode ? '<div class="muted">Without a mode Studio shows the wizard on open. Win32Launch starts the program at Path; Attach modes hook a window already open; SAP is Win32Launch of the SAP GUI (saplgpad).</div>' : '');
  }
  var row = function (a) {
    var long = a.value.length > 300, cmps = MO.COMPARISONS.indexOf(a.cmp || 'Equal') >= 0 ? MO.COMPARISONS : MO.COMPARISONS.concat([a.cmp]);
    return '<tr><td><input type="checkbox"' + (a.inuse ? ' checked' : '') + ' onchange="moSet(\'' + esc(a.name) + '\',{inuse:this.checked})" title="match on this attribute"></td><td class="n">' + esc(a.name) + '</td><td><select onchange="moSet(\'' + esc(a.name) + '\',{cmp:this.value})">' + cmps.map(function (c) { return '<option' + ((a.cmp || 'Equal') === c ? ' selected' : '') + '>' + esc(c) + '</option>'; }).join('') + '</select></td><td>'
      + (long ? '<span class="muted">' + esc(a.value.slice(0, 40)) + '... (' + a.value.length + ' chars, kept as is)</span>' : '<input value="' + esc(a.value) + '" onchange="moSet(\'' + esc(a.name) + '\',{value:this.value})">') + '</td></tr>';
  };
  if (e.attrs.length) {
    var on = e.attrs.filter(function (a) { return a.inuse; }), off = e.attrs.filter(function (a) { return !a.inuse; });
    h += '<h4>Matched on (' + on.length + ')</h4>' + (on.length ? '<table class="mo">' + on.map(row).join('') + '</table>' : '<div class="muted">nothing ticked: Blue Prism would match the first element it finds</div>');
    h += '<details' + (window._moOpen ? ' open' : '') + ' ontoggle="window._moOpen=this.open"><summary><h4 style="display:inline-block;cursor:pointer">Recorded, not matched (' + off.length + ')</h4></summary><table class="mo">' + off.map(row).join('') + '</table></details>';
  }
  h += '<h4>Model</h4><div class="mobtn">' + (e.attrs.length ? '<button onclick="moAddLike()" title="a new element next to this one with the same type, attributes and match ticks">+ one like this</button>' : '')
    + '<select id="mo-kind">' + Object.keys(MO.KINDS).map(function (k) { return '<option value="' + k + '"' + (k === e.kind ? ' selected' : '') + '>' + esc(MO.KINDS[k].label) + '</option>'; }).join('') + '</select><button onclick="moAddBlank()" title="a new, empty element of that spy mode under this one">+ blank child</button>'
    + (e.attrs.length ? '<button onclick="moFill()" title="paste the JSON a spy printed for this element: its values go into the attributes, ticks stay">fill from spy</button>' : '')
    + (SERVED && MO.KINDS[e.kind] ? '<button onclick="moSpy(false)" style="background:#2f5f9e;color:#fff;border-color:#2f5f9e" title="5 seconds to switch to the application and put the mouse on the control (a region: its two corners, one after the other); the values then fill this element">Spy this element</button>' : '')
    + (SERVED ? '<button onclick="moSpy(true)" title="spy a control (mode from the list on the left) and add it as a new element: inside this window, or next to this control">Spy a new element</button>' : '')
    + (SERVED && e.kind === 'application' ? '<button onclick="moLaunch()" title="start the application from the Path in this model (the last saved version)">Launch application</button>' : '')
    + (e.parent ? '<button onclick="moRemove()" style="margin-left:auto;color:#c62828">remove</button>' : '') + '</div><div class="muted">Values typed here are what Blue Prism will look for. "fill from spy" takes the JSON of a spied element (docs: copilot_mordecai_spy_handoff.md).</div>';
  $('sh-body').innerHTML = h; $('sheet').hidden = false; moTree();
}
// an Action stage names a Blue Prism internal object by its class (Blueprism.Automate.clsWorkQueuesActions): show it under its display name
function objAlias(name) { for (var i = 0; i < OBJ.length; i++) if ((OBJ[i].classes || []).indexOf(name) >= 0 || OBJ[i].cls === name) return OBJ[i].object; return name; }
window.moCreate = function () { var n = prompt('Name of the application (the root element):', M.name || 'Application'); if (!n) return; snap(); M.appdef = MO.create(n); moSync(); renderPage(); var p = MO.parse(M.appdef); openElement(p.list[0].id); };
window.moSetMode = function (mode) { moApply(function (t) { var cur = MO.parse(t).app, keep = {}; cur.params.forEach(function (x) { keep[x.name] = x.value; });
  if (!mode) { var a = t.indexOf('<apptypeinfo'), b = a < 0 ? -1 : t.indexOf('</apptypeinfo>', a); return a >= 0 && b >= 0 ? t.slice(0, a) + t.slice(b + '</apptypeinfo>'.length) : t; }
  var params = (MO.MODES[mode] ? MO.MODES[mode].params : cur.params.map(function (x) { return [x.name, x.value]; })).map(function (q) { return [q[0], keep[q[0]] != null ? keep[q[0]] : q[1]]; });
  return MO.setApp(t, mode, params); }); };
window.moSetParam = function (name, value) { moApply(function (t) { var cur = MO.parse(t).app; return MO.setApp(t, cur.mode, cur.params.map(function (x) { return [x.name, x.name === name ? value : x.value]; })); }); };
window.moSet = function (name, patch) { var id = selEl; moApply(function (t) { return MO.setAttribute(t, id, name, patch); }); };
window.moRename = function (name) { var id = selEl; moApply(function (t) { return MO.rename(t, id, name); }); };
window.moAddLike = function () { var id = selEl, e = MO.parse(moText()).byId[id], n = prompt('Name of the new element:', e.name + ' 2'); if (!n) return; moApply(function (t) { return MO.add(t, e.parent ? e.parent.id : id, n, { like: id }); }); };
window.moAddBlank = function () { var id = selEl, k = $('mo-kind').value, n = prompt('Name of the new ' + MO.KINDS[k].label + ' element:', ''); if (!n) return; moApply(function (t) { return MO.add(t, id, n, { kind: k }); }); };
window.moFill = function () { var id = selEl, raw = prompt('Paste the spy JSON for this element ({"attrs": {...}} or just {name: value}):', ''); if (!raw) return; var j; try { j = JSON.parse(raw); } catch (e) { return toast('not JSON: ' + e.message); }
  var res = null; if (moApply(function (t) { res = MO.fill(t, id, j.attrs || j); return res.appdef; })) toast(res.set.length + ' value(s) set' + (res.skipped.length ? ', ' + res.skipped.length + ' not in this element' : '')); };
// the spy, run by gumball: countdown here, the reading happens in PowerShell, the result lands in the element
var SPY_HINT = { sap: 'the SAP field', html: 'the element in the page (IE mode)', web: 'the element in the Edge page', region: 'the corner' };
function spyCall(mode, secs, say, extra) {   // one run of the spy with a countdown; resolves with its JSON
  var t = $('toast'), left = secs, tick = function () { t.hidden = false; clearTimeout(t._t); t.textContent = left > 0 ? say + ' ... ' + left : 'reading: keep the mouse there until this message changes'; };
  tick(); var iv = setInterval(function () { left--; tick(); if (left <= 0) clearInterval(iv); }, 1000);
  return fetch('/spy?mode=' + mode + '&seconds=' + secs + (extra || ''), { method: 'POST' }).then(function (r) { return r.json(); }).then(function (r) { clearInterval(iv); t.hidden = true; if (r.error) throw new Error(r.error); return r.spy; }, function (e) { clearInterval(iv); t.hidden = true; throw e; });
}
function spyRegion() {   // two corners, each held under the mouse, then the rectangle is captured
  var a;
  return spyCall('point', 5, 'REGION 1/2: switch to the application and hold the mouse on the TOP-LEFT corner').then(function (p1) { a = p1.point;
    return spyCall('point', 4, 'REGION 2/2: now hold the mouse on the BOTTOM-RIGHT corner'); }).then(function (p2) { var b = p2.point;
    if (!a || !b || b.x <= a.x || b.y <= a.y) throw new Error('the second corner has to be below and to the right of the first (got ' + JSON.stringify(a) + ' then ' + JSON.stringify(b) + ')');
    return spyCall('region', 0, 'capturing', '&x1=' + a.x + '&y1=' + a.y + '&x2=' + b.x + '&y2=' + b.y); });
}
window.moSpy = function (asNew) {
  var id = selEl, e = MO.parse(moText()).byId[id], pick = $('mo-kind') ? $('mo-kind').value : 'uia', ok = function (k) { return !!MO.KINDS[k]; };
  var mode = asNew ? (ok(pick) ? pick : ok(e.kind) ? e.kind : 'uia') : e.kind;
  var run = mode === 'region' ? spyRegion() : spyCall(mode, 5, 'SPY (' + MO.KINDS[mode].label + '): switch to the application and hold the mouse on ' + (SPY_HINT[mode] || 'the control'));
  run.then(function (j) {
    var n = Object.keys(j.attrs || {}).length, extra = mode === 'sap' ? ['SubType'] : [];
    if (!n) { alert('The spy found nothing readable there' + (j.errors ? ':\n' + j.errors.join('\n') : '.')); return; }
    var what = 'Found: ' + (j.name || '(no name)') + ' [' + (j.base || mode) + ']' + (j.errors && j.errors.length ? '\nNotes: ' + j.errors.join('; ') : '');
    if (asNew) {
      var name = prompt(what + '\nName of the new element:', j.name || ''); if (!name) return;
      var under = (e.kind === 'application' || e.children.length || /Window$/.test(e.base) || !e.parent) ? id : e.parent.id;   // next to a control, inside a window
      moApply(function (x) { var a = MO.add(x, under, name, { kind: mode, base: j.base || undefined }); var f = MO.fill(a.appdef, a.id, j.attrs, { addMissing: extra }); return { appdef: f.appdef, id: a.id }; });
      toast('added "' + name + '" with ' + n + ' values');
    } else {
      if (!confirm(what + '\n\nPut its ' + n + ' values into "' + e.name + '"? (ticks and comparison types stay; Ctrl+Z undoes it)')) return;
      var res = null; if (moApply(function (x) { res = MO.fill(x, id, j.attrs, { addMissing: extra }); return res.appdef; })) toast(res.set.length + ' value(s) changed' + (res.skipped.length ? ', ' + res.skipped.length + ' not in this element' : ''));
    }
    var un = Object.keys(j.unconfirmed || {}); if (un.length) console.log('spy, unconfirmed values (not used):', j.unconfirmed);
  }, function (err) { alert('Spy failed:\n\n' + (err && err.message || err)); });
};
window.moLaunch = function () {
  if (undo.length && !confirm('The application is started from the last SAVED version of this object. Continue?')) return;
  fetch('/launch?base=' + encodeURIComponent(BW_BASE) + (window.BW_SERVE.rel ? '&rel=' + encodeURIComponent(window.BW_SERVE.rel) : ''), { method: 'POST' }).then(function (r) { return r.json(); }).then(function (r) { if (r.error) alert(r.error); else toast('started ' + r.started); });
};
window.moRemove = function () { var id = selEl, e = MO.parse(moText()).byId[id], u = moUsed(), hit = []; (function walk(x) { if (u[x.id]) hit = hit.concat(u[x.id]); x.children.forEach(walk); })(e);
  if (!confirm('Remove "' + e.name + '"' + (e.children.length ? ' and the ' + e.children.length + ' element(s) under it' : '') + '?' + (hit.length ? '\n\nStill used by: ' + hit.slice(0, 12).join(', ') + (hit.length > 12 ? ', ...' : '') + '\nThose stages will point at nothing.' : ''))) return;
  selEl = null; $('sheet').hidden = true; moApply(function (t) { return MO.remove(t, id); }); };
if (MO && M.type === 'object' && moText()) moTree();
if (SERVED && window.BW_SERVE.problem) toast(window.BW_SERVE.problem);
// ---------- Run (served only): bprun executes the flow, the trace lands on the drawing like a Radar incident ----------
if (SERVED && $('runb')) $('runb').hidden = false; if (SERVED && $('brkb')) $('brkb').hidden = false;
if (SERVED && $('sysb')) $('sysb').hidden = false;
if (SERVED && $('logb')) $('logb').hidden = false;
if (SERVED && $('fillb') && M.reconstructed) $('fillb').hidden = false;
function startInputs(pageName) {   // the Start stage's inputs of a page: [{name, type}]
  var bp = E.bpOf(M), st = bp.stages.filter(function (s) { return s.type === 'Start' && s.page === pageName; })[0], out = [];
  if (!st) return out; var re = /<input ([^>]*)\/>/g, m; while ((m = re.exec(st.body))) out.push({ name: D.attr(m[1], 'name'), type: D.attr(m[1], 'type'), stage: D.attr(m[1], 'stage') });
  // an input whose data item already holds a value on the drawing is not asked for: that value is the input
  out.forEach(function (i) { var d = i.stage && bp.stages.filter(function (s) { return s.type === 'Data' && s.page === pageName && s.name === i.stage; })[0]; var v = d ? D.unx(D.tag(d.body, 'initialvalue') || '') : ''; if (v !== '') i.preset = v; });
  out.sort(function (a, b) { return a.name.toLowerCase() < b.name.toLowerCase() ? -1 : a.name.toLowerCase() > b.name.toLowerCase() ? 1 : 0; });
  return out;
}
function askInput(what, i) {   // the value of one run input, or null when the prompt is cancelled
  var v = i.preset !== undefined ? i.preset : prompt(what + ' "' + i.name + '" (' + i.type + '):', ''); if (v === null) return null;
  return { v: i.type === 'flag' ? /^true$/i.test(v) : i.type === 'number' ? Number(v || 0) : i.type === 'collection' ? { columns: [], rows: [] } : v };
}
var RUN_SCOPE = (window.BW_SERVE && window.BW_SERVE.rel) ? ':' + window.BW_SERVE.rel : '';   // a run belongs to the release it was made in: another release with the same process must not pick it up
var RUN_KEY = 'gumball:lastrun' + RUN_SCOPE;   // the last run stays on every page it touched (the process and the objects it called) until Clear
window.runHide = function () { $('runpanel').hidden = true; if ($('lastb')) $('lastb').hidden = false; };
window.runShow = function () { $('runpanel').hidden = false; if ($('lastb')) $('lastb').hidden = true; };
window.openSystem = function () { var s = window.BW_SERVE || {}; window.open('/system?' + (s.rel ? 'rel=' + encodeURIComponent(s.rel) + '&member=' + encodeURIComponent(BW_BASE) : 'base=' + encodeURIComponent(BW_BASE)), 'gumball-system'); };
window.clearRun = function () { if ($('lastb')) $('lastb').hidden = true; photoOff(true); runRows = []; runOv = null; if ($('walkb')) $('walkb').hidden = true; ov.pages = {}; $('runpanel').hidden = true; $('runb').classList.remove('on'); try { localStorage.removeItem(RUN_KEY); } catch (e) { } renderAll(); };
function showRun(s, from) {
  $('runpanel').hidden = false; $('run-status').textContent = (from ? '(run of ' + from + ') ' : '') + s.status; $('run-sum').textContent = s.sum; $('run-log').textContent = s.log;
  if (s.incident) { var o2 = D.overlayFrom(s.incident); ov.pages = o2.pages; runOv = ov.pages; }
  runRows = s.rows || []; runCut = !!s.rowsCut; if ($('walkb')) $('walkb').hidden = !runRows.length;
  if (runRows.length) learnLinks(s.links);
  var at = null; try { at = localStorage.getItem(PHOTO_KEY); } catch (e) { }
  if (at !== null && runRows.length) setTimeout(function () { photoOn(+at || 0); }, 0);   // the walk goes on when it led to this object's page
}
// ---------- the walk: a finished run, frozen, stepped through stage by stage ----------
// runRows comes from Run: one record per stage executed {n, f (which execution of the page), process, page, stage, type, ms, error, set, gset}.
var runRows = [], runCut = false, runOv = null, photo = null, PHOTO_KEY = 'gumball:photo' + RUN_SCOPE;
// Where the other objects and processes of this walk are. Every page the walk passes adds what it knows (a page of a release
// knows the release, a rebuilt object's page does not), and the list travels with the run: so the walk finds its way back.
var runLinks = {};
function linkKey(n) { return '~' + String(n == null ? '' : n).replace(/\s+/g, ' ').trim().toLowerCase(); }
function learnLinks(saved) {
  var so = window.BW_SERVE || {}, add = function (m) { for (var k in (m || {})) if (!runLinks[k]) runLinks[k] = m[k]; };
  add(saved); add(so.objects); add(so.procs); runLinks[linkKey(M.name)] = location.pathname + location.search;
  try { var s = JSON.parse(localStorage.getItem(RUN_KEY) || 'null'); if (s) { s.links = runLinks; localStorage.setItem(RUN_KEY, JSON.stringify(s)); } } catch (e) { }
}
function sameName(a, b) { return String(a || '').trim().toLowerCase() === String(b || '').trim().toLowerCase(); }
function photoState(i) {   // the overlay of every page of THIS object / process as it stood after row i
  var pagesOv = {}, row = runRows[i], g = {};
  for (var k = 0; k <= i; k++) { var r = runRows[k]; if (sameName(r.process, M.name) && r.gset) for (var n in r.gset) g[n] = r.gset[n]; }
  pages().forEach(function (pg) {
    var f = null; for (var k = i; k >= 0; k--) if (sameName(runRows[k].process, M.name) && sameName(runRows[k].page, pg)) { f = runRows[k].f; break; }
    var p = D.pageOverlayCreate({ pages: pagesOv }, M.name, pg); p.now = new Set(); p.fresh = new Set();
    for (var n in g) p.values.set(n, g[n]);
    if (f !== null) for (var k2 = 0; k2 <= i; k2++) { var r2 = runRows[k2]; if (r2.f === f && r2.set) for (var n2 in r2.set) p.values.set(n2, r2.set[n2]); }
    if (sameName(row.process, M.name) && sameName(row.page, pg)) {
      var key = row.sid ? '#' + row.sid : row.stage;       // by id where the row has one: stages may share a name
      p.now.add(key); if (row.error) p.fail.add(key);
      for (var n3 in (row.set || {})) p.fresh.add(n3); for (var n4 in (row.gset || {})) p.fresh.add(n4);
    }
  });
  return pagesOv;
}
function photoOn(i) {
  if (!runRows.length) return; if (!runOv) runOv = ov.pages;
  photo = { i: 0 }; document.body.classList.add('frozen'); closeSheet(); multi = []; sel = null;
  runShow(); $('photo').hidden = false; $('walkb').classList.add('on'); $('walkb').textContent = 'leave the walk'; $('ph-range').max = runRows.length - 1;
  photoGo(i === undefined ? runRows.length - 1 : i, true);
}
function photoOff(quiet) {
  if (!photo) return; photo = null; document.body.classList.remove('frozen'); $('photo').hidden = true; $('walkb').classList.remove('on'); $('walkb').textContent = 'walk through';
  try { localStorage.removeItem(PHOTO_KEY); } catch (e) { }
  if (runOv) ov.pages = runOv; if (!quiet) renderAll();
}
window.photoToggle = function () { if (photo) photoOff(); else photoOn(); };
window.photoLoad = function (rows, cut) { photoOff(true); runRows = rows || []; runCut = !!cut; runOv = ov.pages; $('runpanel').hidden = false; $('walkb').hidden = !runRows.length; };   // rows from somewhere other than a Run here (a replayed log)
window.photoGo = function (d, absolute) {
  if (!photo) return; var i = Math.max(0, Math.min(runRows.length - 1, absolute ? d : photo.i + d)); photo.i = i; var row = runRows[i];
  try { localStorage.setItem(PHOTO_KEY, String(i)); } catch (e) { }
  $('ph-range').value = i; $('ph-n').textContent = (i + 1) + ' / ' + runRows.length; ov.pages = photoState(i);
  var here = sameName(row.process, M.name), pg = pages(), at = $('ph-at');
  if (here) for (var k = 0; k < pg.length; k++) if (sameName(pg[k], row.page)) { cur = k; break; }
  renderAll();
  var nk = linkKey(row.process), so = window.BW_SERVE || {}, ob = so.objects || {}, pr = so.procs || {};
  var other = here || row.unknown === 'internal' ? null : (ob[row.process] || ob[nk] || pr[row.process] || pr[nk] || runLinks[row.process] || runLinks[nk] || null);   // an object the run went into, or the process it came back to; never a built-in object (it has no page)
  // the walk follows the run by itself; never to the address we are already on (a name that does not match must not reload for ever)
  if (other) { var go = other + '#page=' + encodeURIComponent(row.page), a0 = document.createElement('a'); a0.href = other; if (a0.pathname + a0.search !== location.pathname + location.search) { location.href = go; return; } other = null; }
  at.className = row.error ? 'err' : '';
  at.title = row.process + ' / ' + label(row.page) + ' / ' + row.stage;
  at.innerHTML = esc(row.process + ' / ' + label(row.page) + ' / ' + row.stage + '  (' + (NICE[row.type] || row.type) + ', ' + row.ms + ' ms)' + (runCut ? '   [the last ' + runRows.length + ' stages of a longer run]' : ''))
    + (here ? '' : row.unknown === 'internal' ? ' <span class="muted">(a built-in Blue Prism object: it has no pages)</span>' : ' <span class="muted">(not in gumball: bring its export in to see it)</span>');
  var lines = []; if (row.error) lines.push('ERROR  ' + row.error);
  if (row.unknown && here) lines.push(row.unknown === 'stage' ? 'this stage is in the log but not in the XML that is open (another version?)' : '');
  if (row.params) { var pin = row.params.filter(function (p) { return p.dir === 'in'; }), pout = row.params.filter(function (p) { return p.dir === 'out'; }), show = function (p) { return p.name + ' = ' + (p.value === '' ? '(empty)' : p.value); }; if (pin.length) lines.push('in: ' + pin.map(show).join('   |   ')); if (pout.length) lines.push('out: ' + pout.map(show).join('   |   ')); }
  if (row.result) lines.push('result: ' + row.result);
  lines = lines.filter(Boolean);
  var ch = Object.assign({}, row.gset || {}, row.set || {}), names = Object.keys(ch).sort(function (a, b) { return a.localeCompare(b); });
  if (names.length) lines.push((row.type === 'Start' ? 'at the start of the page: ' : 'changed here: ') + names.map(function (n) { return n + ' = ' + (ch[n] === '' ? '(empty)' : ch[n]); }).join('   |   '));
  $('ph-set').innerHTML = lines.map(function (l) { return '<span title="' + esc(l) + '">' + esc(l) + '</span>'; }).join('');
  var sel2 = $('ph-item'), seen = {}, opts = '<option value="">where did a value come from</option>';
  for (var k3 = 0; k3 <= i; k3++) { var r3 = runRows[k3]; if (r3.f === row.f) for (var n5 in (r3.set || {})) seen[n5] = 1; if (sameName(r3.process, row.process)) for (var n6 in (r3.gset || {})) seen[n6] = 1; }
  Object.keys(seen).sort(function (a, b) { return a.localeCompare(b); }).forEach(function (n) { opts += '<option>' + esc(n) + '</option>'; }); sel2.innerHTML = opts;
};
window.photoTrace = function (name) {   // back to the stage that last gave this data item its value (before the row we stand on, if this row is that stage)
  if (!photo || !name) return; var row = runRows[photo.i];
  for (var k = photo.i - 1; k >= 0; k--) { var r = runRows[k]; if ((r.f === row.f && r.set && name in r.set) || (sameName(r.process, row.process) && r.gset && name in r.gset)) { photoGo(k, true); toast(name + ' got its value here' + (r.type === 'Start' ? ' (start of the page: initial value or input)' : '')); return; } }
  toast(name + ' was not changed before this point');
};
window.loadLog = function (inp) {   // a real run: its session log is read by the server against the XML it has, then walked like a Run
  var f = inp.files && inp.files[0]; inp.value = ''; if (!f) return;
  f.text().then(function (t) { return fetch('/replay?base=' + encodeURIComponent(BW_BASE) + (window.BW_SERVE.rel ? '&rel=' + encodeURIComponent(window.BW_SERVE.rel) : ''), { method: 'POST', body: t }); }).then(function (r) { return r.json(); }).then(function (r) {
    if (r.error) { toast('log not loaded: ' + r.error, 6000); return; }
    var status = 'log ' + f.name + ': ' + r.total + ' stages, ' + r.errors + ' error' + (r.errors === 1 ? '' : 's'), sum = [r.rebuilt && r.rebuilt.length ? 'rebuilt from this log (drawn dashed): ' + r.rebuilt.join(', ') : '', r.missing.length ? 'not in gumball (their stages can not be shown): ' + r.missing.join(', ') : '', r.unplaced ? r.unplaced + ' stage' + (r.unplaced === 1 ? '' : 's') + ' could not be placed on a drawing' : '', recoveredLine(r.rows)].filter(Boolean).join('  |  ');
    $('run-status').textContent = status; $('run-sum').textContent = sum; $('run-log').textContent = ''; ov.pages = {}; runOv = ov.pages;
    photoLoad(r.rows, r.rowsCut);
    var keep = { base: BW_BASE, name: f.name, status: status, sum: sum, log: '', incident: null, rows: r.rows, rowsCut: r.rowsCut };
    try { localStorage.setItem(RUN_KEY, JSON.stringify(keep)); } catch (e) { toast('this log is too big to follow into other pages; it can be walked here', 6000); }
    runLinks = {}; learnLinks(null);
    var first = -1; for (var k = 0; k < r.rows.length; k++) if (r.rows[k].error) { first = k; break; }
    photoOn(first >= 0 ? first : r.rows.length - 1);
  }, function (e) { toast('log not loaded: ' + e, 6000); });
};
// ---------- Darwin: a question for the model. Gumball writes it as a file; the Darwin extension in VS Code asks Copilot and
// writes the answer back; this page waits for it. kind 'explain' = what went wrong at this point of the walk;
// kind 'fill' = what the stages of an object rebuilt from a log probably do (the answer becomes its next version).
var darwinT = null;
function darwinSay(t) { var el = $('dw-out'); if (!el) { toast(t, 6000); return; } if ($('photo').hidden) { toast(t, 6000); return; } el.hidden = false; el.textContent = t; }
window.darwinAsk = function (kind) {
  var ok = false; try { ok = localStorage.getItem('gumball:darwin-ok') === '1'; } catch (e) { }
  if (!ok) { if (!confirm('This sends stage names and the logged values of this run to GitHub Copilot, through the Darwin extension in VS Code.\n\nAccount numbers, long numbers, mail addresses and passwords are masked first. The exact text is kept as prompt.md in gumball\'s darwin\\jobs folder.\n\nSend?')) return; try { localStorage.setItem('gumball:darwin-ok', '1'); } catch (e) { } }
  var rows = runRows; if (kind === 'fill') { try { var s = JSON.parse(localStorage.getItem(RUN_KEY) || 'null'); rows = (s && s.rows) || runRows; } catch (e) { } rows = rows.filter(function (r) { return sameName(r.process, M.name); }); }
  var so = window.BW_SERVE || {}, url = '/darwin/ask?base=' + encodeURIComponent(BW_BASE) + (so.rel ? '&rel=' + encodeURIComponent(so.rel) : '');
  darwinSay('writing the question..');
  fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ kind: kind, rows: rows, i: photo ? photo.i : null }) }).then(function (r) { return r.json(); }).then(function (r) {
    if (r.error) { darwinSay('Darwin: ' + r.error); return; }
    var t0 = Date.now(); clearInterval(darwinT);
    darwinT = setInterval(function () {
      fetch('/darwin/job?id=' + encodeURIComponent(r.id)).then(function (x) { return x.json(); }).then(function (j) {
        var secs = Math.round((Date.now() - t0) / 1000);
        if (j.state === 'waiting') darwinSay('waiting for the Darwin extension in VS Code to pick the question up (' + secs + ' s)' + (secs > 20 ? '\nIs VS Code open with the Darwin extension installed? The question is in ' + r.file : ''));
        else if (j.state === 'asking') darwinSay('the model is answering (' + secs + ' s)..');
        else if (j.state === 'failed') { clearInterval(darwinT); darwinSay('Darwin could not get an answer: ' + j.error); }
        else if (j.state === 'done') {
          clearInterval(darwinT);
          if (kind !== 'fill') { darwinSay(j.answer + '\n\n(' + (j.model || 'model') + ', through Darwin; a suggestion to check, not a finding)'); return; }
          fetch('/darwin/apply?id=' + encodeURIComponent(r.id), { method: 'POST' }).then(function (x) { return x.json(); }).then(function (a) { if (a.error) { darwinSay('Darwin answered, but it could not be used: ' + a.error); return; } toast(a.stages + ' stages described by the model: opening the new version', 4000); setTimeout(function () { location.href = a.url; }, 900); });
        }
      }, function () { });
    }, 1500);
  }, function (e) { darwinSay('Darwin: ' + e); });
};
window.photoErr = function () { if (!photo) return; for (var k = photo.i + 1; k < runRows.length; k++) if (runRows[k].error) return photoGo(k, true); toast('no error after this point'); };
document.addEventListener('keydown', function (e) {
  if (!photo || /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement.tagName) && document.activeElement.id !== 'ph-range') return;
  var k = e.key; if (k === 'ArrowLeft') photoGo(-1); else if (k === 'ArrowRight') photoGo(1); else if (k === 'Home') photoGo(0, true); else if (k === 'End') photoGo(1e9, true); else if (k === 'Escape') photoOff(); else return;
  e.preventDefault(); e.stopPropagation();
}, true);
function restoreRun() {
  if (!SERVED || !$('runpanel') || BW_INCIDENT) return; var s = null;
  try { s = JSON.parse(localStorage.getItem(RUN_KEY) || 'null'); } catch (e) { }
  if (!s || (!s.incident && !(s.rows && s.rows.length))) return;
  if (!s.incident) { if (s.rows.some(function (r) { return sameName(r.process, M.name); })) showRun(s, ''); return; }   // a loaded log: shown on every object / process it went through
  var mine = String(M.name || '').trim().toLowerCase() + '|', touched = Object.keys(D.overlayFrom(s.incident).pages).some(function (k) { return k.indexOf(mine) === 0; });
  if (touched) showRun(s, s.base === BW_BASE ? '' : s.name || s.base);
}
function runPayload() {   // what a run is started with: the page as it is on screen, the other drafts, the action and its inputs (asked)
  // Run takes the page as it is on screen, saved or not, and the drafts of the other objects of this project / release
  if (draftT) draftNow();
  var o = { xml: E.serialize(M), drafts: [] }, pg = pages()[cur];
  try { for (var di = 0; di < localStorage.length; di++) { var dk = localStorage.key(di); if (dk.indexOf(DRAFT_PRE) !== 0 || dk === DRAFT_KEY) continue; var dv = JSON.parse(localStorage.getItem(dk)); if (dv && dv.xml) o.drafts.push({ base: dk.slice(DRAFT_PRE.length), ver: dv.ver, src: dv.src, xml: dv.xml }); } } catch (e) { }
  if (M.type === 'object') {
    // the page that is open is the action that runs; on Initialise there is nothing to pick from the drawing, so ask
    var act = pg === 'Main Page' ? prompt('Action to run (a page of this object):', pages()[1] || '') : pg; if (!act) return; o.action = act;
    var ins = startInputs(act), inputs = {};
    for (var i = 0; i < ins.length; i++) { var v = askInput('Input', ins[i]); if (v === null) return; inputs[ins[i].name] = v.v; }
    o.inputs = inputs;
  } else {
    var only = pg !== 'Main Page' && confirm('Run only the page "' + pg + '"?\n\nOK = this page alone, from its Start\nCancel = the whole process, from Main Page');
    if (only) o.action = pg;
    var pins = startInputs(only ? pg : 'Main Page'), pin = {};
    for (var k = 0; k < pins.length; k++) { var pv = askInput('Process input', pins[k]); if (pv === null) return; pin[pins[k].name] = pv.v; }
    if (pins.length) o.inputs = pin;
  }
  return o;
}
// break test: one normal run, then one run per stage that touches something outside the flow, with that stage failing once
window.breakTest = function () {
  if (!SERVED) return toast('Break test works from the served page (gumball.cmd)');
  var o = runPayload(); if (!o) return;
  var panel = $('runpanel'), box = $('brk-out'); panel.hidden = false; box.hidden = false; box.textContent = ''; $('run-status').textContent = 'break test: running once, then once per stage with that stage failing...'; $('brkb').classList.add('on');
  var url = '/breaktest?base=' + encodeURIComponent(BW_BASE) + (window.BW_SERVE.rel ? '&rel=' + encodeURIComponent(window.BW_SERVE.rel) : '');
  fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(o) }).then(function (r) { return r.json(); }).then(function (r) {
    $('brkb').classList.remove('on');
    if (r.error) { $('run-status').textContent = 'break test could not run: ' + r.error; return; }
    var st = r.tests.filter(function (t) { return t.outcome === 'stopped'; }).length, lk = r.tests.filter(function (t) { return t.locked; }).length, hd = r.tests.filter(function (t) { return t.outcome === 'handled'; }).length;
    $('run-status').textContent = 'break test: ' + r.tests.length + ' stage' + (r.tests.length === 1 ? '' : 's') + ' failed one at a time - ' + hd + ' handled, ' + st + ' stop the run' + (lk ? ', ' + lk + ' leave a queue item locked' : '') + (r.cut ? ' (the first ' + r.tests.length + ' of ' + r.reached + ' reached)' : '');
    var order = { stopped: 0, error: 1, handled: 2, 'not reached': 3 };
    var rows = r.tests.slice().sort(function (a, b) { return (b.locked ? 1 : 0) - (a.locked ? 1 : 0) || order[a.outcome] - order[b.outcome] || a.n - b.n; });
    box.innerHTML = '<div class="muted">normal run: ' + (r.baseline.ok ? 'finished' : 'failed (' + esc((r.baseline.exception || {}).detail || '') + ')') + ', ' + r.baseline.stages + ' stages. Only stages this run reached are tested; each is made to fail the first time it runs.</div><table><tr><th>if this fails</th><th>where</th><th>then</th></tr>'
      + rows.map(function (t) { return '<tr><td><b>' + esc(t.stage) + '</b> <span class="muted">' + esc(t.type) + '</span></td><td class="muted">' + esc((t.process !== M.name ? t.process + ' / ' : '') + t.page) + '</td><td class="' + (t.locked ? 'lock' : esc(t.outcome)) + '">' + esc(t.detail) + '</td></tr>'; }).join('') + '</table>';
  }, function (e) { $('brkb').classList.remove('on'); $('run-status').textContent = 'break test failed: ' + e; });
};
window.runFlow = function () {
  if (!SERVED) return toast('Run works from the served page (gumball.cmd)');
  var o = runPayload(); if (!o) return;
  var panel = $('runpanel'); panel.hidden = false; $('run-status').textContent = 'running...'; $('run-sum').textContent = ''; $('run-log').textContent = ''; $('runb').classList.add('on');
  var url = '/run?base=' + encodeURIComponent(BW_BASE) + (window.BW_SERVE.rel ? '&rel=' + encodeURIComponent(window.BW_SERVE.rel) : '');
  fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(o) }).then(function (r) { return r.json(); }).then(function (r) {
    $('runb').classList.remove('on');
    if (r.error) { $('run-status').textContent = 'could not run'; $('run-log').textContent = r.error; return; }
    $('run-status').textContent = (r.ok ? 'finished' : 'FAILED') + ' after ' + r.stages + ' stages' + (r.exception ? ': ' + r.exception.type + ' at "' + r.exception.stage + '": ' + r.exception.detail : '');
    var sum = [];
    if (r.host && !r.host.used) sum.push('code stages skipped: ' + (r.host.note || 'no stage host'));
    if (r.host && r.host.problems && r.host.problems.length) sum.push(r.host.problems.join('; '));
    if (r.skipped.length) sum.push(r.skipped.length + ' code stage calls skipped');
    if (r.screen && r.screen.simulated && r.screen.stages) { var sc = r.screen, er = sc.empty_reads || [];   // there is no application here: say what was made up
      sum.push('screen simulated (' + sc.stages + ' screen stage' + (sc.stages === 1 ? '' : 's') + (sc.assumed_waits ? ', ' + sc.assumed_waits + ' wait' + (sc.assumed_waits === 1 ? '' : 's') + ' assumed met' : '') + (er.length ? ', read as empty: ' + er.slice(0, 6).join(', ') + (er.length > 6 ? ' +' + (er.length - 6) : '') : '') + (sc.waits_skipped_s ? ', ' + Math.round(sc.waits_skipped_s) + ' s of timeouts skipped' : '') + ((sc.unknown_actions || []).length ? ', actions not simulated in particular: ' + sc.unknown_actions.slice(0, 6).join(', ') : '') + '; values: "screen" in estate.json)'); }
    var qn = Object.keys(r.queues || {}); if (qn.length) sum.push('queues: ' + qn.map(function (q) { var it = r.queues[q]; return q + ' ' + it.length + ' item' + (it.length === 1 ? '' : 's') + (it.length ? ' (' + it.filter(function (x) { return x.status === 'Completed'; }).length + ' completed, ' + it.filter(function (x) { return x.status === 'Exception'; }).length + ' exception)' : ''); }).join(', '));
    if (r.dir) sum.push('log: ' + r.dir + (/\\/.test(r.dir) ? '\\' : '/') + 'run.log');
    var on = Object.keys(r.outputs || {}); if (on.length) sum.push('outputs: ' + on.map(function (k) { return k + ' = ' + shortVal(r.outputs[k]); }).join(', '));
    $('run-sum').textContent = sum.join('  |  ');
    on.forEach(function (k) { var full = typeof r.outputs[k] === 'string' ? r.outputs[k] : JSON.stringify(r.outputs[k]); if (!full || full.length <= 300) return;   // a long output: one button copies it whole
      var b = document.createElement('button'); b.textContent = 'copy ' + k; b.title = 'copy the whole value (' + full.length + ' characters)';
      b.onclick = function () { copyText(full, k); }; $('run-sum').appendChild(document.createTextNode(' ')); $('run-sum').appendChild(b); });
    $('run-log').textContent = (r.log || []).map(function (l) { l = String(l); return l.length <= 600 ? l : l.slice(0, 600) + ' ... (line cut: ' + l.length + ' characters)'; }).join('\n') + (r.stderr ? '\n--- stderr ---\n' + r.stderr : '');
    if (r.incident) { var o2 = D.overlayFrom(r.incident); ov.pages = o2.pages; renderAll(); }
    photoOff(true); runRows = r.rows || []; runCut = !!r.rowsCut; $('walkb').hidden = !runRows.length;
    var keep = { base: BW_BASE, name: r.name, status: $('run-status').textContent, sum: sum.join('  |  '), log: $('run-log').textContent, incident: r.incident, rows: runRows, rowsCut: runCut };
    try { localStorage.setItem(RUN_KEY, JSON.stringify(keep)); } catch (e) { try { delete keep.rows; localStorage.setItem(RUN_KEY, JSON.stringify(keep)); } catch (e2) { } }
    runLinks = {}; learnLinks(null);
    toast(r.ok ? 'run finished: the path is on the drawing' : 'run failed at "' + (r.exception && r.exception.stage) + '"');
  }, function (e) { $('runb').classList.remove('on'); $('run-status').textContent = 'failed: ' + e; });
};
restoreRun();
// arriving from an Action stage: open the page that implements the action
(function () { var m = /[#&]page=([^&]+)/.exec(location.hash || ''); if (!m) return; var want = decodeURIComponent(m[1]), pg = pages(); for (var i = 0; i < pg.length; i++) if (pg[i] === want || label(pg[i]) === want) { cur = i; return; } toast('no page "' + want + '" in this object'); })();

// ---------- go ----------
if (BW_DIFF) {
  var d = BW_DIFF, parts = [];
  if (d.added.length) parts.push('<b>added</b> ' + d.added.map(esc).join(', '));
  if (d.removed.length) parts.push('<b>removed</b> ' + d.removed.map(esc).join(', '));
  if (d.renamed.length) parts.push('<b>renamed</b> ' + d.renamed.map(function (r) { return esc(r[0]) + ' &rarr; ' + esc(r[1]); }).join(', '));
  if (d.changed.length) parts.push('<b>changed</b> ' + d.changed.map(esc).join(', '));
  if (d.moved.length) parts.push('<b>moved</b> ' + d.moved.length + ' stage' + (d.moved.length === 1 ? '' : 's'));
  $('diff').innerHTML = parts.length ? 'v' + (BW_VER - 1) + ' &rarr; v' + BW_VER + ': ' + parts.join(' &middot; ') : 'v' + BW_VER + ': no changes against v' + (BW_VER - 1);
}
if (window.BW_SERVE) { var br = document.querySelector('.tb .brand'); if (br) { br.style.cursor = 'pointer'; br.title = window.BW_SERVE.home ? 'back to the release' : 'back to the inbox and projects'; br.onclick = function () { location.href = window.BW_SERVE.home || '/'; }; } }
setMode('select'); renderAll();
window.bw = { snap: snap, multi: function (ids) { multi = ids; highlight(null); }, model: M, redraw: renderAll, place: startPlace, open: openSheet, pages: pages, current: function () { return cur; }, edit: E, blockMembers: blockMembers, blockChange: blockChange };   // for scripts and tests
})();
