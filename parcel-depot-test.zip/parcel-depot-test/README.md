# Parcel Depot test pack

Everything two models built for the "bigger test", the fixes made afterwards, and the test environment.
`RESULTS.md` has the scores and what went wrong in each.

## What is in here

| Folder | Content |
|---|---|
| `process/` | `PDD.md` (what the three processes do) and `TASK.md` (the brief the models got) |
| `builds/haiku` | the smaller model's delivery as it came: 5 XML files, its build script, HANDOVER.md, spy files |
| `builds/haiku_fix` | the same with its one wrong element corrected (26 of 26) |
| `builds/control` | the stronger model's delivery as it came (6 XML files) |
| `builds/control_fix` | the same with its two bugs repaired (26 of 26). Its Approve process has two real globals (`g_txt_Lock Token`, `g_flg_Depot Open`) |
| `incident-fixes/` | three production-style fixes made on `haiku_fix`: renamed controls, a notice window, the application closing. Each folder: the complete XML set, `FIX.md`, the incident text |
| `estate/` | the browser object the builds call, and the portal's config |
| `environment/portal` | the mock web portal (one HTML page and a small Python server for its state) |
| `environment/desktop-app-linux-only` | the mock desktop application (GTK, Linux). For reading only: it does not run on Windows |

Nothing in the pack runs by itself. The XML files are Blue Prism exports; the `.py` / `.sh` files are the models'
build scripts and are only text here.

## What to test, in this order

### 1. A release your team built, in the new Gumball (the important one)

Export a process and the objects it calls that somebody on the team built by hand in 7.2.1. Drop the release into
Gumball, open the process, press Run.

Photograph the Run summary line and whatever stopped it. Look for:
- `Data item [...] not found on page ...` : the runner still gets visibility wrong somewhere
- `the expression is blank`, or any text that looks like a Python error rather than a Blue Prism exception
- a line about code stages that "did not compile" or were skipped, and for which object (C# or Visual Basic)
- `unknown actions` in the "screen simulated" part of the summary: the list of action ids is what I need
- a Recover that does not catch a failure inside its block (old-format positions)

### 2. Import the builds into Blue Prism

Import `builds/control_fix` and `builds/haiku_fix` (with `estate/BPA Object - GK Revoke Browser.xml` first).
- Does every file import, and how many errors and warnings does Blue Prism's own Validate show per file?
- `control_fix`, process Approve Orders, page "Wrap Up Run": do the stages that use `g_txt_Lock Token` and
  `g_flg_Depot Open` validate without "data item not found"? On the Main Page, are those two items shown with
  "Hide from other pages" unticked? This is the first global the generator ever wrote.
- Open an object's Application Modeller: do the elements show the ticked attributes and the match types
  (Wildcard / RegEx) the HANDOVER describes?

### 3. Run the builds in Gumball

Drop `builds/haiku_fix` plus the browser object into Gumball and Run `Parcel Depot - Approve Orders` (it needs no
site: the desktop screen is simulated). Photograph the summary. Here it stops only where the simulated screen has no
answer; anything else is a difference between the two machines.

### 4. Visual Basic through the code stage host

Run any action of an object whose code stages are Visual Basic (an older team object, or a standard VBO such as
Utility - Collection Manipulation). Never run on Windows so far. Photograph the result and the host line.

### 5. Still open from before

In Application Modeller, Highlight on an element that matches several controls: photograph the message.
