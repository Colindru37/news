"""Builds BPA Object - Parcel Depot Helper.xml: pure code (no application). A process cannot run code, so the
two calculations the approval needs (money with the invariant culture, a one-row queue item) live here."""
import sys, os
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'skill', 'lib'))
from bp_gen import Proc

o = Proc('Parcel Depot Helper', 'object', 'Code helpers for the Parcel Depot processes: classify an order, build a results row.')
o.code_options()
o.page('Clean Up', 'Standard first object page.', page_type='CleanUp')

o.code_action('Classify Order',
    'Compare the amount shown with the approval limit, pick the reason (Manager override above Override Above, else Standard) '
    'and tick Priority when any order line Item contains the Fragile Word (any case). Money is parsed with the invariant culture.',
    inputs=[('text', 'Amount', 'Amount'), ('collection', 'Order Lines', 'Order_Lines'),
            ('text', 'Approval Limit', 'Approval_Limit'), ('text', 'Override Above', 'Override_Above'),
            ('text', 'Fragile Word', 'Fragile_Word')],
    outputs=[('flag', 'Above Limit', 'Above_Limit'), ('text', 'Reason', 'Reason'), ('flag', 'Priority', 'Priority')],
    body='''var inv = System.Globalization.CultureInfo.InvariantCulture;
var st = System.Globalization.NumberStyles.Number;
decimal amount = decimal.Parse((Amount ?? "").Trim(), st, inv);
decimal limit = decimal.Parse((Approval_Limit ?? "").Trim(), st, inv);
decimal over = decimal.Parse((Override_Above ?? "").Trim(), st, inv);
Above_Limit = amount > limit;
Reason = amount > over ? "Manager override" : "Standard";
Priority = false;
string word = (Fragile_Word ?? "").Trim();
if (Order_Lines != null && word.Length > 0)
{
    foreach (DataRow r in Order_Lines.Rows)
    {
        string item = Convert.ToString(r["Item"]) ?? "";
        if (item.IndexOf(word, StringComparison.OrdinalIgnoreCase) >= 0) { Priority = true; break; }
    }
}''')

o.code_action('Build Result Row',
    'One-row collection with the fields Order ID and Result: the Data of a results queue item.',
    inputs=[('text', 'Order ID', 'Order_ID'), ('text', 'Result', 'Result')],
    outputs=[('collection', 'Row', 'Row')],
    body='''Row = new DataTable();
Row.Columns.Add("Order ID", typeof(string));
Row.Columns.Add("Result", typeof(string));
DataRow nr = Row.NewRow();
nr["Order ID"] = Order_ID ?? "";
nr["Result"] = Result ?? "";
Row.Rows.Add(nr);''')
print(o.write('BPA Object - Parcel Depot Helper.xml', outdir=HERE))
