#!/bin/bash
# Rebuild everything and run the gates. Run from the control folder: bash out/build_all.sh
set -e
(cd out && python3 build_depot.py >/dev/null && python3 build_portal.py >/dev/null && python3 build_helper.py >/dev/null)
python3 out/build_processes.py >/dev/null
python3 out/identify_depot.py
python3 skill/lib/validate.py out --flow --strict --with estate | grep -v -- '--on[a-z]*--' | grep -v '^\s*$'
python3 skill/lib/compile_check.py out | tail -9
node tools/twins.js "out/BPA Object - Parcel Depot Desktop.xml" spy/signin.json spy/signin_err.json spy/main.json spy/after.json spy/state2.json spy/confirm.json spy/busy.json spy/busy1.json spy/busy2.json spy/busy3.json spy/busy4.json
