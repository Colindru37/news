"""Fills the Application Modeller of BPA Object - Parcel Depot Desktop.xml from the spy dumps (spy/*.json,
made with tools/spy.py dump). Run from the control folder: python3 out/identify_depot.py"""
import json, os, subprocess, sys, tempfile
OBJ = 'out/BPA Object - Parcel Depot Desktop.xml'
def nodes(f): return json.load(open(f'spy/{f}'))['elements']
def pick(f, **kw):
    hits = [n for n in nodes(f) if all(n.get(k) == v for k, v in kw.items())]
    if len(hits) != 1: sys.exit(f'{f} {kw}: {len(hits)} nodes')
    return dict(hits[0])
def ident(name, node, use, sets=None, cmps=None):
    fd, tmp = tempfile.mkstemp(suffix='.json'); os.close(fd)
    json.dump(node, open(tmp, 'w'))
    cmd = ['node', 'tools/identify.js', OBJ, name, tmp, '--use', ','.join(use)]
    for k, v in (sets or {}).items(): cmd += ['--set', f'{k}={v}']
    for k, v in (cmps or {}).items(): cmd += ['--cmp', f'{k}={v}']
    r = subprocess.run(cmd, capture_output=True, text=True); os.remove(tmp)
    if r.returncode: sys.exit(name + ': ' + r.stdout + r.stderr)
NT = ['uControlType', 'uClassName', 'uName']
ID = ['uControlType', 'uAutomationId']
# the sign-in screen
ident('Window - Sign In - UIA', pick('signin.json', uControlType='Window'), NT)
ident('Textbox - User Name - UIA', pick('signin.json', uAutomationId='loginUser'), ID)
ident('Textbox - Password - UIA', pick('signin.json', uAutomationId='loginPassword'), ID)
ident('Button - Sign In - UIA', pick('signin.json', uControlType='Button', uName='Sign in'), NT)
ident('Label - Sign In Message - UIA', pick('signin_err.json', uName='Wrong user or password'),
      ['uControlType', 'uClassName', 'puClassName', 'uAutomationId', 'uName'],
      {'uName': '^(?!Parcel Depot - Sign in$|Password$|User$).+$'}, {'uName': 'RegEx'})
# the main window
ident('Window - Main - UIA', pick('main.json', uControlType='Window'), NT,
      {'uName': 'Parcel Depot - session *'}, {'uName': 'Wildcard'})
PN = ['uControlType', 'uClassName', 'uName', 'puClassName']
cust = [n for n in nodes('main.json') if n['uName'] == 'Search' and n['puClassName'] == 'GtkBox']
order = [n for n in nodes('main.json') if n['uName'] == 'Search' and n['puClassName'] == 'GtkFrame']
cfind = [n for n in nodes('main.json') if n['uName'] == 'Find' and n['puClassName'] == 'GtkBox']
ofind = [n for n in nodes('main.json') if n['uName'] == 'Find' and n['puClassName'] == 'GtkFrame']
assert len(cust) == len(order) == len(cfind) == len(ofind) == 1
ident('Textbox - Customer Search - UIA', cust[0], PN)
ident('Button - Customer Find - UIA', cfind[0], PN)
ident('Textbox - Order Search - UIA', order[0], PN)
ident('Button - Order Find - UIA', ofind[0], PN)
ident('Label - Customer Result - UIA', pick('state2.json', uName='No such customer'),
      ['uControlType', 'uClassName', 'puClassName', 'uAutomationId', 'uName'],
      {'uName': '^(?!Parcel Depot - session |Signed in as ).+$'}, {'uName': 'RegEx'})
ident('Label - Order Status - UIA', pick('after.json', uAutomationId='orderStatus'), ID)
ident('Label - Order Status Busy - UIA', pick('busy2.json', uAutomationId='orderStatus'), ID + ['uName'])
ident('Label - Order Amount - UIA', pick('after.json', uAutomationId='orderAmount'), ID)
ident('Table - Order Lines - UIA', pick('main.json', uControlType='Table'), NT)
ident('Checkbox - Priority - UIA', pick('main.json', uControlType='CheckBox'), NT)
ident('Radio - Reason Standard - UIA', pick('main.json', uControlType='RadioButton', uName='Standard'), NT)
ident('Radio - Reason Manager Override - UIA', pick('main.json', uControlType='RadioButton', uName='Manager override'), NT)
ident('Button - Approve - UIA', pick('main.json', uControlType='Button', uName='Approve'), NT)
ident('Label - Order Message - UIA', pick('after.json', uName='Order P-2002 approved'),
      ['uControlType', 'uClassName', 'puClassName', 'uAutomationId', 'uName'],
      {'uName': '^(?!Amount:$|Status:$|Orders$|Customers$).+$'}, {'uName': 'RegEx'})
# the confirm window
conf = [n for n in nodes('confirm.json') if n['uControlType'] == 'Window' and n['uName'].startswith('Approve ')]
assert len(conf) == 1
ident('Window - Confirm - UIA', conf[0], NT, {'uName': 'Approve *'}, {'uName': 'Wildcard'})
ident('Button - Confirm Yes - UIA', pick('confirm.json', uAutomationId='confirmYes'), ID)
print('identified')
