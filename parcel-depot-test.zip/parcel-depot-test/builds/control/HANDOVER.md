# Parcel Depot order approval: handover

Rebuild: `bash out/build_all.sh` (from the control folder): regenerates, identifies the desktop elements from `spy/*.json`,
validates, compiles, checks twins. Profile: estate-native (Application Modeller, Environment Variables, Credential Manager,
Environment Locking). Process names are the exact ones the task fixes (not the PRC000 grammar).

## Design
| Artefact | Role |
|---|---|
| `Parcel Depot Desktop` (object, UIA Application Modeller) | Launch Depot, Sign In, Find Customer (-> Found, Customer Name), Find Order (-> Status, Amount, Order Lines), Approve Order (Reason, Priority -> Message), Close Depot (Terminate, errors swallowed) |
| `Parcel Portal` (object, no model) | on top of `GK Revoke Browser` only: Launch Portal (Load Config, Launch Browser, Navigate), Sign In, Get Open Orders (deduplicated collection), Post Result (-> Message), Close Portal |
| `Parcel Depot Helper` (code-only object) | Classify Order (limit, reason, Priority; invariant-culture money), Build Result Row (one-row collection for the results queue). A process cannot run code, hence an object |
| `Parcel Depot - Load Orders` | credentials, portal sign-in, read list, Add To Queue (Tags `Loaded`), close browser (also on failure: page-level Recover) |
| `Parcel Depot - Approve Orders` | credentials, Acquire Lock (empty token -> System Exception `Parcel Depot is locked by another session`), Start Depot, claim loop; per-item Block captures the exception in recovery mode; page `Wrap Up Run` (close depot if open, release lock if held) runs at the normal end AND as the page-level Recover handler before the rethrow |
| `Parcel Depot - Post Results` | credentials, portal sign-in, claim loop on the results queue, per-item Block, close browser on every path |

Every process has `Reset Global Data` and `Continue To Work` (IsStopRequested only: the PDD defines no item limit / working hours).
Only process Main reads the 11 contract environment variables; objects get values as inputs.

## Queue items
- Work queue (`Parcel Depot Queue Name`): fields `Order ID`, `Customer ID`; tag `Loaded` at load; then tag `Approved` or `Already approved` + Completed; or Mark Exception (Retry False) with reason `Business Exception: <text>` / `System Exception: <text>`.
- Results queue (`Parcel Depot Results Queue Name`): fields `Order ID`, `Result`; Result = the tag text, or the full exception reason. One per item worked, whatever the outcome (Add To Queue is on the common path after both outcomes).
- Post Results: `Saved <id>` -> Completed; `Unknown order <id>` -> Business Exception `Parcel Portal does not know order <id>`; else System Exception `Result not saved for <id>: <message>`; Mark Exception Retry False, run carries on.

## Business rules and where they sit
Customer `No such customer` -> Business Exception; order Choice: `Not found` / `Approved` (result `Already approved`) / `Pending` / otherwise unexpected status; limit 2000.00 and override above 500.00 are visible Data items on page `Work Item`; Fragile = any line Item contains `Fragile`, case-INSENSITIVE (my reading; PDD does not say). Approve is judged by the message `Order <id> approved` (as observed), anything else -> System Exception `Approve failed for <id>: <message>`.

## Application Modeller (UIA), how each element matches
The tree is only folders (gotchas.md): every element is unique on its own ticked attributes. One branch per window.
`NT` = uControlType + uClassName + uName. All twins checked with `tools/twins.js` on 11 dumps (sign-in, refused sign-in, main empty, main after approve, main after customer lookup, confirm dialog, status busy `...`): TWINS CLEAN. A deliberately weakened Customer Search was flagged (positive control).
- Window - Sign In: NT, name `Parcel Depot - Sign in` (fixed). Window - Main: NT, name Wildcard `Parcel Depot - session *` (session number changes). Window - Confirm: NT, name Wildcard `Approve *` (carries the order id).
- User Name / Password edits: uControlType + uAutomationId (`loginUser`, `loginPassword`). Button Sign In: NT.
- Customers vs Orders twins (same name `Search`/`Find`, same class): told apart by parent class: Customers' controls sit in a GtkBox, Orders' in a GtkFrame (`puClassName`); NT + puClassName.
- Order Status / Amount: uControlType + automation id (`orderStatus`, `orderAmount`). Order Status Busy: the same plus uName `...` (the lookup shows `...` for about a second; spied live). A state of the same control, deliberately narrower.
- Labels whose name IS their text (sign-in message, customer result, order message) cannot match on a name: they match on type, class, parent class, empty automation id and a RegEx on the name that EXCLUDES the fixed labels of that parent (title, `Signed in as ..`, `Password`, `User`, `Amount:`, `Status:`, `Orders`, `Customers`) and, being `.+`, only exists when there is text. This is also what the Waits use ("a message has appeared"). Weakest part of the model: a new fixed label in the same parent would need adding to the pattern.
- Order Lines table (NT, name `Order lines`), Priority checkbox, the two reason radios, Approve button: NT (names are fixed and unique). Approve's Enabled state is not ticked. Yes button: uControlType + automation id `confirmYes`.
- No coordinates, sizes or match indexes ticked anywhere.
- Waits: named timeouts (`Depot Wait Seconds` 15, `Lookup Start Seconds` 3). The lookup waits first for the `...` to appear (a fast lookup may never show it; 3 s then continues) and then for it to go, so a stale status is not read.

## What I could not verify
1. Nothing ran in Blue Prism (none here): flow, Recover scopes, Environment Locking and Work Queues behaviour are checked by validate only. `Credentials`, `Environment Locking`, `Work Queues` calls are "NOT checked" by validate (internal objects, no XML to check against).
2. `compile_check` used mono's mcs, not Blue Prism's compiler: rerun with `--ref-dir` on the Blue Prism machine.
3. The application model's Launch Path is EMPTY (I do not know where Parcel Depot lives and the contract has no variable for it): set it in Application Modeller (or the harness maps Launch). Attach is not used: Launch attaches within the object instance. `GetTable`/`GetChecked` action ids are not in the skill's "verified" list (the task gives them; generator warns for GetTable).
4. Element types I gave (Table, CheckBox, RadioButton) are my choice; `identify` stored the UIA attributes, but Blue Prism may re-type them when re-identified.
5. Browser side: only the config and the browser object's documented behaviour; never run against the portal. Login success = `portal_desk` displayed, failure = non-empty `portal_login_msg` read via `textContent`; result message is cleared with Execute Script before Save, then polled up to 20 s. Headless is passed False.
6. Dedupe: within one run (case-insensitive on Order ID). Items left on the queue by an earlier run are not looked at.
7. No consecutive-failure guard (estate default): the PDD says carry on after an item failure and no retries; a guard would leave items unworked. Not added.
8. Password to text: unwrapped with NetworkCredential in a code stage (as BlueSpace does) and wiped after typing.
