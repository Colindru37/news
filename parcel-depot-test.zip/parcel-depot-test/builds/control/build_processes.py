"""Builds the three processes. Run from the control folder: python3 out/build_processes.py"""
import sys, os
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'skill', 'lib'))
from bp_gen import Proc, lit

PORTAL, DEPOT, HELPER = 'Parcel Portal', 'Parcel Depot Desktop', 'Parcel Depot Helper'
CRED = 'Credentials'
QN = 'Parcel Depot Queue Name'
RQN = 'Parcel Depot Results Queue Name'
PORTAL_ENV = ['Parcel Portal Credential Name', 'Parcel Portal Config Path', 'Parcel Portal Driver Path',
              'Parcel Portal Browser Kind', 'Parcel Portal Run Mode', 'Parcel Portal Log Folder']


def common_pages(p, reset_outputs):
    """Reset Global Data and Continue To Work: every long-running process has them (estate rule)."""
    rg = p.page('Reset Global Data', 'Reset run-level state before the first item.')
    for dt, nm, val in reset_outputs:
        rg.add_output(dt, nm)
    for dt, nm, val in reset_outputs:
        rg.calc('Reset ' + nm.split('_', 2)[-1], val, nm)
    cw = p.page('Continue To Work', 'Control Room stop request (the business defines no item limit or working hours).')
    cw.add_output('flag', 'o_flg_Continue')
    cw.decision('Stop Requested?', 'IsStopRequested()', true_target='Stop Working', false_target='NEXT')
    cw.calc('Keep Working', 'True', 'o_flg_Continue', goto='END')
    cw.calc('Stop Working', 'False', 'o_flg_Continue')


def env(main, names):
    for n in names:
        main.data(n, 'text', exposure='Environment')


def portal_start(main, first_stage_name):
    """Credentials, Launch Portal, Sign In -- the same in Load and Post."""
    main.action(first_stage_name, CRED, 'Get',
                inputs=[('text', 'Credentials Name', '[Parcel Portal Credential Name]')],
                outputs=[('text', 'Username', 'g_txt_User'), ('password', 'Password', 'g_pwd_Password')])
    main.action('Launch Portal', PORTAL, 'Launch Portal',
                inputs=[('text', 'Config Path', '[Parcel Portal Config Path]'),
                        ('text', 'Driver Path', '[Parcel Portal Driver Path]'),
                        ('text', 'Browser Kind', '[Parcel Portal Browser Kind]'),
                        ('text', 'Run Mode', '[Parcel Portal Run Mode]'),
                        ('text', 'Log Folder', '[Parcel Portal Log Folder]')])
    main.action('Sign In To Portal', PORTAL, 'Sign In',
                inputs=[('text', 'User Name', '[g_txt_User]'), ('password', 'Password', '[g_pwd_Password]')])


# =====================================================================================================
# 1. Load Orders
# =====================================================================================================
p = Proc('Parcel Depot - Load Orders', 'process',
         'Sign in to Parcel Portal, read the Open orders list and put every order on the work queue once.')
m = p.page('Main', 'Control framework: reset, stop check, portal sign-in, read, queue, close. Browser closed on every path.')
env(m, [QN] + PORTAL_ENV)
for dt, nm in [('text', 'g_txt_User'), ('password', 'g_pwd_Password'), ('collection', 'g_col_Orders'),
               ('number', 'g_nr_Order Count'), ('flag', 'g_flg_Continue')]:
    m.data(nm, dt)
m.page_ref('Reset Data', page='Reset Global Data', outputs=[('number', 'o_nr_Order Count', 'g_nr_Order Count')])
m.page_ref('Check Continue To Work', page='Continue To Work', outputs=[('flag', 'o_flg_Continue', 'g_flg_Continue')])
m.decision('Continue Working?', '[g_flg_Continue]', true_target='NEXT', false_target='END')
portal_start(m, 'Get Portal Credentials')
m.action('Read Open Orders', PORTAL, 'Get Open Orders',
         outputs=[('collection', 'Orders', 'g_col_Orders'), ('number', 'Order Count', 'g_nr_Order Count')])
m.decision('Any Orders?', '[g_nr_Order Count] > 0', true_target='NEXT', false_target='Close Portal')
m.action('Add Orders To Queue', 'Work Queues', 'Add To Queue',
         inputs=[('text', 'Queue Name', '[' + QN + ']'), ('collection', 'Data', '[g_col_Orders]'),
                 ('text', 'Tags', lit('Loaded'))])
m.action('Close Portal', PORTAL, 'Close Portal')
m.work_block('Load Orders Run', 'Get Portal Credentials', 'Close Portal', scope='page',
             handler=[('Close Portal On Failure', PORTAL, 'Close Portal', [])], then='RETHROW')
common_pages(p, [('number', 'o_nr_Order Count', '0')])
print(p.write('BPA Process - Parcel Depot - Load Orders.xml', outdir=HERE))

# =====================================================================================================
# 2. Approve Orders
# =====================================================================================================
p = Proc('Parcel Depot - Approve Orders', 'process',
         'Approve the queued orders in Parcel Depot under the environment lock; one results item per order worked.')
m = p.page('Main', 'Control framework: reset, lock, start the depot, claim loop with per-item recovery, wrap up (close + release) on every path.')
env(m, [QN, RQN, 'Parcel Depot Credential Name', 'Parcel Depot Lock Name'])
for dt, nm in [('text', 'g_txt_User'), ('password', 'g_pwd_Password'), ('text', 'g_txt_Lock Token'),
               ('flag', 'g_flg_Depot Open'), ('flag', 'g_flg_Continue'), ('text', 'g_txt_Item ID'),
               ('collection', 'g_col_Item Data'), ('text', 'g_txt_Order ID'), ('text', 'g_txt_Customer ID'),
               ('text', 'g_txt_Result'), ('collection', 'g_col_Result Row'),
               ('text', 'g_txt_Ex Type'), ('text', 'g_txt_Ex Detail'), ('text', 'g_txt_Ex Stage')]:
    m.data(nm, dt)
m.page_ref('Reset Data', page='Reset Global Data',
           outputs=[('text', 'o_txt_Lock Token', 'g_txt_Lock Token'), ('flag', 'o_flg_Depot Open', 'g_flg_Depot Open')])
m.action('Get Depot Credentials', CRED, 'Get',
         inputs=[('text', 'Credentials Name', '[Parcel Depot Credential Name]')],
         outputs=[('text', 'Username', 'g_txt_User'), ('password', 'Password', 'g_pwd_Password')])
m.action('Acquire Depot Lock', 'Environment Locking', 'Acquire Lock',
         inputs=[('text', 'Name', '[Parcel Depot Lock Name]'),
                 ('text', 'Preferred Token', '"Parcel Depot Approve Orders " & Now()'),
                 ('text', 'Comment', lit('Parcel Depot - Approve Orders'))],
         outputs=[('text', 'Token', 'g_txt_Lock Token')])
m.decision('Lock Acquired?', '[g_txt_Lock Token] <> ""', true_target='NEXT', false_target='Raise Depot Locked')
m.page_ref('Start Depot', page='Start Depot',
           inputs=[('text', 'i_txt_User', '[g_txt_User]'), ('password', 'i_pwd_Password', '[g_pwd_Password]')],
           outputs=[('flag', 'o_flg_Depot Open', 'g_flg_Depot Open')])
# ---- claim loop: both ends of an item come back to the stop check; only the decisions leave ----
m.page_ref('Check Continue To Work', page='Continue To Work', outputs=[('flag', 'o_flg_Continue', 'g_flg_Continue')])
m.decision('Continue Working?', '[g_flg_Continue]', true_target='NEXT', false_target='Wrap Up Run')
m.action('Get Next Item', 'Work Queues', 'Get Next Item',
         inputs=[('text', 'Queue Name', '[' + QN + ']')],
         outputs=[('text', 'Item ID', 'g_txt_Item ID'), ('collection', 'Data', 'g_col_Item Data')])
m.decision('Item Available?', '[g_txt_Item ID] <> ""', true_target='NEXT', false_target='Wrap Up Run')
m.multi_calc('Read Item Fields', [('[g_col_Item Data.Order ID]', 'g_txt_Order ID'),
                                  ('[g_col_Item Data.Customer ID]', 'g_txt_Customer ID')])
m.page_ref('Work Item', page='Work Item',
           inputs=[('text', 'i_txt_Order ID', '[g_txt_Order ID]'), ('text', 'i_txt_Customer ID', '[g_txt_Customer ID]')],
           outputs=[('text', 'o_txt_Result', 'g_txt_Result')])
m.action('Tag Item With Result', 'Work Queues', 'Tag Item',
         inputs=[('text', 'Item ID', '[g_txt_Item ID]'), ('text', 'Tag', '[g_txt_Result]')])
m.action('Mark Item Completed', 'Work Queues', 'Mark Completed',
         inputs=[('text', 'Item ID', '[g_txt_Item ID]')], goto='Build Result Row')
m.decision('Business Exception?', '[g_txt_Ex Type] = "Business Exception"',
           true_target='Set Business Reason', false_target='Set System Reason')
m.calc('Set Business Reason', '"Business Exception: " & [g_txt_Ex Detail]', 'g_txt_Result', goto='Mark Item Exception')
m.calc('Set System Reason', '"System Exception: " & [g_txt_Ex Detail]', 'g_txt_Result')
m.action('Mark Item Exception', 'Work Queues', 'Mark Exception',
         inputs=[('text', 'Item ID', '[g_txt_Item ID]'), ('text', 'Exception Reason', '[g_txt_Result]'),
                 ('flag', 'Retry', 'False')])
m.action('Build Result Row', HELPER, 'Build Result Row',
         inputs=[('text', 'Order ID', '[g_txt_Order ID]'), ('text', 'Result', '[g_txt_Result]')],
         outputs=[('collection', 'Row', 'g_col_Result Row')])
m.action('Add Result To Results Queue', 'Work Queues', 'Add To Queue',
         inputs=[('text', 'Queue Name', '[' + RQN + ']'), ('collection', 'Data', '[g_col_Result Row]')],
         goto='Check Continue To Work')
m.page_ref('Wrap Up Run', page='Wrap Up Run', goto='END')
m.exception('Raise Depot Locked', 'System Exception', lit('Parcel Depot is locked by another session'))
m.work_block('Work The Order', 'Work Item', 'Work Item',
             capture=('g_txt_Ex Type', 'g_txt_Ex Detail', 'g_txt_Ex Stage'), then='Business Exception?')
m.work_block('Approve Orders Run', 'Get Depot Credentials', 'Wrap Up Run', scope='page',
             handler=[('Wrap Up On Failure', 'PAGE', 'Wrap Up Run', [])], then='RETHROW')

# ---- Start Depot ----
s = p.page('Start Depot', 'Start Parcel Depot and sign in. The depot counts as open as soon as it is launched.')
s.add_input('text', 'i_txt_User'); s.add_input('password', 'i_pwd_Password'); s.add_output('flag', 'o_flg_Depot Open')
s.action('Launch Depot', DEPOT, 'Launch Depot')
s.calc('Mark Depot Open', 'True', 'o_flg_Depot Open')
s.action('Sign In To Depot', DEPOT, 'Sign In',
         inputs=[('text', 'User Name', '[i_txt_User]'), ('password', 'Password', '[i_pwd_Password]')])

# ---- Wrap Up Run: close the depot (if open), release the lock (if held). Safe to call twice. ----
w = p.page('Wrap Up Run', 'Close Parcel Depot when it is open and release the lock when it is held; safe on every path.')
w.decision('Depot Open?', '[g_flg_Depot Open]', true_target='NEXT', false_target='Lock Held?')
w.action('Close Depot', DEPOT, 'Close Depot')
w.calc('Mark Depot Closed', 'False', 'g_flg_Depot Open')
w.decision('Lock Held?', '[g_txt_Lock Token] <> ""', true_target='NEXT', false_target='END')
w.action('Release Depot Lock', 'Environment Locking', 'Release Lock',
         inputs=[('text', 'Name', '[Parcel Depot Lock Name]'), ('text', 'Token', '[g_txt_Lock Token]'),
                 ('text', 'Comment', lit('Parcel Depot - Approve Orders'))])
w.calc('Forget Lock Token', '""', 'g_txt_Lock Token')

# ---- Work Item: the business rules, one order ----
v = p.page('Work Item', 'Customer, order, status, limit, reason, priority, approve. Business rule failures are Business Exceptions.')
v.add_input('text', 'i_txt_Order ID'); v.add_input('text', 'i_txt_Customer ID'); v.add_output('text', 'o_txt_Result')
for dt, nm, init in [('flag', 'flg_Customer Found', None), ('text', 'txt_Customer Name', None), ('text', 'txt_Status', None),
                     ('text', 'txt_Amount', None), ('collection', 'col_Order Lines', None), ('flag', 'flg_Above Limit', None),
                     ('text', 'txt_Reason', None), ('flag', 'flg_Priority', None), ('text', 'txt_Message', None),
                     ('text', 'txt_Approval Limit', '2000.00'), ('text', 'txt_Override Above', '500.00'),
                     ('text', 'txt_Fragile Word', 'Fragile')]:
    v.data(nm, dt, initial=init)
v.action('Find Customer', DEPOT, 'Find Customer', inputs=[('text', 'Customer ID', '[i_txt_Customer ID]')],
         outputs=[('flag', 'Found', 'flg_Customer Found'), ('text', 'Customer Name', 'txt_Customer Name')])
v.decision('Customer Found?', '[flg_Customer Found]', true_target='NEXT', false_target='Raise Customer Not Found')
v.action('Find Order', DEPOT, 'Find Order', inputs=[('text', 'Order ID', '[i_txt_Order ID]')],
         outputs=[('text', 'Status', 'txt_Status'), ('text', 'Amount', 'txt_Amount'),
                  ('collection', 'Order Lines', 'col_Order Lines')])
v.choice('Order Status?', [('Not found', '[txt_Status] = "Not found"', 'Raise Order Not Found'),
                           ('Approved', '[txt_Status] = "Approved"', 'Set Already Approved'),
                           ('Pending', '[txt_Status] = "Pending"', 'Classify Order')],
         otherwise='Raise Unexpected Status')
v.calc('Set Already Approved', '"Already approved"', 'o_txt_Result', goto='END')
v.action('Classify Order', HELPER, 'Classify Order',
         inputs=[('text', 'Amount', '[txt_Amount]'), ('collection', 'Order Lines', '[col_Order Lines]'),
                 ('text', 'Approval Limit', '[txt_Approval Limit]'), ('text', 'Override Above', '[txt_Override Above]'),
                 ('text', 'Fragile Word', '[txt_Fragile Word]')],
         outputs=[('flag', 'Above Limit', 'flg_Above Limit'), ('text', 'Reason', 'txt_Reason'),
                  ('flag', 'Priority', 'flg_Priority')])
v.decision('Within Limit?', '[flg_Above Limit] = False', true_target='NEXT', false_target='Raise Above Limit')
v.action('Approve Order', DEPOT, 'Approve Order',
         inputs=[('text', 'Reason', '[txt_Reason]'), ('flag', 'Priority', '[flg_Priority]')],
         outputs=[('text', 'Message', 'txt_Message')])
v.decision('Order Approved?', 'Trim([txt_Message]) = "Order " & [i_txt_Order ID] & " approved"',
           true_target='NEXT', false_target='Raise Approve Failed')
v.calc('Set Approved', '"Approved"', 'o_txt_Result', goto='END')
v.exception('Raise Customer Not Found', 'Business Exception',
            '"Customer " & [i_txt_Customer ID] & " not found in Parcel Depot"')
v.exception('Raise Order Not Found', 'Business Exception', '"Order " & [i_txt_Order ID] & " not found in Parcel Depot"')
v.exception('Raise Unexpected Status', 'Business Exception',
            '"Order " & [i_txt_Order ID] & " has unexpected status: " & [txt_Status]')
v.exception('Raise Above Limit', 'Business Exception',
            '"Order " & [i_txt_Order ID] & " is above the approval limit: " & [txt_Amount]')
v.exception('Raise Approve Failed', 'System Exception',
            '"Approve failed for " & [i_txt_Order ID] & ": " & [txt_Message]')

common_pages(p, [('text', 'o_txt_Lock Token', '""'), ('flag', 'o_flg_Depot Open', 'False')])
print(p.write('BPA Process - Parcel Depot - Approve Orders.xml', outdir=HERE))

# =====================================================================================================
# 3. Post Results
# =====================================================================================================
p = Proc('Parcel Depot - Post Results', 'process',
         'Report every results queue item to Parcel Portal (Report a result) and mark it by the message shown.')
m = p.page('Main', 'Control framework: reset, portal sign-in, claim loop with per-item recovery, close the browser on every path.')
env(m, [RQN] + PORTAL_ENV)
for dt, nm in [('text', 'g_txt_User'), ('password', 'g_pwd_Password'), ('flag', 'g_flg_Continue'),
               ('text', 'g_txt_Item ID'), ('collection', 'g_col_Item Data'), ('text', 'g_txt_Order ID'),
               ('text', 'g_txt_Result'), ('text', 'g_txt_Reason'),
               ('text', 'g_txt_Ex Type'), ('text', 'g_txt_Ex Detail'), ('text', 'g_txt_Ex Stage')]:
    m.data(nm, dt)
m.page_ref('Reset Data', page='Reset Global Data', outputs=[('text', 'o_txt_Item ID', 'g_txt_Item ID')])
portal_start(m, 'Get Portal Credentials')
m.page_ref('Check Continue To Work', page='Continue To Work', outputs=[('flag', 'o_flg_Continue', 'g_flg_Continue')])
m.decision('Continue Working?', '[g_flg_Continue]', true_target='NEXT', false_target='Close Portal')
m.action('Get Next Item', 'Work Queues', 'Get Next Item',
         inputs=[('text', 'Queue Name', '[' + RQN + ']')],
         outputs=[('text', 'Item ID', 'g_txt_Item ID'), ('collection', 'Data', 'g_col_Item Data')])
m.decision('Item Available?', '[g_txt_Item ID] <> ""', true_target='NEXT', false_target='Close Portal')
m.multi_calc('Read Item Fields', [('[g_col_Item Data.Order ID]', 'g_txt_Order ID'),
                                  ('[g_col_Item Data.Result]', 'g_txt_Result')])
m.page_ref('Post Item', page='Post Item',
           inputs=[('text', 'i_txt_Order ID', '[g_txt_Order ID]'), ('text', 'i_txt_Result', '[g_txt_Result]')])
m.action('Mark Item Completed', 'Work Queues', 'Mark Completed',
         inputs=[('text', 'Item ID', '[g_txt_Item ID]')], goto='Check Continue To Work')
m.decision('Business Exception?', '[g_txt_Ex Type] = "Business Exception"',
           true_target='Set Business Reason', false_target='Set System Reason')
m.calc('Set Business Reason', '"Business Exception: " & [g_txt_Ex Detail]', 'g_txt_Reason', goto='Mark Item Exception')
m.calc('Set System Reason', '"System Exception: " & [g_txt_Ex Detail]', 'g_txt_Reason')
m.action('Mark Item Exception', 'Work Queues', 'Mark Exception',
         inputs=[('text', 'Item ID', '[g_txt_Item ID]'), ('text', 'Exception Reason', '[g_txt_Reason]'),
                 ('flag', 'Retry', 'False')], goto='Check Continue To Work')
m.action('Close Portal', PORTAL, 'Close Portal')
m.work_block('Post The Result', 'Post Item', 'Post Item',
             capture=('g_txt_Ex Type', 'g_txt_Ex Detail', 'g_txt_Ex Stage'), then='Business Exception?')
m.work_block('Post Results Run', 'Get Portal Credentials', 'Close Portal', scope='page',
             handler=[('Close Portal On Failure', PORTAL, 'Close Portal', [])], then='RETHROW')

v = p.page('Post Item', 'Report one result and classify the message the portal shows.')
v.add_input('text', 'i_txt_Order ID'); v.add_input('text', 'i_txt_Result')
v.data('txt_Message', 'text')
v.action('Post Result', PORTAL, 'Post Result',
         inputs=[('text', 'Order ID', '[i_txt_Order ID]'), ('text', 'Result', '[i_txt_Result]')],
         outputs=[('text', 'Message', 'txt_Message')])
v.decision('Result Saved?', '[txt_Message] = "Saved " & [i_txt_Order ID]', true_target='END', false_target='NEXT')
v.decision('Order Unknown?', '[txt_Message] = "Unknown order " & [i_txt_Order ID]',
           true_target='Raise Order Unknown', false_target='Raise Not Saved')
v.exception('Raise Order Unknown', 'Business Exception', '"Parcel Portal does not know order " & [i_txt_Order ID]')
v.exception('Raise Not Saved', 'System Exception', '"Result not saved for " & [i_txt_Order ID] & ": " & [txt_Message]')

common_pages(p, [('text', 'o_txt_Item ID', '""')])
print(p.write('BPA Process - Parcel Depot - Post Results.xml', outdir=HERE))
