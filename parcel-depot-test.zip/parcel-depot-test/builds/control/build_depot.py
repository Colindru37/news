"""Builds BPA Object - Parcel Depot Desktop.xml (UI object, UIA elements empty; identify_depot.sh fills them)."""
import sys, os
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'skill', 'lib'))
from bp_gen import Proc, lit

o = Proc('Parcel Depot Desktop', 'object',
         'Drives the Parcel Depot desktop application: sign in, look up a customer, look up and approve an order.')
o.application('Parcel Depot', 'Win32Launch',
              {'Path': '', 'CommandLineParams': '', 'WorkingDirectory': '', 'NonInvasive': 'True'})
o.code_options()

# ---- Application Modeller: a branch per window; every element unique by its OWN ticked attributes ----
W_SIGN, W_MAIN, W_CONF = 'Window - Sign In - UIA', 'Window - Main - UIA', 'Window - Confirm - UIA'
o.element(W_SIGN, 'Window')
o.element(W_SIGN + '/Textbox - User Name - UIA', 'Edit')
o.element(W_SIGN + '/Textbox - Password - UIA', 'Edit')
o.element(W_SIGN + '/Button - Sign In - UIA', 'Button')
o.element(W_SIGN + '/Label - Sign In Message - UIA', 'Label')
o.element(W_MAIN, 'Window')
o.element(W_MAIN + '/Textbox - Customer Search - UIA', 'Edit')
o.element(W_MAIN + '/Button - Customer Find - UIA', 'Button')
o.element(W_MAIN + '/Label - Customer Result - UIA', 'Label')
o.element(W_MAIN + '/Textbox - Order Search - UIA', 'Edit')
o.element(W_MAIN + '/Button - Order Find - UIA', 'Button')
o.element(W_MAIN + '/Label - Order Status - UIA', 'Label')
o.element(W_MAIN + '/Label - Order Status Busy - UIA', 'Label')
o.element(W_MAIN + '/Label - Order Amount - UIA', 'Label')
o.element(W_MAIN + '/Table - Order Lines - UIA', 'Table')
o.element(W_MAIN + '/Checkbox - Priority - UIA', 'CheckBox')
o.element(W_MAIN + '/Radio - Reason Standard - UIA', 'RadioButton')
o.element(W_MAIN + '/Radio - Reason Manager Override - UIA', 'RadioButton')
o.element(W_MAIN + '/Button - Approve - UIA', 'Button')
o.element(W_MAIN + '/Label - Order Message - UIA', 'Label')
o.element(W_CONF, 'Window')
o.element(W_CONF + '/Button - Confirm Yes - UIA', 'Button')

o.object_data('Depot Wait Seconds', 'number', initial='15')        # named timeout (new object default)
o.object_data('Lookup Start Seconds', 'number', initial='3')       # how long to look for the "..." before assuming a fast lookup

o.page('Clean Up', 'Standard first object page.', page_type='CleanUp')

# ---------------- Launch Depot ----------------
p = o.page('Launch Depot', 'Start Parcel Depot and wait for its sign-in window.')
p.navigate('Launch Parcel Depot', [('Parcel Depot', 'Launch')])
p.wait_for('Wait For Sign In Window', [('Window - Sign In - UIA', 'CheckExists', 'END')],
           '[Depot Wait Seconds]', on_timeout='Sign In Window Missing')
p.exception('Sign In Window Missing', 'System Exception', lit('Parcel Depot did not show its sign-in window'))

# ---------------- Sign In ----------------
p = o.page('Sign In', 'Sign in with the depot bot credentials; a refused sign-in raises the reason shown.')
p.add_input('text', 'User Name')
p.add_input('password', 'Password')
p.data('txt_Message', 'text')
p.write('Enter User Name', [('Textbox - User Name - UIA', '[User Name]')])
p.code('Unwrap Password', 'Password_Text = new System.Net.NetworkCredential("", Password).Password;',
       inputs=[('password', 'Password', '[Password]')], outputs=[('text', 'Password_Text', 'Password Text')])
p.write('Enter Password', [('Textbox - Password - UIA', '[Password Text]')])
p.calc('Forget Password Text', '""', 'Password Text')
p.navigate('Press Sign In', [('Button - Sign In - UIA', 'Press')])
p.wait_for('Wait For Sign In Result', [('Window - Main - UIA', 'CheckExists', 'END'),
                                       ('Label - Sign In Message - UIA', 'CheckExists', 'Read Sign In Message')],
           '[Depot Wait Seconds]', on_timeout='Sign In Timed Out')
p.read('Read Sign In Message', [('Label - Sign In Message - UIA', 'GetWindowText', 'txt_Message', 'text')])
p.exception('Raise Sign In Refused', 'System Exception', lit('Parcel Depot sign-in refused: ') + ' & [txt_Message]')
p.exception('Sign In Timed Out', 'System Exception', lit('Parcel Depot gave no answer to the sign-in'))

# ---------------- Find Customer ----------------
p = o.page('Find Customer', 'Look the customer id up in the Customers part. Found = False when the depot says No such customer.')
p.add_input('text', 'Customer ID')
p.add_output('flag', 'Found')
p.add_output('text', 'Customer Name')
p.wait_for('Wait For Main Window', [('Window - Main - UIA', 'CheckExists', 'NEXT')],
           '[Depot Wait Seconds]', on_timeout='Main Window Missing')
p.write('Enter Customer ID', [('Textbox - Customer Search - UIA', '[Customer ID]')])
p.navigate('Press Customer Find', [('Button - Customer Find - UIA', 'Press')])
p.wait_for('Wait For Customer Result', [('Label - Customer Result - UIA', 'CheckExists', 'NEXT')],
           '[Depot Wait Seconds]', on_timeout='Customer Result Missing')
p.read('Read Customer Result', [('Label - Customer Result - UIA', 'GetWindowText', 'Customer Name', 'text')])
p.calc('Set Customer Found', '[Customer Name] <> "No such customer"', 'Found', goto='END')
p.exception('Main Window Missing', 'System Exception', lit('Parcel Depot main window is not open'))
p.exception('Customer Result Missing', 'System Exception', lit('Parcel Depot showed no customer result'))

# ---------------- Find Order ----------------
p = o.page('Find Order', 'Look the order id up in the Orders part and read status, amount and lines once the lookup has finished.')
p.add_input('text', 'Order ID')
p.add_output('text', 'Status')
p.add_output('text', 'Amount')
p.add_output('collection', 'Order Lines')
p.wait_for('Wait For Main Window', [('Window - Main - UIA', 'CheckExists', 'NEXT')],
           '[Depot Wait Seconds]', on_timeout='Main Window Missing')
p.write('Enter Order ID', [('Textbox - Order Search - UIA', '[Order ID]')])
p.navigate('Press Order Find', [('Button - Order Find - UIA', 'Press')])
# the status shows "..." while the lookup runs: first see it start (a fast lookup may never show it), then wait until it is gone
p.wait_for('Wait For Lookup To Start', [('Label - Order Status Busy - UIA', 'CheckExists', 'Wait For Lookup To Finish')],
           '[Lookup Start Seconds]', on_timeout='Wait For Lookup To Finish')
p.wait_for('Wait For Lookup To Finish', [('Label - Order Status Busy - UIA', 'CheckExists', 'NEXT', 'NotEqual')],
           '[Depot Wait Seconds]', on_timeout='Lookup Timed Out')
p.read('Read Order Result', [('Label - Order Status - UIA', 'GetWindowText', 'Status', 'text'),
                             ('Label - Order Amount - UIA', 'GetWindowText', 'Amount', 'text'),
                             ('Table - Order Lines - UIA', 'GetTable', 'Order Lines', 'collection')], goto='END')
p.exception('Main Window Missing', 'System Exception', lit('Parcel Depot main window is not open'))
p.exception('Lookup Timed Out', 'System Exception', lit('Parcel Depot order lookup did not finish'))

# ---------------- Approve Order ----------------
p = o.page('Approve Order', 'Choose the reason, set Priority, press Approve and confirm with Yes; returns the message shown under the button.')
p.add_input('text', 'Reason')
p.add_input('flag', 'Priority')
p.add_output('text', 'Message')
p.write('Set Priority', [('Checkbox - Priority - UIA', '[Priority]')])
p.decision('Manager Override Reason?', '[Reason] = "Manager override"',
           true_target='NEXT', false_target='Standard Reason?')
p.navigate('Press Manager Override', [('Radio - Reason Manager Override - UIA', 'Press')], goto='Press Approve')
p.decision('Standard Reason?', '[Reason] = "Standard"', true_target='NEXT', false_target='Raise Unknown Reason')
p.navigate('Press Standard', [('Radio - Reason Standard - UIA', 'Press')])
p.navigate('Press Approve', [('Button - Approve - UIA', 'Press')])
p.wait_for('Wait For Confirm Window', [('Button - Confirm Yes - UIA', 'CheckExists', 'NEXT')],
           '[Depot Wait Seconds]', on_timeout='Confirm Window Missing')
p.navigate('Press Yes', [('Button - Confirm Yes - UIA', 'Press')])
p.wait_for('Wait For Approve Message', [('Label - Order Message - UIA', 'CheckExists', 'NEXT')],
           '[Depot Wait Seconds]', on_timeout='Approve Message Missing')
p.read('Read Approve Message', [('Label - Order Message - UIA', 'GetWindowText', 'Message', 'text')], goto='END')
p.exception('Raise Unknown Reason', 'System Exception', lit('Unknown approval reason: ') + ' & [Reason]')
p.exception('Confirm Window Missing', 'System Exception', lit('Parcel Depot did not ask to confirm the approval'))
p.exception('Approve Message Missing', 'System Exception', lit('Parcel Depot showed no message after the approval'))

# ---------------- Close Depot ----------------
p = o.page('Close Depot', 'Close Parcel Depot. Safe to call when it is already closed.')
p.navigate('Terminate Parcel Depot', [('Parcel Depot', 'Terminate')])
p.work_block('Terminate The Application', 'Terminate Parcel Depot', 'Terminate Parcel Depot', handler=[], then='END')

print(o.write('BPA Object - Parcel Depot Desktop.xml', outdir=os.path.join(HERE)))
print('spy:', ', '.join(x.split('/')[-1] for x in o.spy_checklist()))
