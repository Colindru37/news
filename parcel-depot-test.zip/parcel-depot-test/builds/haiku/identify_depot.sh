#!/bin/sh
# Identify every Parcel Depot element from the spy captures in out/spy (run after out/build.py).
# Usage (from the work folder):  sh out/identify_depot.sh
set -e
OBJ="out/BPA Object - Parcel Depot.xml"
S=out/spy
I="node tools/identify.js"
$I "$OBJ" "Window - Sign In - UIA" $S/sign_win.json --use uName,uControlType
$I "$OBJ" "Edit - User Name - UIA" $S/sign_user.json --use uAutomationId,uControlType
$I "$OBJ" "Edit - Password - UIA" $S/sign_pass.json --use uAutomationId,uControlType
$I "$OBJ" "Button - Sign In - UIA" $S/sign_btn.json --use uName,uControlType
$I "$OBJ" "Window - Depot - UIA" $S/main_win.json --use uName,uControlType --set "uName=Parcel Depot - session*" --cmp uName=Wildcard
$I "$OBJ" "Edit - Customer Search - UIA" $S/cust_edit.json --use uControlType,uName,puClassName
$I "$OBJ" "Button - Customer Find - UIA" $S/cust_find.json --use uControlType,uName,puClassName
$I "$OBJ" "Text - Customer Result - UIA" $S/cust_result.json --use uControlType,uClassName,puClassName,puName,uAutomationId
$I "$OBJ" "Edit - Order Search - UIA" $S/ord_edit.json --use uControlType,uName,puClassName
$I "$OBJ" "Button - Order Find - UIA" $S/ord_find.json --use uControlType,uName,puClassName
$I "$OBJ" "Text - Order Status - UIA" $S/ord_status.json --use uControlType,uAutomationId
$I "$OBJ" "Text - Order Amount - UIA" $S/ord_amount.json --use uControlType,uAutomationId
$I "$OBJ" "Table - Order Lines - UIA" $S/ord_table.json --use uControlType,uName
$I "$OBJ" "CheckBox - Priority - UIA" $S/priority.json --use uControlType,uName
$I "$OBJ" "RadioButton - Standard - UIA" $S/radio_std.json --use uControlType,uName
$I "$OBJ" "RadioButton - Manager Override - UIA" $S/radio_mgr.json --use uControlType,uName
$I "$OBJ" "Button - Approve - UIA" $S/approve.json --use uControlType,uName
$I "$OBJ" "Text - Order Message - UIA" $S/ord_msg.json --use uControlType,uClassName,uAutomationId,puClassName,puName,uName --set "uName=^(?!Amount:$|Status:$)" --cmp uName=RegEx
$I "$OBJ" "Window - Confirm Approve - UIA" $S/confirm_win.json --use uControlType,uName --set "uName=Approve *" --cmp uName=Wildcard
$I "$OBJ" "Button - Yes - UIA" $S/confirm_yes.json --use uControlType,uAutomationId
