#!/bin/sh
# Full rebuild from the work folder: generate the XML, identify the Parcel Depot elements from out/spy, then the gates.
set -e
python3 out/build.py >/dev/null
sh out/identify_depot.sh >/dev/null
python3 skill/lib/validate.py out --flow --strict --with estate | grep -v "^         '" | grep -v "^$"
python3 skill/lib/compile_check.py out | tail -1
node tools/twins.js "out/BPA Object - Parcel Depot.xml" out/spy/S1_signin.json out/spy/S2_idle.json out/spy/S3_cust_found.json out/spy/S4_cust_missing.json out/spy/S5_order_pending.json out/spy/S6_confirm.json out/spy/S7_approved.json out/spy/S8_already.json out/spy/S8b_approved_again.json out/spy/S9_notfound.json out/spy/S10_limit.json
