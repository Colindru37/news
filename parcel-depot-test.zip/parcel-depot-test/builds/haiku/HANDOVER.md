# Parcel Depot order approval: handover

Three processes and two business objects. The browser object `GK Revoke Browser` (estate/) is called, never rebuilt.
Built with the rpa-bp generator (`out/build.py`); nothing has been run in Blue Prism (none on this machine).

## Files

| File | What |
|---|---|
| `BPA Process - Parcel Depot - Load Orders.xml` | Process 1: sign in, read the open orders, queue each order once, close the browser. |
| `BPA Process - Parcel Depot - Approve Orders.xml` | Process 2: lock, start Parcel Depot, sign in, claim/approve/mark loop, one result row per item, clean-up on every path. |
| `BPA Process - Parcel Depot - Post Results.xml` | Process 3: sign in to the portal, save each result, mark each item. |
| `BPA Object - Parcel Portal.xml` | Web object over `GK Revoke Browser`: Open Portal Session, Get Open Orders, Save Result, Close Portal. |
| `BPA Object - Parcel Depot.xml` | Desktop object (UI Automation): Start Depot, Open Depot Session, Get Customer, Get Order, Approve Order, Build Result Row, Close Depot. 20 elements, all identified. |
| `build.py` | Generator. Change this, then rerun `sh out/make.sh`. Never hand-edit the XML. |
| `identify_depot.sh` | Writes the Application Modeller ticks from the spy captures in `spy/` (the element identities). |
| `make.sh` | Rebuild, identify, validate, compile, twins: the whole chain. |
| `spy/*.json` | Element attributes and screen dumps from the live depot (11 screens). Needed to rerun identify. |

## Queue items

- Work queue (`Parcel Depot Queue Name`), written by Load Orders: one item per order, fields `Order ID`, `Customer ID`, tag `Loaded`.
  Read by Approve Orders with Get Next Item. Duplicates are removed inside the portal object before queueing.
- Results queue (`Parcel Depot Results Queue Name`), written by Approve Orders for every item worked: fields `Order ID`, `Result`.
  `Result` is `Approved`, `Already approved`, or the full failure text (`Business Exception: ...` / `System Exception: ...`).
  Read by Post Results.
- Mark Exception always uses Retry = False (PDD: "No retries").

## Design (how it fits together)

- Approve Orders holds the environment lock for the whole run. Its page-level Recover calls `Clean Up Run` (stop Parcel Depot if
  started, release the lock if taken) on every failure and on the normal end.
- Each item runs in one work block: `Work Item` (page in the process), with exception type/detail captured in recovery mode.
  Business exceptions and system exceptions are both marked on the item; the loop carries on. A consecutive-system-failure
  guard (limit 5, a data item, not an environment variable) stops the run.
- Business rules (limit 2000.00, reason above 500.00, Fragile priority) are decisions in the `Work Item` page and the depot object;
  the depot object returns the status, the amount and whether a line says Fragile.
- Each element is matched on its own ticked attributes: the Customers and Orders parts are told apart by the parent class
  (GtkBox vs GtkFrame); the Orders message label by its parent class, empty automation id and a name RegEx that excludes the
  two labels next to it; the Find/Search pairs the same way; the window title by Wildcard (it carries a session number).
  Positive control: weakening two elements to a single tick produced 22 twin findings, so the clean result is meaningful.

## Gates (run from this folder)

- `python3 skill/lib/validate.py out --flow --strict --with estate`: ALL CLEAN.
- `python3 skill/lib/compile_check.py out`: ALL COMPILED (mono's mcs and vbc, NOT Blue Prism's compiler: rerun with `--ref-dir` on the BP machine).
- `node tools/twins.js ...` on the 11 depot screens: TWINS CLEAN.
- Internal objects (Work Queues, Credentials, Environment Locking) are checked against stubs written from the signatures in
  `skill/reference/estate-objects.md` (`work/stubs`, not shipped): all calls match them.

## Timing measured on the depot (used for the waits)

- Customer result: updated within the read (no pause needed).
- Order status: "..." appears about 0.1 s after Find and the final status about 0.5 s after: a 2 s pause, then a poll on "...".
- Approve: the confirm window closes about 0.2 s after Yes; the message and the status appear together about 0.9 s after Yes:
  the message is polled (20 tries, 1 s apart) before the status is read.
- The depot refuses an approval above 500.00 without a reason ("Error: a reason is required above 500.00"); the design always
  sets the reason. It also has an order locked by another user (P-2005: "Error: order P-2005 is locked by another user"),
  which is the approve system-exception path.

## Not verified / open items

1. Nothing has run in Blue Prism. Compile is with mono, not Blue Prism's compiler; import and run on the BP machine first.
2. Parcel Depot launch path: the Application Modeller Path is blank (no environment variable exists for it in the contract).
   Set it on the machine. The desktop object uses Win32Launch with UI Automation elements (base type UIAElement).
3. The portal was never opened (no browser allowed). Its locators come only from config/portal.ini. The texts "Saved <id>" and
   "Unknown order <id>" are as the PDD writes them. Save Result detects a new message by comparing with the one shown before the save.
4. Blue Prism's work queue Key Name must be set to `Order ID` in System Manager (the process does not set it).
5. `Enter Password` passes a password item into a text parameter of the browser object. Blue Prism may need a text conversion.
6. Write stage assumed to replace the text in the search boxes (the spy's `type` does), so repeated lookups do not append.
7. The Blue Prism technology is assumed to be UI Automation for every element; check the element types when first identified in Studio.
8. Not done (PDD silent): no house logging object (none named in the estate pack); no item/time limits or working hours (only
   IsStopRequested); Post Results has no consecutive-failure guard; Load and Post have no Continue To Work / Reset Global Data pages.
9. The skill's own selftest reports missing files in this copy (DEV_PROMPT_*.md, copilot/*, tools/bprun/*): its behaviour and
   compile checks pass. The bprun harness that would run the flows is not in this copy, so the processes were not run here.
10. Depot test data: `depot_state.json` was reset to the initial data at the end of the session.
