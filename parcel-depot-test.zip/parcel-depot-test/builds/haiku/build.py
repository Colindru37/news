"""Build the Parcel Depot order approval: 2 objects + 3 processes. Run from the work folder:
    python3 out/build.py
Writes XML into out/ (never edit the XML by hand: change this file and rerun)."""
import sys, os
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, 'skill', 'lib'))
from bp_gen import Proc, lit

OUT = HERE
PORTAL = 'Parcel Portal'
DEPOT = 'Parcel Depot'
BROWSER = 'GK Revoke Browser'
WQ = 'Work Queues'
ENVLOCK = 'Environment Locking'
CRED = 'Credentials'
UIA = 'UIAElement'

# ============================================================================
# OBJECT: Parcel Portal (web, through the GK Revoke Browser object)
# ============================================================================
po = Proc(PORTAL, 'object', 'Parcel Portal (web): signs in, reads the open orders, saves one order result. '
          'All browser work goes through the GK Revoke Browser object; locators are [XPATHS] keys of the portal config.')
po.code_options()
po.page('Clean Up', 'Standard first object page.', page_type='CleanUp')

# -- Open Portal Session -----------------------------------------------------
pg = po.page('Open Portal Session', 'Load the portal config, start the browser, sign in. A refused sign-in is a '
             'System Exception with the reason shown by the portal; the browser is closed on any failure after launch.')
for dt, nm in [('text', 'Config Path'), ('text', 'Driver Path'), ('text', 'Browser Kind'), ('text', 'Run Mode'),
               ('text', 'Log Folder'), ('text', 'Username'), ('password', 'Password')]:
    pg.add_input(dt, nm)
pg.data('Signed In', 'flag')
pg.data('Message Shown', 'flag')
pg.data('Login Reason', 'text')
pg.action('Load Portal Config', BROWSER, 'Load Config', inputs=[('text', 'Config Path', '[Config Path]')])
pg.action('Launch Portal Browser', BROWSER, 'Launch Browser', inputs=[
    ('text', 'Run Mode', '[Run Mode]'), ('text', 'Driver Path', '[Driver Path]'), ('text', 'Browser', '[Browser Kind]'),
    ('flag', 'Headless', 'False'), ('text', 'Profile Root', lit('')), ('text', 'Profile Name', lit('')),
    ('text', 'Clone Name', lit('')), ('text', 'Download Folder', lit('')), ('text', 'Log Folder', '[Log Folder]'),
    ('number', 'Implicit Wait', '0'), ('number', 'Explicit Wait', '0')])
pg.work_block('Sign In To Portal', 'Navigate To Portal', 'Login Failed',
              handler=[('Close Browser After Failure', BROWSER, 'Close Browser')], then='RETHROW')
pg.action('Navigate To Portal', BROWSER, 'Navigate', inputs=[('text', 'URL Key', lit('portal_url'))])
pg.action('Enter User Name', BROWSER, 'Send Keys', inputs=[
    ('text', 'XPath Key', lit('portal_user')), ('number', 'Index', '0'), ('text', 'Text', '[Username]'),
    ('flag', 'Clear First', 'True'), ('flag', 'Press Enter', 'False'), ('number', 'Timeout', '0')])
pg.action('Enter Password', BROWSER, 'Send Keys', inputs=[
    ('text', 'XPath Key', lit('portal_pass')), ('number', 'Index', '0'), ('text', 'Text', '[Password]'),
    ('flag', 'Clear First', 'True'), ('flag', 'Press Enter', 'False'), ('number', 'Timeout', '0')])
pg.action('Press Log In', BROWSER, 'Click', inputs=[
    ('text', 'XPath Key', lit('portal_login')), ('number', 'Index', '0'), ('number', 'Timeout', '0')])
pg.action('Wait For Portal Desk', BROWSER, 'Wait For Element', inputs=[
    ('text', 'XPath Key', lit('portal_desk')), ('number', 'Index', '0'), ('text', 'Condition', lit('visible')),
    ('number', 'Timeout', '30')], outputs=[('flag', 'Found', 'Signed In')])
pg.decision('Portal Desk Shown?', '[Signed In] = True', true_target='END', false_target='Wait For Login Message')
pg.action('Wait For Login Message', BROWSER, 'Wait For Element', inputs=[
    ('text', 'XPath Key', lit('portal_login_msg')), ('number', 'Index', '0'), ('text', 'Condition', lit('visible')),
    ('number', 'Timeout', '3')], outputs=[('flag', 'Found', 'Message Shown')])
pg.decision('Login Message Shown?', '[Message Shown] = True', true_target='Read Login Message', false_target='Login Failed')
pg.action('Read Login Message', BROWSER, 'Get Text', inputs=[
    ('text', 'XPath Key', lit('portal_login_msg')), ('number', 'Index', '0'), ('number', 'Timeout', '0')],
    outputs=[('text', 'Text', 'Login Reason')], goto='Login Failed')
pg.exception('Login Failed', 'System Exception', '"Parcel Portal sign-in failed: " & [Login Reason]')

# -- Get Open Orders -----------------------------------------------------------
pg = po.page('Get Open Orders', 'Read every row of the Open orders list into one collection (Order ID, Customer ID), '
             'each order once. An order listed twice is kept once.')
pg.add_output('collection', 'Orders')
pg.data('Orders Loaded', 'flag')
pg.data('Row Count', 'number')
pg.data('Row Index', 'number')
pg.data('Order ID', 'text')
pg.data('Customer ID', 'text')
pg.action('Wait For Orders List', BROWSER, 'Wait For Element', inputs=[
    ('text', 'XPath Key', lit('portal_orders_loaded')), ('number', 'Index', '0'), ('text', 'Condition', lit('present')),
    ('number', 'Timeout', '30')], outputs=[('flag', 'Found', 'Orders Loaded')])
pg.decision('Orders Loaded?', '[Orders Loaded] = True', true_target='NEXT', false_target='Orders List Missing')
pg.action('Count Order Rows', BROWSER, 'Count Elements', inputs=[
    ('text', 'XPath Key', lit('portal_order_rows')), ('number', 'Index', '0'), ('flag', 'Wait For One', 'False')],
    outputs=[('number', 'Count', 'Row Count')])
pg.calc('Start At First Row', '1', 'Row Index')
pg.decision('Row In Range?', '[Row Index] <= [Row Count]', true_target='NEXT', false_target='END')
pg.action('Get Order ID', BROWSER, 'Get Text', inputs=[
    ('text', 'XPath Key', lit('portal_order_id')), ('number', 'Index', '[Row Index]'), ('number', 'Timeout', '0')],
    outputs=[('text', 'Text', 'Order ID')])
pg.action('Get Customer ID', BROWSER, 'Get Text', inputs=[
    ('text', 'XPath Key', lit('portal_order_customer')), ('number', 'Index', '[Row Index]'), ('number', 'Timeout', '0')],
    outputs=[('text', 'Text', 'Customer ID')])
pg.code('Add Order Row', r'''
System.Data.DataTable table = Orders_In ?? new System.Data.DataTable();
if (!table.Columns.Contains("Order ID")) table.Columns.Add("Order ID");
if (!table.Columns.Contains("Customer ID")) table.Columns.Add("Customer ID");
bool seen = false;
foreach (System.Data.DataRow row in table.Rows)
{
    if (row["Order ID"].ToString() == Order_ID) { seen = true; break; }
}
if (!seen) table.Rows.Add(Order_ID, Customer_ID);
Orders = table;
''', inputs=[('collection', 'Orders In', '[Orders]'), ('text', 'Order ID', '[Order ID]'),
             ('text', 'Customer ID', '[Customer ID]')],
    outputs=[('collection', 'Orders', 'Orders')], goto='Next Order Row')
pg.calc('Next Order Row', '[Row Index] + 1', 'Row Index', goto='Row In Range?')
pg.exception('Orders List Missing', 'System Exception', lit('Parcel Portal open orders list did not load'))

# -- Save Result ---------------------------------------------------------------
pg = po.page('Save Result', 'Enter the order id and the result text in "Report a result", press Save and return the '
             'message the portal shows for this save. A message left over from the previous save does not count: '
             'the read waits for a message that differs from the one shown before.')
pg.add_input('text', 'Order ID')
pg.add_input('text', 'Result')
pg.add_output('text', 'Message')
pg.data('Prior Shown', 'flag')
pg.data('Prior Message', 'text', initial='')
pg.data('Message Shown', 'flag')
pg.data('Save Poll', 'number', initial='0')
pg.action('Wait For Prior Message', BROWSER, 'Wait For Element', inputs=[
    ('text', 'XPath Key', lit('portal_result_msg')), ('number', 'Index', '0'), ('text', 'Condition', lit('visible')),
    ('number', 'Timeout', '1')], outputs=[('flag', 'Found', 'Prior Shown')])
pg.decision('Prior Message Shown?', '[Prior Shown] = True', true_target='Get Prior Message', false_target='No Prior Message')
pg.action('Get Prior Message', BROWSER, 'Get Text', inputs=[
    ('text', 'XPath Key', lit('portal_result_msg')), ('number', 'Index', '0'), ('number', 'Timeout', '0')],
    outputs=[('text', 'Text', 'Prior Message')], goto='Enter Result Order ID')
pg.calc('No Prior Message', lit(''), 'Prior Message')
pg.action('Enter Result Order ID', BROWSER, 'Send Keys', inputs=[
    ('text', 'XPath Key', lit('portal_result_order')), ('number', 'Index', '0'), ('text', 'Text', '[Order ID]'),
    ('flag', 'Clear First', 'True'), ('flag', 'Press Enter', 'False'), ('number', 'Timeout', '0')])
pg.action('Enter Result Text', BROWSER, 'Send Keys', inputs=[
    ('text', 'XPath Key', lit('portal_result_text')), ('number', 'Index', '0'), ('text', 'Text', '[Result]'),
    ('flag', 'Clear First', 'True'), ('flag', 'Press Enter', 'False'), ('number', 'Timeout', '0')])
pg.action('Press Save Result', BROWSER, 'Click', inputs=[
    ('text', 'XPath Key', lit('portal_result_save')), ('number', 'Index', '0'), ('number', 'Timeout', '0')])
pg.calc('Reset Save Poll', '0', 'Save Poll')
pg.action('Wait For Result Message', BROWSER, 'Wait For Element', inputs=[
    ('text', 'XPath Key', lit('portal_result_msg')), ('number', 'Index', '0'), ('text', 'Condition', lit('visible')),
    ('number', 'Timeout', '2')], outputs=[('flag', 'Found', 'Message Shown')])
pg.decision('Result Message Shown?', '[Message Shown] = True', true_target='Get Result Message', false_target='Count Save Poll')
pg.action('Get Result Message', BROWSER, 'Get Text', inputs=[
    ('text', 'XPath Key', lit('portal_result_msg')), ('number', 'Index', '0'), ('number', 'Timeout', '0')],
    outputs=[('text', 'Text', 'Message')])
pg.decision('Result Message Changed?', '[Message] <> [Prior Message]', true_target='END', false_target='Count Save Poll')
pg.calc('Count Save Poll', '[Save Poll] + 1', 'Save Poll')
pg.decision('Save Poll Exhausted?', '[Save Poll] >= 10', true_target='No Result Message', false_target='Pause Before Save Poll')
pg.wait('Pause Before Save Poll', '1', goto='Wait For Result Message')
pg.exception('No Result Message', 'System Exception', '"Result not saved for " & [Order ID] & ": no new message appeared"')

# -- Close Portal ----------------------------------------------------------------
pg = po.page('Close Portal', 'Close the browser opened by Open Portal Session.')
pg.action('Close Portal Browser', BROWSER, 'Close Browser', inputs=[])

# ============================================================================
# OBJECT: Parcel Depot (desktop, UI Automation)
# ============================================================================
do = Proc(DEPOT, 'object', 'Parcel Depot (desktop, UI Automation): starts and closes the application, signs in, '
          'looks up customers and orders, and approves an order. Each element is matched on its own ticked attributes.')
do.application(DEPOT, 'Win32Launch', {'Path': '', 'CommandLineParams': '', 'WorkingDirectory': '', 'NonInvasive': 'True'})
do.code_options()
# Application Modeller: the windows, then their controls (folders only: each element is matched on its own ticks)
W_SIGN = 'Window - Sign In - UIA'
W_DEPOT = 'Window - Depot - UIA'
W_CONFIRM = 'Window - Confirm Approve - UIA'
do.element(W_SIGN, UIA)
do.element(f'{W_SIGN}/Edit - User Name - UIA', UIA)
do.element(f'{W_SIGN}/Edit - Password - UIA', UIA)
do.element(f'{W_SIGN}/Button - Sign In - UIA', UIA)
do.element(W_DEPOT, UIA)
do.element(f'{W_DEPOT}/Edit - Customer Search - UIA', UIA)
do.element(f'{W_DEPOT}/Button - Customer Find - UIA', UIA)
do.element(f'{W_DEPOT}/Text - Customer Result - UIA', UIA)
do.element(f'{W_DEPOT}/Edit - Order Search - UIA', UIA)
do.element(f'{W_DEPOT}/Button - Order Find - UIA', UIA)
do.element(f'{W_DEPOT}/Text - Order Status - UIA', UIA)
do.element(f'{W_DEPOT}/Text - Order Amount - UIA', UIA)
do.element(f'{W_DEPOT}/Table - Order Lines - UIA', UIA)
do.element(f'{W_DEPOT}/CheckBox - Priority - UIA', UIA)
do.element(f'{W_DEPOT}/RadioButton - Standard - UIA', UIA)
do.element(f'{W_DEPOT}/RadioButton - Manager Override - UIA', UIA)
do.element(f'{W_DEPOT}/Button - Approve - UIA', UIA)
do.element(f'{W_DEPOT}/Text - Order Message - UIA', UIA)
do.element(W_CONFIRM, UIA)
do.element(f'{W_CONFIRM}/Button - Yes - UIA', UIA)

do.page('Clean Up', 'Standard first object page.', page_type='CleanUp')

# -- Start Depot -----------------------------------------------------------------
pg = do.page('Start Depot', 'Launch Parcel Depot and wait for its sign-in window.')
pg.navigate('Launch Depot', [(DEPOT, 'Launch')])
pg.wait_for('Wait For Sign In Window', [(W_SIGN, 'CheckExists', 'END')], '30', 'Sign In Window Missing')
pg.exception('Sign In Window Missing', 'System Exception', lit('Parcel Depot sign-in window did not appear'))

# -- Open Depot Session ----------------------------------------------------------
pg = do.page('Open Depot Session', 'Type the depot bot credentials into the sign-in window and wait for the depot window.')
pg.add_input('text', 'Username')
pg.add_input('password', 'Password')
pg.write('Enter User Name', [('Edit - User Name - UIA', '[Username]')])
pg.write('Enter Password', [('Edit - Password - UIA', '[Password]')])
pg.navigate('Press Sign In', [('Button - Sign In - UIA', 'Press')])
pg.wait_for('Wait For Depot Window', [(W_DEPOT, 'CheckExists', 'END')], '30', 'Depot Window Missing')
pg.exception('Depot Window Missing', 'System Exception', lit('Parcel Depot did not open after sign-in'))

# -- Get Customer ----------------------------------------------------------------
pg = do.page('Get Customer', 'Look the customer id up in the Customers part. Found is False when Parcel Depot says '
             '"No such customer" (a valid answer, not an error).')
pg.add_input('text', 'Customer ID')
pg.add_output('flag', 'Found')
pg.add_output('text', 'Customer Name')
pg.write('Enter Customer ID', [('Edit - Customer Search - UIA', '[Customer ID]')])
pg.navigate('Press Customer Find', [('Button - Customer Find - UIA', 'Press')])
pg.read('Read Customer Result', [('Text - Customer Result - UIA', 'GetWindowText', 'Customer Name', 'text')])
pg.decision('Customer Exists?', '[Customer Name] <> "No such customer"', true_target='Customer Found',
            false_target='Customer Not Found')
pg.calc('Customer Found', 'True', 'Found', goto='END')
pg.calc('Customer Not Found', 'False', 'Found', goto='END')

# -- Get Order -------------------------------------------------------------------
pg = do.page('Get Order', 'Look the order id up in the Orders part, wait while the status shows "...", and read the '
             'status, the amount and the order lines (Fragile = a line item says Fragile).')
pg.add_input('text', 'Order ID')
pg.add_output('text', 'Status')
pg.add_output('text', 'Amount')
pg.add_output('flag', 'Fragile')
pg.data('Poll Count', 'number', initial='0')
pg.data('Lines', 'collection')
pg.write('Enter Order ID', [('Edit - Order Search - UIA', '[Order ID]')])
pg.navigate('Press Order Find', [('Button - Order Find - UIA', 'Press')])
pg.wait('Pause For Order Lookup', '2')     # the status shows the previous order until the lookup starts (measured)
pg.read('Read Order Status', [('Text - Order Status - UIA', 'GetWindowText', 'Status', 'text')])
pg.decision('Still Looking Up?', '[Status] = "..."', true_target='Count Status Poll', false_target='Read Order Amount')
pg.calc('Count Status Poll', '[Poll Count] + 1', 'Poll Count')
pg.decision('Lookup Timed Out?', '[Poll Count] >= 30', true_target='Order Lookup Timeout', false_target='Pause Before Status Check')
pg.wait('Pause Before Status Check', '1', goto='Read Order Status')
pg.read('Read Order Amount', [('Text - Order Amount - UIA', 'GetWindowText', 'Amount', 'text')])
pg.read('Read Order Lines', [('Table - Order Lines - UIA', 'GetTable', 'Lines', 'collection')])
pg.code('Check Fragile Lines', r'''
Fragile = false;
if (Lines != null)
{
    foreach (System.Data.DataRow row in Lines.Rows)
    {
        string item = row["Item"] == null ? "" : row["Item"].ToString();
        if (System.Text.RegularExpressions.Regex.IsMatch(item, @"\bFragile\b", System.Text.RegularExpressions.RegexOptions.IgnoreCase))
        {
            Fragile = true;
            break;
        }
    }
}
''', inputs=[('collection', 'Lines', '[Lines]')], outputs=[('flag', 'Fragile', 'Fragile')], goto='END')
pg.exception('Order Lookup Timeout', 'System Exception', '"Order lookup did not finish for " & [Order ID]')

# -- Approve Order ---------------------------------------------------------------
pg = do.page('Approve Order', 'Set Priority and the reason, press Approve, confirm with Yes, then check the message and '
             'the status. Result is Approved only when both say so; anything else is a System Exception.')
pg.add_input('text', 'Order ID')
pg.add_input('text', 'Reason')
pg.add_input('flag', 'Priority')
pg.add_output('text', 'Result')
pg.write('Set Priority', [('CheckBox - Priority - UIA', '[Priority]')])
pg.decision('Manager Override?', '[Reason] = "Manager override"', true_target='Press Manager Override', false_target='Press Standard')
pg.navigate('Press Manager Override', [('RadioButton - Manager Override - UIA', 'Press')], goto='Press Approve')
pg.navigate('Press Standard', [('RadioButton - Standard - UIA', 'Press')])
pg.navigate('Press Approve', [('Button - Approve - UIA', 'Press')])
pg.wait_for('Wait For Approve Confirmation', [(W_CONFIRM, 'CheckExists', 'NEXT')], '10', 'No Approve Confirmation')
pg.navigate('Press Yes', [('Button - Yes - UIA', 'Press')])
pg.wait_for('Wait For Confirmation Closed', [(W_CONFIRM, 'CheckExists', 'NEXT', 'NotEqual')], '10', 'Read Approve Message')
pg.data('Approve Poll', 'number', initial='0')
pg.read('Read Approve Message', [('Text - Order Message - UIA', 'GetWindowText', 'Message', 'text')])
pg.decision('Approve Message Shown?', '[Message] <> ""', true_target='Read Approved Status', false_target='Count Approve Poll')
pg.calc('Count Approve Poll', '[Approve Poll] + 1', 'Approve Poll')
pg.decision('Approve Poll Timed Out?', '[Approve Poll] >= 20', true_target='No Approve Message', false_target='Pause Before Approve Message')
pg.wait('Pause Before Approve Message', '1', goto='Read Approve Message')
pg.read('Read Approved Status', [('Text - Order Status - UIA', 'GetWindowText', 'Status', 'text')])
pg.decision('Approved?', '([Message] = ("Order " & [Order ID] & " approved")) AND ([Status] = "Approved")',
            true_target='Set Approved Result', false_target='Approve Failed')
pg.calc('Set Approved Result', lit('Approved'), 'Result', goto='END')
pg.exception('Approve Failed', 'System Exception', '"Approve failed for " & [Order ID] & ": " & [Message]')
pg.exception('No Approve Confirmation', 'System Exception', '"Approve failed for " & [Order ID] & ": no confirmation appeared"')
pg.exception('No Approve Message', 'System Exception', '"Approve failed for " & [Order ID] & ": no result message appeared"')

# -- Build Result Row --------------------------------------------------------------
pg = do.page('Build Result Row', 'Make the one-row collection (Order ID, Result) that goes on the results queue.')
pg.add_input('text', 'Order ID')
pg.add_input('text', 'Result')
pg.add_output('collection', 'Result Row')
pg.code('Make Result Row', r'''
Result_Row = new System.Data.DataTable();
Result_Row.Columns.Add("Order ID");
Result_Row.Columns.Add("Result");
Result_Row.Rows.Add(Order_ID ?? "", Result ?? "");
''', inputs=[('text', 'Order ID', '[Order ID]'), ('text', 'Result', '[Result]')],
    outputs=[('collection', 'Result Row', 'Result Row')])

# -- Close Depot -------------------------------------------------------------------
pg = do.page('Close Depot', 'Close Parcel Depot.')
pg.navigate('Terminate Depot', [(DEPOT, 'Terminate')])

# ============================================================================
# PROCESS: Load Orders
# ============================================================================
ENV_PORTAL = ['Parcel Portal Config Path', 'Parcel Portal Driver Path', 'Parcel Portal Browser Kind',
              'Parcel Portal Run Mode', 'Parcel Portal Log Folder']

def portal_open_inputs(prefix=''):
    return [('text', 'Config Path', f'[{ENV_PORTAL[0]}]'), ('text', 'Driver Path', f'[{ENV_PORTAL[1]}]'),
            ('text', 'Browser Kind', f'[{ENV_PORTAL[2]}]'), ('text', 'Run Mode', f'[{ENV_PORTAL[3]}]'),
            ('text', 'Log Folder', f'[{ENV_PORTAL[4]}]'), ('text', 'Username', '[g_txt_Portal User]'),
            ('password', 'Password', '[g_pwd_Portal Password]')]

def portal_env_decls(pg):
    for nm in ENV_PORTAL + ['Parcel Portal Credential Name']:
        pg.data(nm, 'text', exposure='Environment')

def close_if_open_page(proc, name):
    cp = proc.page(name, 'Close the portal browser when it was opened in this run.')
    cp.add_input('flag', 'Portal Opened')
    cp.decision('Portal Is Open?', '[Portal Opened] = True', true_target='Close Portal Browser', false_target='END')
    cp.action('Close Portal Browser', PORTAL, 'Close Portal', goto='END')

lo = Proc('Parcel Depot - Load Orders', 'process',
          'Load Orders: sign in to Parcel Portal, read the open orders, put each order once on the work queue, close the browser.')
m = lo.page('Main', 'Control: credentials, portal sign-in, read the open orders, queue them, close the browser.')
portal_env_decls(m)
m.data('Parcel Depot Queue Name', 'text', exposure='Environment')
m.data('g_txt_Portal User', 'text')
m.data('g_pwd_Portal Password', 'password')
m.data('g_flg_Portal Opened', 'flag', initial='False')
m.data('g_col_Orders', 'collection')
m.action('Get Portal Credentials', CRED, 'Get', inputs=[('text', 'Credentials Name', '[Parcel Portal Credential Name]')],
         outputs=[('text', 'Username', 'g_txt_Portal User'), ('password', 'Password', 'g_pwd_Portal Password')])
m.action('Open Portal Session', PORTAL, 'Open Portal Session', inputs=portal_open_inputs())
m.calc('Mark Portal Opened', 'True', 'g_flg_Portal Opened')
m.action('Get Open Orders', PORTAL, 'Get Open Orders', outputs=[('collection', 'Orders', 'g_col_Orders')])
m.action('Queue Orders', WQ, 'Add To Queue', inputs=[
    ('text', 'Queue Name', '[Parcel Depot Queue Name]'), ('collection', 'Data', '[g_col_Orders]'),
    ('text', 'Tags', lit('Loaded'))])
m.page_ref('Close Portal', 'Close Portal If Open', inputs=[('flag', 'Portal Opened', '[g_flg_Portal Opened]')])
m.work_block('Load Orders Run', 'Get Portal Credentials', 'Close Portal', scope='page', then='RETHROW',
             handler=[('Close Portal After Failure', 'PAGE', 'Close Portal If Open',
                       [('flag', 'Portal Opened', '[g_flg_Portal Opened]')])])
close_if_open_page(lo, 'Close Portal If Open')

# ============================================================================
# PROCESS: Approve Orders
# ============================================================================
ENV_DEPOT_QUEUES = ['Parcel Depot Queue Name', 'Parcel Depot Results Queue Name']
ap = Proc('Parcel Depot - Approve Orders', 'process',
          'Approve Orders: take the environment lock, start Parcel Depot and sign in, then for every work item look the '
          'customer and the order up, approve when allowed, mark the item and put one result row per item.')
m = ap.page('Main', 'Control framework: lock, application, claim loop with stop check, item work block, '
            'consecutive-failure guard, clean-up on every path.')
for nm in ENV_DEPOT_QUEUES:
    m.data(nm, 'text', exposure='Environment')
m.data('Max Consecutive Failures', 'number', initial='5')
m.data('g_txt_Lock Token', 'text')
m.data('g_flg_Depot Started', 'flag', initial='False')
m.data('g_nr_Consecutive Failures', 'number', initial='0')
m.data('g_flg_Continue', 'flag', initial='False')
m.data('g_txt_Item ID', 'text')
m.data('g_col_Item Data', 'collection')
m.data('g_txt_Order ID', 'text')
m.data('g_txt_Customer ID', 'text')
m.data('g_txt_Result', 'text')
m.data('g_txt_Outcome', 'text')
m.data('g_txt_Ex Type', 'text')
m.data('g_txt_Ex Detail', 'text')
m.data('g_txt_Ex Stage', 'text')
m.data('g_col_Result Row', 'collection')
m.page_ref('Take Depot Lock', 'Take Depot Lock', outputs=[('text', 'Lock Token', 'g_txt_Lock Token')])
m.page_ref('Start Depot Application', 'Start Depot Application')
m.calc('Mark Depot Started', 'True', 'g_flg_Depot Started')
m.page_ref('Sign In To Depot', 'Sign In To Depot')
m.page_ref('Reset Global Data', 'Reset Global Data', outputs=[('number', 'Consecutive Failures', 'g_nr_Consecutive Failures')])
m.page_ref('Check Continue To Work', 'Check Continue To Work', outputs=[('flag', 'Continue', 'g_flg_Continue')])
m.decision('Continue Working?', '[g_flg_Continue] = True', true_target='NEXT', false_target='Finish Run')
m.action('Get Next Item', WQ, 'Get Next Item', inputs=[('text', 'Queue Name', '[Parcel Depot Queue Name]')],
         outputs=[('text', 'Item ID', 'g_txt_Item ID'), ('collection', 'Data', 'g_col_Item Data')])
m.decision('Item Available?', '[g_txt_Item ID] <> ""', true_target='NEXT', false_target='Finish Run')
m.calc('Read Order ID', '[g_col_Item Data.Order ID]', 'g_txt_Order ID')
m.calc('Read Customer ID', '[g_col_Item Data.Customer ID]', 'g_txt_Customer ID')
m.page_ref('Work Item', 'Work Item', inputs=[('text', 'Order ID', '[g_txt_Order ID]'),
                                             ('text', 'Customer ID', '[g_txt_Customer ID]')],
           outputs=[('text', 'Result', 'g_txt_Result')])
m.calc('Set Success Outcome', '[g_txt_Result]', 'g_txt_Outcome')
m.calc('Reset Consecutive Failures', '0', 'g_nr_Consecutive Failures')
m.action('Tag Item', WQ, 'Tag Item', inputs=[('text', 'Item ID', '[g_txt_Item ID]'), ('text', 'Tag', '[g_txt_Outcome]')])
m.action('Mark Item Completed', WQ, 'Mark Completed', inputs=[('text', 'Item ID', '[g_txt_Item ID]')],
         goto='Build Result Row')
m.calc('Set Failure Outcome', '[g_txt_Ex Type] & ": " & [g_txt_Ex Detail]', 'g_txt_Outcome')
m.decision('Business Exception?', '[g_txt_Ex Type] = "Business Exception"',
           true_target='Mark Business Exception', false_target='Mark System Exception')
m.action('Mark Business Exception', WQ, 'Mark Exception', inputs=[
    ('text', 'Item ID', '[g_txt_Item ID]'), ('text', 'Exception Reason', '[g_txt_Outcome]'), ('flag', 'Retry', 'False')],
    goto='Build Result Row')
m.action('Mark System Exception', WQ, 'Mark Exception', inputs=[
    ('text', 'Item ID', '[g_txt_Item ID]'), ('text', 'Exception Reason', '[g_txt_Outcome]'), ('flag', 'Retry', 'False')])
m.calc('Count Consecutive Failure', '[g_nr_Consecutive Failures] + 1', 'g_nr_Consecutive Failures')
m.decision('Too Many Consecutive Failures?', '[g_nr_Consecutive Failures] >= [Max Consecutive Failures]',
           true_target='Stop On Consecutive Failures', false_target='Build Result Row')
m.exception('Stop On Consecutive Failures', 'System Exception',
            lit('Stopped: too many consecutive system exceptions'))
m.action('Build Result Row', DEPOT, 'Build Result Row', inputs=[
    ('text', 'Order ID', '[g_txt_Order ID]'), ('text', 'Result', '[g_txt_Outcome]')],
    outputs=[('collection', 'Result Row', 'g_col_Result Row')])
m.action('Add To Results Queue', WQ, 'Add To Queue', inputs=[
    ('text', 'Queue Name', '[Parcel Depot Results Queue Name]'), ('collection', 'Data', '[g_col_Result Row]')],
    goto='Check Continue To Work')
m.page_ref('Finish Run', 'Clean Up Run', inputs=[('text', 'Lock Token', '[g_txt_Lock Token]'),
                                                  ('flag', 'Depot Started', '[g_flg_Depot Started]')])
m.work_block('Approve Run', 'Take Depot Lock', 'Finish Run', scope='page', then='RETHROW',
             handler=[('Clean Up After Failure', 'PAGE', 'Clean Up Run', [
                 ('text', 'Lock Token', '[g_txt_Lock Token]'), ('flag', 'Depot Started', '[g_flg_Depot Started]')])])
m.work_block('Work The Item', 'Work Item', 'Work Item', capture=('g_txt_Ex Type', 'g_txt_Ex Detail', 'g_txt_Ex Stage'),
             then='Set Failure Outcome')
# NOTE: the Block above must not overlap the page-level Recover; it wraps only the Work Item call.

# -- Take Depot Lock -------------------------------------------------------------
pg = ap.page('Take Depot Lock', 'Take the environment lock for Parcel Depot. Not taken: System Exception.')
pg.add_output('text', 'Lock Token')
pg.data('Parcel Depot Lock Name', 'text', exposure='Environment')
pg.action('Acquire Depot Lock', ENVLOCK, 'Acquire Lock', inputs=[
    ('text', 'Name', '[Parcel Depot Lock Name]'), ('text', 'Preferred Token', lit('')),
    ('text', 'Comment', lit('Parcel Depot approval run'))], outputs=[('text', 'Token', 'Lock Token')])
pg.decision('Lock Acquired?', '[Lock Token] <> ""', true_target='END', false_target='Depot Locked')
pg.exception('Depot Locked', 'System Exception', lit('Parcel Depot is locked by another session'))

# -- Start Depot Application -----------------------------------------------------
pg = ap.page('Start Depot Application', 'Start Parcel Depot (the object waits for its sign-in window).')
pg.action('Start Depot', DEPOT, 'Start Depot')

# -- Sign In To Depot ------------------------------------------------------------
pg = ap.page('Sign In To Depot', 'Read the depot credential and sign in.')
pg.data('Parcel Depot Credential Name', 'text', exposure='Environment')
pg.action('Get Depot Credentials', CRED, 'Get', inputs=[('text', 'Credentials Name', '[Parcel Depot Credential Name]')],
          outputs=[('text', 'Username', 'Depot User'), ('password', 'Password', 'Depot Password')])
pg.action('Open Depot Session', DEPOT, 'Open Depot Session', inputs=[
    ('text', 'Username', '[Depot User]'), ('password', 'Password', '[Depot Password]')])

# -- Reset Global Data -----------------------------------------------------------
pg = ap.page('Reset Global Data', 'Reset the run-level state before the first item.')
pg.add_output('number', 'Consecutive Failures')
pg.calc('Reset Failure Counter', '0', 'Consecutive Failures')

# -- Check Continue To Work ------------------------------------------------------
pg = ap.page('Check Continue To Work', 'Stop request from Control Room: stop when IsStopRequested().')
pg.add_output('flag', 'Continue')
pg.decision('Stop Requested?', 'IsStopRequested()', true_target='Stop Working', false_target='Keep Working')
pg.calc('Keep Working', 'True', 'Continue', goto='END')
pg.calc('Stop Working', 'False', 'Continue')

# -- Work Item -------------------------------------------------------------------
pg = ap.page('Work Item', 'Look the customer up, look the order up, apply the limit and reason rules, approve. '
             'Business rules that stop an item are Business Exceptions.')
pg.add_input('text', 'Order ID')
pg.add_input('text', 'Customer ID')
pg.add_output('text', 'Result')
pg.data('Reason', 'text')
pg.action('Get Customer', DEPOT, 'Get Customer', inputs=[('text', 'Customer ID', '[Customer ID]')],
          outputs=[('flag', 'Found', 'Customer Found')])
pg.decision('Customer Exists?', '[Customer Found] = True', true_target='NEXT', false_target='Customer Missing')
pg.action('Get Order Details', DEPOT, 'Get Order', inputs=[('text', 'Order ID', '[Order ID]')],
          outputs=[('text', 'Status', 'Order Status'), ('text', 'Amount', 'Order Amount'), ('flag', 'Fragile', 'Order Fragile')])
pg.choice('Order Status?', [
    ('Pending', '[Order Status] = "Pending"', 'Above Limit?'),
    ('Approved', '[Order Status] = "Approved"', 'Already Approved'),
    ('Not found', '[Order Status] = "Not found"', 'Order Not Found')],
    otherwise='Unexpected Status', otherwise_name='Order Status Otherwise')
pg.calc('Already Approved', lit('Already approved'), 'Result', goto='END')
pg.decision('Above Limit?', 'ToNumber([Order Amount]) > 2000', true_target='Order Above Limit', false_target='Above Manager Limit?')
pg.decision('Above Manager Limit?', 'ToNumber([Order Amount]) > 500', true_target='Set Manager Reason', false_target='Set Standard Reason')
pg.calc('Set Manager Reason', lit('Manager override'), 'Reason', goto='Approve The Order')
pg.calc('Set Standard Reason', lit('Standard'), 'Reason')
pg.action('Approve The Order', DEPOT, 'Approve Order', inputs=[
    ('text', 'Order ID', '[Order ID]'), ('text', 'Reason', '[Reason]'), ('flag', 'Priority', '[Order Fragile]')],
    outputs=[('text', 'Result', 'Result')], goto='END')
pg.exception('Customer Missing', 'Business Exception', '"Customer " & [Customer ID] & " not found in Parcel Depot"')
pg.exception('Order Not Found', 'Business Exception', '"Order " & [Order ID] & " not found in Parcel Depot"')
pg.exception('Unexpected Status', 'Business Exception', '"Order " & [Order ID] & " has unexpected status: " & [Order Status]')
pg.exception('Order Above Limit', 'Business Exception', '"Order " & [Order ID] & " is above the approval limit: " & [Order Amount]')

# -- Clean Up Run ----------------------------------------------------------------
pg = ap.page('Clean Up Run', 'Close Parcel Depot when it was started, release the lock when it was taken. Runs on every path.')
pg.add_input('text', 'Lock Token')
pg.add_input('flag', 'Depot Started')
pg.data('Parcel Depot Lock Name', 'text', exposure='Environment')
pg.decision('Depot Started?', '[Depot Started] = True', true_target='Close Depot', false_target='Lock Held?')
pg.action('Close Depot', DEPOT, 'Close Depot')
pg.decision('Lock Held?', '[Lock Token] <> ""', true_target='Release Depot Lock', false_target='END')
pg.action('Release Depot Lock', ENVLOCK, 'Release Lock', inputs=[
    ('text', 'Name', '[Parcel Depot Lock Name]'), ('text', 'Token', '[Lock Token]'),
    ('text', 'Comment', lit('Parcel Depot approval run finished'))], goto='END')

# ============================================================================
# PROCESS: Post Results
# ============================================================================
pr = Proc('Parcel Depot - Post Results', 'process',
          'Post Results: sign in to Parcel Portal, then for every results item enter the order id and the result in '
          '"Report a result", press Save, and mark the item from the message the portal shows.')
m = pr.page('Main', 'Control: portal sign-in, results claim loop, mark each item, close the browser.')
portal_env_decls(m)
m.data('Parcel Depot Results Queue Name', 'text', exposure='Environment')
m.data('g_txt_Portal User', 'text')
m.data('g_pwd_Portal Password', 'password')
m.data('g_flg_Portal Opened', 'flag', initial='False')
m.data('g_txt_Item ID', 'text')
m.data('g_col_Result Data', 'collection')
m.data('g_txt_Order ID', 'text')
m.data('g_txt_Result', 'text')
m.data('g_txt_Outcome', 'text')
m.data('g_txt_Ex Type', 'text')
m.data('g_txt_Ex Detail', 'text')
m.data('g_txt_Ex Stage', 'text')
m.action('Get Portal Credentials', CRED, 'Get', inputs=[('text', 'Credentials Name', '[Parcel Portal Credential Name]')],
         outputs=[('text', 'Username', 'g_txt_Portal User'), ('password', 'Password', 'g_pwd_Portal Password')])
m.action('Open Portal Session', PORTAL, 'Open Portal Session', inputs=portal_open_inputs())
m.calc('Mark Portal Opened', 'True', 'g_flg_Portal Opened')
m.action('Get Next Result', WQ, 'Get Next Item', inputs=[('text', 'Queue Name', '[Parcel Depot Results Queue Name]')],
         outputs=[('text', 'Item ID', 'g_txt_Item ID'), ('collection', 'Data', 'g_col_Result Data')])
m.decision('Result Item Available?', '[g_txt_Item ID] <> ""', true_target='NEXT', false_target='Finish Run')
m.calc('Read Result Order ID', '[g_col_Result Data.Order ID]', 'g_txt_Order ID')
m.calc('Read Result Text', '[g_col_Result Data.Result]', 'g_txt_Result')
m.page_ref('Save Result', 'Check Saved Result', inputs=[('text', 'Order ID', '[g_txt_Order ID]'),
                                                       ('text', 'Result', '[g_txt_Result]')])
m.action('Mark Item Completed', WQ, 'Mark Completed', inputs=[('text', 'Item ID', '[g_txt_Item ID]')],
         goto='Get Next Result')
m.calc('Set Failure Outcome', '[g_txt_Ex Type] & ": " & [g_txt_Ex Detail]', 'g_txt_Outcome')
m.action('Mark Item Exception', WQ, 'Mark Exception', inputs=[
    ('text', 'Item ID', '[g_txt_Item ID]'), ('text', 'Exception Reason', '[g_txt_Outcome]'), ('flag', 'Retry', 'False')],
    goto='Get Next Result')
m.page_ref('Finish Run', 'Close Portal If Open', inputs=[('flag', 'Portal Opened', '[g_flg_Portal Opened]')])
m.work_block('Post Result', 'Save Result', 'Save Result', scope='block',
             capture=('g_txt_Ex Type', 'g_txt_Ex Detail', 'g_txt_Ex Stage'), then='Set Failure Outcome')
m.work_block('Post Run', 'Get Portal Credentials', 'Finish Run', scope='page', then='RETHROW',
             handler=[('Close Portal After Failure', 'PAGE', 'Close Portal If Open',
                       [('flag', 'Portal Opened', '[g_flg_Portal Opened]')])])
close_if_open_page(pr, 'Close Portal If Open')

pg = pr.page('Check Saved Result', 'Save one result in the portal and read what it says: Saved is done, Unknown order '
             'and anything else are exceptions for the item.')
pg.add_input('text', 'Order ID')
pg.add_input('text', 'Result')
pg.action('Save Result In Portal', PORTAL, 'Save Result', inputs=[
    ('text', 'Order ID', '[Order ID]'), ('text', 'Result', '[Result]')], outputs=[('text', 'Message', 'Message')])
pg.decision('Result Saved?', '[Message] = ("Saved " & [Order ID])', true_target='END', false_target='Unknown Order?')
pg.decision('Unknown Order?', '[Message] = ("Unknown order " & [Order ID])', true_target='Unknown Order Exception',
            false_target='Result Not Saved')
pg.exception('Unknown Order Exception', 'Business Exception', '"Parcel Portal does not know order " & [Order ID]')
pg.exception('Result Not Saved', 'System Exception', '"Result not saved for " & [Order ID] & ": " & [Message]')

# ============================================================================
po.write('BPA Object - Parcel Portal.xml', outdir=OUT)
do.write('BPA Object - Parcel Depot.xml', outdir=OUT)
lo.write('BPA Process - Parcel Depot - Load Orders.xml', outdir=OUT)
ap.write('BPA Process - Parcel Depot - Approve Orders.xml', outdir=OUT)
pr.write('BPA Process - Parcel Depot - Post Results.xml', outdir=OUT)
print('written:', sorted(f for f in os.listdir(OUT) if f.endswith('.xml')))
print('spy checklist (Parcel Depot):', do.spy_checklist())
