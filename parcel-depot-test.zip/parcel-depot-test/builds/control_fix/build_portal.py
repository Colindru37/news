"""Builds BPA Object - Parcel Portal.xml: the portal work, on top of the existing GK Revoke Browser object
(every browser call goes through it; locators and the URL are keys of config/portal.ini)."""
import sys, os
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'skill', 'lib'))
from bp_gen import Proc, lit

B = 'GK Revoke Browser'
o = Proc('Parcel Portal', 'object',
         'Parcel Portal work (sign in, read the open orders, report a result) on top of the GK Revoke Browser object.')
o.code_options()
o.object_data('Portal Wait Seconds', 'number', initial='15')
o.object_data('Portal List Wait Seconds', 'number', initial='30')

def key(k): return ('text', 'XPath Key', lit(k))
IDX0 = ('number', 'Index', '0')

o.page('Clean Up', 'Standard first object page.', page_type='CleanUp')

# ---------------- Launch Portal ----------------
p = o.page('Launch Portal', 'Read the portal config, start the browser and open the portal page.')
for n in ('Config Path', 'Driver Path', 'Browser Kind', 'Run Mode', 'Log Folder'):
    p.add_input('text', n)
p.action('Load Portal Config', B, 'Load Config', inputs=[('text', 'Config Path', '[Config Path]')])
p.action('Start Browser', B, 'Launch Browser',
         inputs=[('text', 'Run Mode', '[Run Mode]'), ('text', 'Driver Path', '[Driver Path]'),
                 ('text', 'Browser', '[Browser Kind]'), ('flag', 'Headless', 'False'),
                 ('text', 'Profile Root', '""'), ('text', 'Profile Name', '""'), ('text', 'Clone Name', '""'),
                 ('text', 'Download Folder', '""'), ('text', 'Log Folder', '[Log Folder]'),
                 ('number', 'Implicit Wait', '0'), ('number', 'Explicit Wait', '0')])
p.action('Open Portal Page', B, 'Navigate', inputs=[('text', 'URL Key', lit('portal_url'))])

# ---------------- Sign In ----------------
p = o.page('Sign In', 'Sign in to the portal; a refused sign-in raises the reason the portal shows.')
p.add_input('text', 'User Name')
p.add_input('password', 'Password')
p.data('flg_Form Shown', 'flag'); p.data('flg_Desk Shown', 'flag'); p.data('txt_Reason', 'text')
p.data('nr_Attempt', 'number'); p.data('nr_Max Attempts', 'number', initial='30')
p.action('Wait For Login Form', B, 'Wait For Element',
         inputs=[key('portal_user'), IDX0, ('text', 'Condition', lit('visible')), ('number', 'Timeout', '[Portal Wait Seconds]')],
         outputs=[('flag', 'Found', 'flg_Form Shown')])
p.decision('Login Form Shown?', '[flg_Form Shown]', true_target='NEXT', false_target='Raise Login Form Missing')
p.action('Type User Name', B, 'Send Keys',
         inputs=[key('portal_user'), IDX0, ('text', 'Text', '[User Name]'), ('flag', 'Clear First', 'True'),
                 ('flag', 'Press Enter', 'False'), ('number', 'Timeout', '0')])
p.code('Unwrap Password', 'Password_Text = new System.Net.NetworkCredential("", Password).Password;',
       inputs=[('password', 'Password', '[Password]')], outputs=[('text', 'Password_Text', 'Password Text')])
p.action('Type Password', B, 'Send Keys',
         inputs=[key('portal_pass'), IDX0, ('text', 'Text', '[Password Text]'), ('flag', 'Clear First', 'True'),
                 ('flag', 'Press Enter', 'False'), ('number', 'Timeout', '0')])
p.calc('Forget Password Text', '""', 'Password Text')
p.action('Click Login', B, 'Click', inputs=[key('portal_login'), IDX0, ('number', 'Timeout', '0')])
p.calc('Reset Attempts', '0', 'nr_Attempt')
p.action('Check Desk Shown', B, 'Is Displayed', inputs=[key('portal_desk'), IDX0],
         outputs=[('flag', 'Displayed', 'flg_Desk Shown')])
p.decision('Desk Shown?', '[flg_Desk Shown]', true_target='END', false_target='NEXT')
p.action('Read Login Message', B, 'Execute Script',
         inputs=[('text', 'Script', lit("return arguments[0].textContent;")), key('portal_login_msg'), IDX0],
         outputs=[('text', 'Result', 'txt_Reason')])
p.calc('Trim Reason', 'Trim([txt_Reason])', 'txt_Reason')
p.decision('Login Refused?', '[txt_Reason] <> ""', true_target='Raise Sign In Refused', false_target='NEXT')
p.calc('Count Attempt', '[nr_Attempt] + 1', 'nr_Attempt')
p.decision('Waited Too Long?', '[nr_Attempt] >= [nr_Max Attempts]', true_target='Raise No Answer', false_target='NEXT')
p.wait('Pause Before Checking Again', '1', goto='Check Desk Shown')
p.exception('Raise Login Form Missing', 'System Exception', lit('Parcel Portal sign-in failed: the login form did not appear'))
p.exception('Raise Sign In Refused', 'System Exception', lit('Parcel Portal sign-in failed: ') + ' & [txt_Reason]')
p.exception('Raise No Answer', 'System Exception', lit('Parcel Portal sign-in failed: the portal gave no answer'))

# ---------------- Get Open Orders ----------------
p = o.page('Get Open Orders', 'Wait for the Open orders list, read every row (order id, customer id), each order once.')
p.add_output('collection', 'Orders')
p.add_output('number', 'Order Count')
p.data('flg_List Loaded', 'flag'); p.data('nr_Row Count', 'number'); p.data('nr_Row', 'number')
p.data('txt_Order ID', 'text'); p.data('txt_Customer ID', 'text')
p.action('Wait For Orders List', B, 'Wait For Element',
         inputs=[key('portal_orders_loaded'), IDX0, ('text', 'Condition', lit('present')),
                 ('number', 'Timeout', '[Portal List Wait Seconds]')],
         outputs=[('flag', 'Found', 'flg_List Loaded')])
p.decision('List Loaded?', '[flg_List Loaded]', true_target='NEXT', false_target='Raise List Missing')
p.action('Count Order Rows', B, 'Count Elements',
         inputs=[key('portal_order_rows'), IDX0, ('flag', 'Wait For One', 'False')],
         outputs=[('number', 'Count', 'nr_Row Count')])
p.code('Create Orders Table',
       'Orders = new DataTable();\nOrders.Columns.Add("Order ID", typeof(string));\nOrders.Columns.Add("Customer ID", typeof(string));\nOrder_Count = 0;',
       outputs=[('collection', 'Orders', 'Orders'), ('number', 'Order_Count', 'Order Count')])
p.calc('Start At First Row', '1', 'nr_Row')
p.decision('More Rows?', '[nr_Row] <= [nr_Row Count]', true_target='NEXT', false_target='END')
p.action('Read Order ID', B, 'Get Text',
         inputs=[key('portal_order_id'), ('number', 'Index', '[nr_Row]'), ('number', 'Timeout', '0')],
         outputs=[('text', 'Text', 'txt_Order ID')])
p.action('Read Customer ID', B, 'Get Text',
         inputs=[key('portal_order_customer'), ('number', 'Index', '[nr_Row]'), ('number', 'Timeout', '0')],
         outputs=[('text', 'Text', 'txt_Customer ID')])
p.code('Add Order Row Once',
       'string id = (Order_ID_In ?? "").Trim();\nstring cust = (Customer_ID_In ?? "").Trim();\n'
       'if (id.Length > 0)\n{\n    bool seen = false;\n'
       '    foreach (DataRow r in Orders.Rows)\n    {\n'
       '        if (string.Equals(Convert.ToString(r["Order ID"]), id, StringComparison.OrdinalIgnoreCase)) { seen = true; break; }\n    }\n'
       '    if (!seen)\n    {\n        DataRow nr = Orders.NewRow();\n        nr["Order ID"] = id;\n        nr["Customer ID"] = cust;\n        Orders.Rows.Add(nr);\n    }\n}\n'
       'Order_Count = Orders.Rows.Count;',
       inputs=[('collection', 'Orders', '[Orders]'), ('text', 'Order_ID_In', '[txt_Order ID]'),
               ('text', 'Customer_ID_In', '[txt_Customer ID]')],
       outputs=[('collection', 'Orders', 'Orders'), ('number', 'Order_Count', 'Order Count')])
p.calc('Go To Next Row', '[nr_Row] + 1', 'nr_Row', goto='More Rows?')
p.exception('Raise List Missing', 'System Exception', lit('Parcel Portal: the Open orders list did not load'))

# ---------------- Post Result ----------------
p = o.page('Post Result', 'Report one result: order id and result text, Save, then return the message the portal shows.')
p.add_input('text', 'Order ID')
p.add_input('text', 'Result')
p.add_output('text', 'Message')
p.data('txt_Script Result', 'text'); p.data('nr_Attempt', 'number'); p.data('nr_Max Attempts', 'number', initial='20')
p.action('Type Order ID', B, 'Send Keys',
         inputs=[key('portal_result_order'), IDX0, ('text', 'Text', '[Order ID]'), ('flag', 'Clear First', 'True'),
                 ('flag', 'Press Enter', 'False'), ('number', 'Timeout', '0')])
p.action('Type Result Text', B, 'Send Keys',
         inputs=[key('portal_result_text'), IDX0, ('text', 'Text', '[Result]'), ('flag', 'Clear First', 'True'),
                 ('flag', 'Press Enter', 'False'), ('number', 'Timeout', '0')])
p.action('Clear Old Message', B, 'Execute Script',
         inputs=[('text', 'Script', lit("arguments[0].textContent = ''; return '';")), key('portal_result_msg'), IDX0],
         outputs=[('text', 'Result', 'txt_Script Result')])
p.action('Click Save', B, 'Click', inputs=[key('portal_result_save'), IDX0, ('number', 'Timeout', '0')])
p.calc('Reset Attempts', '0', 'nr_Attempt')
p.action('Read Result Message', B, 'Execute Script',
         inputs=[('text', 'Script', lit("return arguments[0].textContent;")), key('portal_result_msg'), IDX0],
         outputs=[('text', 'Result', 'Message')])
p.calc('Trim Message', 'Trim([Message])', 'Message')
p.decision('Message Shown?', '[Message] <> ""', true_target='END', false_target='NEXT')
p.calc('Count Attempt', '[nr_Attempt] + 1', 'nr_Attempt')
p.decision('Waited Too Long?', '[nr_Attempt] >= [nr_Max Attempts]', true_target='END', false_target='NEXT')
p.wait('Pause Before Reading Again', '1', goto='Read Result Message')

# ---------------- Close Portal ----------------
p = o.page('Close Portal', 'Close the browser. Safe to call twice.')
p.action('Close Browser Window', B, 'Close Browser')

print(o.write('BPA Object - Parcel Portal.xml', outdir=HERE))
