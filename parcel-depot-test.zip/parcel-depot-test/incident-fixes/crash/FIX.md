# FIX INC-7760: Parcel Depot closes by itself

## Cause

When Parcel Depot closes in the middle of a run, the next UI call in the Parcel Depot object (here
`Get Order`, at `Read Order Status`) fails with "Element not found". The Work Item page of
`Parcel Depot - Approve Orders` catches that as a System Exception and nothing starts the application
again. Every later item then fails at its first UI step ("Enter Customer ID", element not found), until
the consecutive-failure guard stops the run after 5 items (P-2003 to P-2007 in the log).

## What was changed (out/ holds all five XML files, same names as in existing/)

1. `BPA Object - Parcel Depot.xml`: one new published action page, **Is Depot Open**. It waits up to 5 s
   for the existing element `Window - Depot - UIA` (CheckExists, Equal) and outputs `Depot Open`
   (True when the window is on screen, False when not). No element, page or stage was changed.

2. `BPA Process - Parcel Depot - Approve Orders.xml`: the page **Work Item** was regenerated with
   `bp_merge.py --replace-page "Work Item"`. Main, the other pages and the other processes are unchanged.
   - Block **Look Up And Approve** (Get Customer .. Order Above Limit, with its own Recover) captures the
     exception type and detail and resumes at **Check Depot Open**.
   - **Check Depot Open** (object action Is Depot Open) -> **Restart Allowed?**: restart only when the
     depot is gone AND the exception is a System Exception AND no restart was used for this item.
   - Restart: page calls **Start Depot Application** and **Sign In To Depot** (existing pages), in block
     **Restart Depot**; then **Mark Restart Used** and back to **Get Customer**, so the same order is
     worked once more. If the restart fails, the block resumes at **Business Exception?** and the original
     exception is raised.
   - Otherwise: **Rethrow Business Exception** / **Rethrow System Exception** with the captured detail, so
     Main reports exactly the same type and text as before.
   - Approve bookkeeping: **Mark Approve Sent** runs just before the Approve click. The existing
     **Already Approved** calculation is now reached through **Approved In This Run?**: an order that this
     item approved itself (before a crash) reports "Approved", not "Already approved".
   - Existing stages changed in content: **Order Status?** (the Approved choice now targets
     Approved In This Run?), **Set Manager Reason** and **Set Standard Reason** (now go to Mark Approve
     Sent). The two old anchors "Set Manager Reason next to Approve The Order" were removed. All other
     existing stages keep their name, type, expression and id; their display coordinates moved with the
     regenerated layout.

Never approved twice: Approve runs only when the order status is Pending, and the status is read again
before every retry.

## Gates

- `validate.py out --flow --strict --with estate`: ALL CLEAN.
- `compile_check.py out`: ALL COMPILED (development mcs/vbc, indicative only; Blue Prism's own compiler not available here).
- `twins.js` for the Parcel Depot object on three screens (sign-in, depot, confirm approve): TWINS CLEAN.

## Checked on the test application

- After the third lookup the application closes: no window is left, so the premise of "Is Depot Open" holds.
- `desk.py app` starts it again at the sign-in window; signing in opens a new session title
  ("Parcel Depot - session NNNN"), which matches the element's ticked name pattern `Parcel Depot - session*`.
- The off-screen desktop was stopped and the data reset.

## Not verified

- Not run in Blue Prism (no Blue Prism here): the Recover/Resume behaviour of the new blocks and the
  page calls inside them follow the verified patterns of the skill but were not executed.
- The complete run (crash at P-2003, restart, P-2003 worked again, run carries on) was not executed end to end.
- Test data: P-2003 is "Approved" in the test state, so the retry reports "Already approved" for it. That is the data, not a fault.

## Unsure

- The 5 s window check: a slow start or a window missing for a moment would be read as "gone", and Start Depot
  would then open a second instance. Watch the first live run.
- If the depot stays closed, each following item gets one restart attempt (bounded per item, not per run).
- Business exceptions now also pass through the Is Depot Open check (one object call; it returns at once while the window is open).
- A crash during the Approve click: if the approve went through, the retry reports "Approved" (via Approve Sent); if it did not, the order is still Pending and is approved once.
