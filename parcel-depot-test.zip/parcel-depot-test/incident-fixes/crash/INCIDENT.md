# Incident INC-7760: Parcel Depot closes by itself

Known vendor defect, no fix date: now and then Parcel Depot simply closes while it is being used. When that happens
`Parcel Depot - Approve Orders` marks the order it was on, and every order after it, as a System Exception and stops
itself. All of those orders are then worked again by hand.

- `incident/run.log` : the log of such a run (stage by stage; `>` a call, `<` its outputs, `?` a decision).
- The test application in this folder closes by itself once per reset, at the third order lookup of a session.
  `python3 tools/reset_app.py` resets its data so that it does it again.

Wanted: when Parcel Depot is gone, the automation starts it again, signs in again and works the SAME order once
more. If that second try fails as well, the order gets its System Exception as today and the run carries on with
the next order. An order must never be approved twice and never be reported as something it is not.
Everything else stays as it is.
