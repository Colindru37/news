# Task: fix an incident in an automation that is in production

Read `INCIDENT.md`. The automation was built by a colleague; everything they delivered is in `existing/` (the Blue
Prism XML, their build scripts, their HANDOVER.md, their spy files). `PDD.md` is what it is supposed to do.

You are on a machine WITHOUT Blue Prism: you cannot run objects or processes. You CAN start the desktop application
on an off-screen desktop and spy it. Work only inside this folder.

## Rules for a fix in production

- Find the cause first, from the log and from the application. Say what it is in one or two sentences.
- Change as little as possible. A stage, page or element the incident does not touch stays byte for byte as it is.
  Use `skill/lib/bp_merge.py` to put new or changed pages / elements into the existing files; do not regenerate a
  whole object or process when a part of it is enough. (If you rebuild from the colleague's scripts instead, say why.)
- Names of processes, objects, actions, their inputs and outputs, queue fields, tags and exception texts stay as they
  are: other things depend on them.

## What is here

- `skill/` : the rpa-bp skill. Read `skill/SKILL.md` first; `skill/reference/gotchas.md` has the rules for choosing
  what an element matches on.
- `estate/` : objects that exist and are called, never changed (the browser object).
- `tools/` : run from THIS folder.
  - `python3 tools/desk.py start | app | stop` : the off-screen desktop with Parcel Depot. Always `stop` at the end.
  - `python3 tools/spy.py ...` : `windows`, `tree`, `element <ref> -o f.json`, `press`, `type`, `text`, `checked <ref>`,
    `table <ref>`, `dump <f.json>`. Run it without arguments for the help.
  - `node tools/identify.js <object.xml> "<element>" <spy.json> --use <attrs> [--set a=v] [--cmp a=Wildcard|RegEx]`
  - `node tools/twins.js <object.xml> <dump.json> ...` : is every element unique on the screens you dumped?
  - `python3 tools/reset_app.py` : put the application's data back to the start.
- Desktop test sign-in: user `depotbot`, password `depot!42`. Test data: orders P-2001 .. P-2005, customers C-77, C-78.

## What the desktop application's elements can do (use exactly these action ids)

- Write stage: text into an edit box; `True` / `False` into a tick box.
- Navigate stage: `Press` (buttons, radio buttons, tick boxes); on the application root `Launch` and `Terminate`.
- Read stage: `GetWindowText` (the text of a label or edit box), `GetChecked`, `GetTable`.
- Wait stage: `CheckExists` (with Equal, or NotEqual to wait until it is gone).

## What to deliver, in `out/`

- The complete set of XML files (changed and unchanged ones), same file names as in `existing/`.
- `FIX.md` : the cause, what you changed (file, page, stage or element), what you did not verify.

## Done means

`python3 skill/lib/validate.py out --flow --strict --with estate` prints ALL CLEAN, `python3 skill/lib/compile_check.py out`
prints ALL COMPILED, and `node tools/twins.js` is clean for the desktop object on dumps of every screen it uses,
including any new one. Then stop the desktop and stop. Final message: the cause, the changes, the gate lines, and
what you are unsure about.
