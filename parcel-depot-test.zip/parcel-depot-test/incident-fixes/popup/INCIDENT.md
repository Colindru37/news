# Incident INC-7745: Approve Orders stops in the middle of a run

Twice this week `Parcel Depot - Approve Orders` worked the first orders, then marked the rest as System Exceptions
and stopped itself. When operations looked at the robot's screen there was a small window titled "Notice" in front of
Parcel Depot, with a text about maintenance and an OK button. The vendor says such notices are sent by their
administrators "when needed": any text, at any moment, always one OK button; Parcel Depot does not react until OK
is pressed.

- `incident/run.log` : the log of the last such run (stage by stage; `>` a call, `<` its outputs, `?` a decision).
- The test application in this folder shows a notice once per reset, after the second order lookup of a session.
  `python3 tools/reset_app.py` resets its data so that it shows the notice again.

Wanted: a notice no longer costs any order: wherever it appears, it is closed and the work carries on as if it had
not been there. Everything else stays as it is.
