# INC-7745: Approve Orders stops in the middle of a run

## Cause

A "Notice" window is a separate top-level window that comes to the front of Parcel Depot. While it is open, every element
of the Parcel Depot window is disabled (spied on the test application: the Customers and Orders panes, Approve, Priority
and the order table all read "disabled" with the notice up). The Approve Orders process has no step for it. The next
Parcel Depot action (Set Priority, Customer search, ...) raises "element is disabled" as a System Exception, the item is
marked as a System Exception, and the next item fails the same way until the consecutive-failure limit stops the run.

## Changes

1. `BPA Object - Parcel Depot.xml` (2 changes, all else byte-identical)
   - Application Modeller: `Window - Notice - UIA` (uControlType=Window, uName=Notice) and, under it,
     `Button - OK - UIA` (uControlType=Button, uName=OK). Spied on the test application, see the gates below.
   - New published action page `Close Notice`, output `Closed` (flag). Waits up to 3 s for the Notice window; if it is
     there, presses OK and waits up to 5 s for it to go. `Closed` = True only when the window was there and has gone.
     If no Notice is shown, `Closed` = False. It does not raise an exception.
2. `BPA Process - Parcel Depot - Approve Orders.xml` (1 change: page `Work Item` replaced, all else byte-identical)
   - The item's work (Get Customer ... Approve The Order) is now inside a Block `Look Up And Approve` with its own
     Recover. On a system exception: the exception detail is captured, then `Close Notice` runs.
     If a Notice was closed and this item has had fewer than 3 notice closes (`Notice Closes`, a page local that starts at 0
     for every item), the steps run again from Get Customer. Otherwise the captured exception is raised again as
     `System Exception` with the same detail, so the process's existing handling (Mark System Exception, consecutive
     failure count) is unchanged.
   - All business logic is unchanged: the stage-by-stage comparison of the old and new page shows the same decisions,
     calculations, action calls (object, action, inputs, outputs), Business Exception texts and End output. The only new
     stages are the recovery chain and three page locals: `Ex Detail`, `Notice Closed`, `Notice Closes`.
   - Process Main, Load Orders, Post Results: byte-identical.

Note: re-raising with a fixed type is exact here because every exception the block can catch comes from the object's
actions, and all six of the object's Exception stages are System Exceptions.

Behaviour when a Notice hits Approve: if it appears after Yes was pressed, the retry reads the status `Approved` and the
item is reported as `Already approved`. The order is not approved twice.

## Gates

- `python3 skill/lib/validate.py out --flow --strict --with estate`: ALL CLEAN (exit 0). The WARN lines are for
  Credentials, Work Queues and Environment Locking, which are not in this folder.
- `python3 skill/lib/compile_check.py out`: ALL COMPILED (exit 0). The changed files have no code stages; the self-test
  printed SELF-TEST PASS.
- `node tools/twins.js "out/BPA Object - Parcel Depot.xml"` on 4 dumps (sign-in screen, depot screen, Approve confirmation
  screen, Notice screen): TWINS CLEAN.

## Not verified

- Nothing was run in Blue Prism (none on this machine). The Notice check, the Block recovery and the retry are verified
  statically (validator, flow links, stage comparison). The Notice window and OK button were spied and the OK press was
  tested by hand in the test application, not by the process.
- The Notice is matched on its exact window title "Notice". If the vendor's titles differ (for example with the text or a
  suffix), `Close Notice` will not see it and the incident is not fixed. Check the real title on a Parcel Depot machine
  with a Notice up.
- A Notice that appears while the sign-in, Start Depot, Open Depot Session, Take Depot Lock or Clean Up Run stages run is
  not handled by this change. Those failures still go to the existing Approve Run recovery.
- A Notice that appears while the Approve confirmation (Yes/No) is open: `Close Notice` closes the Notice, but the
  confirmation may still be open, and the retry will fail. Not handled.
- The waits in `Close Notice` (3 s, 5 s) are literals, not Environment Variables.
- Timing against the real application (how quickly a Notice appears and disappears) is not measured.
