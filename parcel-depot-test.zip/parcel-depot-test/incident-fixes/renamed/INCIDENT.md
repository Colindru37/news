# Incident INC-7731: Approve Orders fails on every order since this morning

Since 07:00 today `Parcel Depot - Approve Orders` marks every item as a System Exception and then stops itself.
Yesterday's run was fine. Nothing was changed on our side. The vendor installed a new version of Parcel Depot last
night; their note says "minor user interface refresh, no functional change".

- `incident/run.log` : the log of this morning's run (stage by stage; `>` a call, `<` its outputs, `?` a decision).
- The test application in this folder is already the new version. Start it as before (`python3 tools/desk.py start`).

Wanted: the automation works again with the new version, and nothing else about it changes.
