# FIX: INC-7731 Approve Orders fails on every order

## Cause

Parcel Depot's new version renamed or re-identified several controls that the object's Application Modeller
elements match on. The first element used is the customer lookup button: its stored definition matches the name
"Find", but the new screen shows it as "Search". The Get Customer page fails with "Element not found" on the first
item, and the run stops after five items through the consecutive-failure guard. The same change breaks every later
step (order lookup, status and amount, Approve, Confirm), so the fix had to cover all of them, not only the first.

## What changed

Only the element definitions in `BPA Object - Parcel Depot.xml` changed. No page, stage, process, name, input,
output, queue field, tag or exception text was touched. The other four files are byte for byte the same as in
`existing/`. Each element was re-identified with `tools/identify.js` from a spy of the new version and kept the
same ticked attributes as before:

| Element | Was matched on | Now matched on | Reason |
|---|---|---|---|
| Button - Customer Find - UIA | uName "Find" (+ uControlType, puClassName GtkBox) | uName "Search" (same ticks) | Button renamed. Cause of the incident. |
| Button - Order Find - UIA | uName "Find" (+ uControlType, puClassName GtkFrame) | uName "Search" (same ticks) | Same rename, Orders part. |
| Text - Order Status - UIA | uAutomationId "orderStatus" | uAutomationId "lblOrderState" | Id changed. |
| Text - Order Amount - UIA | uAutomationId "orderAmount" | uAutomationId "lblOrderTotal" | Id changed. |
| Button - Approve - UIA | uName "Approve" | uName "Approve order" | Label changed. |
| Button - Yes - UIA | uAutomationId "confirmYes" | uAutomationId "btnConfirm" (button now reads "Confirm") | Id and label changed. |

Each element's position and size attributes were also rewritten from the new screen, as `identify.js` always does.
These are not matching attributes.

## Checked on the new version (spy, off-screen desktop)

- Sign-in with depotbot works. Customer lookup C-77 shows "Ana Pop". Unknown customer C-99 shows
  "No such customer" (the wording the Customer Exists? decision compares against).
- Order lookup P-2001 is Pending, amount 120.00, lines Envelope 3 / Small box 1. Unknown order P-9999 shows
  "Not found", as the PDD says.
- Standard radio, Approve order, then the confirmation window "Approve P-2001?" with Confirm (btnConfirm) and No.
  The No path was used for the dumps and the identification. In an earlier exploratory session Confirm was pressed
  once (P-2001 approved); the data was then reset to the start state.
- After that Confirm, the message reads "Order P-2001 approved" and the status "Approved". This was observed in that
  session, not in the final dumps. The message element was not changed.

## Gates

- `twins.js "out/BPA Object - Parcel Depot.xml"` on dumps of the sign-in, main (customer C-77, order P-2001 Pending,
  Standard ticked) and confirmation screens: TWINS CLEAN on 3 screen(s).
- `validate.py out --flow --strict --with estate`: ALL CLEAN.
- `compile_check.py out`: ALL COMPILED (development mcs/vbc compilers; the real gate is a run on the Blue Prism
  machine).

## Not verified

- No run inside Blue Prism. Blue Prism's matching and the Wait/Read stages were not exercised. Only the spy and the
  twins check were.
- The "Approve failed" message path, the Manager override and Priority ticks, and the "..." status during a lookup
  were not exercised on the new version. Their elements were not changed.
- The final dumps do not include the post-Confirm screen; the post-Confirm message was seen once in the earlier
  exploratory session only.
- Whether the new version differs anywhere else (e.g. timings) is not known from this check alone.
