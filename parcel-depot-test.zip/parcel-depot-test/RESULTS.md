# The bigger test (2026-11-20): three processes, two applications, internals

Can a model keep a larger build consistent with itself? `base/PDD.md` describes three processes run in order:
Load Orders (web portal -> work queue), Approve Orders (desktop application, with rules: customer check, approval
limit, a reason by amount, Priority when a line is Fragile; writes a results queue; holds an environment lock),
Post Results (results queue -> web portal). The model designs the objects itself.

- Desktop: `../desk/app/depot2.py` (GTK, off-screen), spied by the model with `tools/spy.py`; run live by
  `../desk/tools/live.py` behind the object's Application Modeller (as in ../desk).
- Web: `site/` served by `serve.py`; driven through the existing `GK Revoke Browser` object with `base/config/portal.ini`.
  The model cannot open the portal: it has the config and the PDD only.
- `python3 grade.py <attempt folder> [runs]` runs Load, Approve, Post in one runner (queues carry over) with a real
  Firefox and the live desktop application: 28 checks per start.

Set-up for an attempt: copy `base/` to a work folder, copy the rpa-bp skill into it as `skill/`, hand over TASK.md.

## Results, round 1 (one run per model, one fresh start; examples, not rates)

| Attempt | Score | What went wrong |
|---|---|---|
| control (attempts/control) | 21/26 | (1) Approve's clean-up page read two Main Page data items that were private: the run died in its own wrap-up, lock and application left open. (2) Post read the portal's message with Get Attribute "textContent", which the browser object returns empty: every result was saved in the portal and marked as failed in the queue. |
| haiku (attempts/haiku) | 10/26 | Load fully correct. Approve: one element ("Text - Customer Result - UIA") was spied while empty and matched four labels, so every item failed at the customer check and the consecutive-failure guard stopped the run. |
| haiku with that one element given a name pattern | 26/26 | nothing |

Two faults of the test bed were found by this round and fixed:
- the runner did not pass code stage inputs / outputs whose name has a space (Blue Prism: "Orders In" -> Orders_In);
  before the fix haiku's Load failed for that reason alone (8/26);
- `twins.js` skipped any element that had no id and was spied with an empty name, so it told haiku "TWINS CLEAN"
  about the very element that failed. It now reports it.
Consequences taken into the skill: validate.py fails on a private Main Page item used on another page; gotchas.md says
to read text with Get Text.

## Environment faults (2026-11-20): what the builds do when the application misbehaves

`python3 envtest.py <attempt> <fault> [...]` runs Load, Approve, Post with one fault switched on and reports: did the
automation stay truthful (nothing approved wrongly, queues and portal agree with the application), did it clean up
(lock, application, browser, locked items), and how much work ended as in a clean run. Faults are switched on in the
applications' state (`"faults": [...]`), none by default.
Desktop: `slow` (16x), `popup` (a Notice window, main window dead until OK), `crash` (closes at the 3rd lookup),
`logout` (session expired -> sign-in window), `renamed` (new ids and button texts). Portal: `pslow`, `overlay`
(full-page cookie layer), `savelost` (one save swallowed), `expire` (session ends after 3 saves), `loginfail`.

Builds tested: `attempts/haiku_fix` (haiku's with its one element corrected) and `attempts/control_fix` (the control
with its two bugs repaired); both 26/26 without faults.

| Fault | haiku_fix | control_fix |
|---|---|---|
| slow, pslow, overlay | all work done | all work done |
| savelost | 5/6 posted, the lost one a System Exception | same |
| expire | 3/6 posted, the rest System Exceptions | same |
| loginfail | Load stops with the PDD's sign-in exception, nothing queued | same |
| popup | 1/7 orders, then every item a System Exception | same |
| crash, logout | 2/7 orders, then every item a System Exception | same |
| renamed | 0/7 | 0/7 |

Every one of the 20 runs: truthful and left clean. Neither build recovers from anything the PDD did not describe
(haiku's stops itself after consecutive failures; the control burns the whole queue). The overlay is harmless because
the existing browser object clicks through script when a click is intercepted.

`incidents/` holds three briefs (renamed, popup, crash) and `make.py` to lay out a work folder for a model to fix one
in an existing build. Not run yet.

### Incident fixes by haiku (2026-11-21, one run each; `incidents/attempts/`)

Each got its own corrected build (`attempts/haiku_fix`), the failing run's log, the misbehaving application and
`incidents/TASK.md`. Graded with `envtest.py` on: no fault, the fault, and the fault at a second moment where one exists.

| Incident | Result | What it changed |
|---|---|---|
| renamed | 7/7 orders, 6/6 posted, truthful | six element definitions in the desktop object; four files byte-identical |
| popup (+ popup_late) | 7/7, 6/6 in all three runs | two new elements + a "Close Notice" action; the Work Item page replaced with a recover-close-retry block |
| crash (+ crash_late) | 7/7, 6/6 in all three runs | one new action "Is Depot Open"; the Work Item page replaced with a restart-and-retry-once block |

Test-bed fault found while grading crash: `desk.alive()` counted an exited, uncollected process as running, so Launch
after the crash answered "already running" and the fix looked broken (2/7). Fixed; the numbers above are after it.
