"""Parcel Depot 2: the bigger test application (GTK 3). Test bed only. Like depot.py, plus per order: an amount, a table
of order lines, a reason (radio buttons) and a Priority tick box, with rules the application itself enforces.
State: the JSON file named by DEPOT_STATE."""
import gi, json, os, random
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib

STATE_FILE = os.environ.get('DEPOT_STATE', os.path.join(os.path.dirname(os.path.abspath(__file__)), 'state2.json'))
DEFAULT = {'orders': {
    'P-2001': {'status': 'Pending', 'amount': '120.00', 'customer': 'C-77', 'lines': [['Envelope', '3'], ['Small box', '1']]},
    'P-2002': {'status': 'Pending', 'amount': '750.50', 'customer': 'C-77', 'lines': [['Fragile vase', '1'], ['Bubble wrap', '2']]},
    'P-2003': {'status': 'Approved', 'amount': '80.00', 'customer': 'C-78', 'lines': [['Letter', '1']]},
    'P-2004': {'status': 'Pending', 'amount': '2500.00', 'customer': 'C-78', 'lines': [['Pallet', '1']]},
    'P-2005': {'status': 'Pending', 'amount': '300.00', 'customer': 'C-77', 'lines': [['Box', '2']]}},
    'locked': ['P-2005'], 'customers': {'C-77': 'Ana Pop', 'C-78': 'Dan Ilie'}, 'log': []}
REASONS = ['No reason', 'Standard', 'Manager override']
SESSION = random.randint(10000, 99999)
PAD = random.randint(0, 60)


def load():
    try:
        with open(STATE_FILE, encoding='utf-8') as f:
            s = json.load(f)
    except Exception:
        s = json.loads(json.dumps(DEFAULT))
    for k, v in DEFAULT.items():
        s.setdefault(k, json.loads(json.dumps(v)))
    return s


def save(s):
    with open(STATE_FILE + '.tmp', 'w', encoding='utf-8') as f:
        json.dump(s, f)
    os.replace(STATE_FILE + '.tmp', STATE_FILE)


def faults():
    """Environment faults for the robustness tests, named in the state file: "faults": ["slow", "popup", "crash", "logout",
    "renamed"]. None by default. popup / crash / logout happen once per state file (noted in "fault_done")."""
    return set(load().get('faults', []))


def once(name):
    s = load()
    if name not in s.get('faults', []) or name in s.get('fault_done', []):
        return False
    s.setdefault('fault_done', []).append(name); s['log'].append('fault ' + name); save(s)
    return True


def ms(n):
    return n * 16 if 'slow' in faults() else n


def aid(w, ident):
    try:
        w.get_accessible().set_accessible_id(ident)
    except Exception:
        pass
    return w


class Login(Gtk.Window):
    def __init__(self, note=''):
        super().__init__(title='Parcel Depot - Sign in')
        self.set_border_width(12 + PAD // 3)
        g = Gtk.Grid(row_spacing=6, column_spacing=6); self.add(g)
        g.attach(Gtk.Label(label='User'), 0, 0, 1, 1)
        self.user = aid(Gtk.Entry(), 'loginUser'); self.user.get_accessible().set_name('User name'); g.attach(self.user, 1, 0, 1, 1)
        g.attach(Gtk.Label(label='Password'), 0, 1, 1, 1)
        self.pw = aid(Gtk.Entry(visibility=False), 'loginPassword'); self.pw.get_accessible().set_name('Password'); g.attach(self.pw, 1, 1, 1, 1)
        b = Gtk.Button(label='Sign in'); b.connect('clicked', lambda *_: GLib.timeout_add(ms(400), self.done, self.user.get_text(), self.pw.get_text())); g.attach(b, 1, 2, 1, 1)
        self.msg = Gtk.Label(label=note); g.attach(self.msg, 0, 3, 2, 1)
        self.connect('destroy', Gtk.main_quit); self.show_all()

    def done(self, u, p):
        if u != 'depotbot' or p != 'depot!42':
            self.msg.set_text('Wrong user or password'); return False
        s = load(); s['log'].append('login'); save(s)
        self.disconnect_by_func(Gtk.main_quit); Main(u); self.destroy()
        return False


class Main(Gtk.Window):
    def __init__(self, user):
        super().__init__(title='Parcel Depot - session %d' % SESSION)
        self.set_border_width(8 + PAD // 2); self.cur = None; self.finds = 0
        ren = 'renamed' in faults()      # an application update: new ids, new button texts
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8 + PAD // 6); self.add(box)
        box.add(Gtk.Label(label='Signed in as ' + user))
        cf = Gtk.Frame(label='Customers'); box.add(cf)
        cb = Gtk.Box(spacing=6); cf.add(cb)
        self.cust = Gtk.Entry(); self.cust.get_accessible().set_name('Search'); cb.add(self.cust)
        b = Gtk.Button(label='Search' if ren else 'Find'); b.connect('clicked', self.find_customer); cb.add(b)
        self.cres = Gtk.Label(label=''); cb.add(self.cres)
        of = Gtk.Frame(label='Orders'); box.add(of)
        og = Gtk.Grid(row_spacing=6, column_spacing=6); of.add(og)
        self.oid = Gtk.Entry(); self.oid.get_accessible().set_name('Search'); og.attach(self.oid, 0, 0, 1, 1)
        b = Gtk.Button(label='Search' if ren else 'Find'); b.connect('clicked', self.find_order); og.attach(b, 1, 0, 1, 1)
        og.attach(Gtk.Label(label='Status:'), 0, 1, 1, 1)
        self.status = aid(Gtk.Label(label='-'), 'lblOrderState' if ren else 'orderStatus'); og.attach(self.status, 1, 1, 1, 1)
        og.attach(Gtk.Label(label='Amount:'), 0, 2, 1, 1)
        self.amount = aid(Gtk.Label(label='-'), 'lblOrderTotal' if ren else 'orderAmount'); og.attach(self.amount, 1, 2, 1, 1)
        self.store = Gtk.ListStore(str, str)
        self.lines = Gtk.TreeView(model=self.store)
        for i, t in enumerate(['Item', 'Qty']):
            self.lines.append_column(Gtk.TreeViewColumn(t, Gtk.CellRendererText(), text=i))
        self.lines.get_accessible().set_name('Order lines'); og.attach(self.lines, 0, 3, 2, 1)
        rb = Gtk.Box(spacing=6); og.attach(rb, 0, 4, 2, 1)
        self.radios = []
        for r in REASONS:
            w = Gtk.RadioButton.new_with_label_from_widget(self.radios[0] if self.radios else None, r); self.radios.append(w); rb.add(w)
        self.prio = Gtk.CheckButton(label='Priority'); og.attach(self.prio, 0, 5, 1, 1)
        self.approve = Gtk.Button(label='Approve order' if ren else 'Approve'); self.approve.connect('clicked', self.ask); self.approve.set_sensitive(False); og.attach(self.approve, 1, 5, 1, 1)
        self.msg = Gtk.Label(label=''); og.attach(self.msg, 0, 6, 2, 1)
        self.connect('destroy', Gtk.main_quit); self.show_all()

    def find_customer(self, *_):
        s = load(); self.cres.set_text(s['customers'].get(self.cust.get_text().strip(), 'No such customer'))

    def find_order(self, *_):
        oid = self.oid.get_text().strip()
        self.status.set_text('...'); self.amount.set_text('...'); self.msg.set_text(''); self.approve.set_sensitive(False); self.store.clear()
        self.radios[0].set_active(True); self.prio.set_active(False)
        GLib.timeout_add(ms(500), self.found, oid)

    def found(self, oid):
        s = load(); o = s['orders'].get(oid); self.cur = oid
        self.status.set_text(o['status'] if o else 'Not found'); self.amount.set_text(o['amount'] if o else '-')
        for l in (o['lines'] if o else []):
            self.store.append([str(l[0]), str(l[1])])
        self.approve.set_sensitive(bool(o) and o['status'] == 'Pending')
        s['log'].append('find ' + oid); save(s)
        self.finds += 1
        if self.finds == 3 and once('crash'):
            os._exit(1)
        if self.finds == 3 and once('logout'):
            self.disconnect_by_func(Gtk.main_quit); Login('Session expired, sign in again'); self.destroy()
        if self.finds == 2 and once('popup'):
            self.notice()
        return False

    def notice(self):
        d = Gtk.Window(title='Notice', transient_for=self, modal=True); d.set_border_width(12)
        b = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8); d.add(b)
        b.add(Gtk.Label(label='Maintenance tonight at 22:00. Save your work.'))
        k = Gtk.Button(label='OK'); b.add(k)
        self.get_child().set_sensitive(False)          # nothing in the main window reacts while the notice is up
        def close(*_):
            self.get_child().set_sensitive(True); d.destroy()
            s = load(); s['log'].append('notice closed'); save(s)
        k.connect('clicked', close); d.show_all()

    def ask(self, *_):
        oid = self.cur
        self.asks = getattr(self, 'asks', 0) + 1
        if self.asks == 2 and once('crash_late'):       # variant: closes when Approve is pressed the second time
            os._exit(1)
        reason = next(r for r, w in zip(REASONS, self.radios) if w.get_active()); prio = self.prio.get_active()
        d = Gtk.Window(title='Approve %s?' % oid, transient_for=self, modal=True); d.set_border_width(12)
        ren = 'renamed' in faults()
        b = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8); d.add(b)
        b.add(Gtk.Label(label='Approve order %s? This cannot be undone.' % oid))
        hb = Gtk.Box(spacing=6); b.add(hb)
        no = Gtk.Button(label='No'); no.connect('clicked', lambda *_: d.destroy()); hb.add(no)
        yes = aid(Gtk.Button(label='Confirm' if ren else 'Yes'), 'btnConfirm' if ren else 'confirmYes'); yes.connect('clicked', lambda *_: (d.destroy(), GLib.timeout_add(ms(600), self.done, oid, reason, prio), once('popup_late') and self.notice())); hb.add(yes)
        GLib.timeout_add(ms(200), lambda: (d.show_all(), False)[1]) if 'slow' in faults() else d.show_all()

    def done(self, oid, reason, prio):
        s = load(); o = s['orders'][oid]
        if oid in s['locked']:
            self.msg.set_text('Error: order %s is locked by another user' % oid); s['log'].append('approve-refused ' + oid); save(s); return False
        if float(o['amount']) > 500 and reason == 'No reason':
            self.msg.set_text('Error: a reason is required above 500.00'); s['log'].append('approve-noreason ' + oid); save(s); return False
        o['status'] = 'Approved'; o['reason'] = reason; o['priority'] = bool(prio)
        self.status.set_text('Approved'); self.approve.set_sensitive(False); self.msg.set_text('Order %s approved' % oid)
        s['log'].append('approve ' + oid); save(s)
        return False


if __name__ == '__main__':
    Login(); Gtk.main()
