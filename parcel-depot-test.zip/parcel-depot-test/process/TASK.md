# Task: build the Parcel Depot order approval automation

Build everything `PDD.md` describes: the objects and the three processes. Nothing exists yet except the browser
object. You spy the desktop application yourself.

You are on a machine WITHOUT Blue Prism: you cannot run objects or processes. You CAN start the desktop application
on an off-screen desktop and spy it. You cannot open the web portal: for it you have its config (`config/portal.ini`,
with every locator the bot needs) and the browser object. Work only inside this folder.

## What is here

- `PDD.md` : what the three processes do.
- `skill/` : the rpa-bp skill. Read `skill/SKILL.md` first; `skill/reference/gotchas.md` has the rules for choosing
  what an element matches on.
- `estate/` : objects that already exist and that you call, never rebuild:
  - `BPA Object - GK Revoke Browser.xml` (described in `estate/BROWSER_OBJECT.md`): ALL browser work goes through its
    actions. It reads an INI (`Load Config`) and takes `[XPATHS]` / `[URLS]` keys as inputs.
  - `BPA Object - GK Revoke BlueSpace.xml` : an existing application object built on the browser object, as an example.
- `config/portal.ini` : the web portal's config (URL and locators).
- `tools/` : run from THIS folder.
  - `python3 tools/desk.py start | app | stop` : the off-screen desktop with Parcel Depot. Always `stop` at the end.
  - `python3 tools/spy.py ...` : `windows`, `tree`, `element <ref> -o f.json`, `press`, `type`, `text`, `checked <ref>`,
    `table <ref>`, `dump <f.json>`. Run it without arguments for the help.
  - `node tools/identify.js <object.xml> "<element>" <spy.json> --use <attrs> [--set a=v] [--cmp a=Wildcard|RegEx]`
  - `node tools/twins.js <object.xml> <dump.json> ...` : is every element unique on the screens you dumped?
- Desktop test sign-in: user `depotbot`, password `depot!42`. Test data: orders P-2001 .. P-2005, customers C-77, C-78.
  `depot_state.json` in this folder is the application's data (delete it to reset).

## What the desktop application's elements can do (use exactly these action ids)

- Write stage: text into an edit box; `True` / `False` into a tick box.
- Navigate stage: `Press` (buttons, radio buttons, tick boxes); on the application root `Launch` and `Terminate`.
- Read stage: `GetWindowText` (the text of a label or edit box), `GetChecked` (flag: is a tick box / radio button
  ticked), `GetTable` (collection: a table's rows, one column per table column, all text).
- Wait stage: `CheckExists` (with Equal, or NotEqual to wait until it is gone).

## Blue Prism's internal objects (signatures)

Work Queues and Credentials: see `skill/reference/estate-objects.md`. Environment Locking:
`Acquire Lock` (inputs `Name`, `Preferred Token`, `Comment`; output `Token`, empty when the lock is held elsewhere),
`Release Lock` (inputs `Name`, `Token`, `Comment`).

## What to deliver, in `out/`

- Processes named exactly `Parcel Depot - Load Orders`, `Parcel Depot - Approve Orders`, `Parcel Depot - Post Results`.
- The objects they need, yours to design (names, how many, which actions), with every Application Modeller element
  identified. The desktop object's application is started with `Launch` on its root and closed with `Terminate`.
- `HANDOVER.md` : the design (which object does what, which process calls what), the data each queue item carries,
  how each element is matched, what you could not verify.
- Generate with the skill's generator; keep your build script(s) in `out/`.

## Fixed contract (the test run supplies exactly these; use no other environment variables)

| Environment variable (Text) | Meaning |
|---|---|
| `Parcel Depot Queue Name` | work queue: items `Order ID`, `Customer ID` |
| `Parcel Depot Results Queue Name` | results queue: items `Order ID`, `Result` |
| `Parcel Depot Credential Name` | Credentials for the desktop sign-in |
| `Parcel Depot Lock Name` | name of the environment lock |
| `Parcel Portal Credential Name` | Credentials for the portal sign-in |
| `Parcel Portal Config Path` | the portal INI |
| `Parcel Portal Driver Path`, `Parcel Portal Browser Kind`, `Parcel Portal Run Mode`, `Parcel Portal Log Folder` | for the browser object's Launch Browser |

The three processes are run in the order Load, Approve, Post, each to its end, several times on fresh starts.

## Done means

`python3 skill/lib/validate.py out --flow --strict --with estate` prints ALL CLEAN, `python3 skill/lib/compile_check.py out`
prints ALL COMPILED, and `node tools/twins.js` is clean for every object with an Application Modeller on dumps of
every screen it uses. Then stop the desktop and stop. Final message: the gate lines, the files in `out/`, the design
in five lines, and what you are unsure about.
