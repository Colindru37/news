# Parcel Depot order approval: process description

Three robots' worth of work, run one after the other every morning: load, approve, report.

## The two applications

- **Parcel Portal** (web). Lists the orders waiting for approval and takes the outcome of each one back.
- **Parcel Depot** (desktop). Where an order is looked up and approved.

## 1. Load Orders

1. Sign in to Parcel Portal with the portal bot's credentials. A refused sign-in shows the reason: system exception
   `Parcel Portal sign-in failed: <reason>`.
2. The "Open orders" list arrives a moment after the page. Each row has an order id and a customer id.
3. Put every order on the work queue: one item per order, fields `Order ID` and `Customer ID`, tagged `Loaded`.
   The portal sometimes lists the same order twice: an order goes on the queue once per run.
4. Close the browser.

## 2. Approve Orders

Only one robot may work in Parcel Depot at a time: take the environment lock before starting the application and
release it when the run ends, also when the run fails. If the lock cannot be taken, stop: system exception
`Parcel Depot is locked by another session`.

Start Parcel Depot and sign in with the depot bot's credentials. Then for every item of the work queue:

1. **Customer.** In the Customers part, look up the item's customer id. `No such customer`: business exception
   `Customer <customer id> not found in Parcel Depot`; the order is not looked up.
2. **Order.** In the Orders part, look up the order id. While the lookup runs the status shows `...`.
   - `Not found`: business exception `Order <id> not found in Parcel Depot`.
   - `Approved`: nothing to do, result `Already approved`.
   - `Pending`: continue. Anything else: business exception `Order <id> has unexpected status: <status>`.
3. **Limit.** The amount is shown under the status. Above 2000.00 the robot must not approve: business exception
   `Order <id> is above the approval limit: <amount as shown>`.
4. **Reason.** Above 500.00 choose the reason `Manager override`; otherwise `Standard`.
5. **Priority.** If any order line's Item contains the word `Fragile`, tick Priority; otherwise leave it unticked.
6. **Approve.** Press Approve, confirm with Yes in the window that appears. A message appears under the button:
   the order was approved (status then reads `Approved`): result `Approved`. Any other message: system exception
   `Approve failed for <id>: <the message>`.

Per item: result `Approved` / `Already approved` -> tag the item with that text, mark it Completed. Business exception
-> Mark Exception, reason `Business Exception: <text>`. System exception on an item -> Mark Exception, reason
`System Exception: <text>`, and carry on with the next item. No retries.

**For every item worked, whatever its outcome,** put one item on the results queue: fields `Order ID` and `Result`,
where Result is the tag text for a completed item and the full exception reason for a failed one.

When the queue is empty: close Parcel Depot, release the lock.

## 3. Post Results

1. Sign in to Parcel Portal (as in Load Orders).
2. For every item of the results queue: in "Report a result" enter the order id and the result text, press Save.
   A message appears: `Saved <id>` -> mark the item Completed. `Unknown order <id>` -> business exception
   `Parcel Portal does not know order <id>`. Any other message -> system exception `Result not saved for <id>: <message>`.
   Exceptions are marked on the item as in Approve Orders, and the run carries on.
3. Close the browser.
