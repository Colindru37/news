GK Revoke Browser update, 2026-11-26

File > Import this object, overwrite the existing one. Nothing else changes.
Take Screenshot now captures the whole screen (taskbar, clock, URL in the address bar).
The browser window must be visible and the session unlocked; otherwise the bot writes the
browser picture with a "<url>  |  <time>" band on top and says so in the browser log.
