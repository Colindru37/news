GK Revoke Browser update, 2026-11-26

File > Import this object, overwrite the existing one. Nothing else changes.
Take Screenshot now puts a black band on top of each picture: <url>  |  <yyyy-MM-dd HH:mm:ss>.
