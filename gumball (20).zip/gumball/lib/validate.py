"""
validate.py -- structural + link validator for generated Blue Prism XML.

Checks each *.xml in a directory (default: ./out) for:
  * well-formed XML with a <process> root
  * no broken flow links: every onsuccess / ontrue / onfalse points at a real
    stageid in the same file; no duplicate stageids
  * subsheet declarations and SubSheetInfo stages agree (every page is both
    declared and defined)
  * Code Options / ProcessInfo shape: no <globalcode>/<code>/<references>/<imports>
    as direct children of <process>; no <namespaces> anywhere (must be <imports>)
  * internal name does not carry the 'BPA Object - ' / 'BPA Process - ' prefix
  * every output stage="X" names a Data/Collection stage on the SAME page
    (the classic "null-reference at the Action stage, no other clue")
  * collections are type="Collection" stages, ForEach <loopdata> names one,
    LoopStart/LoopEnd groupids pair up
  * unquoted text literals in input expressions (use lit())
  * cross-object calls: when the called object is ALSO in the directory, the
    action must exist as a published page and every passed input name must be
    one of that page's Start inputs (exact string match, like Blue Prism)
  * [Item] references that resolve to no data item on the page (WARN)
  * non-ASCII in names/narratives (WARN -- garbles on import)

Run:  python validate.py [directory] [--flow] [--estate]
Exit code is 0 when everything is clean, 1 otherwise (CI-friendly).
Pass --flow (or -f) to also print a resolved link report (stage --tag--> target)
so you can eyeball where decisions/gotos/loops actually go; links landing on an
End stage are marked *(End) to expose mistyped targets that silently fell back.
Pass --with DIR (repeatable) to load called objects or interface STUBS from another folder
for the cross-object check only (they are not validated or shipped).
Pass --strict to enforce the estate review checklist mechanically: unique stage names
per page, no generic/numbered/++ names, no unreachable stages or dead ends, no unused
data items, explicit initial values on flags/numbers, no leftover breakpoints,
Choice/Wait pairing, populated exception types, clean boolean expressions. Use it on
everything GENERATED; on legacy exports it lists the debt rather than blocking.
Pass --estate for new estate-native work. It checks objective mandatory
conventions; omit it only for a documented project-compatible exception.
"""
import os, sys, glob, re
import xml.etree.ElementTree as ET


INTERNAL_OBJECTS = {                     # display name -> XML class name (Blue Prism internal objects)
    'Work Queues': 'Blueprism.Automate.clsWorkQueuesActions',
    'Credentials': 'Blueprism.Automate.clsCredentialsActions',
    'Environment Locking': 'BluePrism.AutomateAppCore.clsEnvironmentLockingBusinessObject',
    'Collections': 'Blueprism.AutomateProcessCore.clsCollectionActions',
}
INTERNAL_BY_CLASS = {v: k for k, v in INTERNAL_OBJECTS.items()}


def ident(name):
    s = re.sub(r'[^A-Za-z0-9_]', '_', name.strip().replace(' ', '_'))
    return ('_' + s) if (not s or s[0].isdigit()) else s

LIT_OK = [
    re.compile(r'^-?\d+(\.\d+)?$'),                    # number
    re.compile(r'^(True|False)$', re.I),               # flag
    re.compile(r'^[A-Za-z][A-Za-z0-9]*\([^()]*\)'),    # function call, e.g. Today()
]
REF_RE = re.compile(r'\[([^\[\]]+)\]')
QUOTED_RE = re.compile(r'"(?:[^"]|"")*"')


def page_of(st):
    ss = st.find('subsheetid')
    return ss.text.strip() if ss is not None and ss.text else None   # None = main page


def bad_literal(e):
    e = (e or '').strip()
    if not e:
        return False
    if e.startswith('[') or e.startswith('"') or e.startswith('&quot;'):
        return False
    return not any(r.match(e) for r in LIT_OK)


def load(fp):
    with open(fp, 'r', encoding='utf-8') as f:
        raw = f.read()
    root = ET.fromstring(raw)
    # Blue Prism exports often carry a default xmlns; strip it or every 'stage' search is empty
    for el in root.iter():
        if isinstance(el.tag, str) and '}' in el.tag:
            el.tag = el.tag.split('}', 1)[1]
    return root


def object_catalogue(roots):
    """name -> {page name -> (published, [start input names])} for every object in dir."""
    cat = {}
    for root in roots.values():
        if root.tag != 'process' or root.get('type') != 'object':
            continue
        pub = {}
        for ss in root.iter('subsheet'):
            nm = (ss.findtext('name') or '').strip()
            pub[ss.get('subsheetid')] = (nm, (ss.get('published') or '').lower() == 'true')
        pages = {}
        for st in root.iter('stage'):
            if st.get('type') != 'Start':
                continue
            sid = page_of(st)
            if sid not in pub:
                continue
            nm, published = pub[sid]
            ins = [i.get('name') for i in st.iter('input')]
            pages[nm] = (published, ins)
        cat[root.get('name')] = pages
    return cat


# ---------------------------------------------------------------------------
# --strict: the estate review checklist / anti-pattern list, made mechanical.
# Sources: process conventions s.29 + s.31, object conventions s.10 + s.11.
# ---------------------------------------------------------------------------
FLOW_TYPES = {'Start', 'End', 'Action', 'Code', 'Decision', 'Calculation', 'MultipleCalculation',
              'LoopStart', 'LoopEnd', 'SubSheet', 'Exception', 'Recover', 'Resume', 'Anchor',
              'ChoiceStart', 'ChoiceEnd', 'WaitStart', 'WaitEnd', 'Navigate', 'Read', 'Write',
              'Alert', 'Skill'}
TERMINAL_TYPES = {'End', 'Exception'}
GENERIC_NAME_RE = re.compile(
    r'^(Stage|Action|Calc|Calculation|Multiple ?Calculation|Decision|Code|Anchor|Block|Recover|'
    r'Resume|End|Start|Loop ?Start|Loop ?End|Choice|Choice ?Start|Choice ?End|Wait|Wait ?Start|'
    r'Wait ?End|Exception|Navigate|Read|Write|Data|Collection|Process ?Info|SubSheet|Page)\d+$', re.I)
PLUSPLUS_RE = re.compile(r'\+\+\s*$')
EXPOSED = {'Environment', 'Session', 'Statistic'}


def _expr_texts(st):
    """Every expression-ish string a stage carries (for data-item usage)."""
    out = []
    for el in st.iter():
        for attr in ('expr', 'expression', 'detail'):
            v = el.get(attr)
            if v:
                out.append(v)
        if el.tag in ('expression', 'timeout', 'loopdata') and el.text:
            out.append(el.text if el.tag != 'loopdata' else f'[{el.text}]')
    return out


def _targets(st):
    """Stage ids this stage can flow to."""
    ids = []
    for tag in ('onsuccess', 'ontrue', 'onfalse'):
        for el in st.iter(tag):
            if el.text:
                ids.append(el.text.strip())
    return ids


def strict_checks(root, stages):
    probs = []
    by_page = {}
    for st in stages:
        by_page.setdefault(page_of(st), []).append(st)
    page_name = {(st.find('subsheetid').text if st.find('subsheetid') is not None else None): st.get('name')
                 for st in stages if st.get('type') == 'SubSheetInfo'}
    page_name.setdefault(None, 'Main')

    # 1. duplicate stage names on one page (Notes exempt: estate keeps default Note names)
    for pg, sts in by_page.items():
        seen = {}
        for st in sts:
            if (st.get('type') in ('Note', 'SubSheetInfo', 'ProcessInfo')
                    or (st.get('type') == 'End' and st.get('name') == 'End')):
                continue          # several End stages all named "End" is normal Blue Prism
            seen.setdefault(st.get('name'), []).append(st.get('type'))
        dups = {n: t for n, t in seen.items() if len(t) > 1}
        if dups:
            probs.append(f"strict: page '{page_name.get(pg, '?')}' duplicate stage names: " +
                         ', '.join(f'{n!r} x{len(t)}' for n, t in sorted(dups.items())))

    # 1c. a code stage input and output with the same name = the same method parameter twice
    for st in stages:
        if st.get('type') != 'Code':
            continue
        ins = {ident(i.get('name') or '') for i in st.iter('input')}
        outs = {ident(o.get('name') or '') for o in st.iter('output')}
        both = sorted(ins & outs)
        if both:
            probs.append(f"strict: page '{page_name.get(page_of(st), '?')}' code stage {st.get('name')!r}: "
                         f"{both} is both an input and an output (duplicate parameter in Blue Prism; "
                         f"name the input '<name>_In' and assign it to the output first)")

    # 1b. code stage names must be unique across the WHOLE file (each becomes one method)
    code_names = {}
    for st in stages:
        if st.get('type') == 'Code':
            code_names.setdefault(st.get('name'), []).append(page_name.get(page_of(st), '?'))
    code_dups = {n: p for n, p in code_names.items() if len(p) > 1}
    if code_dups:
        probs.append('strict: code stage names repeated on several pages (they compile to one '
                     'method each -> CS0111 in Blue Prism): ' +
                     ', '.join(f'{n!r} on {sorted(p)}' for n, p in sorted(code_dups.items())))

    # 2. generic / numbered / ++ names
    generic = sorted({st.get('name') for st in stages
                      if st.get('type') not in ('Note',)
                      and (GENERIC_NAME_RE.match(st.get('name') or '')
                           or PLUSPLUS_RE.search(st.get('name') or ''))})
    if generic:
        probs.append(f'strict: generic/numbered names (anti-pattern): {generic[:10]}')

    # 3. unreachable flow stages + 4. dead ends
    for pg, sts in by_page.items():
        flow = {st.get('stageid'): st for st in sts if st.get('type') in FLOW_TYPES}
        flow_notes = {st.get('stageid'): st for st in sts
                      if st.get('type') == 'Note' and st.find('onsuccess') is not None}
        roots = [sid for sid, st in flow.items() if st.get('type') in ('Start', 'Recover')]
        # ChoiceEnd / WaitEnd / LoopEnd (otherwise / time-out / collection-exhausted path)
        # are entered implicitly from their Start with the same groupid -- follow that
        # pairing inside the same walk. Notes can sit in the flow (they carry onsuccess).
        for sid, st in flow_notes.items():
            flow.setdefault(sid, st)
        pair_end = {}
        for sid, st in flow.items():
            if st.get('type') in ('ChoiceEnd', 'WaitEnd', 'LoopEnd'):
                pair_end.setdefault((st.findtext('groupid') or '').strip(), []).append(sid)
        reach, todo = set(), list(roots)
        while todo:
            sid = todo.pop()
            if sid in reach or sid not in flow:
                continue
            reach.add(sid)
            st = flow[sid]
            todo.extend(_targets(st))
            if st.get('type') in ('ChoiceStart', 'WaitStart', 'LoopStart'):
                todo.extend(pair_end.get((st.findtext('groupid') or '').strip(), []))
        unreachable = [st.get('name') for sid, st in flow.items()
                       if sid not in reach and st.get('type') != 'Note']
        if unreachable:
            probs.append(f"strict: page '{page_name.get(pg, '?')}' unreachable stages: {unreachable[:8]}")
        dead = []
        for sid, st in flow.items():
            t = st.get('type')
            if t in TERMINAL_TYPES or t == 'Note':
                continue
            if t == 'Decision':
                if st.find('ontrue') is None or st.find('onfalse') is None:
                    dead.append(st.get('name'))
            elif t in ('ChoiceStart', 'WaitStart'):
                continue            # exits are per-choice ontrue + the matching End's onsuccess
            elif not _targets(st):
                dead.append(st.get('name'))
        if dead:
            probs.append(f"strict: page '{page_name.get(pg, '?')}' dead ends (no exit): {dead[:8]}")

    # 5. unused data items (referenced nowhere in the file)
    used = set()
    for st in stages:
        for e in _expr_texts(st):
            for ref in REF_RE.findall(QUOTED_RE.sub('', e)):
                used.add(ref.split('.')[0].strip())
        for el in st.iter():
            v = el.get('stage')
            if v:
                used.add(v)
    unused = []
    for st in stages:
        if st.get('type') not in ('Data', 'Collection'):
            continue
        if (st.findtext('exposure') or '').strip() in EXPOSED:
            continue
        if st.get('name') not in used:
            unused.append(st.get('name'))
    if unused:
        probs.append(f'strict: {len(unused)} unused data item(s): {sorted(unused)[:10]}')

    # 6. flags/numbers without an explicit initial value
    no_init = [st.get('name') for st in stages if st.get('type') == 'Data'
               and (st.findtext('datatype') or '') in ('flag', 'number')
               and not (st.findtext('initialvalue') or '').strip()
               and (st.findtext('exposure') or '').strip() not in EXPOSED]
    if no_init:
        probs.append(f'strict: flag/number item(s) without explicit initial value: {sorted(no_init)[:10]}')

    # 7. leftover debug breakpoints
    bps = [st.get('name') for st in stages if st.find('breakpoint') is not None]
    if bps:
        probs.append(f'strict: debug breakpoint(s) left in: {bps[:8]}')

    # 8. Choice / Wait pairing
    for a, b in (('ChoiceStart', 'ChoiceEnd'), ('WaitStart', 'WaitEnd')):
        sa = [(st.findtext('groupid') or '') for st in stages if st.get('type') == a]
        sb = [(st.findtext('groupid') or '') for st in stages if st.get('type') == b]
        for g in set(sa) | set(sb):
            if sa.count(g) != 1 or sb.count(g) != 1:
                probs.append(f'strict: {a}/{b} groupid {g[:8]}.. does not pair 1:1')

    # 9. Exception stage with empty type (not a rethrow)
    empty_ex = [st.get('name') for st in stages if st.get('type') == 'Exception'
                and st.find('exception') is not None
                and st.find('exception').get('usecurrent') != 'yes'
                and not (st.find('exception').get('type') or '').strip()]
    if empty_ex:
        probs.append(f'strict: Exception stage(s) with empty type: {empty_ex}')

    # 9b. recovery mode: ExceptionType()/Detail()/Stage() and 'preserve current exception'
    # only work between Recover and Resume. Walk backwards: every path must reach a Recover
    # before it reaches a Resume or the Start.
    ids = {st.get('stageid'): st for st in stages}
    preds = {}
    for st in stages:
        for t in _targets(st):
            preds.setdefault(t, []).append(st.get('stageid'))

    def bad_path(sid):
        seen, todo = set(), [sid]
        while todo:
            cur = todo.pop()
            if cur in seen:
                continue
            seen.add(cur)
            ps = preds.get(cur, [])
            if not ps and cur != sid:
                return True                       # reached an entry that is not a Recover
            for pr in ps:
                t = ids[pr].get('type') if pr in ids else None
                if t == 'Recover':
                    continue
                if t in ('Resume', 'Start'):
                    return True
                todo.append(pr)
        return False
    fn_re = re.compile(r'Exception(Type|Detail|Stage)\(\)')
    for st in stages:
        ex = st.find('exception')
        rethrow = ex is not None and ex.get('usecurrent') == 'yes'
        uses_fn = any(fn_re.search(e) for e in _expr_texts(st))
        if (rethrow or uses_fn) and bad_path(st.get('stageid')):
            what = 'rethrows the current exception' if rethrow else 'reads ExceptionType/Detail/Stage()'
            probs.append(f"strict: '{st.get('name')}' {what} outside recovery mode (a Resume or Start "
                         f"precedes it); capture details / rethrow BEFORE Resume")

    # 10. expression hygiene. Blue Prism has NO negation operator: neither NOT nor Not() is
    # valid (verified on the estate machine); the way to negate a flag is [Flag] = False
    # (the official training solution does exactly that). So: '= False' is correct, '= True'
    # is merely redundant (not reported), and any NOT is an error.
    for st in stages:
        for e in _expr_texts(st):
            bare = QUOTED_RE.sub('""', e)
            if re.search(r'\bNOT\b', REF_RE.sub('[]', bare), re.I):      # ignore [Not Found]-style names
                probs.append(f"strict: '{st.get('name')}' uses NOT ({e[:50]}) -- Blue Prism has no NOT "
                             f"operator or Not() function; write [Flag] = False")
            if re.search(r'\bAND\b', bare, re.I) and re.search(r'\bOR\b', bare, re.I) and '(' not in bare:
                probs.append(f"strict: '{st.get('name')}' mixes AND/OR without parentheses ({e[:50]})")
    return probs


# Application Modeller action ids seen in real exports of the estate (reference/action-ids.md). Blue Prism refuses the
# import of an object that names an id it does not know, so an id outside these lists is reported.
NAVIGATE_IDS = set('''
AAClickCentre AAFocus AAHideDropdown AAMouseClick AASelectItem AASendKeys AAShowDropdown ActivateApp
AttachApplication AttachMainframe ClickToolbarButton ClickWindow ClickWindowCentre CloseWindow
Default DetachApplication DetachMainframe EnsureItemVisible HTMLClickCentre HTMLDoubleClickCentre
HTMLFocus HTMLHover HTMLInsertJavascriptFragment HTMLInvokeJavascriptMethod HTMLNavigate
HTMLSelectItem HideDropdown Launch LaunchMainframe ListRegionMouseClickCentre MaximiseWindow
MinimiseWindow MouseClick MouseClickCentre MouseDoubleClick MouseDoubleClickCentre MoveWindow Press
RegionMouseClick RegionMouseClickCentre RegionVerify ResizeWindow RestoreWindow Select SelectItem
SelectMenuItem SendKeyEvents SendKeys SetChecked SetFocus SetMainframeCursorPos ShowDropdown
Terminate TerminateMainframe TypeText TypeTextAlt UIAButtonPress UIAClickCentre UIAComboSelect
UIAExpandCollapse UIAFocus UIAListSelect UIAMenuItemPress UIAMouseClick UIAPress UIASelect
UIASelectTabItem UIASendKeys Verify WebCheckRadio WebClick WebCloseApplication WebDetachApplication
WebFocus WebHover WebInjectJavascript WebInsertJavascriptFragment WebInvokeJavascript
WebNavigateApplication WebSelectListItem WebSendKeys
'''.split())
READ_IDS = set('''
AAGetAllItems AAGetChecked AAGetDescription AAGetItemCount AAGetName AAGetSelectedItemText
AAGetTable AAGetValue GetAAIdentifier GetAllItems GetChecked GetElementBounds GetElementScreenBounds
GetField GetHTMLIdentifier GetItemCount GetRelativeElementBounds GetSelectedItemText
GetTreenodeChildItems GetUIAIdentifier GetWindowIdentifier GetWindowText HTMLCountItems
HTMLGetAllItems HTMLGetOuterHTML HTMLGetPath HTMLGetSelectedItemText HTMLGetTable IsConnected
IsWindowActive ListReadTextOCR ReadBitmap ReadCurrentValue ReadTextOCR RegionGetElementScreenBounds
SearchTerminal UIAComboGetAllItems UIAComboGetItemCount UIAGetAllItems UIAGetElementScreenBounds
UIAGetItemCount UIAGetName UIAGetPressedState UIAGetRadioCheckedState UIAGetRelativeElementBounds
UIAGetToggleState UIAGetValue UIATableRowCount UIATableRows WebCountListItems WebGetAttribute
WebGetBounds WebGetCheckState WebGetHtml WebGetItems WebGetSelectedItemText WebGetSelectedItems
WebGetSelectedItemsText WebGetTableItems WebGetText WebGetValue WebIsConnected WindowsSnapshot
'''.split())
WRITE_IDS = {'WebWrite'}
WAIT_IDS = set('''
CheckAAIdentifier CheckExists CheckField CheckWindowActive Checked DocumentLoaded GetItemCount
HTMLCheckExistsAndDocumentLoaded WebCheckExists WebCheckParentDocumentLoaded WebGetDocumentURL
'''.split())


def validate_dir(base, show_flow=False, estate=False, strict=False, with_dirs=()):
    files = sorted(glob.glob(os.path.join(base, '*.xml')))
    if not files:
        print(f'(no .xml files in {base})')
        return False

    all_ok = True
    roots = {}
    for fp in files:
        name = os.path.basename(fp)
        try:
            roots[name] = load(fp)
        except Exception as e:
            print(f'[FAIL] {name}: XML error {e}')
            all_ok = False
    extra = {}
    for d in with_dirs or ():
        for fp in sorted(glob.glob(os.path.join(d, '*.xml'))):
            try:
                extra[os.path.basename(fp)] = load(fp)
            except Exception as e:
                print(f'WARNING: --with file {fp}: XML error {e}')
    catalogue = object_catalogue({**extra, **roots})   # stubs: used for checking, not validated

    for name, root in roots.items():
        problems, warnings = [], []
        stages = list(root.iter('stage'))

        if root.tag != 'process':
            problems.append(f'root is <{root.tag}> not <process>')

        pname = root.get('name') or ''
        for pre in ('BPA Object - ', 'BPA Process - '):
            if pname.startswith(pre):
                problems.append(f"internal name carries filename prefix '{pre}' "
                                f"(breaks cross-object resolution)")

        for child in root:
            if child.tag in ('globalcode', 'code', 'references', 'imports', 'language'):
                problems.append(f'<{child.tag}> is a direct child of <process>; it must live '
                                f'inside the Code Options ProcessInfo stage (object will not compile)')
        if list(root.iter('namespaces')):
            problems.append('<namespaces> found: the tag must be <imports>')

        stage_ids, dup_ids = set(), set()
        for st in stages:
            sid = st.get('stageid')
            if sid:
                if sid in stage_ids:
                    dup_ids.add(sid)
                stage_ids.add(sid)
        if dup_ids:
            problems.append(f'{len(dup_ids)} duplicate stageid(s)')

        decl_ids = set()
        for ss in root.iter('subsheet'):
            i = ss.get('subsheetid')
            if i:
                decl_ids.add(i)
        page_ids = set()
        for st in stages:
            if st.get('type') == 'SubSheetInfo':
                si = st.find('subsheetid')
                if si is not None and si.text:
                    page_ids.add(si.text)

        broken = []
        for st in stages:
            for tag in ('onsuccess', 'ontrue', 'onfalse'):
                el = st.find(tag)
                if el is not None and el.text and el.text not in stage_ids:
                    broken.append((st.get('name'), tag, el.text))

        # invalid input expressions: an unquoted text/password literal imports as
        # "Invalid expression for input parameter". Use lit() in the generator.
        bad_exprs = []
        for st in stages:
            for inp in st.iter('input'):
                if inp.get('type') in ('text', 'password') and bad_literal(inp.get('expr')):
                    bad_exprs.append((st.get('name'), inp.get('name'), inp.get('expr')))

        if broken:
            problems.append(f'{len(broken)} broken flow refs')
        if bad_exprs:
            problems.append(f'{len(bad_exprs)} invalid literal expr(s)')
        missing_info = decl_ids - page_ids
        missing_decl = page_ids - decl_ids

        # --- a process cannot run Code stages -------------------------------------
        # Process Studio has no Code stage; the importer accepts one, Process Validation
        # does not flag it, and at run time it fails with "could not be run because it was
        # added or modified since the object was started" (only objects compile code).
        if root.get('type') == 'process':
            pcode = [st.get('name') for st in stages if st.get('type') == 'Code']
            if pcode:
                problems.append(f'{len(pcode)} Code stage(s) in a PROCESS (Blue Prism processes cannot '
                                f'run code; make them actions of an object): {pcode[:6]}')

        # --- every sheet runs from a linked Start to an End ------------------------
        # The object's Initialise (main) sheet included: Blue Prism runs it once per session
        # and an unlinked Start there means no action of the object ever runs (no detail in
        # the exception either). Processes: Main is the sheet that is started.
        sheet_names = {(st.find('subsheetid').text if st.find('subsheetid') is not None else None):
                       st.get('name') for st in stages if st.get('type') == 'SubSheetInfo'}
        sheet_names.setdefault(None, 'Main' if root.get('type') == 'process' else 'Initialise')
        sheets = {}
        for st in stages:
            sheets.setdefault(page_of(st), {})[st.get('stageid')] = st
        for sid in sheet_names:
            sheets.setdefault(sid, {})
        for sid, sts in sorted(sheets.items(), key=lambda kv: sheet_names.get(kv[0], '')):
            label = sheet_names.get(sid, '?')
            starts = [st for st in sts.values() if st.get('type') == 'Start']
            if len(starts) != 1:
                problems.append(f"sheet '{label}': {len(starts)} Start stages (needs exactly one)")
                continue
            pair_end = {}
            for st in sts.values():
                if st.get('type') in ('ChoiceEnd', 'WaitEnd', 'LoopEnd'):
                    pair_end.setdefault((st.findtext('groupid') or '').strip(), []).append(st.get('stageid'))
            reach, todo = set(), [starts[0].get('stageid')]
            while todo:
                x = todo.pop()
                if x in reach or x not in sts:
                    continue
                reach.add(x)
                todo.extend(_targets(sts[x]))      # onsuccess/ontrue/onfalse + per-choice links
                if sts[x].get('type') in ('ChoiceStart', 'WaitStart', 'LoopStart'):
                    todo.extend(pair_end.get((sts[x].findtext('groupid') or '').strip(), []))
            if not any(sts[x].get('type') in ('End', 'Exception') for x in reach):
                problems.append(f"sheet '{label}': Start is not linked to an End "
                                f"(nothing on this sheet runs)")
        if missing_info:
            problems.append(f'{len(missing_info)} subsheet decls without SubSheetInfo')
        if missing_decl:
            problems.append(f'{len(missing_decl)} SubSheetInfo without decl')

        # --- per-page data items ------------------------------------------
        data_by_page = {}
        types_by_page = {}
        for st in stages:
            if st.get('type') in ('Data', 'Collection'):
                pg = page_of(st)
                data_by_page.setdefault(pg, set()).add(st.get('name'))
                types_by_page.setdefault(pg, {})[st.get('name')] = st.get('type')
            if st.get('type') == 'Data' and (st.findtext('datatype') or '') == 'collection':
                problems.append(f"Data stage '{st.get('name')}' has datatype collection: must be "
                                f"a type=\"Collection\" stage (ForEach/[Coll.Field] break)")

        # main-page items are visible everywhere UNLESS private ("Hide from other pages"); page items locally
        # (and, as Blue Prism's own training release shows, so is an unhidden item of ANY page)
        private_main = {st.get('name') for st in stages if st.get('type') in ('Data', 'Collection')
                        and page_of(st) is None and st.find('private') is not None}
        public_any = {st.get('name') for st in stages if st.get('type') in ('Data', 'Collection')
                      and st.find('private') is None}
        hidden_uses = set()
        # two items of one name that are both visible everywhere: Blue Prism's own validation calls it a conflict (an error)
        ss_names = {(x.findtext('subsheetid') or '').strip(): x.get('name') for x in stages if x.get('type') == 'SubSheetInfo'}
        seen_public = {}
        for st in stages:
            if st.get('type') in ('Data', 'Collection') and st.find('private') is None:
                seen_public.setdefault(st.get('name'), []).append(ss_names.get(page_of(st), str(page_of(st))) if page_of(st) is not None else 'Main Page')
        clash = {n: pgs for n, pgs in seen_public.items() if len(set(pgs)) > 1}
        if clash:
            problems.append(f'{len(clash)} data item(s) declared on more than one page without "Hide from other pages" (Blue Prism: "conflicts with the data item .. on page .."): ' +
                            ', '.join(f"'{n}' on {sorted(set(p))}" for n, p in sorted(clash.items())[:5]) +
                            '. Declare an Environment / Session item once (the generator does); every page sees it')

        def visible(pg):
            return data_by_page.get(pg, set()) | public_any

        # outputs must land on an existing data item (gotcha: null-ref, no clue)
        for st in stages:
            if st.get('type') in ('Start', 'End'):
                continue   # Start/End params ARE the data items (checked below)
            for out in st.iter('output'):
                tgt = out.get('stage')
                if tgt and tgt not in visible(page_of(st)):
                    problems.append(f"stage '{st.get('name')}': output '{out.get('name')}' -> "
                                    f"'{tgt}' is not a data item on this page")
        for st in stages:
            if st.get('type') in ('Start', 'End'):
                for prm in list(st.iter('input')) + list(st.iter('output')):
                    tgt = prm.get('stage')
                    if tgt and tgt not in visible(page_of(st)):
                        problems.append(f"{st.get('type')} param '{prm.get('name')}' -> '{tgt}' "
                                        f"has no data item on its page")

        # loops
        starts, ends = {}, {}
        for st in stages:
            t = st.get('type')
            if t in ('LoopStart', 'LoopEnd'):
                g = (st.findtext('groupid') or '').strip()
                (starts if t == 'LoopStart' else ends).setdefault(g, []).append(st.get('name'))
            if t == 'LoopStart':
                coll = (st.findtext('loopdata') or '').strip()
                if (types_by_page.get(page_of(st), {}).get(coll) != 'Collection'
                        and types_by_page.get(None, {}).get(coll) != 'Collection'):
                    problems.append(f"loop '{st.get('name')}': loopdata '{coll}' is not a "
                                    f"Collection stage on this page")
        for g in set(starts) | set(ends):
            if len(starts.get(g, [])) != 1 or len(ends.get(g, [])) != 1:
                problems.append(f'LoopStart/LoopEnd groupid {g[:8]}.. does not pair 1:1 '
                                f'(starts={starts.get(g, [])}, ends={ends.get(g, [])})')

        # [Item] references (warn: env vars / session vars are legit unknowns)
        unresolved = set()
        for st in stages:
            exprs = []
            for inp in st.iter('input'):
                exprs.append(inp.get('expr') or '')
            d = st.find('decision')
            if d is not None:
                exprs.append(d.get('expression') or '')
            for c in st.iter('calculation'):
                exprs.append(c.get('expression') or '')
            ex = st.find('exception')
            if ex is not None:
                exprs.append(ex.get('detail') or '')
            for e in exprs:
                for ref in REF_RE.findall(QUOTED_RE.sub('', e)):
                    base_name = ref.split('.')[0]
                    if base_name not in visible(page_of(st)):
                        if base_name in private_main and page_of(st) is not None:
                            hidden_uses.add((st.get('name'), base_name))
                        else:
                            unresolved.add((st.get('name'), base_name))
        if hidden_uses:
            # not a warning: Blue Prism stops with "Data item not found" the first time the stage runs
            problems.append(f'{len(hidden_uses)} use(s) of a Main Page data item that is PRIVATE (hidden from other pages) on another page: ' +
                            ', '.join(sorted(f"'{s}' uses [{r}]" for s, r in hidden_uses)[:6]) +
                            '. Declare the item as a global (not private) or pass it to the page as an input')
        if unresolved:
            warnings.append(f'{len(unresolved)} [ref](s) with no data item on the page: ' +
                            ', '.join(sorted(f'{s}->[{r}]' for s, r in unresolved)[:6]))

        # Application Modeller: every element a stage uses must exist in this object's model
        elements = {}
        ad = root.find('appdef')
        if ad is not None:
            def walk(e, prefix):
                for c in e.findall('element'):
                    path = f'{prefix}/{c.get("name")}' if prefix else c.get('name')
                    attrs = c.find('attributes')
                    # the application ROOT never has attributes (its settings are the app type
                    # info) -- verified on real exports; it is not something to spy
                    is_root = (c.findtext('type') or '') == 'Application'
                    elements[(c.findtext('id') or '').strip()] = (path, is_root or (attrs is not None and len(attrs) > 0))
                    walk(c, path)
            walk(ad, '')
        used_elements = set()
        for st in stages:
            if st.get('type') not in ('Read', 'Write', 'Navigate', 'WaitStart'):
                continue
            for el in st.iter('element'):
                eid = (el.get('id') or '').strip()
                if not eid:
                    continue
                if eid not in elements:
                    problems.append(f"stage '{st.get('name')}': element id {eid[:8]}.. is not in this "
                                    f"object's Application Modeller")
                else:
                    used_elements.add(eid)
        to_spy = sorted(elements[e][0] for e in used_elements if not elements[e][1])
        if to_spy:
            warnings.append(f'{len(to_spy)} element(s) used by stages are NOT SPIED yet -- Identify '
                            f'them in Application Modeller: ' + '; '.join(to_spy))

        # page calls: inputs must be the target page's Start parameter names (exact match)
        start_ins = {}
        for st in stages:
            if st.get('type') == 'Start' and st.find('subsheetid') is not None:
                start_ins[st.find('subsheetid').text] = [i.get('name') for i in st.iter('input')]
        for st in stages:
            if st.get('type') != 'SubSheet':
                continue
            tgt = (st.findtext('processid') or '').strip()
            if tgt not in start_ins:
                continue
            for inp in st.iter('input'):
                if inp.get('name') not in start_ins[tgt]:
                    problems.append(f"page call '{st.get('name')}': input '{inp.get('name')}' is not a "
                                    f"Start parameter of the called page (has {start_ins[tgt]})")

        # action ids of Navigate / Read / Write steps and Wait conditions
        bad_ids = set()
        for st in stages:
            known = {'Navigate': NAVIGATE_IDS, 'Read': READ_IDS | NAVIGATE_IDS, 'Write': WRITE_IDS, 'WaitStart': WAIT_IDS}.get(st.get('type'))
            if known is None:
                continue
            for tag in ('action', 'condition'):
                for a in st.iter(tag):
                    i = (a.findtext('id') or '').strip()
                    if i and i not in known:
                        bad_ids.add(f"{st.get('type')} '{st.get('name')}': {i}")
        # an action belongs to the spy mode of its element: a UIA element takes UIA ids, not Press / GetWindowText
        el_type = {}
        for e in root.iter('element'):
            if e.find('id') is not None and e.find('type') is not None:
                el_type[(e.findtext('id') or '').strip().lower()] = (e.findtext('type') or '').strip()
        def mode(name, prefixes=('UIA', 'AA', 'HTML', 'Web', 'SAP', 'Region')):
            return next((p for p in prefixes if name.startswith(p) and name[len(p):len(p) + 1].isupper()), '')
        NEUTRAL = {'CheckExists', 'Verify', 'Default', 'SendKeys', 'SendKeyEvents', 'ActivateApp', 'ReadCurrentValue', 'GetElementBounds',
                   'GetElementScreenBounds', 'GetRelativeElementBounds', 'ReadTextOCR', 'ReadBitmap', 'GetUIAIdentifier', 'GetAAIdentifier', 'GetHTMLIdentifier'}
        wrong_mode = set()
        for st in stages:
            if st.get('type') not in ('Navigate', 'Read', 'Write', 'WaitStart'):
                continue
            for step in list(st.iter('step')) + list(st.iter('choice')):
                e, a = step.find('element'), step.find('action') if step.find('action') is not None else step.find('condition')
                t = el_type.get((e.get('id') or '').lower(), '') if e is not None else ''
                i = (a.findtext('id') or '').strip() if a is not None else ''
                if not t or t == 'Application' or not i or i in NEUTRAL:
                    if t == 'UIAElement' and st.get('type') == 'Write':
                        wrong_mode.add(f"Write '{st.get('name')}' into a UIAElement (real objects write into a UIAEdit)")
                    continue
                if mode(t) in ('UIA', 'AA', 'HTML', 'Web') and mode(i) != mode(t):
                    wrong_mode.add(f"{st.get('type')} '{st.get('name')}': {i} on a {t}")
        if wrong_mode:
            warnings.append(f'{len(wrong_mode)} action(s) that do not belong to the spy mode / type of their element (reference/action-ids.md): ' +
                            ', '.join(sorted(wrong_mode)[:6]))
        # compulsory arguments (Blue Prism's Validate: "Row 1 does not supply a value to the compulsory parameter 'First Row Number'")
        no_args = set()
        for st in stages:
            for a in st.iter('action'):
                need = {'UIATableRows': ['firstrownumber', 'lastrownumber']}.get((a.findtext('id') or '').strip())
                if need:
                    got = {(g.findtext('id') or '').strip(): (g.findtext('value') or '').strip() for g in a.iter('argument')}
                    miss = [n for n in need if not got.get(n)]
                    if miss:
                        no_args.add(f"{st.get('type')} '{st.get('name')}': {a.findtext('id')} without {', '.join(miss)}")
        if no_args:
            problems.append(f'{len(no_args)} action(s) without a compulsory argument (Blue Prism validation error): ' + ', '.join(sorted(no_args)[:6]))
        if bad_ids:
            msg = (f'{len(bad_ids)} Application Modeller action id(s) not among those seen in real exports (reference/action-ids.md); '
                   'Blue Prism refuses to import an object with an id it does not know: ' + ', '.join(sorted(bad_ids)[:6]))
            (problems if strict else warnings).append(msg)

        # Blocks may not overlap or nest (Blue Prism: "Block overlaps another block", an error)
        blocks_by_page = {}
        for st in stages:
            if st.get('type') == 'Block':
                d = st.find('display')      # 7.x: <display x y w h />; exports of 6.x and older: <displayx> .. <displayheight>
                g = ([d.get(k) for k in 'xywh'] if d is not None else
                     [st.findtext(k) for k in ('displayx', 'displayy', 'displaywidth', 'displayheight')])
                blocks_by_page.setdefault(page_of(st), []).append(
                    (st.get('name'),) + tuple(int(float(v or 0)) for v in g))
        for pg, bl in blocks_by_page.items():
            for i in range(len(bl)):
                for j in range(i + 1, len(bl)):
                    a, b = bl[i], bl[j]
                    if a[1] < b[1] + b[3] and b[1] < a[1] + a[3] and a[2] < b[2] + b[4] and b[2] < a[2] + a[4]:
                        problems.append(f"Block '{a[0]}' overlaps Block '{b[0]}' (Blue Prism forbids nested/"
                                        f"overlapping Blocks; make the outer scope the page)")

        # cross-object calls into objects present in this directory
        unchecked = set()
        for st in stages:
            if st.get('type') != 'Action':
                continue
            res = st.find('resource')
            if res is None:
                continue
            obj, act = res.get('object'), res.get('action')
            if obj in INTERNAL_OBJECTS:
                problems.append(f"stage '{st.get('name')}': internal object referenced by its display name "
                                f"'{obj}'; Blue Prism needs the class name '{INTERNAL_OBJECTS[obj]}' "
                                f"(imports as \"does not seem to be installed\")")
            obj = INTERNAL_BY_CLASS.get(obj, obj)     # stubs carry the display name
            if obj not in catalogue:
                unchecked.add(obj)
                continue
            pages = catalogue[obj]
            if act not in pages:
                problems.append(f"stage '{st.get('name')}': object '{obj}' has no action "
                                f"'{act}' (exact match). Has: {sorted(pages)[:8]}")
                continue
            published, ins = pages[act]
            if not published:
                problems.append(f"stage '{st.get('name')}': '{obj}'.'{act}' is not published")
            for inp in st.iter('input'):
                if inp.get('name') not in ins:
                    problems.append(f"stage '{st.get('name')}': input '{inp.get('name')}' is not a "
                                    f"Start input of '{obj}'.'{act}' (has {ins})")

        # Python-format slots fed to C# string.Format -> FormatException at runtime
        fmt_bad = []
        for st in stages:
            if st.get('type') not in ('Code', 'ProcessInfo'):
                continue
            body = st.findtext('code') or ''
            for m in re.finditer(r'(?:string|String)\.Format\s*\(([^;]*)', body):
                if '{}' in m.group(1):
                    fmt_bad.append(st.get('name'))
        if fmt_bad:
            problems.append(f"string.Format with a Python-style '{{}}' slot in: {sorted(set(fmt_bad))} "
                            f"(throws FormatException; use .Replace(\"{{}}\", ...))")

        # non-ASCII
        nonascii = [st.get('name') for st in stages
                    if any(ord(c) > 126 for c in (st.get('name') or '') + (st.findtext('narrative') or ''))]
        if nonascii:
            warnings.append(f'non-ASCII in {len(nonascii)} stage name/narrative(s): {nonascii[:4]}')

        if estate:
            subsheets = list(root.iter('subsheet'))
            artifact_type = root.get('type')
            if not any(st.get('type') == 'ProcessInfo' for st in root.iter('stage')):
                problems.append('estate: no Code Options (ProcessInfo) stage on the main page -- objects null-ref at the first call, processes cannot open Process Info / be published')
            if artifact_type == 'object':
                if not subsheets:
                    problems.append('estate: object has no action pages')
                if any(st.get('type') == 'ProcessInfo' for st in root.iter('stage')):
                    first = subsheets[0]
                    first_name = (first.findtext('name') or '').strip()
                    if first_name != 'Clean Up' or first.get('type') != 'CleanUp':
                        problems.append('estate: first object page must be Clean Up/CleanUp')
                    unpublished_cleanup = [ss for ss in subsheets
                                           if (ss.findtext('name') or '').strip() == 'Clean Up'
                                           and (ss.get('published') or '').lower() != 'true']
                    if unpublished_cleanup:
                        problems.append('estate: Clean Up page must be published')
            elif artifact_type == 'process':
                published_pages = [(ss.findtext('name') or '').strip() for ss in subsheets
                                   if (ss.get('published') or '').lower() == 'true']
                if published_pages:
                    problems.append('estate: process subsheets must be unpublished: ' +
                                    ', '.join(published_pages))

            bad_decisions = [st.get('name') for st in stages
                             if st.get('type') == 'Decision'
                             and not (st.get('name') or '').rstrip().endswith('?')]
            if bad_decisions:
                problems.append(f"estate: {len(bad_decisions)} Decision name(s) lack '?': " +
                                ', '.join(bad_decisions[:5]))

            bad_exception_types = []
            for st in stages:
                if st.get('type') != 'Exception':
                    continue
                ex = st.find('exception')
                if ex is None or ex.get('usecurrent') == 'yes':
                    continue
                ex_type = (ex.get('type') or '').strip()
                if ex_type not in ('System Exception', 'Business Exception', 'Runtime Exception'):
                    bad_exception_types.append((st.get('name'), ex_type))
            if bad_exception_types:
                problems.append(f'estate: {len(bad_exception_types)} invalid exception type(s): ' +
                                ', '.join(f'{n}={t!r}' for n, t in bad_exception_types[:5]))

            for info in [st for st in stages if st.get('type') == 'ProcessInfo']:
                if (info.findtext('globalcode') or '').strip():
                    problems.append('estate: <globalcode> must be empty')
                code = info.findtext('code') or ''
                if code.strip() and info.findtext('language') != 'csharp':
                    problems.append('estate: new shared code must use csharp')

            waits = [st for st in stages if st.get('type') == 'WaitStart']
            wait_ends = [st for st in stages if st.get('type') == 'WaitEnd']
            if len(waits) != len(wait_ends):
                problems.append(f'estate: WaitStart/WaitEnd mismatch ({len(waits)}/{len(wait_ends)})')

        # Reachability: a non-main page is invoked by a SubSheet (page-call) stage
        # whose <processid> equals that page's subsheetid. A process page that is
        # never referenced is ORPHANED -- flag it instead of passing it as ALL
        # CLEAN. (Objects are called externally by action name, so this
        # reachability rule only applies to type="process".)
        is_process = root.get('type') == 'process'
        called_ssids = set()
        for st in stages:
            pidel = st.find('processid')
            if pidel is not None and pidel.text:
                called_ssids.add(pidel.text)
        orphan_pages = []
        for st in stages:
            if st.get('type') == 'SubSheetInfo':
                si = st.find('subsheetid')
                if si is not None and si.text and si.text not in called_ssids:
                    orphan_pages.append(st.get('name'))
        if orphan_pages and is_process:
            problems.append(f'{len(orphan_pages)} unreachable page(s) '
                            f'(not called by any page-ref): ' + ', '.join(orphan_pages))

        # Same-name collisions: a page name that equals an action/decision name
        # is misleading in the --flow report (looks like a page call, is an
        # object call).
        page_names = {st.get('name') for st in stages if st.get('type') == 'SubSheetInfo'}
        step_names = {st.get('name') for st in stages
                      if st.get('type') in ('Action', 'Decision', 'Code')}
        collisions = page_names & step_names
        if collisions and root.get('type') == 'process':
            problems.append(f'{len(collisions)} page/stage name collision(s): ' +
                            ', '.join(sorted(collisions)))


        if strict:
            problems.extend(strict_checks(root, stages))

        status = 'OK  ' if not problems else 'FAIL'
        if problems:
            all_ok = False
        print(f'[{status}] {name}: stages={len(stage_ids)} pages={len(page_ids)} '
              f'decls={len(decl_ids)}' + ((' -> ' + '; '.join(problems)) if problems else ''))
        for w in warnings:
            print(f'       WARN {w}')
        for b in broken[:5]:
            print(f'       broken: {b}')
        for e in bad_exprs[:5]:
            print(f'       bad expr: stage={e[0]!r} input={e[1]!r} expr={e[2]!r} '
                  f'(unquoted text literal -- wrap with lit())')

        # Flow-target report: resolve every link to the TARGET stage's name so
        # you can actually eyeball where decisions/gotos/loops go. A link that
        # points at an End stage is flagged (*) because that is where a mistyped
        # goto/decision target silently falls back to -- the usual hidden bug.
        if unchecked:
            print(f'       WARN calls to objects NOT checked (not in dir, no --with): {sorted(unchecked)}')
        if show_flow:
            id2name, id2type, id2stage = {}, {}, {}
            for st in stages:
                sid = st.get('stageid')
                if sid:
                    id2name[sid] = st.get('name')
                    id2type[sid] = st.get('type')
                    id2stage[sid] = st
            for st in stages:
                stype = st.get('type')
                if stype not in ('Decision', 'Action', 'Code', 'LoopStart', 'LoopEnd', 'Start',
                                 'SubSheet', 'Calculation', 'MultipleCalculation',
                                 'ChoiceStart', 'ChoiceEnd', 'Resume', 'Recover',
                                 'Read', 'Write', 'Navigate', 'WaitStart', 'WaitEnd'):
                    continue
                for tag, el in [(t, e) for t in ('onsuccess', 'ontrue', 'onfalse') for e in st.iter(t)]:
                    if el is None or not el.text:
                        continue
                    # follow routing anchors to the real target
                    cur, hops = el.text, 0
                    while id2type.get(cur) == 'Anchor' and hops < 50:
                        nxt_el = id2stage[cur].find('onsuccess')
                        if nxt_el is None or not nxt_el.text:
                            break
                        cur, hops = nxt_el.text, hops + 1
                    tgt = id2name.get(cur, '??')
                    via = f' (via {hops} anchors)' if hops else ''
                    flag = ' *(End)' if id2type.get(cur) == 'End' else ''
                    print(f'         {st.get("name")!r:32} --{tag}--> {tgt!r}{flag}{via}')
            print()
    print('ALL CLEAN' if all_ok else 'PROBLEMS FOUND')
    return all_ok


if __name__ == '__main__':
    if '-h' in sys.argv or '--help' in sys.argv:
        print(__doc__)
        sys.exit(0)
    args = [a for a in sys.argv[1:] if not a.startswith('-')]
    flags = [a for a in sys.argv[1:] if a.startswith('-')]
    with_dirs = [sys.argv[i + 1] for i, a in enumerate(sys.argv) if a == '--with' and i + 1 < len(sys.argv)]
    args = [a for a in args if a not in with_dirs]
    ok = validate_dir(args[0] if args else 'out', with_dirs=with_dirs,
                      show_flow=('--flow' in flags or '-f' in flags),
                      estate='--estate' in flags,
                      strict='--strict' in flags)
    sys.exit(0 if ok else 1)
