"""The Blue Prism internal objects as bprun simulates them: every action once, outputs and exception texts checked.
Run: python test/internal_test.py  (prints INTERNAL-TEST PASS)"""
import os, sys, datetime
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'lib'))
import bprun
from bprun import Runtime, Collection, BPException, internal_name
from decimal import Decimal

fails = []
def ok(name, cond, detail=''):
    print(('PASS ' if cond else 'FAIL ') + name + ('' if cond else '  | ' + str(detail)[:300]))
    if not cond:
        fails.append(name)
def throws(fn, text):
    try:
        fn(); return False
    except BPException as e:
        return text in e.detail or (text, e.detail)

logs = []
estate = {'locks': {'Held Elsewhere': 'robot 2'}, 'calendars': {'Bank': {'working_days': [0, 1, 2, 3, 4], 'public_holidays': {'2026-12-25': 'Christmas'}, 'other_holidays': ['2026-12-31']}}}
rt = Runtime([], None, {}, {'App Login': ['alice', 's3cret'], 'Api': {'username': 'svc', 'password': 'p', 'expiry': '2027-01-01', 'properties': {'Token': 'abc'}}},
             log=logs.append, queues={'Orders': {'key': 'Ref', 'attempts': 2, 'items': [{'Ref': 'A1', 'Amount': '10'}, {'Ref': 'A2', 'Amount': '20'}]}, 'Empty': []}, estate=estate)
call = rt.call_object
C = lambda rows, cols=None: Collection(cols or [(k, 'text') for k in rows[0]], rows)

# --- names
ok('internal: class names resolve', internal_name('Blueprism.Automate.clsWorkQueuesActions') == 'Work Queues' and internal_name('BluePrism.AutomateAppCore.clsEnvironmentLockingBusinessObject') == 'Environment Locking'
   and internal_name('Blueprism.AutomateProcessCore.clsCollectionActions') == 'Collections' and internal_name('Blueprism.Automate.clsEventLogActions') == 'Event Log' and internal_name('Utility - Strings') is None)

# --- Work Queues
WQ = 'Blueprism.Automate.clsWorkQueuesActions'
r = call(WQ, 'Add To Queue', {'Queue Name': 'Orders', 'Data': C([{'Ref': 'B1', 'Amount': '5'}]), 'Priority': Decimal(1), 'Tags': 'urgent;de', 'Status': 'new'})
ok('wq: Add To Queue returns the ids', len(r['Item IDs'].rows) == 1 and r['Item ID'] == r['Item IDs'].rows[0]['Item ID'])
pend = call(WQ, 'Get Pending Items', {'Queue Name': 'Orders'})['Items']
ok('wq: seed items + added one are pending, keyed by the key field', [x['Key'] for x in pend.rows] == ['A1', 'A2', 'B1'] and pend.rows[2]['Tags'] == 'de;urgent', pend.rows)
g = call(WQ, 'Get Next Item', {'Queue Name': 'Orders'})
ok('wq: Get Next Item takes the lowest priority number first, then the oldest', g['Key Value'] == 'A1' and g['Attempt'] == Decimal(1) and g['Data'].rows[0]['Amount'] == '10', g)
g2 = call(WQ, 'Get Next Item', {'Queue Name': 'Orders', 'Tag Filter': '+urgent'})
ok('wq: tag filter', g2['Key Value'] == 'B1', g2)
ok('wq: locked items are listed as locked', len(call(WQ, 'Get Locked Items', {'Queue Name': 'Orders'})['Items'].rows) == 2)
g3 = call(WQ, 'Get Next Item', {'Queue Name': 'Orders', 'Key Filter': 'nope'})
ok('wq: no match = empty id, empty data, no exception', g3['Item ID'] == '' and g3['Data'].rows == [])
call(WQ, 'Update Status', {'Item ID': g['Item ID'], 'Status': 'half'}); call(WQ, 'Tag Item', {'Item ID': g['Item ID'], 'Tag': 'seen'})
d = call(WQ, 'Get Item Data', {'Item ID': g['Item ID']})
ok('wq: Update Status / Tag Item / Get Item Data', d['Status'] == 'half' and d['Tags'] == 'seen' and d['Data'].rows[0]['Ref'] == 'A1', d)
call(WQ, 'Set Data', {'Item ID': g['Item ID'], 'Data': C([{'Ref': 'A1', 'Amount': '11'}])})
ok('wq: Set Data replaces the data', call(WQ, 'Get Item Data', {'Item ID': g['Item ID']})['Data'].rows[0]['Amount'] == '11')
call(WQ, 'Mark Completed', {'Item ID': g['Item ID']})
ok('wq: Mark Completed', [x['Key'] for x in call(WQ, 'Get Completed Items', {'Queue Name': 'Orders'})['Items'].rows] == ['A1'])
ok('wq: Mark Completed twice = not locked', throws(lambda: call(WQ, 'Mark Completed', {'Item ID': g['Item ID']}), 'is not locked') is True)
ok('wq: unknown item id', throws(lambda: call(WQ, 'Mark Completed', {'Item ID': 'xyz'}), 'No queue item found with ID xyz') is True)
me = call(WQ, 'Mark Exception', {'Item ID': g2['Item ID'], 'Exception Reason': 'boom', 'Retry': True})
ok('wq: Mark Exception with retry under max attempts gives a new pending item with the attempt count carried', me['New Item ID'] != '' and call(WQ, 'Get Item Data', {'Item ID': me['New Item ID']})['Attempts'] == Decimal(1))
g4 = call(WQ, 'Get Next Item', {'Queue Name': 'Orders', 'Key Filter': 'B1'})
me2 = call(WQ, 'Mark Exception', {'Item ID': g4['Item ID'], 'Exception Reason': 'boom again', 'Retry': True})
ok('wq: retry stops at max attempts (2 for Orders)', g4['Attempt'] == Decimal(2) and me2['New Item ID'] == '', (g4['Attempt'], me2))
ok('wq: exception items listed with the reason', [x['Exception Reason'] for x in call(WQ, 'Get Exception Items', {'Queue Name': 'Orders'})['Items'].rows] == ['boom', 'boom again'])
g5 = call(WQ, 'Get Next Item', {'Queue Name': 'Orders'}); call(WQ, 'Defer', {'Item ID': g5['Item ID'], 'Until': '2999-01-01'})
ok('wq: a deferred item is not served', g5['Key Value'] == 'A2' and call(WQ, 'Get Next Item', {'Queue Name': 'Orders'})['Item ID'] == '')
ok('wq: Is Item In Queue by key', call(WQ, 'Is Item In Queue', {'Queue Name': 'Orders', 'Key': 'A2'})['Result'] is True and call(WQ, 'Is Item In Queue', {'Queue Name': 'Orders', 'Key': 'Z'})['Result'] is False)
rep = call(WQ, 'Get Report Data', {'Queue Name': 'Orders'})
ok('wq: Get Report Data counts', (rep['Total Items'], rep['Completed'], rep['Exceptioned'], rep['Pending']) == (4, 1, 2, 1), rep)
cp = call(WQ, 'Copy To Queue', {'Item ID': g['Item ID'], 'Queue Name': 'Empty'})
ok('wq: Copy To Queue', cp['New Item ID'] and len(call(WQ, 'Get Pending Items', {'Queue Name': 'Empty'})['Items'].rows) == 1)
dl = call(WQ, 'Delete Processed Items', {'Queue Name': 'Orders'})
ok('wq: Delete Processed Items removes completed + exceptioned', dl['Count'] == Decimal(3) and call(WQ, 'Get Report Data', {'Queue Name': 'Orders'})['Total Items'] == Decimal(1))
ok('wq: an unknown action says so', throws(lambda: call('Work Queues', 'Frobnicate', {}), 'Work Queues.Frobnicate not simulated') is True)

# --- Work Queues: the actions and parameter names of the real 7.2.1 list
ok('wq: Get Queue Names', [x['Queue Name'] for x in call(WQ, 'Get Queue Names', {})['Queue Names'].rows] == ['Empty', 'Orders'])
rt.queues.configure('Q2', 'Ref', 3)
call(WQ, 'Add To Queue', {'Queue Name': 'Q2', 'Data': C([{'Ref': 'X1'}, {'Ref': 'X2'}, {'Ref': 'X3'}]), 'Tags': 'a', 'Batch Size': Decimal(10)})
ok('wq: Get Pending Items gives Pending Items, with Maximum and Skip', len(call(WQ, 'Get Pending Items', {'Queue Name': 'Q2'})['Pending Items'].rows) == 3 and len(call(WQ, 'Get Pending Items', {'Queue Name': 'Q2', 'Maximum': Decimal(1), 'Skip': Decimal(1)})['Pending Items'].rows) == 1)
ids = [x['Item ID'] for x in call(WQ, 'Get Pending Items', {'Queue Name': 'Q2'})['Pending Items'].rows]
b1 = call(WQ, 'Get Item By ID', {'Queue Name': 'Q2', 'Item ID': ids[1]})
ok('wq: Get Item By ID locks that item', b1['Item ID'] == ids[1] and b1['Attempts'] == Decimal(1) and [x['Item ID'] for x in call(WQ, 'Get Locked Items', {'Queue Name': 'Q2', 'Tags': '+a'})['Locked Items'].rows] == [ids[1]])
ok('wq: Get Item By ID on a locked item gives nothing', call(WQ, 'Get Item By ID', {'Queue Name': 'Q2', 'Item ID': ids[1]})['Item ID'] == '')
ok('wq: Delete Item refuses a locked item', throws(lambda: call(WQ, 'Delete Item', {'Item ID': ids[1]}), 'is locked') is True)
ok('wq: Unlock Item says whether it was locked', call(WQ, 'Unlock Item', {'Item ID': ids[1]})['Unlocked'] is True and call(WQ, 'Unlock Item', {'Item ID': ids[1]})['Unlocked'] is False)
call(WQ, 'Delete Item', {'Item ID': ids[2]})
ok('wq: Delete Item', len(call(WQ, 'Get Pending Items', {'Queue Name': 'Q2'})['Pending Items'].rows) == 2)
n1 = call(WQ, 'Get Next Item', {'Queue Name': 'Q2'}); call(WQ, 'Mark Completed', {'Item ID': n1['Item ID']})
d = call(WQ, 'Get Item Data', {'Item ID': n1['Item ID']})
ok('wq: Get Item Data has every output of the real list', set(p['name'] for p in next(a for a in next(o for o in __import__('json').load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'internal', 'internal.json')))['objects'] if o['object'] == 'Work Queues')['actions'] if a['name'] == 'Get Item Data')['outputs']) <= set(d) and d['Completed DateTime'] != '' and d['Exception DateTime'] == '' and d['Worktime'].startswith('0.00:00:0'), d)
ok('wq: Completed Items / Maximum Rows', len(call(WQ, 'Get Completed Items', {'Queue Name': 'Q2', 'Maximum Rows': Decimal(1)})['Completed Items'].rows) == 1 and call(WQ, 'Get Exception Items', {'Queue Name': 'Q2'})['Exception Items'].rows == [])
iq = call(WQ, 'Is Item In Queue', {'Queue Name': 'Q2', 'Key': 'X1'})
ok('wq: Is Item In Queue counts completed items unless told not to', iq['Result'] is True and len(iq['Item IDs'].rows) == 1 and call(WQ, 'Is Item In Queue', {'Queue Name': 'Q2', 'Key': 'X1', 'Include Completed': False})['Result'] is False)
rep = call(WQ, 'Get Report Data', {'Queue Name': 'Q2'})
ok('wq: Get Report Data real outputs', rep['Item Count'] == Decimal(2) and len(rep['Item IDs'].rows) == 2 and rep['Time Total'].count(':') == 2 and call(WQ, 'Get Report Data', {'Queue Name': 'Q2', 'Include unworked items?': False})['Item Count'] == Decimal(1), rep)
cp = call(WQ, 'Copy Item to Queue', {'Item ID': n1['Item ID'], 'Queue Name': 'Q3', 'Tag Mask': '+copied;-a'})
ok('wq: Copy Item to Queue with a tag mask', call(WQ, 'Get Item Data', {'Item ID': cp['New Item ID']})['Tags'] == 'copied')
tx = call(WQ, 'Get Transaction Data', {'Excluded Queue Names': C([{'Queue Name': 'Orders'}, {'Queue Name': 'Empty'}])})
ok('wq: Get Transaction Data counts what happened', (tx['Created'], tx['Completed'], tx['Deletions'], tx['Locked']) == (4, 1, 1, 2) and tx['Total Count'] == Decimal(8) and [x['Queue Name'] for x in tx['Included Queues'].rows] == ['Q2', 'Q3'], tx)
ok('wq: Get Transaction Data honours the Count flags', call(WQ, 'Get Transaction Data', {'Count item creations': False})['Created'] == Decimal(0))
ok('wq: Delete Processed Items / Deletion Count / all queues', call(WQ, 'Delete Processed Items', {'Queue Name': 'Q3', 'Delete From All Queues': True})['Deletion Count'] == Decimal(1))

# --- Credentials
CR = 'Blueprism.Automate.clsCredentialsActions'
ok('cred: Get (list form)', call(CR, 'Get', {'Credentials Name': 'App Login'}) == {'Username': 'alice', 'Password': 's3cret', 'Expiry Date': '', 'Status': 'Valid'})
ok('cred: Get (dict form) + Get Property', call(CR, 'Get', {'Credentials Name': 'Api'})['Expiry Date'] == '2027-01-01' and call(CR, 'Get Property', {'Credentials Name': 'Api', 'Property Name': 'Token'})['Property Value'] == 'abc')
ok('cred: missing', throws(lambda: call(CR, 'Get', {'Credentials Name': 'Nope'}), "Credential 'Nope' not found") is True)
call(CR, 'Set Property', {'Credentials Name': 'Api', 'Property Name': 'Token', 'Property Value': 'new'})
ok('cred: Set Property', call(CR, 'Get Property', {'Credentials Name': 'Api', 'Property Name': 'Token'})['Property Value'] == 'new')
pw = call(CR, 'Generate Password', {'Length': Decimal(12), 'Use Upper Case': True, 'Use Numeric': True, 'Additional Characters': '#'})['Password']
ok('cred: Generate Password uses the classes asked for', len(pw) == 12 and set(pw) <= set('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789#') and any(c.isdigit() for c in pw) and any(c.isupper() for c in pw) and '#' in pw, pw)
gs = call(CR, 'Generate and Set', {'Credentials Name': 'New One', 'Username': 'bob', 'Length': Decimal(8), 'Use Lower Case': True})
ok('cred: Generate and Set stores what it returns', len(gs['Password']) == 8 and call(CR, 'Get', {'Credentials Name': 'New One'})['Password'] == gs['Password'] and call(CR, 'Get', {'Credentials Name': 'New One'})['Username'] == 'bob')
call(CR, 'Mark as Invalid', {'Credentials Name': 'Api'})
ok('cred: Mark as Invalid + List by status', call(CR, 'Get', {'Credentials Name': 'Api'})['Status'] == 'Invalid' and [x['Name'] for x in call(CR, 'List', {'Status': 'Invalid'})['Credentials'].rows] == ['Api'] and len(call(CR, 'List', {})['Credentials'].rows) == 3)
call(CR, 'Set', {'Credentials Name': 'Api', 'Username': 'svc2', 'Password': 'p2', 'Expiry Date': '2028-01-01'})
ok('cred: Set makes it valid again', call(CR, 'Get', {'Credentials Name': 'Api'}) == {'Username': 'svc2', 'Password': 'p2', 'Expiry Date': '2028-01-01', 'Status': 'Valid'})
WC = 'Blueprism.Automate.WindowsCredentialsActions'
call(WC, 'Set', {'Credentials Name': 'Share', 'Username': 'dom\\u', 'Password': 'w'})
ok('windows credentials: their own store', call(WC, 'Get', {'Credentials Name': 'Share'})['Username'] == 'dom\\u' and throws(lambda: call(CR, 'Get', {'Credentials Name': 'Share'}), 'not found') is True and len(call(WC, 'Generate Password', {'Length': Decimal(5)})['Password']) == 5)

# --- Environment Locking
EL = 'BluePrism.AutomateAppCore.clsEnvironmentLockingBusinessObject'
tok = call(EL, 'Acquire Lock', {'Name': 'L1', 'Comment': 'me'})['Token']
q = call(EL, 'Query Lock', {'Name': 'L1'})
ok('lock: Acquire Lock gives a token, Query Lock sees it', tok != '' and q == {'Lock Held': True, 'Comment': 'me', 'Result': True, 'Status': 'Locked'} and call(EL, 'Query Lock', {'Name': 'L1', 'Token': 'other'})['Lock Held'] is False, q)
ok('lock: Release Lock wants the token', throws(lambda: call(EL, 'Release Lock', {'Name': 'L1'}), 'not held with the token supplied') is True)
call(EL, 'Release Lock', {'Name': 'L1', 'Token': tok})
ok('lock: released', call(EL, 'Query Lock', {'Name': 'L1'})['Lock Held'] is False)
ok('lock: a lock the estate says another session holds gives an empty token', call(EL, 'Acquire Lock', {'Name': 'Held Elsewhere'})['Token'] == '' and call(EL, 'Query Lock', {'Name': 'Held Elsewhere'})['Comment'] == 'robot 2')
ok('lock: acquiring twice in the same run fails the second time, Preferred Token is used', call(EL, 'Acquire Lock', {'Name': 'L2', 'Preferred Token': 'T'})['Token'] == 'T' and call(EL, 'Acquire Lock', {'Name': 'L2'})['Token'] == '')

# --- Calendars
CA = 'Blueprism.Automate.clsCalendarsActions'
ok('cal: default is Mon-Fri', call(CA, 'Is Working Day', {'Date': '2026-11-14'})['Is Working Day'] is False and call(CA, 'Is Working Day', {'Date': '2026-11-16'})['Is Working Day'] is True)
ok('cal: holidays from the estate', call(CA, 'Is Working Day', {'Calendar Name': 'Bank', 'Date': '2026-12-25'})['Is Working Day'] is False and call(CA, 'Is Working Day', {'Date': '2026-12-25'})['Is Working Day'] is True)
ok('cal: Add Working Days skips the holiday', call(CA, 'Add Working Days', {'Calendar Name': 'Bank', 'Date': '2026-12-24', 'Days': 1})['Result Date'] == '2026-12-28')
rg = {'Calendar Name': 'Bank', 'First Date': '2026-12-21', 'Last Date': '2026-12-31'}
ok('cal: Count / Get Working Days In Range', call(CA, 'Count Working Days In Range', rg)['Days'] == Decimal(7) and len(call(CA, 'Get Working Days In Range', rg)['Working Days'].rows) == 7)
ok('cal: public and other holidays in range', call(CA, 'Get Public Holidays In Range', rg)['Public Holidays'].rows == [{'Date': '2026-12-25', 'Name': 'Christmas'}] and call(CA, 'Get Other Holidays In Range', rg)['Other Holidays'].rows == [{'Date': '2026-12-31'}])
ok('cal: Is Public Holiday / Is Other Holiday / Is Weekend', call(CA, 'Is Public Holiday', {'Calendar Name': 'Bank', 'Date': '2026-12-25'}) == {'Is Public Holiday': True, 'Name': 'Christmas'} and call(CA, 'Is Other Holiday', {'Calendar Name': 'Bank', 'Date': '2026-12-31'})['Is Other Holiday'] is True
   and call(CA, 'Is Weekend', {'Calendar Name': 'Bank', 'Date': '2026-12-26'})['Is Weekend'] is True and call(CA, 'Is Weekend', {'Calendar Name': 'Bank', 'Date': '2026-12-25'})['Is Weekend'] is False)

# --- Data Gateways, Encryption, Radio buttons
call('Event Log', 'Write Event', {'Event Type': 'Information', 'Message': 'hello'})
ok('event log (old seed name): written to the run log', any('[event log] Information: hello' in l for l in logs))
call('Blueprism.Automate.clsDataGatewaysActions', 'Send Custom Data', {'Custom Data': C([{'k': 'v'}])})
ok('data gateways: logged, no exception', any('[data gateway]' in l and '1 rows' in l for l in logs))
vals = {'Text': 'Pa$$ wörd', 'Password': 's3', 'Number': Decimal('12.5'), 'Flag': True, 'Date': '2026-11-16', 'DateTime': '2026-11-16 10:00:00', 'Time': '10:00:00', 'TimeSpan': '0.01:00:00', 'Binary': 'AQID'}
bad = []
for T, v in vals.items():
    e = call('Encryption', 'Encrypt ' + T, {'Encryption Scheme': 'Default', 'Plain Value': v})['Encrypted Value']
    back = call('Encryption', 'Decrypt ' + T, {'Encryption Scheme': 'Default', 'Encrypted Value': e})['Plain Value']
    if back != v or e == v: bad.append((T, back))
ok('encryption: round trip for every type', not bad, bad)
e = call('EncryptionBusinessObject', 'Encrypt Collection', {'Plain Value': C([{'a': 'x'}])})['Encrypted Value']
ok('encryption: a collection comes back as a collection', call('Encryption', 'Decrypt Collection', {'Encrypted Value': e})['Plain Value'].rows == [{'a': 'x'}])
ok('encryption: a real Blue Prism value cannot be decrypted here (said so)', throws(lambda: call('Encryption', 'Decrypt Text', {'Encrypted Value': 'AQID'}), 'not produced by this run') is True)
ok('radio buttons: Get selected as text', call('Blueprism.Automate.RadioButtonsBusinessObject', 'Get selected as text', {'Radio button options': 'B'})['Radio button selected'] == 'B')

# --- Collections: Blue Prism passes the NAME of a collection on the calling page; run through a real process
ok('collections: Count Rows on a value (direct call)', call('Blueprism.AutomateProcessCore.clsCollectionActions', 'Count Rows', {'Collection': C([{'a': 1}, {'a': 2}])})['Count'] == Decimal(2))
import tempfile, shutil
CO = 'Blueprism.AutomateProcessCore.clsCollectionActions'
def act(i, name, nxt, extra='', outs=''):
    return ('<stage stageid="a%d" name="%s %d" type="Action"><inputs><input type="text" name="Collection Name" expr="&quot;Items&quot;" />%s</inputs><outputs>%s</outputs>'
            '<onsuccess>%s</onsuccess><resource object="%s" action="%s" /></stage>') % (i, name, i, extra, outs, nxt, CO, name)
PROC = ('<process name="Coll" version="1.0" bpversion="7.2.1.15451"><stage stageid="s" name="Start" type="Start"><onsuccess>a1</onsuccess></stage>'
        '<stage stageid="c" name="Items" type="Collection"><datatype>collection</datatype><private /><alwaysinit /></stage>'
        '<stage stageid="c2" name="Part" type="Collection"><datatype>collection</datatype><private /><alwaysinit /></stage>'
        '<stage stageid="n" name="N" type="Data"><datatype>number</datatype><initialvalue>0</initialvalue><private /><alwaysinit /></stage>'
        '<stage stageid="m" name="M" type="Data"><datatype>number</datatype><initialvalue>0</initialvalue><private /><alwaysinit /></stage>'
        + act(1, 'Add Row', 'a2') + act(2, 'Add Row', 'a3') + act(3, 'Add Row', 'a4') + act(4, 'Remove Row', 'a5')
        + act(5, 'Count Rows', 'a6', outs='<output type="number" name="Count" stage="N" />')
        + act(6, 'Copy Rows', 'a7', '<input type="number" name="Start Row" expr="0" /><input type="number" name="End Row" expr="0" />', '<output type="collection" name="Result" stage="Part" />')
        + act(7, 'Remove All Rows', 'a8') + act(8, 'Count Rows', 'e', outs='<output type="number" name="Count" stage="M" />')
        + '<stage stageid="e" name="End" type="End"><outputs><output type="number" name="N" stage="N" /><output type="number" name="M" stage="M" /><output type="collection" name="Part" stage="Part" /></outputs></stage></process>')
tmp = tempfile.mkdtemp()
try:
    with open(os.path.join(tmp, 'BPA Process - Coll.xml'), 'w', encoding='utf-8') as f: f.write(PROC)
    r2 = Runtime([tmp], None, {}, log=logs.append).run_process('Coll')
    ok('collections: Add Row x3, Remove Row, Count Rows, Copy Rows, Remove All Rows act on the page\'s collection by name', r2.get('N') == Decimal(2) and r2.get('M') == Decimal(0) and len(r2['Part'].rows) == 1, r2)
finally:
    shutil.rmtree(tmp, ignore_errors=True)

# --- a real export can hold the same stageid twice (data items): both must exist in a run
sx = lambda i, n, t, b: '<stage stageid="%s" name="%s" type="%s">%s</stage>' % (i, n, t, b)
DUP = ('<process name="Dup">' + sx('s', 'Start', 'Start', '<onsuccess>c</onsuccess>') + sx('d', 'A', 'Data', '<datatype>number</datatype><initialvalue>1</initialvalue>') + sx('d', 'B', 'Data', '<datatype>number</datatype><initialvalue>41</initialvalue>')
       + sx('c', 'Add', 'Calculation', '<calculation expression="[A] + [B]" stage="A" /><onsuccess>e</onsuccess>') + sx('e', 'End', 'End', '<outputs><output type="number" name="A" stage="A" /></outputs>') + '</process>')
tmp = tempfile.mkdtemp()
try:
    with open(os.path.join(tmp, 'Dup.xml'), 'w', encoding='utf-8') as f: f.write(DUP)
    ok('run: two data items sharing one stageid are both there', Runtime([tmp], None, {}, log=logs.append).run_process('Dup').get('A') == Decimal(42))
finally:
    shutil.rmtree(tmp, ignore_errors=True)

# --- stage types only processes have: Alert (to the run log) and Process (another process, named by id, run in place)
PARENT = ('<process name="Parent">' + sx('s', 'Start', 'Start', '<onsuccess>a</onsuccess>') + sx('v', 'Got', 'Data', '<datatype>number</datatype><initialvalue />')
          + sx('a', 'Tell', 'Alert', '<alert expression="&quot;started &quot; &amp; GetSessionId()" /><onsuccess>p</onsuccess>')
          + sx('p', 'Call child', 'Process', '<inputs><input type="number" name="N" expr="20" /><input type="text" name="Unused" /></inputs><outputs><output type="number" name="Twice" stage="Got" /></outputs><onsuccess>e</onsuccess><processid>ABC-1</processid>')
          + sx('e', 'End', 'End', '<outputs><output type="number" name="Got" stage="Got" /></outputs>') + '</process>')
CHILD = ('<process name="Child">' + sx('s', 'Start', 'Start', '<inputs><input type="number" name="N" stage="N" /></inputs><onsuccess>c</onsuccess>') + sx('n', 'N', 'Data', '<datatype>number</datatype><initialvalue />')
         + sx('c', 'Dbl', 'Calculation', '<calculation expression="[N] * 2 + 2" stage="N" /><onsuccess>e</onsuccess>') + sx('e', 'End', 'End', '<outputs><output type="number" name="Twice" stage="N" /></outputs>') + '</process>')
tmp = tempfile.mkdtemp()
try:
    for nm, xx in (('Parent', PARENT), ('Child', CHILD)):
        with open(os.path.join(tmp, nm + '.xml'), 'w', encoding='utf-8') as f: f.write(xx)
    lg = []
    ok('run: a Process stage runs the process its id names, an Alert goes to the run log', Runtime([tmp], None, {}, log=lg.append, estate={'process_ids': {'ABC-1': 'Child'}}).run_process('Parent').get('Got') == Decimal(42) and any('alert from' in l and 'started ' in l for l in lg), lg[-5:])
    ok('run: a Process stage whose target is not in the release says so', throws(lambda: Runtime([tmp], None, {}, log=lg.append).run_process('Parent'), 'is not in this release') is True)
finally:
    shutil.rmtree(tmp, ignore_errors=True)

# --- every action of the verified list is answered (none says "not simulated")
import json
doc = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'internal', 'internal.json'), encoding='utf-8'))
missing = []
for o in doc['objects']:
    for a in o['actions']:
        try:
            Runtime([], None, {}, log=lambda s: None).call_object(o['classes'][-1], a['name'], {})
        except BPException as ex:
            if 'not simulated' in ex.detail or 'not loaded' in ex.detail: missing.append(o['object'] + '.' + a['name'])
        except Exception as ex:
            missing.append(o['object'] + '.' + a['name'] + ' crashed: ' + repr(ex))
ok('every action of internal.json is simulated (%d actions)' % sum(len(o['actions']) for o in doc['objects']), not missing and all(o.get('verified') for o in doc['objects']), missing)
ok('an internal object that is not in the list says which', throws(lambda: call('Blueprism.Automate.clsSessionVariablesActions', 'Set', {}), 'Session Variables.Set not simulated') is True)
ok('a plain unknown object is still "not loaded"', throws(lambda: call('Utility - Nope', 'X', {}), "Object 'Utility - Nope' not loaded") is True)

print('INTERNAL-TEST ' + ('PASS' if not fails else 'FAIL ' + str(fails)))
sys.exit(1 if fails else 0)
