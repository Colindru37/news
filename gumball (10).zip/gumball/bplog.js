// A Blue Prism session log (the CSV the Control Room exports) read into the rows the walk steps through.
//
// Layout it reads (the "BPA Partial Session Log" seen on the bank machine, 2026-10-22): one line per stage with the columns
//   LogNumber, StageID, StageName, StageType, Process, Page, Object, Action, Result, ResultType, Resource Start, Resource End,
//   ..., Direction, Name, Type, Value
// A stage inside an object has Object and Action filled and Process empty. In an Errors Only log the last four columns are
// empty. ASSUMED, not yet seen on a real full log: each parameter of a stage is one more line with the same LogNumber and
// Direction (In / Out), Name, Type, Value filled. If the real thing differs, `paramsOf` is the one place to change.
//
// A log says what went in and out of a STAGE. Which DATA ITEM that changed is in the XML (an output is stored in an item, a
// calculation has a Store In). So with the XML a row gets `set` like a Run's rows; without it the row is marked `unknown`
// and only carries its parameters.
'use strict';
const D = require('./bpdraw');

function parseCsv(text) {
  text = String(text || '').replace(/^﻿/, '');
  const first = text.slice(0, text.search(/\r?\n|$/)), sep = (first.match(/;/g) || []).length > (first.match(/,/g) || []).length ? ';' : (first.match(/\t/g) || []).length > (first.match(/,/g) || []).length ? '\t' : ',';
  const rows = []; let row = [], cell = '', q = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) { if (c === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else q = false; } else cell += c; }
    else if (c === '"') q = true;
    else if (c === sep) { row.push(cell); cell = ''; }
    else if (c === '\n' || c === '\r') { if (c === '\r' && text[i + 1] === '\n') i++; row.push(cell); cell = ''; if (row.length > 1 || row[0] !== '') rows.push(row); row = []; }
    else cell += c;
  }
  row.push(cell); if (row.length > 1 || row[0] !== '') rows.push(row);
  if (!rows.length) return [];
  const key = h => String(h || '').toLowerCase().replace(/[^a-z]/g, ''), head = rows[0].map(key);
  return rows.slice(1).map(r => { const o = {}; head.forEach((h, i) => { if (h && !(h in o)) o[h] = r[i] == null ? '' : r[i]; }); return o; });
}
const norm = n => String(n == null ? '' : n).replace(/\s+/g, ' ').trim().toLowerCase();
function paramsOf(line) { const d = String(line.direction || '').trim(); return d && line.name ? { dir: /^o/i.test(d) ? 'out' : 'in', name: line.name, type: String(line.type || '').toLowerCase(), value: line.value == null ? '' : line.value } : null; }
function when(s) { const t = Date.parse(String(s || '').replace(/^(\d{2})[./](\d{2})[./](\d{4})/, '$3-$2-$1')); return isNaN(t) ? null : t; }
const TYPES = { 'sub-sheet': 'SubSheet', subsheet: 'SubSheet', page: 'SubSheet', 'multiple calculation': 'MultipleCalculation', multicalc: 'MultipleCalculation', 'loop start': 'LoopStart', 'loop end': 'LoopEnd', 'choice start': 'ChoiceStart', 'choice end': 'ChoiceEnd', 'wait start': 'WaitStart', 'wait end': 'WaitEnd', wait: 'WaitStart', choice: 'ChoiceStart' };
function typeName(t) { const k = norm(t); return TYPES[k] || String(t || '').replace(/\s+/g, '') || 'Undefined'; }

// lines of the CSV -> one record per stage, with its parameters
function stagesOf(lines) {
  const out = []; let cur = null;
  for (const l of lines) {
    const p = paramsOf(l), sameStage = cur && l.lognumber !== '' && l.lognumber === cur.lognumber, bare = !l.stagename && !l.stagetype;
    if (!cur || !(sameStage || bare)) { if (!l.stagename && !l.stagetype && !p) continue; cur = Object.assign({}, l, { params: [] }); out.push(cur); }
    if (p) cur.params.push(p);
  }
  return out;
}

// xmlFor(name) -> the XML of the process / object of that name, or null. Returns { rows, missing: [names], known: [names] }.
function rowsFrom(text, xmlFor) {
  const stages = stagesOf(parseCsv(text)).filter(s => String(s.process || '').trim() || String(s.object || '').trim()), rows = [], bps = {}, missing = new Set(), known = new Set();
  const bpOf = name => { const k = norm(name); if (!(k in bps)) { let x = null; try { x = xmlFor(name); } catch (e) { } bps[k] = x ? D.parseBp(x) : null; (bps[k] ? known : missing).add(name); } return bps[k]; };
  const frames = {}; let fseq = 0, n = 0;
  for (const s of stages) {
    const inObject = !!String(s.object || '').trim(), process = inObject ? s.object.trim() : String(s.process || '').trim(), page = (inObject ? (s.action || s.page) : s.page) || 'Main Page';
    const type = typeName(s.stagetype), key = norm(process) + '|' + norm(page);
    if (type === 'Start' || !(key in frames)) frames[key] = ++fseq;
    const t0 = when(s.resourcestart), t1 = when(s.resourceend), result = String(s.result || '');
    const row = { n: ++n, f: frames[key], process, page: page === 'Initialise' ? 'Main Page' : page, stage: s.stagename, type, ms: t0 != null && t1 != null ? Math.max(0, t1 - t0) : 0, at: s.resourcestart || '' };
    if (/^\s*ERROR\b/i.test(result)) row.error = result.replace(/^\s*ERROR:?\s*/i, '');
    if (s.params.length) row.params = s.params;
    const bp = process ? bpOf(process) : null, st = bp && (bp.stages.find(x => x.name === s.stagename && norm(x.page) === norm(row.page) && x.type === type) || bp.stages.find(x => x.name === s.stagename && norm(x.page) === norm(row.page)));
    if (!st) row.unknown = bp ? 'stage' : 'object';        // no XML for it (object), or the XML has no such stage on that page (stage)
    else {
      const set = {}, outs = s.params.filter(p => p.dir === 'out'), ins = s.params.filter(p => p.dir === 'in');
      const map = (tagName, list) => { const re = new RegExp('<' + tagName + ' ([^>]*)/?>', 'g'); let m; while ((m = re.exec(st.body))) { const nm = D.unx(D.attr(m[1], 'name') || ''), to = D.unx(D.attr(m[1], 'stage') || ''), p = list.find(x => norm(x.name) === norm(nm)); if (p && to) set[to] = p.value; } };
      if (type === 'Calculation' && !row.error) { const c = /<calculation ([^>]*)\/?>/.exec(st.body), to = c ? D.unx(D.attr(c[1], 'stage') || '') : ''; if (to && result !== '') set[to] = result; }
      else if (type === 'Start') map('input', ins);
      else if (!row.error) map('output', outs);
      if (Object.keys(set).length) row.set = set;
    }
    if (result && !row.error && (type === 'Decision' || type === 'Calculation')) row.result = result;
    rows.push(row);
  }
  return { rows, missing: [...missing], known: [...known] };
}
module.exports = { parseCsv, stagesOf, rowsFrom };
