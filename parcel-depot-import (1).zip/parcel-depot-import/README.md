# Parcel Depot builds with real element types and action ids (third version)

Changes since the version you imported: the table read supplies its two compulsory inputs (First Row Number = 1,
Last Row Number = the row count read just before it), and Haiku's Approve Orders no longer declares one environment
item on two pages.

For the single-import check: `haiku_real/BPA Object - Parcel Depot.xml`. It calls nothing else.

Look for:
1. Validate on the object: 0 errors expected. Photograph anything else.
2. Stage "Read Order Lines" (page Get Order): two rows, "Get Table Row Count"-like and the rows read, the second with
   both inputs filled.
3. The names Blue Prism shows for the two inputs and for the row count action (the labels are not in the file).
