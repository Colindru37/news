// mordecai: the Application Modeller of a Blue Prism object, read and written outside Studio.
// Works on the <appdef>...</appdef> text of an export. Every edit is a splice: only the bytes of what changed move,
// the rest of the appdef (and of the file) stays exactly as Blue Prism wrote it.
//
//   find(xml)                      -> { start, end } of the appdef in an export (null when the object has none)
//   parse(appdef)                  -> { app: { mode, params }, list: [element...], byId }   (list is in file order, with depth)
//   setAttribute(appdef, id, name, { value, inuse, cmp })   rename(appdef, id, name)   remove(appdef, id)
//   add(appdef, parentId, name, { like: <element id> | kind: 'win32' | 'aa' | 'uia' | 'web' | 'html' | 'sap' | 'region' })
//   usedBy(xml)                    -> { elementId: [stage names] }
// Kinds are told apart the way the estate's own objects are (read from real exports, 2026-11-13).
(function (root) {
'use strict';
const ent = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const unent = s => String(s == null ? '' : s).replace(/&#x([0-9a-f]+);/gi, (m, h) => String.fromCharCode(parseInt(h, 16))).replace(/&#(\d+);/g, (m, d) => String.fromCharCode(+d)).replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, '&');
function guid() { const h = '0123456789abcdef'; let g = ''; for (let i = 0; i < 36; i++) g += (i === 8 || i === 13 || i === 18 || i === 23) ? '-' : (i === 14 ? '4' : i === 19 ? h[8 + Math.floor(Math.random() * 4)] : h[Math.floor(Math.random() * 16)]); return g; }

// ---- what each spy mode records. [name, datatype, matched by default]. Parent copies and state flags are generated below. ----
const WIN32 = [['WindowText', 'text', 1], ['ClassName', 'text', 1], ['CtrlID', 'number', 0], ['X', 'number', 0], ['Y', 'number', 0], ['Width', 'number', 0], ['Height', 'number', 0], ['Visible', 'flag', 1], ['ScreenVisible', 'flag', 1], ['Enabled', 'flag', 1], ['Active', 'flag', 0], ['Ordinal', 'number', 0], ['ChildCount', 'number', 0], ['AncestorsText', 'text', 0], ['AncestorCount', 'number', 0], ['TypeName', 'text', 0], ['ScreenBounds', 'text', 0], ['Style', 'number', 0]];
const WIN32_PARENT = ['WindowText', 'ClassName', 'CtrlID', 'X', 'Y', 'Width', 'Height', 'Visible', 'ScreenVisible', 'Enabled', 'Active', 'Ordinal', 'ChildCount', 'Style'];
const AA_FLAGS = ['Unavailable', 'Selected', 'Focused', 'Pressed', 'aChecked', 'Mixed', 'ReadOnly', 'Hottracked', 'Default', 'Expanded', 'Collapsed', 'Busy', 'Floating', 'Marqueed', 'Animated', 'Invisible', 'Offscreen', 'Sizeable', 'Moveable', 'SelfVoicing', 'Focusable', 'Selectable', 'Linked', 'Traversed', 'Multiselectable', 'Extselectable', 'Alert_low', 'Alert_medium', 'Alert_high'];
const AA_OWN = [['aX', 'number', 0], ['aY', 'number', 0], ['aWidth', 'number', 0], ['aHeight', 'number', 0], ['Name', 'text', 1], ['Description', 'text', 0], ['Role', 'text', 1], ['ID', 'text', 0], ['State', 'text', 0], ['Value2', 'text', 0], ['KeyboardShortcut', 'text', 0], ['DefaultAction', 'text', 0], ['ElementCount', 'number', 0], ['aAncestorCount', 'number', 0]];
const AA_PARENT = [['paX', 'number'], ['paY', 'number'], ['paWidth', 'number'], ['paHeight', 'number'], ['pName', 'text'], ['pDescription', 'text'], ['pRole', 'text'], ['pID', 'text'], ['pState', 'text'], ['pValue2', 'text'], ['pKeyboardShortcut', 'text'], ['pDefaultAction', 'text'], ['pElementCount', 'number']];
const typeOf = Object.fromEntries(WIN32.map(a => [a[0], a[1]]));
const KINDS = {
  win32: { label: 'Win32', base: 'Window', attrs: WIN32.concat(WIN32_PARENT.map(n => ['p' + n, typeOf[n], 0]), [['MatchIndex', 'number', 0], ['MatchReverse', 'flag', 0]]) },
  aa: { label: 'Active Accessibility', base: 'AAElement',
        attrs: WIN32.map(a => [a[0], a[1], a[0] === 'WindowText' || a[0] === 'ClassName' || a[0] === 'Visible' || a[0] === 'ScreenVisible' ? 1 : 0]).concat(AA_OWN, AA_FLAGS.map(f => [f, 'flag', 0]),
          AA_PARENT.map(a => [a[0], a[1], a[0] === 'pRole' ? 1 : 0]), AA_FLAGS.map(f => ['p' + (f === 'aChecked' ? 'aChecked' : f), 'flag', 0]), [['matchindex', 'number', 1], ['matchreverse', 'flag', 0]]) },
  uia: { label: 'UI Automation', base: 'UIAElement',
         attrs: [['uX', 'number', 0], ['uY', 'number', 0], ['uWidth', 'number', 0], ['uHeight', 'number', 0], ['uClassName', 'text', 1], ['uAutomationId', 'text', 0], ['uControlType', 'text', 1], ['uLocalizedControlType', 'text', 0], ['uIsPassword', 'flag', 0], ['uIsRequiredForForm', 'flag', 0], ['uName', 'text', 1], ['uOrientation', 'text', 0], ['uItemStatus', 'text', 0], ['uItemType', 'text', 0], ['uOffscreen', 'flag', 0], ['uTopLevelWindowId', 'text', 0], ['uLabeledBy', 'text', 0], ['uEnabled', 'text', 0], ['uAcceleratorKey', 'text', 0], ['uAccessKey', 'text', 0], ['uHasKeyboardFocus', 'text', 0], ['uHelpText', 'text', 0], ['uProcessId', 'text', 0], ['puControlType', 'text', 0], ['puLocalizedControlType', 'text', 0], ['puClassName', 'text', 0], ['puName', 'text', 0], ['puAutomationId', 'text', 0], ['MatchIndex', 'number', 1]] },
  web: { label: 'Browser', base: 'WebElement',
         attrs: [['wX', 'number', 0], ['wY', 'number', 0], ['wWidth', 'number', 0], ['wHeight', 'number', 0], ['wClientX', 'number', 0], ['wClientY', 'number', 0], ['wClientWidth', 'number', 0], ['wClientHeight', 'number', 0], ['wOffsetX', 'number', 0], ['wOffsetY', 'number', 0], ['wOffsetWidth', 'number', 0], ['wOffsetHeight', 'number', 0], ['wScrollX', 'number', 0], ['wScrollY', 'number', 0], ['wScrollWidth', 'number', 0], ['wScrollHeight', 'number', 0], ['wElementType', 'text', 1], ['wXPath', 'text', 1], ['wCssSelector', 'text', 0], ['wValue', 'text', 0], ['wPageAddress', 'text', 1], ['wClass', 'text', 0], ['wChildCount', 'number', 0], ['wIsEditable', 'flag', 0], ['wStyle', 'text', 0], ['wTabIndex', 'number', 0], ['wInputType', 'text', 0], ['wAccessKey', 'text', 0], ['wInnerText', 'text', 0], ['wSource', 'text', 0], ['wTargetAddress', 'text', 0], ['wAlt', 'text', 0], ['wPattern', 'text', 0], ['wRel', 'text', 0], ['wLinkTarget', 'text', 0], ['wPlaceholder', 'text', 0], ['matchindex', 'number', 0]] },
  html: { label: 'HTML (IE mode)', base: 'HTML',
          attrs: [['X', 'number', 0], ['Y', 'number', 0], ['Width', 'number', 0], ['Height', 'number', 0], ['Path', 'text', 1], ['TagName', 'text', 1], ['ClassName', 'text', 0], ['ID', 'text', 1], ['Title', 'text', 0], ['Link', 'text', 0], ['InputType', 'text', 0], ['InputIdentifier2', 'text', 0], ['AncestorCount', 'number', 0], ['Value', 'text', 0], ['Enabled', 'flag', 0], ['Checked', 'flag', 0], ['pURL', 'text', 0], ['ScreenBounds', 'text', 0], ['MatchIndex', 'number', 1], ['MatchReverse', 'flag', 0]] },
  sap: { label: 'SAP', base: 'SAPComponent', attrs: [['ID', 'text', 1], ['ComponentType', 'text', 0]] },
  region: { label: 'Region', base: 'Region',
            attrs: [['StartX', 'number', 1], ['StartY', 'number', 1], ['EndX', 'number', 1], ['EndY', 'number', 1], ['ElementSnapshot', 'image', 1], ['FontName', 'text', 1], ['LocationMethod', 'text', 1], ['RegionPosition', 'text', 1], ['ImageSearchPadding', 'text', 1], ['ColourTolerance', 'number', 1], ['Greyscale', 'flag', 1]]
              .concat(WIN32.map(a => [a[0], a[1], a[0] === 'ClassName' || a[0] === 'Visible' || a[0] === 'ScreenVisible' || a[0] === 'Enabled' ? 1 : 0]), WIN32_PARENT.map(n => ['p' + n, typeOf[n], 0]), [['MatchIndex', 'number', 1], ['MatchReverse', 'flag', 0]]) }
};
const REGION_DEFAULT = { LocationMethod: 'Coordinates', RegionPosition: 'Fixed', ImageSearchPadding: '0, 0, 0, 0', ColourTolerance: '0', Greyscale: 'False' };
/// Launch modes (apptypeinfo) with their parameters in the order Blue Prism writes them. verified = read off a real export
/// (training release, the estate's digests); the others are the closest known shape, to compare with one Studio wrote.
const MODES = {
  Win32Launch:   { label: 'Windows application, launched', verified: true, params: [['Path', ''], ['CommandLineParams', ''], ['WorkingDirectory', ''], ['NonInvasive', 'True'], ['ProcessMode', 'Internal'], ['ExternalProcessTimeout', '0'], ['Options', '']] },
  Win32Attach:   { label: 'Windows application, attached', verified: true, params: [['WindowTitle', ''], ['ProcessName', ''], ['Path', ''], ['CommandLineParams', ''], ['NonInvasive', 'True'], ['ProcessMode', 'Internal'], ['ExternalProcessTimeout', '0'], ['Options', '']] },
  BrowserLaunch: { label: 'Browser (Edge), launched', verified: true, params: [['Path', ''], ['CommandLineParams', ''], ['WindowTitle', ''], ['ProcessMode', 'Internal'], ['ExternalProcessTimeout', '0']] },
  BrowserAttach: { label: 'Browser (Edge), attached', verified: false, params: [['WindowTitle', ''], ['ProcessName', 'msedge'], ['Path', ''], ['CommandLineParams', ''], ['ProcessMode', 'Internal'], ['ExternalProcessTimeout', '0']] },
  HTMLAttach:    { label: 'HTML (IE mode), attached', verified: true, params: [['WindowTitle', ''], ['ProcessName', ''], ['Path', ''], ['CommandLineParams', ''], ['ActiveTabOnly', 'False'], ['UseJavaInBrowser', 'False'], ['ExcludeHTC', 'False'], ['ProcessMode', 'Internal']] },
  HTMLLaunch:    { label: 'HTML (IE mode), launched', verified: false, params: [['Path', ''], ['CommandLineParams', ''], ['ActiveTabOnly', 'False'], ['UseJavaInBrowser', 'False'], ['ExcludeHTC', 'False'], ['ProcessMode', 'Internal'], ['ExternalProcessTimeout', '0']] }
};
const COMPARISONS = ['Equal', 'NotEqual', 'Wildcard', 'RegEx', 'Range', 'GreaterThan', 'GreaterThanOrEqual', 'LessThan', 'LessThanOrEqual'];
/// Which spy mode an element belongs to: its base type first, its attribute names when the base type is a plain one.
function kindOf(el) {
  const b = el.base || el.type || '', names = new Set(el.attrs.map(a => a.name));
  if (b === 'Application') return 'application';
  if (!el.attrs.length) return 'none';
  if (/^SAP/.test(b) || names.has('ComponentType')) return 'sap';
  if (/^UIA/.test(b) || names.has('uControlType')) return 'uia';
  if (/^Web/.test(b) || names.has('wXPath')) return 'web';
  if (names.has('ElementSnapshot') || names.has('RegionPosition') || /Region/.test(b)) return 'region';
  if (/^AA/.test(b) || names.has('Role')) return 'aa';
  if (/^HTML/.test(b) || names.has('TagName')) return 'html';
  return 'win32';
}

function find(xml) { const s = xml.indexOf('<appdef'); if (s < 0) return null; const e = xml.indexOf('</appdef>', s); return e < 0 ? null : { start: s, end: e + '</appdef>'.length }; }

/// The element tree with the offsets every edit needs. Never throws on odd content: what it does not know it leaves alone.
function parse(appdef) {
  const list = [], byId = {}, stack = [];
  const re = /<(\/?)(element|attributes|attribute|ProcessValue|id|type|basetype|datatype|diagnose|apptypeinfo)\b((?:"[^"]*"|[^>"])*?)(\/?)>/g; let m, app = { mode: '', params: [] }, curAttr = null;
  while ((m = re.exec(appdef))) {
    const close = m[1] === '/', tag = m[2], rest = m[3], self = m[4] === '/', top = stack[stack.length - 1];
    if (tag === 'apptypeinfo' && !close) {
      const e = appdef.indexOf('</apptypeinfo>', m.index); if (e < 0) continue; const body = appdef.slice(m.index, e);
      app.mode = (/<id>([^<]*)<\/id>/.exec(body) || [])[1] || ''; const rp = /<parameter>\s*<name>([^<]*)<\/name>\s*<value>([^<]*)<\/value>/g; let p; while ((p = rp.exec(body))) app.params.push({ name: unent(p[1]), value: unent(p[2]) });
      re.lastIndex = e; continue;
    }
    if (tag === 'element') {
      if (close) { const el = stack.pop(); if (el) el.end = m.index + m[0].length; continue; }
      const nm = /\bname="([^"]*)"/.exec(rest);
      const el = { name: nm ? unent(nm[1]) : '', id: '', type: '', base: '', dtype: '', attrs: [], depth: stack.length, parent: top ? top : null, children: [], start: m.index, openEnd: m.index + m[0].length, end: -1, typeAt: -1, attrsAt: null };
      if (top) top.children.push(el); list.push(el); if (!self) stack.push(el); else el.end = el.openEnd; continue;
    }
    if (!top) continue;
    if (tag === 'attributes') { if (self) top.attrsAt = { start: m.index, end: m.index + m[0].length, empty: true }; else if (!close) top.attrsAt = { start: m.index, innerStart: m.index + m[0].length, end: -1 }; else if (top.attrsAt) { top.attrsAt.innerEnd = m.index; top.attrsAt.end = m.index + m[0].length; } continue; }
    if (tag === 'attribute') {
      if (close) { if (curAttr) { curAttr.end = m.index + m[0].length; curAttr = null; } continue; }
      const g = k => { const x = new RegExp('\\b' + k + '="([^"]*)"').exec(rest); return x ? unent(x[1]) : null; };
      curAttr = { name: g('name') || '', inuse: /^true$/i.test(g('inuse') || ''), cmp: g('comparisontype') || '', type: '', value: '', start: m.index, openEnd: m.index + m[0].length, end: self ? m.index + m[0].length : -1, pv: null };
      top.attrs.push(curAttr); if (self) curAttr = null; continue;
    }
    if (tag === 'ProcessValue') { if (curAttr && !close) { const dt = /\bdatatype="([^"]*)"/.exec(rest), v = /\bvalue="([^"]*)"/.exec(rest); curAttr.type = dt ? dt[1] : ''; curAttr.value = v ? unent(v[1]) : ''; curAttr.pv = { start: m.index, end: m.index + m[0].length }; } continue; }
    if (close || self) continue;
    // id / type / basetype / datatype: the element's own only (a child's are seen while the child is on top of the stack)
    const e = appdef.indexOf('</' + tag + '>', m.index); if (e < 0) continue; const text = unent(appdef.slice(m.index + m[0].length, e));
    if (tag === 'id' && !top.id) { top.id = text.trim(); top.idEnd = e + 5; byId[top.id] = top; }
    else if (tag === 'type' && top.typeAt < 0) { top.type = text.trim(); top.typeAt = m.index; }
    else if (tag === 'basetype' && !top.base) top.base = text.trim();
    else if (tag === 'datatype' && !top.dtype) top.dtype = text.trim();
    re.lastIndex = e;
  }
  for (const el of list) el.kind = kindOf(el);
  return { app, list, byId };
}

function need(appdef, id) { const el = parse(appdef).byId[id]; if (!el) throw new Error('no element ' + id + ' in the application model'); return el; }
function setTagAttr(open, name, value) {   // value null removes it; the other attributes of the tag are not touched
  const re = new RegExp('\\s' + name + '="[^"]*"');
  if (value == null) return open.replace(re, '');
  if (re.test(open)) return open.replace(re, () => ' ' + name + '="' + ent(value) + '"');
  return open.replace(/(\s*\/?>)$/, (w, tail) => ' ' + name + '="' + ent(value) + '"' + tail);
}
/// One attribute of one element: patch = { value?, inuse?, cmp? }. cmp '' or 'Equal' = Blue Prism's default (the attribute is not written).
function setAttribute(appdef, id, name, patch) {
  const el = need(appdef, id), at = el.attrs.find(a => a.name === name); if (!at) throw new Error('element "' + el.name + '" has no attribute ' + name);
  let out = appdef;
  if (patch.value !== undefined && at.pv) { const pv = appdef.slice(at.pv.start, at.pv.end); out = out.slice(0, at.pv.start) + setTagAttr(pv, 'value', patch.value) + out.slice(at.pv.end); }
  let open = appdef.slice(at.start, at.openEnd), o2 = open;
  if (patch.inuse !== undefined) o2 = setTagAttr(o2, 'inuse', patch.inuse ? 'True' : null);
  if (patch.cmp !== undefined) o2 = setTagAttr(o2, 'comparisontype', patch.cmp && patch.cmp !== 'Equal' ? patch.cmp : null);
  if (o2 !== open) out = out.slice(0, at.start) + o2 + out.slice(at.openEnd);   // the opening tag sits before the ProcessValue: its offsets are still good
  return out;
}
function rename(appdef, id, name) {
  if (!name || !/\S/.test(name)) throw new Error('name is empty');
  const el = need(appdef, id), open = appdef.slice(el.start, el.openEnd);
  return appdef.slice(0, el.start) + setTagAttr(open, 'name', name.trim()) + appdef.slice(el.openEnd);
}
/// Remove an element and everything under it.
function remove(appdef, id) {
  const el = need(appdef, id); if (!el.parent) throw new Error('the application itself cannot be removed');
  let s = el.start; while (s > 0 && /[ \t]/.test(appdef[s - 1])) s--; if (appdef[s - 1] === '\n') { s--; if (appdef[s - 1] === '\r') s--; }
  return appdef.slice(0, s) + appdef.slice(el.end);
}
function elementXml(name, id, base, dtype, attrs) {
  return '<element name="' + ent(name) + '"><id>' + id + '</id><type>' + ent(base) + '</type><basetype>' + ent(base) + '</basetype><datatype>' + ent(dtype || 'text') + '</datatype><diagnose>False</diagnose>'
    + (attrs.length ? '<attributes>' + attrs.map(a => '<attribute name="' + ent(a.name) + '"' + (a.cmp && a.cmp !== 'Equal' ? ' comparisontype="' + ent(a.cmp) + '"' : '') + (a.inuse ? ' inuse="True"' : '') + '><ProcessValue datatype="' + ent(a.type) + '" value="' + ent(a.value) + '" /></attribute>').join('') + '</attributes>' : '<attributes />') + '</element>';
}
/// A new element under parentId. opts.like = an element to copy (its type, attribute set, values and match flags: the usual way,
/// "one more like this one"); opts.kind = a blank one of that spy mode with the attributes that mode records. Returns { appdef, id }.
function add(appdef, parentId, name, opts) {
  opts = opts || {}; if (!name || !/\S/.test(name)) throw new Error('name is empty');
  const model = parse(appdef), parent = model.byId[parentId]; if (!parent) throw new Error('no parent element ' + parentId);
  if (model.list.some(e => e.name.toLowerCase() === name.trim().toLowerCase())) throw new Error('an element named "' + name.trim() + '" already exists');
  const id = guid(); let xml;
  if (opts.like) {
    const src = model.byId[opts.like]; if (!src) throw new Error('no element ' + opts.like + ' to copy');
    xml = elementXml(name.trim(), id, src.base || src.type, src.dtype, src.attrs);
    if (src.type && src.type !== src.base) xml = xml.replace('<type>' + ent(src.base) + '</type>', () => '<type>' + ent(src.type) + '</type>');
  } else {
    const k = KINDS[opts.kind]; if (!k) throw new Error('unknown kind ' + opts.kind);
    xml = elementXml(name.trim(), id, opts.base || k.base, 'text', k.attrs.map(a => ({ name: a[0], type: a[1], inuse: !!a[2], cmp: '',
      value: opts.kind === 'region' && REGION_DEFAULT[a[0]] != null ? REGION_DEFAULT[a[0]] : a[1] === 'flag' ? (/Visible$|Enabled$/.test(a[0]) ? 'True' : 'False') : a[1] === 'number' ? (/^(Match|match)index$/i.test(a[0]) ? '1' : '0') : '' })));
  }
  const at = parent.typeAt >= 0 ? parent.typeAt : parent.end - '</element>'.length;   // children sit between <id> and <type>
  // in a pretty-printed file the new element takes its own line: the line break + indent in front of the insert point is repeated after it
  let w = at; while (w > 0 && /[ \t]/.test(appdef[w - 1])) w--; if (appdef[w - 1] === '\n') { w--; if (appdef[w - 1] === '\r') w--; } else w = at;
  return { appdef: appdef.slice(0, at) + xml + appdef.slice(w, at) + appdef.slice(at), id };
}
/// One more attribute on an element (a spy reported something this element does not carry yet, e.g. SubType on a SAP grid).
function addAttribute(appdef, id, name, type, value, inuse) {
  const el = need(appdef, id); if (el.attrs.some(a => a.name === name)) return setAttribute(appdef, id, name, { value });
  const x = '<attribute name="' + ent(name) + '"' + (inuse ? ' inuse="True"' : '') + '><ProcessValue datatype="' + ent(type || 'text') + '" value="' + ent(value) + '" /></attribute>';
  if (!el.attrsAt) throw new Error('element "' + el.name + '" has no attribute list');
  if (el.attrsAt.empty) return appdef.slice(0, el.attrsAt.start) + '<attributes>' + x + '</attributes>' + appdef.slice(el.attrsAt.end);
  return appdef.slice(0, el.attrsAt.innerEnd) + x + appdef.slice(el.attrsAt.innerEnd);
}
/// Values from a spy (docs/copilot_mordecai_spy_handoff.md): { attributeName: value }. Only attributes the element already has are
/// written, match ticks and comparison types stay as they are, and a value marked dynamic is left alone. Returns { appdef, set, skipped }.
// What Blue Prism makes of a spied control (measured on the estate's own objects, 2026-11-23: shapes sections o and p). A
// UIA element is typed after its control type, an AA element after its role; type and basetype are the same thing until
// somebody changes the type by hand. The type decides which actions the element takes (a Write goes into a UIAEdit).
const UIA_TYPES = { Button: 'UIAButton', SplitButton: 'UIAButton', Edit: 'UIAEdit', Text: 'UIAEdit', Document: 'UIAEdit', Hyperlink: 'UIAHyperlink', CheckBox: 'UIACheckBox', RadioButton: 'UIARadio',
  ComboBox: 'UIAComboBox', MenuItem: 'UIAMenuItem', Menu: 'UIAMenu', MenuBar: 'UIAMenu', TabItem: 'UIATabItem', Tab: 'UIATabControl', Window: 'UIAWindow', ListItem: 'UIAListItem', List: 'UIAList',
  Table: 'UIATable', DataGrid: 'UIATable', TreeItem: 'UIATreeViewItem', Tree: 'UIATreeView' };
const AA_TYPES = { PushButton: 'AAButton', Text: 'AAEdit', CheckButton: 'AACheckBox', ComboBox: 'AAComboBox', RadioButton: 'AARadioButton', List: 'AAListBox' };
function typeFor(base, values) {
  const v = values || {};
  if (base === 'UIAElement') return UIA_TYPES[String(v.uControlType == null ? '' : v.uControlType).trim()] || 'UIAElement';
  if (base === 'AAElement') return AA_TYPES[String(v.Role == null ? '' : v.Role).trim()] || 'AAElement';
  return base;
}
/// Set an element's type and basetype (its own, not a child's).
function retype(appdef, id, type) {
  const el = need(appdef, id); if (el.typeAt < 0) return appdef;
  const rest = appdef.slice(el.typeAt).replace(/^<type>[^<]*<\/type>(\s*)<basetype>[^<]*<\/basetype>/, (m, sp) => '<type>' + ent(type) + '</type>' + sp + '<basetype>' + ent(type) + '</basetype>');
  return appdef.slice(0, el.typeAt) + rest;
}
function fill(appdef, id, values, opts) {
  { const el = need(appdef, id);          // a generic element that is now told what control it is gets Blue Prism's type for it
    if ((el.type === 'UIAElement' || el.type === 'AAElement') && el.type === (el.base || el.type)) { const t = typeFor(el.type, values); if (t !== el.type) appdef = retype(appdef, id, t); } }
  let out = appdef; const set = [], skipped = [];
  for (const name of Object.keys(values || {})) {
    const at = need(out, id).attrs.find(a => a.name === name);
    if (!at && opts && opts.addMissing && opts.addMissing.includes(name)) { out = addAttribute(out, id, name, typeof values[name] === 'boolean' ? 'flag' : typeof values[name] === 'number' ? 'number' : 'text', values[name] === true ? 'True' : values[name] === false ? 'False' : String(values[name]), false); set.push(name); continue; }
    if (!at || /^dynamic$/i.test(at.cmp)) { skipped.push(name); continue; }
    const v = values[name] === true ? 'True' : values[name] === false ? 'False' : String(values[name] == null ? '' : values[name]);
    if (v !== at.value) { out = setAttribute(out, id, name, { value: v }); set.push(name); }
  }
  return { appdef: out, set, skipped };
}
/// Which stages use which element (Navigate / Read / Write / Wait): { elementId: [stage names] }.
function usedBy(xml) {
  const out = {}; const rs = /<stage stageid="[^"]*" name="([^"]*)" type="[^"]*"[^>]*>([\s\S]*?)<\/stage>/g; let s;
  while ((s = rs.exec(xml))) { const seen = new Set(); const re = /<element id="([^"]+)"/g; let e; while ((e = re.exec(s[2]))) { if (seen.has(e[1])) continue; seen.add(e[1]); (out[e[1]] = out[e[1]] || []).push(unent(s[1])); } }
  return out;
}

/// A model for an object that never had one: exactly what Studio writes for an untouched object (root element, no mode).
function create(name) {
  return '<appdef><element name="' + ent(name || 'Application Root') + '"><id>' + guid() + '</id><type>Application</type><basetype>Application</basetype><datatype>unknown</datatype><diagnose>False</diagnose></element></appdef>';
}
/// The launch mode and its parameters: params = [[name, value], ...] in file order (MODES gives the defaults for a mode).
/// The apptypeinfo block is replaced, or added after the root element when the model has none; everything else stays.
function setApp(appdef, mode, params) {
  const list = params || (MODES[mode] ? MODES[mode].params : []);
  const block = '<apptypeinfo><id>' + ent(mode) + '</id><parameters>' + list.map(p => '<parameter><name>' + ent(p[0]) + '</name><value>' + ent(p[1] == null ? '' : String(p[1])) + '</value></parameter>').join('') + '</parameters></apptypeinfo>';
  const a = appdef.indexOf('<apptypeinfo'), b = a < 0 ? -1 : appdef.indexOf('</apptypeinfo>', a);
  if (a >= 0 && b >= 0) return appdef.slice(0, a) + block + appdef.slice(b + '</apptypeinfo>'.length);
  const e = appdef.lastIndexOf('</appdef>'); if (e < 0) throw new Error('not an application model');
  return appdef.slice(0, e) + block + appdef.slice(e);
}
/// What can be said about the model without the application: [{ level:'logic', rule:'element matching', stage:<element>, page:'Application Modeller', msg }].
/// screens (optional): [{ name, elements: [{ attributeName: value }] }] = what a spy saw on a screen, every control; then each element is also
/// counted against the real screen (the twin that was never put in the model is found too).
/// Blue Prism finds an element by its ticked attributes only; where it sits in the tree does not limit the search (verified on the estate, 7.2.1, UIA).
function checks(appdef, used, screens) {
  const out = [], p = parse(appdef), els = p.list.filter(e => e.parent && kindOf(e) !== 'application');
  const F = (e, msg) => out.push({ level: 'logic', rule: 'element matching', stage: e.name, page: 'Application Modeller', msg });
  const ticked = e => e.attrs.filter(a => a.inuse), key = e => ticked(e).map(a => a.name + '\u0001' + (a.cmp || 'Equal') + '\u0001' + a.value).sort().join('\u0002');
  const hit = (a, v) => { const c = a.cmp || 'Equal'; try {
    if (c === 'Wildcard') return new RegExp('^' + a.value.replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '[\\s\\S]*').replace(/\?/g, '[\\s\\S]') + '$').test(v);
    if (c === 'RegEx') return new RegExp(a.value).test(v);
    if (c === 'NotEqual') return v !== a.value;
    return c === 'Equal' ? v === a.value : null; } catch (x) { return null; } };
  const POS = /^(?:p?[uwa]?)(?:X|Y|Width|Height|ClientX|ClientY|ClientWidth|ClientHeight)$/, usedIds = used || {};
  const byKey = {};
  for (const e of els) {
    const k = kindOf(e), tk = ticked(e);
    if (k === 'region') continue;
    if (!tk.length) { if (usedIds[e.id] && usedIds[e.id].length) F(e, 'nothing is ticked (the element was never identified), and ' + usedIds[e.id].length + ' stage' + (usedIds[e.id].length === 1 ? ' uses' : 's use') + ' it: ' + usedIds[e.id].slice(0, 3).join(', ')); continue; }
    const pos = tk.filter(a => POS.test(a.name)).map(a => a.name);
    if (pos.length) F(e, 'matches on position or size (' + pos.join(', ') + '): the element is lost as soon as the window moves or the layout shifts');
    (byKey[k + '|' + key(e)] = byKey[k + '|' + key(e)] || []).push(e);
  }
  const same = new Set();
  for (const k of Object.keys(byKey)) { const g = byKey[k]; if (g.length < 2) continue; g.forEach(e => same.add(e.id));
    F(g[0], 'has exactly the same ticked attributes as ' + g.slice(1).map(e => '"' + e.name + '"').join(', ') + ': they find the same control (the tree does not tell them apart)'); }
  // A's ticks also fit what was spied for another element B: with both on screen, A is ambiguous (or finds B's control)
  for (const a of els) {
    const ka = kindOf(a), ta = ticked(a); if (ka === 'region' || !ta.length || same.has(a.id) || ta.some(x => /^matchindex$/i.test(x.name))) continue;
    const also = [];
    for (const b of els) {
      if (b === a || kindOf(b) !== ka || !b.attrs.length) continue;
      const val = {}; b.attrs.forEach(x => { val[x.name] = x.value; });
      if (!ta.every(x => x.name in val && hit(x, val[x.name]) === true)) continue;
      if (a.attrs.every(x => !(x.name in val) || val[x.name] === x.value)) continue;   // the same control spied twice: not a twin
      const tb = ticked(b), tbk = {}; tb.forEach(x => { tbk[x.name] = (x.cmp || 'Equal') + '\u0001' + x.value; });
      const sa = {}; a.attrs.forEach(x => { sa[x.name] = x.value; }); const sameId = ['uAutomationId', 'CtrlID', 'ID'].some(k => sa[k] && sa[k] !== '0' && sa[k] === val[k]);
      if (sameId && tb.length > ta.length && ta.every(x => tbk[x.name] === (x.cmp || 'Equal') + '\u0001' + x.value)) continue;   // same id, b = a plus more ticks: a narrower state of the same control, on purpose
      const win = e => { let q = e.parent; while (q && q.parent && !/window/i.test(q.type + ' ' + q.base + ' ' + q.name)) q = q.parent; return q && q.parent ? q : null; }, wa = win(a), wb = win(b);
      if (wa && wb && wa !== wb) continue;   // the model files them under different windows: not on screen together
      also.push(b);
    }
    if (also.length) F(a, 'its ticked attributes (' + ta.map(x => x.name).join(', ') + ') also fit ' + also.slice(0, 3).map(b => '"' + b.name + '"').join(', ') + (also.length > 3 ? ' +' + (also.length - 3) : '') + ' as spied: with both on screen Blue Prism cannot tell them apart. Tick an automation id or a Parent attribute, or use a pattern (the tree does not limit the search)');
  }
  // against what a spy saw: how many controls of a real screen fit each element
  // an element with no anchor (no id, and spied while its name was empty) cannot be placed on a screen: judge it over all
  // the screens together. If no screen has exactly one control for it and some screen has several, it is ambiguous.
  const scr = Array.isArray(screens) ? screens : [], strv = v => v === true ? 'True' : v === false ? 'False' : String(v == null ? '' : v);
  for (const a of scr.length ? els : []) {
    const ta = ticked(a); if (!ta.length || kindOf(a) === 'region' || ta.some(x => /^matchindex$/i.test(x.name))) continue;
    const sv = {}; a.attrs.forEach(x => { sv[x.name] = x.value; });
    const nameAt = ['uName', 'WindowText', 'aName', 'Name'].find(k => k in sv), idAt = ['uAutomationId', 'CtrlID', 'ID'].find(k => k in sv && sv[k] !== '' && sv[k] !== '0');
    if (idAt || (nameAt && sv[nameAt] !== '')) continue;
    const counts = scr.map(sc => ((sc && sc.elements) || []).filter(n => ta.every(x => x.name in n && hit(x, strv(n[x.name])) === true)).length);
    if (!counts.some(c => c === 1) && counts.some(c => c > 1)) { const i = counts.findIndex(c => c > 1);
      F(a, 'it was spied with an empty name and has no id, and on no spied screen is it the only control that fits its ticked attributes (' + ta.map(x => x.name).join(', ') + '): ' + counts[i] + ' fit on "' + ((scr[i] || {}).name || '?') + '". Spy it again while it shows its text, and match on a pattern of that text'); }
  }
  for (const sc of Array.isArray(screens) ? screens : []) {
    const nodes = (sc && sc.elements) || [];
    for (const a of els) {
      const ta = ticked(a); if (!ta.length || kindOf(a) === 'region' || ta.some(x => /^matchindex$/i.test(x.name))) continue;
      const str = v => v === true ? 'True' : v === false ? 'False' : String(v == null ? '' : v);
      // only on a screen where the control it was spied from is: same automation id, or same name and control type as stored
      const sv = {}; a.attrs.forEach(x => { sv[x.name] = x.value; });
      const nameAt = ['uName', 'WindowText', 'aName', 'Name'].find(k => k in sv), idAt = ['uAutomationId', 'CtrlID', 'ID'].find(k => k in sv && sv[k] !== '' && sv[k] !== '0');
      const typeAt = ['uControlType', 'ClassName', 'aRole', 'TagName'].find(k => k in sv);
      const here = nodes.some(n => (idAt && str(n[idAt]) === sv[idAt]) || (nameAt && sv[nameAt] !== '' && str(n[nameAt]) === sv[nameAt] && (!typeAt || str(n[typeAt]) === sv[typeAt])));
      if (!here) continue;
      const fit = nodes.filter(n => ta.every(x => x.name in n && hit(x, str(n[x.name])) === true));
      if (fit.length > 1) F(a, fit.length + ' controls on the spied screen "' + (sc.name || '?') + '" fit its ticked attributes (' + ta.map(x => x.name).join(', ') + ')' + (fit.some(n => n.puName || n.puClassName) ? ', their parents: ' + fit.slice(0, 4).map(n => (n.puName || '') + '/' + (n.puClassName || '')).join(' | ') : '') + ': Blue Prism cannot tell them apart');
    }
  }
  return out;
}

const api = { find, parse, kindOf, create, setApp, MODES, setAttribute, addAttribute, rename, remove, add, fill, typeFor, retype, usedBy, checks, guid, KINDS, COMPARISONS };
if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.MORDECAI = api;
})(typeof window !== 'undefined' ? window : this);
