"""bprun -- a flow interpreter for the Blue Prism XML our generator emits.

Runs processes and objects end to end on this machine: every Action stage calls the real object
page, every Code stage runs the real C# in the stage host (the exact source compile_check gates),
decisions/calculations use a Blue Prism expression evaluator, loops, choices, waits, blocks with
Recover/Resume and the recovery-mode functions all behave as in Blue Prism. Blue Prism's internal
objects (Work Queues, Credentials, Environment Locking, Calendars, Collections, Encryption, ...) are
simulated in Python. Not a Blue Prism replacement: a way to execute the flows
against mock applications before the laptop ever sees them.

Usage (library): see run_e2e.py. CLI: python bprun.py --xml DIR... [--server <stage host> | --server-cmd '<json list>']
                                      [--env env.json] --run "<process name>" [--action <name> --inputs '<json>'] [--json out.json]
Without a stage host, Code stages are skipped (logged, outputs left at their defaults) so the flow still runs.
"""
import sys, os, json, re, subprocess, time, glob, uuid, datetime, fnmatch, base64, random, string, math, platform
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP, ROUND_UP, ROUND_DOWN
import xml.etree.ElementTree as ET


# =========================================================================================
class BPException(Exception):
    def __init__(self, etype, detail, stage=''):
        super().__init__(f'{etype}: {detail}')
        self.etype, self.detail, self.stage = etype, detail, stage


class Collection:
    """A Blue Prism collection: typed columns, rows of dicts, a current-row pointer."""
    def __init__(self, columns=None, rows=None):
        self.columns = list(columns or [])          # [(name, type)]
        self.rows = list(rows or [])                # [dict]
        self.current = 0

    @staticmethod
    def from_json(d):
        if not d:
            return Collection()
        return Collection([(c['name'], c.get('type', 'string')) for c in d.get('columns', [])], d.get('rows', []))

    def to_json(self):
        return {'columns': [{'name': n, 'type': t} for n, t in self.columns], 'rows': self.rows}

    def field(self, name):
        if not self.rows:
            raise BPException('System Exception', 'Internal : The collection has no current row')   # real text (bank CSV 2026-10-22)
        row = self.rows[min(self.current, len(self.rows) - 1)]
        if name not in row:
            raise BPException('System Exception', f'Field {name!r} not in collection (columns: {[c for c, _ in self.columns]})')
        v = row[name]
        if v is None:
            return ''
        ty = dict(self.columns).get(name, 'string')
        if ty in ('decimal', 'double', 'int'):
            return Decimal(str(v))
        return v

    def __repr__(self):
        return f'<Collection {len(self.rows)} rows {[c for c, _ in self.columns]}>'


# =========================================================================================
class Expr:
    """Blue Prism expression evaluator (the subset the generated flows use)."""
    TOK = re.compile(r'''\s*(?:("(?:[^"]|"")*")|(\[[^\]]+\])|(\d+(?:\.\d+)?)|(<>|<=|>=|[=<>&+\-*/(),])|([A-Za-z_][A-Za-z0-9_]*))''')

    def __init__(self, runtime, frame):
        self.rt, self.frame = runtime, frame

    def tokens(self, s):
        pos, out = 0, []
        s = s.strip()
        while pos < len(s):
            m = self.TOK.match(s, pos)
            if not m or m.end() == pos:
                raise BPException('System Exception', f'Cannot tokenise expression at {s[pos:pos+20]!r} in {s!r}')
            pos = m.end()
            if m.group(1) is not None:
                out.append(('str', m.group(1)[1:-1].replace('""', '"')))
            elif m.group(2) is not None:
                out.append(('ref', m.group(2)[1:-1]))
            elif m.group(3) is not None:
                out.append(('num', Decimal(m.group(3))))
            elif m.group(4) is not None:
                out.append(('op', m.group(4)))
            else:
                out.append(('id', m.group(5)))
        return out

    def eval(self, s):
        self.t = self.tokens(s)
        self.i = 0
        v = self.p_or()
        if self.i != len(self.t):
            raise BPException('System Exception', f'Trailing tokens in expression {s!r}')
        return v

    def peek(self, kind=None, val=None):
        if self.i >= len(self.t):
            return None
        k, v = self.t[self.i]
        if kind and k != kind:
            return None
        if val is not None and (v if k != 'id' else v.upper()) != val:
            return None
        return v

    def take(self):
        tok = self.t[self.i]
        self.i += 1
        return tok

    def p_or(self):
        v = self.p_and()
        while self.peek('id', 'OR') is not None:
            self.take(); r = self.p_and(); v = bool(v) or bool(r)   # always consume the right side
        return v

    def p_and(self):
        v = self.p_not()
        while self.peek('id', 'AND') is not None:
            self.take(); r = self.p_not(); v = bool(v) and bool(r)
        return v

    def p_not(self):
        if self.peek('id', 'NOT') is not None:
            self.take(); return not bool(self.p_not())
        return self.p_cmp()

    def p_cmp(self):
        v = self.p_concat()
        while self.peek('op') in ('=', '<>', '<', '>', '<=', '>='):
            op = self.take()[1]; r = self.p_concat()
            a, b = self.coerce_pair(v, r)
            v = {'=': a == b, '<>': a != b, '<': a < b, '>': a > b, '<=': a <= b, '>=': a >= b}[op]
        return v

    def p_concat(self):
        v = self.p_add()
        while self.peek('op') == '&':
            self.take(); r = self.p_add(); v = self.text(v) + self.text(r)
        return v

    def p_add(self):
        v = self.p_mul()
        while self.peek('op') in ('+', '-'):
            op = self.take()[1]; r = self.p_mul()
            v = self.num(v) + self.num(r) if op == '+' else self.num(v) - self.num(r)
        return v

    def p_mul(self):
        v = self.p_unary()
        while self.peek('op') in ('*', '/'):
            op = self.take()[1]; r = self.p_unary()
            v = self.num(v) * self.num(r) if op == '*' else self.num(v) / self.num(r)
        return v

    def p_unary(self):
        if self.peek('op') == '-':
            self.take(); return -self.num(self.p_unary())
        return self.p_atom()

    def p_atom(self):
        k, v = self.take()
        if k == 'str':
            return v
        if k == 'num':
            return v
        if k == 'ref':
            return self.frame.get(v)
        if k == 'op' and v == '(':
            r = self.p_or()
            if self.take() != ('op', ')'):
                raise BPException('System Exception', 'Expected )')
            return r
        if k == 'id':
            if v.upper() == 'TRUE':
                return True
            if v.upper() == 'FALSE':
                return False
            if self.peek('op') == '(':
                self.take(); args = []
                if self.peek('op') != ')':
                    args.append(self.p_or())
                    while self.peek('op') == ',':
                        self.take(); args.append(self.p_or())
                if self.take() != ('op', ')'):
                    raise BPException('System Exception', f'Expected ) after {v}(')
                return self.call(v, args)
        raise BPException('System Exception', f'Unexpected token {k} {v!r}')

    def num(self, v):
        if isinstance(v, bool):
            raise BPException('System Exception', 'Flag used as number')
        if isinstance(v, Decimal):
            return v
        try:
            return Decimal(str(v).strip())
        except InvalidOperation:
            raise BPException('System Exception', f'Not a number: {v!r}')

    def text(self, v):
        if isinstance(v, bool):
            return 'True' if v else 'False'
        if isinstance(v, Decimal):
            return fmt_num(v)
        return '' if v is None else str(v)

    def coerce_pair(self, a, b):
        if isinstance(a, bool) or isinstance(b, bool):
            return bool(a), bool(b)
        if isinstance(a, Decimal) or isinstance(b, Decimal):
            return self.num(a), self.num(b)
        return self.text(a), self.text(b)

    def call(self, name, args):
        n = name.lower()
        if n == 'upper': return self.text(args[0]).upper()
        if n == 'lower': return self.text(args[0]).lower()
        if n == 'trim': return self.text(args[0]).strip()
        if n == 'len': return Decimal(len(self.text(args[0])))
        if n == 'instr': return Decimal(self.text(args[0]).find(self.text(args[1])) + 1)
        if n == 'tonumber': return self.num(args[0])
        if n == 'isstoprequested': return self.rt.stop_requested
        if n == 'exceptiontype': return self.frame.recovery.etype if self.frame.recovery else ''
        if n == 'exceptiondetail': return self.frame.recovery.detail if self.frame.recovery else ''
        if n == 'exceptionstage': return self.frame.recovery.stage if self.frame.recovery else ''
        if n == 'now': return datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        if n == 'today': return datetime.date.today().isoformat()
        if n == 'hour': return Decimal(datetime.datetime.now().hour)
        if n == 'newline': return '\n'
        if n == 'replace': return self.text(args[0]).replace(self.text(args[1]), self.text(args[2]))
        if n == 'left': return self.text(args[0])[:int(self.num(args[1]))]
        if n == 'right':
            k = int(self.num(args[1])); t = self.text(args[0])
            return t[-k:] if k > 0 else ''
        if n == 'mid':
            s, start = self.text(args[0]), int(self.num(args[1]))
            return s[start - 1:start - 1 + int(self.num(args[2]))] if len(args) > 2 else s[start - 1:]
        # ---- the rest of what the estate's release uses (shapes report 2026-11-17). Dates travel as ISO text here
        # ("YYYY-MM-DD", "YYYY-MM-DD HH:MM:SS", "HH:MM:SS"), time spans as "d.hh:mm:ss": Blue Prism itself shows a
        # date in the machine's locale, so a text comparison against a formatted date can differ from a real run.
        t = lambda i: self.text(args[i]) if len(args) > i else ''
        k = lambda i, d=0: int(self.num(args[i])) if len(args) > i and self.text(args[i]).strip() != '' else d
        if n == 'startswith': return t(0).startswith(t(1))
        if n == 'endswith': return t(0).endswith(t(1))
        if n == 'trimstart': return t(0).lstrip()
        if n == 'trimend': return t(0).rstrip()
        if n == 'chr': return chr(k(0))
        if n == 'concatenate': return ''.join(self.text(a) for a in args)
        if n == 'bytes':
            try: return Decimal(len(base64.b64decode(t(0), validate=True)))
            except Exception: return Decimal(len(t(0).encode('utf-8')))
        if n == 'isnumber':
            try: Decimal(t(0).strip()); return True
            except InvalidOperation: return False
        if n == 'isflag': return isinstance(args[0], bool) or t(0).strip().lower() in ('true', 'false')
        if n in ('isdate', 'isdatetime'): return parse_when(t(0)) is not None
        if n == 'istime': return parse_time(t(0)) is not None
        if n == 'istimespan': return parse_span(t(0)) is not None
        if n in ('round', 'rndup', 'rnddn'):
            q = Decimal(1).scaleb(-k(1)); mode = {'round': ROUND_HALF_UP, 'rndup': ROUND_UP, 'rnddn': ROUND_DOWN}[n]
            return self.num(args[0]).quantize(q, rounding=mode)
        if n == 'sqrt': return self.num(args[0]).sqrt()
        if n == 'log': return Decimal(str(math.log(float(self.num(args[0])), float(self.num(args[1])) if len(args) > 1 else math.e)))
        if n == 'decpad': return format(self.num(args[0]).quantize(Decimal(1).scaleb(-k(1))), 'f')
        if n == 'makedate': return self._when(datetime.datetime(k(2), k(1), k(0))).split(' ')[0]
        if n == 'makedatetime': return self._when(datetime.datetime(k(2), k(1), k(0), k(3), k(4), k(5)))
        if n == 'maketime': return f'{k(0):02d}:{k(1):02d}:{k(2):02d}'
        if n == 'maketimespan': return fmt_span(datetime.timedelta(days=k(0), hours=k(1), minutes=k(2), seconds=k(3)))
        if n == 'todate': return self._when(self._need(t(0))).split(' ')[0]
        if n == 'todatetime': return self._when(self._need(t(0)))
        if n == 'totime':
            w = parse_time(t(0)); w = w if w is not None else self._need(t(0)).time()
            return w.strftime('%H:%M:%S')
        if n in ('todays', 'tohours', 'tominutes', 'toseconds'):
            sp = parse_span(t(0))
            if sp is None: raise BPException('System Exception', f'{name}: {t(0)!r} is not a time span')
            return Decimal(str(sp.total_seconds() / {'todays': 86400, 'tohours': 3600, 'tominutes': 60, 'toseconds': 1}[n]))
        if n == 'adddays': return self._like(t(0), self._need(t(0)) + datetime.timedelta(days=k(1)))
        if n == 'addmonths': return self._like(t(0), add_months(self._need(t(0)), k(1)))
        if n == 'dateadd': return self._like(t(2), date_add(k(0), k(1), self._need(t(2))))
        if n == 'datediff': return Decimal(date_diff(k(0), self._need(t(1)), self._need(t(2))))
        if n in ('formatdate', 'formatdatetime'): return net_format(self._need(t(0)), t(1))
        if n == 'localtime': return datetime.datetime.now().strftime('%H:%M:%S')
        if n == 'utctime': return datetime.datetime.now(datetime.timezone.utc).strftime('%H:%M:%S')
        if n == 'getclipboard': return str(getattr(self.rt, 'clipboard', ''))
        if n == 'setclipboard': self.rt.clipboard = t(0); return True
        if n == 'getresourcename': return platform.node()
        if n == 'getusername': return os.environ.get('USERNAME') or os.environ.get('USER') or ''
        if n == 'getconnection': return 'gumball'
        if n == 'getosversion': return platform.platform()
        if n == 'getosversionmajor': return Decimal(re.sub(r'\D.*$', '', platform.release()) or '0')
        if n == 'getsessionid': return self.rt.session_id
        if n == 'bpversionmajor': return Decimal(7)
        if n == 'bpversionminor': return Decimal(2)
        raise BPException('System Exception', f'Unknown function {name}()')

    @staticmethod
    def _when(d):
        return d.strftime('%Y-%m-%d %H:%M:%S')

    @staticmethod
    def _need(text):
        d = parse_when(text)
        if d is None:
            raise BPException('System Exception', f'Internal : {text!r} is not a date')
        return d

    def _like(self, original, d):
        """A date stays a date, a date-time stays a date-time."""
        return self._when(d) if re.search(r'\d:\d', str(original)) else self._when(d).split(' ')[0]


def parse_when(text):
    """A date or date-time from text: ISO first, then the day-first forms Blue Prism shows on a European machine."""
    v = str(text or '').strip()
    for f in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%dT%H:%M:%S', '%Y-%m-%d %H:%M', '%Y-%m-%d', '%d/%m/%Y %H:%M:%S', '%d/%m/%Y %H:%M', '%d/%m/%Y', '%d.%m.%Y %H:%M:%S', '%d.%m.%Y %H:%M', '%d.%m.%Y', '%d-%m-%Y'):
        try:
            return datetime.datetime.strptime(v, f)
        except ValueError:
            pass
    return None


def parse_time(text):
    v = str(text or '').strip()
    for f in ('%H:%M:%S', '%H:%M'):
        try:
            return datetime.datetime.strptime(v, f).time()
        except ValueError:
            pass
    return None


def parse_span(text):
    m = re.match(r'^\s*(-)?(?:(\d+)\.)?(\d{1,2}):(\d{2}):(\d{2})(?:\.\d+)?\s*$', str(text or ''))
    if not m:
        return None
    td = datetime.timedelta(days=int(m.group(2) or 0), hours=int(m.group(3)), minutes=int(m.group(4)), seconds=int(m.group(5)))
    return -td if m.group(1) else td


def fmt_span(td):
    sec = int(td.total_seconds()); sign = '-' if sec < 0 else ''; sec = abs(sec)
    return f'{sign}{sec // 86400}.{sec % 86400 // 3600:02d}:{sec % 3600 // 60:02d}:{sec % 60:02d}'


def add_months(d, n):
    y, m = divmod(d.year * 12 + d.month - 1 + n, 12)
    last = [31, 29 if (y % 4 == 0 and (y % 100 != 0 or y % 400 == 0)) else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][m]
    return d.replace(year=y, month=m + 1, day=min(d.day, last))


# Blue Prism's interval numbers for DateAdd / DateDiff (as its function help lists them; not checked on the product here)
INTERVALS = {0: 'year', 1: 'week', 2: 'weekday', 3: 'second', 4: 'quarter', 5: 'month', 6: 'minute', 7: 'hour', 8: 'dayofyear', 9: 'day'}


def date_add(interval, n, d):
    u = INTERVALS.get(interval)
    if u == 'year': return add_months(d, 12 * n)
    if u == 'quarter': return add_months(d, 3 * n)
    if u == 'month': return add_months(d, n)
    if u == 'week': return d + datetime.timedelta(weeks=n)
    if u in ('day', 'weekday', 'dayofyear'): return d + datetime.timedelta(days=n)
    if u == 'hour': return d + datetime.timedelta(hours=n)
    if u == 'minute': return d + datetime.timedelta(minutes=n)
    if u == 'second': return d + datetime.timedelta(seconds=n)
    raise BPException('System Exception', f'DateAdd: unknown interval {interval}')


def date_diff(interval, a, b):
    u = INTERVALS.get(interval); sec = (b - a).total_seconds()
    if u == 'year': return b.year - a.year
    if u == 'quarter': return (b.year - a.year) * 4 + (b.month - 1) // 3 - (a.month - 1) // 3
    if u == 'month': return (b.year - a.year) * 12 + b.month - a.month
    if u == 'week': return int((b.date() - a.date()).days / 7)
    if u in ('day', 'weekday', 'dayofyear'): return (b.date() - a.date()).days
    if u == 'hour': return int(sec / 3600)
    if u == 'minute': return int(sec / 60)
    if u == 'second': return int(sec)
    raise BPException('System Exception', f'DateDiff: unknown interval {interval}')


NET_TOKENS = [('yyyy', '%Y'), ('yy', '%y'), ('MMMM', '%B'), ('MMM', '%b'), ('MM', '%m'), ('dddd', '%A'), ('ddd', '%a'), ('dd', '%d'), ('HH', '%H'), ('hh', '%I'), ('mm', '%M'), ('ss', '%S'), ('tt', '%p'), ('fff', '000')]


def net_format(d, fmt):
    """A .NET custom date format, the tokens people use: yyyy yy MMMM MMM MM M dddd ddd dd d HH H hh h mm m ss s tt."""
    out, i = '', 0
    single = {'M': str(d.month), 'd': str(d.day), 'H': str(d.hour), 'h': str(d.hour % 12 or 12), 'm': str(d.minute), 's': str(d.second)}
    while i < len(fmt):
        if fmt[i] == "'":
            j = fmt.find("'", i + 1); j = len(fmt) if j < 0 else j
            out += fmt[i + 1:j]; i = j + 1; continue
        for tok, py in NET_TOKENS:
            if fmt.startswith(tok, i):
                out += d.strftime(py) if py.startswith('%') else py; i += len(tok); break
        else:
            if fmt[i] in single:
                out += single[fmt[i]]
            else:
                out += fmt[i]
            i += 1
    return out


def fmt_num(d):
    s = format(d.normalize(), 'f') if d == d.to_integral() else format(d, 'f')
    return s.rstrip('0').rstrip('.') if '.' in s else s


# =========================================================================================
class Frame:
    """One page execution: its data items, loop state, recovery state."""
    def __init__(self, page, parent_stage=''):
        self.page = page
        self.items = {}
        self.types = {}
        self.loops = {}            # groupid -> row index
        self.recovery = None       # BPException while in recovery mode (Recover..Resume)
        self.parent_stage = parent_stage
        for st in page.stages.values():
            if st.type in ('Data', 'Collection'):
                self.types[st.name] = st.datatype
                self.items[st.name] = initial_value(st.datatype, st.initial, st.exposure, page.proc.rt, st.name)

    def get(self, ref):
        if '.' in ref:
            coll, field = ref.split('.', 1)
            c = self.items.get(coll)
            if not isinstance(c, Collection):
                raise BPException('System Exception', f'[{coll}] is not a collection on page {self.page.name!r}')
            return c.field(field)
        if ref not in self.items:
            obj = self.page.proc.object_items
            if ref in obj:
                return obj[ref]
            raise BPException('System Exception', f'Data item [{ref}] not found on page {self.page.name!r}')
        return self.items[ref]

    def set(self, name, value, dtype=None):
        if name not in self.items and name in self.page.proc.object_items:
            dt = dtype or self.page.proc.object_types.get(name, 'text')
            self.page.proc.object_items[name] = coerce(value, dt, name)
            return
        dtype = dtype or self.types.get(name, 'text')
        self.types.setdefault(name, dtype)
        self.items[name] = coerce(value, dtype, name)


def initial_value(dtype, initial, exposure, rt, name):
    if exposure == 'Environment':
        if name not in rt.env:
            raise BPException('System Exception', f'Environment Variable {name!r} is not defined')
        return coerce(rt.env[name], dtype, name)
    if dtype == 'collection':
        return Collection()
    if initial is None or initial == '':
        return {'number': Decimal(0), 'flag': False}.get(dtype, '')
    return coerce(initial, dtype, name)


def coerce(v, dtype, name=''):
    if dtype == 'collection':
        if isinstance(v, Collection):
            return v
        if isinstance(v, dict):
            return Collection.from_json(v)
        return Collection()
    if dtype == 'number':
        if isinstance(v, bool):
            raise BPException('System Exception', f'Flag assigned to number [{name}]')
        try:
            return Decimal(str(v).strip() or '0')
        except InvalidOperation:
            raise BPException('System Exception', f'Non-numeric value {v!r} assigned to number [{name}]')
    if dtype == 'flag':
        if isinstance(v, bool):
            return v
        return str(v).strip().lower() == 'true'
    if isinstance(v, Decimal):
        return fmt_num(v)
    if isinstance(v, bool):
        return 'True' if v else 'False'
    return '' if v is None else str(v)


def to_json_value(v):
    if isinstance(v, Collection):
        return v.to_json()
    if isinstance(v, Decimal):
        return float(v)
    return v


# =========================================================================================
class Stage:
    def __init__(self, el):
        self.el = el
        self.id = el.get('stageid')
        self.name = el.get('name')
        self.type = el.get('type')
        d = el.find('display')
        self.x = float(d.get('x', 0)) if d is not None else 0
        self.y = float(d.get('y', 0)) if d is not None else 0
        self.w = float(d.get('w', 0)) if d is not None else 0
        self.h = float(d.get('h', 0)) if d is not None else 0
        self.onsuccess = el.findtext('onsuccess')
        self.ontrue = el.findtext('ontrue')
        self.onfalse = el.findtext('onfalse')
        self.datatype = el.findtext('datatype')
        self.initial = el.findtext('initialvalue')
        self.exposure = el.findtext('exposure')
        self.groupid = el.findtext('groupid')

    def inside(self, block):
        """Stage centre inside the block rectangle (Block x,y = top-left; stage x,y = centre)."""
        return block.x <= self.x <= block.x + block.w and block.y <= self.y <= block.y + block.h


class Page:
    def __init__(self, proc, ssid, name):
        self.proc, self.ssid, self.name = proc, ssid, name
        self.stages = {}

    def start(self):
        return next(s for s in self.stages.values() if s.type == 'Start')

    def recover_for(self, stage):
        """Innermost Block containing the stage -> its Recover; else the page-level Recover."""
        all_blocks = [b for b in self.stages.values() if b.type == 'Block']

        def owner(st):          # the innermost Block containing a stage (None = page level)
            inside = [b for b in all_blocks if st.inside(b)]
            return min(inside, key=lambda b: b.w * b.h) if inside else None

        recovers = [r for r in self.stages.values() if r.type == 'Recover']
        # Blue Prism: Blocks never nest (validation error), so the scopes are exactly
        # "inside this Block" or "the page". A Block without a Recover falls to the page's.
        for b in (owner(stage), None):
            for r in recovers:
                if owner(r) is b:
                    return r
        return None


def parse_xml(path):
    """Blue Prism exports may carry raw control characters (a 0x1B in a narrative was seen in a real release): dropped before parsing."""
    with open(path, encoding='utf-8', errors='replace') as f:
        text = f.read()
    return ET.fromstring(re.sub('[\x00-\x08\x0b\x0c\x0e-\x1f]', '', text.lstrip('\ufeff')))


class ProcFile:
    def __init__(self, rt, path):
        self.rt = rt
        root = parse_xml(path)
        for el in root.iter():
            if '}' in el.tag:
                el.tag = el.tag.split('}', 1)[1]
        self.name = root.get('name')
        self.ptype = 'object' if root.get('type') == 'object' else 'process'   # Blue Prism writes type="object" on objects and NO type on a process
        self.pages = {}
        names = {}
        for st in root.iter('stage'):
            if st.get('type') == 'SubSheetInfo':
                names[st.findtext('subsheetid')] = st.get('name')
        for sub in root.iter('subsheet'):       # a page whose information box is missing still has its declaration
            if sub.get('subsheetid') and sub.get('subsheetid') not in names and sub.findtext('name'):
                names[sub.get('subsheetid')] = sub.findtext('name')
        for ssid, nm in names.items():
            self.pages[nm] = Page(self, ssid, nm)
        if self.ptype == 'process':
            self.pages['Main'] = Page(self, None, 'Main')
        byid = {ssid: pg for pg in self.pages.values() for ssid in [pg.ssid]}
        for st in root.iter('stage'):
            s = Stage(st)
            ssid = st.findtext('subsheetid')
            pg = byid.get(ssid)
            if pg is None:
                continue
            key, n = s.id, 1      # a real export can hold the same stageid twice (data items): each stage keeps a place
            while key in pg.stages:
                n += 1; key = f'{s.id}~{n}'
            pg.stages[key] = s
        self.by_ssid = byid
        # Object-level data items (Initialise page of an object, no subsheetid): one instance per object per
        # session in Blue Prism, visible to every action page, values persist between action calls.
        self.object_items, self.object_types = {}, {}
        if self.ptype == 'object':
            for st in root.iter('stage'):
                if st.get('type') in ('Data', 'Collection') and not st.findtext('subsheetid'):
                    s = Stage(st)
                    self.object_types[s.name] = s.datatype
                    self.object_items[s.name] = initial_value(s.datatype, s.initial, s.exposure, rt, s.name)
        # Application Modeller: element id -> element name (the mock app is keyed by name)
        self.elements = {}
        appdef = root.find('appdef')
        if appdef is not None:
            for el in appdef.iter('element'):
                eid = el.findtext('id')
                if eid:
                    self.elements[eid] = el.get('name')
            top = appdef.find('element')
            self.app_root = top.findtext('id') if top is not None else None
        else:
            self.app_root = None


MISSING = object()   # apps={obj: {element name: MISSING}} = the element is not on screen


# =========================================================================================
class QueueItem:
    FIELDS = ('Item ID', 'Key', 'Priority', 'Status', 'Tags', 'Attempts', 'Created', 'Last Updated', 'Deferred Until', 'Exception Reason')

    def __init__(self, queue, data, key, priority=0, tags=(), status='', defer=None):
        now = datetime.datetime.now()
        self.id, self.queue, self.data, self.key = str(uuid.uuid4()), queue, data, key
        self.priority, self.tags, self.status = int(priority or 0), set(t for t in tags if t), status or ''
        self.attempts, self.locked, self.exception, self.deferred = 0, False, '', defer
        self.created = self.updated = now
        self.finished = None
        self.state = 'Pending'            # Pending | Completed | Exception
        self.locked_at = None
        self.worktime = datetime.timedelta(0)       # this attempt
        self.worktime_before = datetime.timedelta(0)   # earlier attempts (carried over a retry)

    def touch(self):
        self.updated = datetime.datetime.now()

    def lock(self):
        self.locked, self.locked_at = True, datetime.datetime.now()

    def unlock(self):
        if self.locked and self.locked_at:
            self.worktime += datetime.datetime.now() - self.locked_at
        self.locked, self.locked_at = False, None

    def row(self):
        return {'Item ID': self.id, 'Key': self.key, 'Priority': Decimal(self.priority), 'Status': self.status, 'Tags': ';'.join(sorted(self.tags)),
                'Attempts': Decimal(self.attempts), 'Created': self.created.strftime('%Y-%m-%d %H:%M:%S'), 'Last Updated': self.updated.strftime('%Y-%m-%d %H:%M:%S'),
                'Deferred Until': self.deferred.strftime('%Y-%m-%d %H:%M:%S') if self.deferred else '', 'Exception Reason': self.exception}


def _flag(v, default):
    """An Action stage input left empty = the action's default."""
    if v in (None, ''):
        return default
    return v if isinstance(v, bool) else str(v).strip().lower() == 'true'


def _int(v, default=0):
    try:
        return int(Decimal(str(v))) if v not in (None, '') else default
    except (InvalidOperation, ValueError):
        return default


def _span(td):
    """A timespan the way Blue Prism writes it: d.hh:mm:ss"""
    s = int(td.total_seconds())
    return f'{s // 86400}.{s % 86400 // 3600:02d}:{s % 3600 // 60:02d}:{s % 60:02d}'


def _dt(d):
    return d.strftime('%Y-%m-%d %H:%M:%S') if d else ''


class WorkQueues:
    """Work Queues, in memory: one queue = a list of items; the key field, max attempts and seed items come from the
    estate (internal/estate.json: "queues": {name: [rows]} or {name: {"key": field, "attempts": 3, "items": [rows]}}),
    a release's own work-queue items on top. Action names and parameters are Blue Prism 7.2.1's own (read off the
    install by internal-objects.ps1, 2026-11-16); the names the seed list used before that are still answered.
    The exception texts and the column names of the returned collections are approximations until a real one is seen."""
    ITEMS_COLS = [(f, 'number' if f in ('Priority', 'Attempts') else 'text') for f in QueueItem.FIELDS]
    EVENTS = ('Created', 'Locked', 'Deferred', 'Completed', 'Exceptions with retry', 'Exceptions with no retry', 'Deletions', 'Force Retries')

    def __init__(self, log):
        self.queues, self.cfg, self.log = {}, {}, log
        self.events = []        # (when, queue, kind) for Get Transaction Data

    def ev(self, queue, kind):
        self.events.append((datetime.datetime.now(), queue, kind))

    def configure(self, name, key_field='', attempts=3):
        self.cfg[name] = {'key': key_field or '', 'attempts': int(attempts or 3)}
        self.q(name)

    def q(self, name):
        if not name:
            raise BPException('System Exception', 'Internal : No queue name supplied')
        return self.queues.setdefault(name, [])

    def _cfg(self, name):
        return self.cfg.get(name, {'key': '', 'attempts': 3})

    def _key(self, name, row):
        k = self._cfg(name)['key']
        v = row.get(k, '') if k else ''
        return '' if v is None else str(v)

    @staticmethod
    def _when(v):
        if v in (None, ''):
            return None
        if isinstance(v, datetime.datetime):
            return v
        s = str(v).strip()
        for f in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%d', '%Y-%m-%dT%H:%M:%S', '%d/%m/%Y %H:%M:%S', '%d/%m/%Y'):
            try:
                return datetime.datetime.strptime(s[:19], f)
            except ValueError:
                pass
        raise BPException('System Exception', f'Internal : Invalid date value {s!r}')

    @staticmethod
    def _tags(v):
        return [t.strip() for t in str(v or '').replace(',', ';').split(';') if t.strip()]

    @staticmethod
    def _tag_ok(item, tag_filter):
        """Blue Prism's tag filter: "+tag" must be present, "-tag" must be absent, '*' and '?' are wildcards."""
        for t in WorkQueues._tags(tag_filter):
            want = not t.startswith('-')
            pat = t[1:] if t[0] in '+-' else t
            hit = any(fnmatch.fnmatchcase(x, pat) for x in item.tags)
            if hit != want:
                return False
        return True

    def _match(self, item, key_filter='', tag_filter=''):
        if key_filter not in (None, '') and item.key != str(key_filter):
            return False
        return self._tag_ok(item, tag_filter)

    def add(self, name, data, priority=0, tags='', status='', defer=None):
        items = self.q(name); ids = []
        for row in data.rows:
            it = QueueItem(name, Collection(data.columns, [dict(row)]), self._key(name, row), priority, self._tags(tags), status, self._when(defer))
            items.append(it); ids.append(it.id); self.ev(name, 'Created')
        self.log(f'  [queue {name}] +{len(ids)} item(s)')
        return ids

    def _claim(self, it):
        it.lock(); it.attempts += 1; it.touch(); self.ev(it.queue, 'Locked')
        self.log(f'  [queue {it.queue}] claimed {it.id[:8]} key={it.key!r} attempt {it.attempts}')
        return it

    def get_next(self, name, key_filter='', tag_filter=''):
        now = datetime.datetime.now()
        cands = [i for i in self.q(name) if i.state == 'Pending' and not i.locked and (i.deferred is None or i.deferred <= now) and self._match(i, key_filter, tag_filter)]
        if not cands:
            self.log(f'  [queue {name}] no pending item' + (f' for key {key_filter!r}' if key_filter else '') + (f' tags {tag_filter!r}' if tag_filter else ''))
            return None
        cands.sort(key=lambda i: (i.priority, i.created))      # lowest priority number first, then oldest (Blue Prism's order)
        return self._claim(cands[0])

    def find(self, item_id):
        for items in self.queues.values():
            for it in items:
                if it.id == item_id:
                    return it
        raise BPException('System Exception', f'Internal : No queue item found with ID {item_id}')

    def _locked(self, item_id):
        it = self.find(item_id)
        if not it.locked:
            raise BPException('System Exception', f'Internal : The item {item_id} is not locked')
        return it

    def mark_completed(self, item_id):
        it = self._locked(item_id); it.unlock(); it.state, it.finished = 'Completed', datetime.datetime.now(); it.touch(); self.ev(it.queue, 'Completed')
        self.log(f'  [queue {it.queue}] completed {item_id[:8]}')

    def mark_exception(self, item_id, reason, retry, keep_locked=False):
        it = self._locked(item_id); it.unlock(); it.state, it.exception, it.finished = 'Exception', reason, datetime.datetime.now(); it.touch()
        self.log(f'  [queue {it.queue}] exception {item_id[:8]} retry={retry}: {str(reason)[:120]}')
        if retry and it.attempts < self._cfg(it.queue)['attempts']:
            new = QueueItem(it.queue, Collection(it.data.columns, [dict(r) for r in it.data.rows]), it.key, it.priority, it.tags, it.status)
            new.attempts, new.worktime_before, new.created = it.attempts, it.worktime_before + it.worktime, it.created
            if keep_locked:
                new.lock()
            self.queues[it.queue].append(new); self.ev(it.queue, 'Exceptions with retry')
            self.log(f'  [queue {it.queue}] retry as {new.id[:8]} (attempt {new.attempts} of {self._cfg(it.queue)["attempts"]})')
            return new.id
        self.ev(it.queue, 'Exceptions with no retry')
        return ''

    def items(self, name, pred, skip=0, maximum=0):
        rows = [i.row() for i in self.q(name) if pred(i)]
        rows = rows[max(0, skip):]
        return Collection(self.ITEMS_COLS, rows[:maximum] if maximum > 0 else rows)

    @staticmethod
    def _next_out(it):
        if it is None:
            return {'Item ID': '', 'Data': Collection(), 'Status': '', 'Attempt': Decimal(0), 'Attempts': Decimal(0), 'Key Value': ''}
        return {'Item ID': it.id, 'Data': it.data, 'Status': it.status, 'Attempt': Decimal(it.attempts), 'Attempts': Decimal(it.attempts), 'Key Value': it.key}

    @staticmethod
    def _ids(items):
        return Collection([('Item ID', 'text')], [{'Item ID': i.id} for i in items])

    def call(self, action, inputs):
        g = inputs.get
        if action == 'Get Queue Names':
            return {'Queue Names': Collection([('Queue Name', 'text')], [{'Queue Name': n} for n in sorted(self.queues)])}
        if action == 'Add To Queue':      # Batch Size only changes how Blue Prism writes to its database: nothing to do here
            ids = self.add(g('Queue Name'), g('Data') if isinstance(g('Data'), Collection) else Collection(), g('Priority', 0), g('Tags', ''), g('Status', ''), g('Defer Until'))
            return {'Item IDs': Collection([('Item ID', 'text')], [{'Item ID': i} for i in ids]), 'Item ID': ids[0] if ids else ''}
        if action == 'Get Next Item':
            return self._next_out(self.get_next(g('Queue Name'), g('Key Filter', ''), g('Tag Filter', '')))
        if action == 'Get Item By ID':    # the same lock as Get Next Item, on one named item
            it = next((i for i in self.q(g('Queue Name')) if i.id == str(g('Item ID', ''))), None)
            if it is None:
                raise BPException('System Exception', f'Internal : No queue item found with ID {g("Item ID", "")}')
            if it.state != 'Pending' or it.locked:
                self.log(f'  [queue {it.queue}] {it.id[:8]} cannot be taken ({"locked" if it.locked else it.state.lower()})')
                return self._next_out(None)
            return self._next_out(self._claim(it))
        if action == 'Mark Completed':
            self.mark_completed(g('Item ID', '')); return {}
        if action == 'Mark Exception':
            return {'New Item ID': self.mark_exception(g('Item ID', ''), g('Exception Reason', ''), _flag(g('Retry'), False), _flag(g('Keep Locked'), False))}
        if action == 'Defer':
            it = self._locked(g('Item ID', '')); it.unlock(); it.deferred = self._when(g('Until')) or datetime.datetime.now(); it.touch(); self.ev(it.queue, 'Deferred')
            self.log(f'  [queue {it.queue}] deferred {it.id[:8]} until {it.deferred}'); return {}
        if action == 'Set Data':
            it = self._locked(g('Item ID', '')); d = g('Data')
            if isinstance(d, Collection):
                it.data = Collection(d.columns, [dict(r) for r in d.rows]); it.key = self._key(it.queue, d.rows[0]) if d.rows else it.key
            it.touch(); return {}
        if action == 'Get Item Data':
            it = self.find(g('Item ID', '')); now = datetime.datetime.now()
            this = it.worktime + ((now - it.locked_at) if it.locked and it.locked_at else datetime.timedelta(0))
            return {'Key': it.key, 'Priority': Decimal(it.priority), 'Status': it.status, 'Attempts': Decimal(it.attempts),
                    'Worktime': _span(it.worktime_before + this), 'Attempt Worktime': _span(this), 'Loaded DateTime': _dt(it.created), 'Deferred DateTime': _dt(it.deferred),
                    'Completed DateTime': _dt(it.finished if it.state == 'Completed' else None), 'Exception DateTime': _dt(it.finished if it.state == 'Exception' else None),
                    'Exception Reason': it.exception, 'Tags': ';'.join(sorted(it.tags)), 'Data': it.data, 'Key Value': it.key}
        if action == 'Update Status':
            it = self.find(g('Item ID', '')); it.status = str(g('Status', '')); it.touch(); return {}
        if action == 'Set Priority':
            it = self.find(g('Item ID', '')); it.priority = _int(g('Priority')); it.touch(); return {}
        if action == 'Tag Item':
            it = self.find(g('Item ID', '')); it.tags.update(self._tags(g('Tag', ''))); it.touch(); return {}
        if action == 'Untag Item':
            it = self.find(g('Item ID', '')); it.tags.difference_update(self._tags(g('Tag', ''))); it.touch(); return {}
        if action == 'Unlock Item':
            it = self.find(g('Item ID', '')); was = it.locked; it.unlock(); it.touch(); return {'Unlocked': was}
        if action == 'Delete Item':
            it = self.find(g('Item ID', ''))
            if it.locked:
                raise BPException('System Exception', f'Internal : The item {it.id} is locked and cannot be deleted')
            self.queues[it.queue].remove(it); self.ev(it.queue, 'Deletions'); self.log(f'  [queue {it.queue}] deleted {it.id[:8]}'); return {}
        if action == 'Is Item In Queue':
            now = datetime.datetime.now()
            def kind(i):
                if i.state == 'Completed':
                    return 'Include Completed'
                if i.state == 'Exception':
                    return 'Include Terminated'
                return 'Include Deferred' if i.deferred is not None and i.deferred > now else 'Include Pending'
            hits = [i for i in self.q(g('Queue Name')) if i.key == str(g('Key', '')) and _flag(g(kind(i)), True) and self._tag_ok(i, g('Tag Filter', ''))]
            return {'Result': bool(hits), 'Item IDs': self._ids(hits), 'Item ID': hits[0].id if hits else ''}
        if action == 'Get Pending Items':
            c = self.items(g('Queue Name'), lambda i: i.state == 'Pending' and not i.locked and self._match(i, g('Key Filter', ''), g('Tag Filter', '')), _int(g('Skip')), _int(g('Maximum')))
            return {'Pending Items': c, 'Items': c}
        if action == 'Get Locked Items':
            c = self.items(g('Queue Name'), lambda i: i.locked and self._match(i, g('Key Filter', ''), g('Tags', '') or g('Tag Filter', '')))
            return {'Locked Items': c, 'Items': c}
        if action in ('Get Completed Items', 'Get Exception Items'):
            want = 'Completed' if action == 'Get Completed Items' else 'Exception'
            a, b = self._when(g('Start Date')), self._when(g('End Date'))     # Resource Name: one resource here, not filtered
            c = self.items(g('Queue Name'), lambda i: i.state == want and (a is None or (i.finished or i.updated) >= a) and (b is None or (i.finished or i.updated) <= b) and self._match(i, g('Key Filter', ''), g('Tag Filter', '')), 0, _int(g('Maximum Rows')))
            return {want + ' Items': c, 'Items': c}
        if action == 'Get Report Data':
            fa, fb, la, lb = (self._when(g(k)) for k in ('Finished Start Date', 'Finished End Date', 'Loaded Start Date', 'Loaded End Date'))
            now = datetime.datetime.now()
            def keep(i):
                if not self._match(i, g('Key Filter', ''), g('Tags', '') or g('Tag Filter', '')):
                    return False
                if (la and i.created < la) or (lb and i.created > lb):
                    return False
                if i.state == 'Pending':
                    if fa or fb:
                        return False
                    return _flag(g('Include deferred items?'), True) if (i.deferred and i.deferred > now) else _flag(g('Include unworked items?'), True)
                if (fa and i.finished < fa) or (fb and i.finished > fb):
                    return False
                return _flag(g('Include completed items?'), True) if i.state == 'Completed' else _flag(g('Include exception items?'), True)
            items = [i for i in self.q(g('Queue Name')) if keep(i)]
            each = _flag(g('Treat each attempt separately?'), False)
            times = sorted((i.worktime if each else i.worktime_before + i.worktime) for i in items if i.state != 'Pending')
            zero = datetime.timedelta(0); tot = sum(times, zero)
            n = lambda s: Decimal(sum(1 for i in items if i.state == s))
            return {'Item Count': Decimal(len(items)), 'Time Total': _span(tot), 'Least Time': _span(times[0] if times else zero), 'Most Time': _span(times[-1] if times else zero),
                    'Median Time': _span(times[len(times) // 2] if times else zero), 'Mean Time': _span(tot / len(times) if times else zero), 'Item IDs': self._ids(items),
                    'Total Items': Decimal(len(items)), 'Pending': n('Pending'), 'Completed': n('Completed'), 'Exceptioned': n('Exception'), 'Locked': Decimal(sum(1 for i in items if i.locked)),
                    'Items': Collection(self.ITEMS_COLS, [i.row() for i in items])}
        if action == 'Get Transaction Data':
            ex = g('Excluded Queue Names'); skip = set(str(v) for r in (ex.rows if isinstance(ex, Collection) else []) for v in r.values())
            a, b = self._when(g('Start Date/Time')), self._when(g('End Date/Time'))
            ask = {'Created': 'Count item creations', 'Locked': 'Count item locks', 'Deferred': 'Count item deferrals', 'Completed': 'Count item completions',
                   'Exceptions with retry': 'Count item exceptions with automatic retry', 'Exceptions with no retry': 'Count item exceptions without automatic retry',
                   'Deletions': 'Count item deletions', 'Force Retries': 'Count item forced retries'}
            out = {k: Decimal(0) for k in self.EVENTS}
            for when, queue, k in self.events:
                if queue not in skip and (a is None or when >= a) and (b is None or when <= b) and _flag(g(ask[k]), True):
                    out[k] += 1
            out['Total Count'] = sum(out.values(), Decimal(0))
            out['Included Queues'] = Collection([('Queue Name', 'text')], [{'Queue Name': n} for n in sorted(self.queues) if n not in skip])
            return out
        if action in ('Copy Item to Queue', 'Copy To Queue'):
            it = self.find(g('Item ID', '')); target = g('Queue Name') or g('Target Queue Name') or g('New Queue Name') or it.queue
            tags = set(it.tags)
            for t in self._tags(g('Tag Mask', '') or g('Tags', '')):      # "+tag" / "tag" adds, "-tag" removes
                (tags.discard if t.startswith('-') else tags.add)(t.lstrip('+-'))
            pr = g('Priority'); st = g('Status')
            ids = self.add(target, it.data, it.priority if pr in (None, '') else pr, ';'.join(sorted(tags)), it.status if st in (None, '') else st, g('Defer Until'))
            return {'New Item ID': ids[0] if ids else ''}
        if action == 'Delete Processed Items':
            thr = self._when(g('Date Threshold') or g('Threshold')); n = 0
            names = list(self.queues) if _flag(g('Delete From All Queues'), False) else [g('Queue Name')]
            for qn in names:
                items = self.q(qn)
                for i in [i for i in items if i.state in ('Completed', 'Exception') and (thr is None or (i.finished or i.updated) < thr)]:
                    items.remove(i); n += 1; self.ev(qn, 'Deletions')
            return {'Deletion Count': Decimal(n), 'Count': Decimal(n), 'Items Deleted': Decimal(n)}
        raise BPException('System Exception', f'Work Queues.{action} not simulated')


def make_password(inputs):
    """Generate Password: Length characters from the classes asked for (all three when none is), never a real secret."""
    sets = [s for k, s in (('Use Upper Case', string.ascii_uppercase), ('Use Lower Case', string.ascii_lowercase), ('Use Numeric', string.digits)) if _flag(inputs.get(k), False)]
    extra = str(inputs.get('Additional Characters', '') or '')
    if extra:
        sets.append(extra)
    if not sets:
        sets = [string.ascii_uppercase, string.ascii_lowercase, string.digits]
    n = _int(inputs.get('Length'), 0)
    if n <= 0:
        raise BPException('System Exception', 'Internal : The password length must be greater than zero')
    chars = [random.choice(s) for s in sets][:n] + [random.choice(''.join(sets)) for _ in range(max(0, n - len(sets)))]
    random.shuffle(chars)
    return ''.join(chars)


class Credentials:
    """Credentials from the estate: {name: [user, pass]} or {name: {"username", "password", "expiry", "status",
    "properties": {..}}}. `what` names the object in the messages (Credentials / Windows Credentials share the code)."""
    def __init__(self, creds, what='Credentials'):
        self.creds, self.what = {}, what
        for name, v in (creds or {}).items():
            if isinstance(v, dict):
                self.creds[name] = {'username': v.get('username', ''), 'password': v.get('password', ''), 'expiry': v.get('expiry', ''), 'status': v.get('status', 'Valid'), 'properties': dict(v.get('properties', {}))}
            else:
                self.creds[name] = {'username': v[0] if len(v) > 0 else '', 'password': v[1] if len(v) > 1 else '', 'expiry': '', 'status': 'Valid', 'properties': {}}

    def _c(self, name):
        if name not in self.creds:
            raise BPException('System Exception', f'Internal : Credential {name!r} not found')
        return self.creds[name]

    def _set(self, name, inputs, password):
        c = self.creds.setdefault(name, {'username': '', 'password': '', 'expiry': '', 'status': 'Valid', 'properties': {}})
        c['username'] = str(inputs.get('Username', c['username'])); c['password'] = password; c['status'] = 'Valid'
        if inputs.get('Expiry Date') not in (None, ''):
            c['expiry'] = str(inputs.get('Expiry Date'))

    def call(self, action, inputs):
        name = inputs.get('Credentials Name') or inputs.get('Name', '')
        if action == 'Get':
            c = self._c(name); return {'Username': c['username'], 'Password': c['password'], 'Expiry Date': c['expiry'], 'Status': c['status']}
        if action == 'Get Property':
            c = self._c(name); p = inputs.get('Property Name', '')
            if p not in c['properties']:
                raise BPException('System Exception', f'Internal : Property {p!r} not found on credential {name!r}')
            return {'Property Value': c['properties'][p]}
        if action == 'Set':
            self._set(name, inputs, str(inputs.get('Password', ''))); return {}
        if action == 'Generate Password':
            return {'Password': make_password(inputs)}
        if action == 'Generate and Set':
            pw = make_password(inputs); self._set(name, inputs, pw); return {'Password': pw}
        if action == 'Mark as Invalid':
            self._c(name)['status'] = 'Invalid'; return {}
        if action == 'Set Property':
            self._c(name)['properties'][str(inputs.get('Property Name', ''))] = str(inputs.get('Property Value', '')); return {}
        if action in ('List', 'Get Credential Names'):
            want = str(inputs.get('Status', '') or '').strip().lower()
            rows = [{'Name': n, 'Status': c['status'], 'Expiry Date': c['expiry']} for n, c in sorted(self.creds.items()) if want in ('', 'all', c['status'].lower())]
            return {'Credentials': Collection([('Name', 'text'), ('Status', 'text'), ('Expiry Date', 'date')], rows)}
        raise BPException('System Exception', f'{self.what}.{action} not simulated')


class EnvLocks:
    """Environment Locking: locks this run holds (name -> token, comment), plus locks the estate says another session
    holds (internal/estate.json "locks": {name: comment}); those can be queried, never acquired or released.
    Acquire Lock does not wait for Timeout: a held lock gives an empty Token at once."""
    def __init__(self, log, foreign=None):
        self.held, self.foreign, self.log = {}, dict(foreign or {}), log

    def call(self, action, inputs):
        name = str(inputs.get('Name', '') or inputs.get('Lock Name', ''))
        token = str(inputs.get('Token', '') or '')
        if action == 'Acquire Lock':
            if name in self.held or name in self.foreign:
                self.log(f'  [lock] {name!r} already held' + (' by another session' if name in self.foreign else '') + ': empty token (the Timeout is not waited for)')
                return {'Token': '', 'Result': False, 'Acquired': False}
            tok = str(inputs.get('Preferred Token', '') or '') or str(uuid.uuid4())
            self.held[name] = (tok, str(inputs.get('Comment', '') or '')); self.log(f'  [lock] acquired {name!r}')
            return {'Token': tok, 'Result': True, 'Acquired': True}
        if action == 'Release Lock':
            if name not in self.held or self.held[name][0] != token:
                raise BPException('System Exception', f'Internal : The lock {name!r} is not held with the token supplied')
            del self.held[name]; self.log(f'  [lock] released {name!r}'); return {'Result': True}
        if action == 'Query Lock':
            if token:
                held = name in self.held and self.held[name][0] == token
            else:
                held = name in self.held or name in self.foreign
            comment = self.held[name][1] if name in self.held else self.foreign.get(name, '')
            return {'Lock Held': held, 'Comment': comment if held else '', 'Result': held, 'Status': 'Locked' if held else 'Free'}
        raise BPException('System Exception', f'Environment Locking.{action} not simulated')


class Calendars:
    """Calendars: Monday to Friday unless the estate defines one (internal/estate.json "calendars": {name:
    {"working_days": [0..6, Monday = 0], "public_holidays": {"YYYY-MM-DD": "name"} or [dates], "other_holidays": [dates]}};
    "holidays" is read as public holidays). An unknown calendar name = the default."""
    def __init__(self, cfg=None):
        self.cfg = {}
        for n, c in (cfg or {}).items():
            pub = c.get('public_holidays', c.get('holidays', []))
            pub = {str(k)[:10]: str(v) for k, v in pub.items()} if isinstance(pub, dict) else {str(h)[:10]: '' for h in pub}
            self.cfg[n] = {'days': set(int(d) for d in c.get('working_days', [0, 1, 2, 3, 4])), 'public': pub, 'other': set(str(h)[:10] for h in c.get('other_holidays', []))}

    @staticmethod
    def _d(v):
        if isinstance(v, datetime.datetime):
            return v.date()
        if isinstance(v, datetime.date):
            return v
        s = str(v).strip()[:10]
        for f in ('%Y-%m-%d', '%d/%m/%Y'):
            try:
                return datetime.datetime.strptime(s, f).date()
            except ValueError:
                pass
        raise BPException('System Exception', f'Internal : Invalid date value {v!r}')

    def _c(self, cal):
        return self.cfg.get(cal, {'days': {0, 1, 2, 3, 4}, 'public': {}, 'other': set()})

    def working(self, cal, d):
        c = self._c(cal)
        return d.weekday() in c['days'] and d.isoformat() not in c['public'] and d.isoformat() not in c['other']

    def call(self, action, inputs):
        g = inputs.get
        cal = str(g('Calendar Name', '') or g('Calendar', '')); c = self._c(cal)
        d = self._d(g('Date') or g('First Date') or g('Start Date') or datetime.date.today())
        if action == 'Is Working Day':
            w = self.working(cal, d); return {'Is Working Day': w, 'Result': w}
        if action == 'Is Weekend':
            return {'Is Weekend': d.weekday() not in c['days']}
        if action == 'Is Public Holiday':
            return {'Is Public Holiday': d.isoformat() in c['public'], 'Name': c['public'].get(d.isoformat(), '')}
        if action == 'Is Other Holiday':
            return {'Is Other Holiday': d.isoformat() in c['other']}
        if action in ('Add Working Days', 'Get Next Working Day', 'Get Previous Working Day'):
            n = _int(g('Days')) if action == 'Add Working Days' else (1 if action == 'Get Next Working Day' else -1)
            step, left = (1 if n >= 0 else -1), abs(n)
            while left > 0:
                d += datetime.timedelta(days=step)
                if self.working(cal, d):
                    left -= 1
            return {'Result Date': d.isoformat(), 'Result': d.isoformat(), 'Date': d.isoformat()}
        if action in ('Count Working Days In Range', 'Get Working Days In Range', 'Get Public Holidays In Range', 'Get Other Holidays In Range', 'Get Working Days', 'Count Working Days'):
            e = self._d(g('Last Date') or g('End Date') or d); x = d; days = []; pub = []; oth = []
            while x <= e:
                k = x.isoformat()
                if self.working(cal, x):
                    days.append({'Date': k})
                if k in c['public']:
                    pub.append({'Date': k, 'Name': c['public'][k]})
                if k in c['other']:
                    oth.append({'Date': k})
                x += datetime.timedelta(days=1)
            n = Decimal(len(days))
            return {'Days': n, 'Working Days': Collection([('Date', 'date')], days), 'Public Holidays': Collection([('Date', 'date'), ('Name', 'text')], pub),
                    'Other Holidays': Collection([('Date', 'date')], oth), 'Result': n, 'Count': n}
        if action == 'Get Calendar Names':
            return {'Calendars': Collection([('Name', 'text')], [{'Name': n} for n in sorted(self.cfg)])}
        raise BPException('System Exception', f'Calendars.{action} not simulated')


class EventLog:
    """Data Gateways (and the old seed's Event Log): writes go to the run log (nothing leaves the run)."""
    def __init__(self, log):
        self.log, self.events = log, []

    def call(self, obj, action, inputs):
        if obj == 'Event Log' and action in ('Write Event', 'Write'):
            e = {'Type': str(inputs.get('Event Type', inputs.get('Type', 'Information'))), 'Message': str(inputs.get('Message', inputs.get('Event Message', '')))}
            self.events.append(e); self.log(f'  [event log] {e["Type"]}: {e["Message"][:200]}'); return {}
        if obj == 'Data Gateways' and action in ('Send Custom Data', 'Send'):
            d = inputs.get('Custom Data', inputs.get('Data')); self.log(f'  [data gateway] custom data: {repr(d)[:200]}'); return {}
        raise BPException('System Exception', f'{obj}.{action} not simulated')


class Encryption:
    """Encryption: a reversible stand-in (base64, tagged with the scheme name): Decrypt X(Encrypt X(v)) == v for the
    ten types Blue Prism has an action pair for. A value a real Blue Prism encrypted cannot be decrypted here."""
    TYPES = {'text', 'password', 'collection', 'number', 'flag', 'date', 'datetime', 'time', 'timespan', 'binary'}

    def call(self, action, inputs):
        scheme = str(inputs.get('Encryption Scheme', inputs.get('Scheme', 'Default')) or 'Default')
        verb, _, kind = action.partition(' ')
        kind = kind.lower() or 'text'
        if verb not in ('Encrypt', 'Decrypt') or kind not in self.TYPES:
            raise BPException('System Exception', f'Encryption.{action} not simulated')
        if verb == 'Encrypt':
            v = inputs.get('Plain Value', inputs.get('Plain Text', inputs.get('Text', inputs.get('Value', ''))))
            raw = json.dumps(v.to_json() if isinstance(v, Collection) else (fmt_num(v) if isinstance(v, Decimal) else v), default=str).encode('utf-8')
            enc = 'sim:' + scheme + ':' + base64.b64encode(raw).decode('ascii')
            return {'Encrypted Value': enc, 'Encrypted Text': enc}
        s = str(inputs.get('Encrypted Value', inputs.get('Encrypted Text', inputs.get('Text', inputs.get('Value', '')))))
        if not s.startswith('sim:'):
            raise BPException('System Exception', 'Internal : The encrypted text was not produced by this run (a real Blue Prism value cannot be decrypted here)')
        v = json.loads(base64.b64decode(s.split(':', 2)[2]).decode('utf-8'))
        v = Collection.from_json(v) if kind == 'collection' else coerce(v, kind if kind in ('number', 'flag') else 'text')
        return {'Plain Value': v, 'Plain Text': v}


INTERNAL_ALIASES = {
    'Work Queues': ('Work Queues', 'Blueprism.Automate.clsWorkQueuesActions'),
    'Credentials': ('Credentials', 'Blueprism.Automate.clsCredentialsActions'),
    'Environment Locking': ('Environment Locking', 'Blueprism.Automate.clsEnvironmentLockingActions', 'BluePrism.AutomateAppCore.clsEnvironmentLockingBusinessObject'),
    'Calendars': ('Calendars', 'Blueprism.Automate.clsCalendarsActions'),
    'Collections': ('Collections', 'Blueprism.AutomateProcessCore.clsCollectionActions', 'BluePrism.AutomateProcessCore.CollectionBusinessObject'),
    'Windows Credentials': ('Windows Credentials', 'Blueprism.Automate.WindowsCredentialsActions', 'BluePrism.AutomateAppCore.WindowsCredentialsBusinessObject',
                            'BluePrism.AutomateProcessCore.BusinessObjects.WindowsCredentialsBusinessObject'),
    'Radio buttons': ('Radio buttons', 'Blueprism.Automate.RadioButtonsBusinessObject', 'BluePrism.AutomateProcessCore.InternalBusinessObjects.RadioButtonsBusinessObject'),
    'Data Gateways': ('Data Gateways', 'Blueprism.Automate.clsDataGatewaysActions'),
    'Encryption': ('Encryption', 'EncryptionBusinessObject', 'Blueprism.Automate.clsEncryptionActions'),
    'Event Log': ('Event Log',),
}
INTERNAL_BY_NAME = {alias.lower(): canon for canon, aliases in INTERNAL_ALIASES.items() for alias in aliases}


def internal_name(obj):
    """The canonical internal object for a name an Action stage uses (display name or .NET class), else None."""
    n = str(obj or '').lower()
    if n in INTERNAL_BY_NAME:
        return INTERNAL_BY_NAME[n]
    m = re.match(r'^blueprism\.(?:automate|automateprocesscore|automateappcore)\.cls(\w+?)(?:actions|businessobject)?$', str(obj or ''), re.I)
    if m:
        return re.sub(r'([a-z])([A-Z])', r'\1 \2', m.group(1))      # clsSessionVariablesActions -> Session Variables
    return None


def collections_call(action, inputs, frame=None):
    """Collections (internal object). Blue Prism passes the NAME of a collection on the calling page (Collection Name)
    and the action changes that collection in place: Add Row appends an empty row and makes it the current row,
    Remove Row removes the current row, Copy Rows gives rows Start Row..End Row (0-based, both included) as Result.
    Without a calling page (a direct call with a collection value under "Collection") the changed copy comes back."""
    name = inputs.get('Collection Name')
    if name not in (None, '') and frame is not None:
        c = frame.get(str(name).strip().strip('[]'))
        if not isinstance(c, Collection):
            raise BPException('System Exception', f'Internal : [{name}] is not a collection')
    else:
        if name not in (None, ''):
            raise BPException('System Exception', f'Collections.{action}: Collection Name {name!r} needs a calling page')
        c = inputs.get('Collection')
        c = Collection(c.columns, [dict(r) for r in c.rows]) if isinstance(c, Collection) else Collection()
    if action == 'Count Rows':
        return {'Count': Decimal(len(c.rows))}
    if action == 'Count Columns':
        return {'Count': Decimal(len(c.columns))}
    if action == 'Remove All Rows':
        c.rows[:] = []; c.current = 0
        return {'Collection': c}
    if action == 'Copy Rows':
        a = _int(inputs.get('Start Row'), 0); b = _int(inputs.get('End Row'), len(c.rows) - 1)
        if c.rows and (a < 0 or b >= len(c.rows) or a > b):
            raise BPException('System Exception', f'Internal : Rows {a} to {b} are outside the collection ({len(c.rows)} rows)')
        out = Collection(c.columns, [dict(r) for r in c.rows[a:b + 1]])
        return {'Result': out, 'Collection': out}
    if action == 'Add Row':
        c.rows.append({n: ({'number': Decimal(0), 'flag': False}.get(t, '')) for n, t in c.columns}); c.current = len(c.rows) - 1
        return {'Collection': c}
    if action == 'Remove Row':
        if not c.rows:
            raise BPException('System Exception', 'Internal : The collection has no current row')
        del c.rows[min(c.current, len(c.rows) - 1)]; c.current = max(0, min(c.current, len(c.rows) - 1))
        return {'Collection': c}
    raise BPException('System Exception', f'Collections.{action} not simulated')


def radio_call(action, inputs):
    """Radio buttons: the selected option of a radio-button value as text (the value itself when it is already text)."""
    if action == 'Get selected as text':
        v = inputs.get('Radio button options', '')
        if isinstance(v, dict):
            v = v.get('selected', '')
        return {'Radio button selected': '' if v is None else str(v)}
    raise BPException('System Exception', f'Radio buttons.{action} not simulated')


# =========================================================================================
class Runtime:
    def __init__(self, xml_dirs, server, env, credentials=None, log=None, wait_scale=1.0, apps=None, queues=None, estate=None):
        self.env = env
        self.trace = []        # (process, page, stage, seq) for every stage executed, in order
        self.rows = []         # one record per stage executed: what ran, how it ended, which data items it changed (the frozen run the studio walks through)
        self.frame_seq = 0
        self.throws = []       # (process, page, stage, type, detail) for every exception raised, innermost first
        self.skipped = []      # code stages not run (no stage host)
        # Application Modeller doubles: {object name: {element name: current value}}. A missing
        # key or MISSING value = the element is not on screen; Write/Read/Navigate then fail the
        # way Blue Prism does (System Exception, the stage name in ExceptionStage()).
        self.apps = apps if apps is not None else {}
        self.app_log = []
        self.stop_requested = False
        self.wait_scale = wait_scale
        self.logf = log or (lambda s: print(s))
        self.files = {}
        for d in xml_dirs:
            for path in sorted(glob.glob(os.path.join(d, '*.xml'))):
                pf = ProcFile(self, path)
                self.files[pf.name] = pf
        self.queues = WorkQueues(self.logf)
        for qn, spec in (queues or {}).items():
            rows = spec.get('items', []) if isinstance(spec, dict) else (spec or [])
            self.queues.configure(qn, spec.get('key', '') if isinstance(spec, dict) else '', spec.get('attempts', 3) if isinstance(spec, dict) else 3)
            if rows:
                cols = [(k, 'text') for k in rows[0].keys()]
                self.queues.add(qn, Collection(cols, [dict(r) for r in rows]))
        estate = estate or {}
        self.process_ids = {str(k).lower(): v for k, v in (estate.get('process_ids') or {}).items()}   # a Process stage names its target by id
        self.session_id = str(uuid.uuid4())
        self.credentials = Credentials(credentials or {})
        self.wincreds = Credentials(estate.get('windows_credentials', {}), 'Windows Credentials')
        self.locks = EnvLocks(self.logf, estate.get('locks', {}))
        self.calendars = Calendars(estate.get('calendars', {}))
        self.events = EventLog(self.logf)
        self.encryption = Encryption()
        # stage host: None (code stages skipped), a command list, or a path (run with mono off Windows)
        self.server = None
        if server:
            cmd = server if isinstance(server, list) else ([server] if os.name == 'nt' else ['mono', server])
            self.server = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True, bufsize=1)
            self.rpc('__ping__', '', {})
        self.depth = 0
        self.stage_count = 0

    def close(self):
        if self.server is None:
            return
        try:
            self.server.stdin.close(); self.server.wait(5)
        except Exception:
            self.server.kill()

    def rpc(self, obj, stage, args):
        if self.server is None:
            self.skipped.append((obj, stage))
            self.log(f'  # code stage {stage!r} not run (no stage host): outputs left at their defaults')
            return {}
        self.server.stdin.write(json.dumps({'obj': obj, 'stage': stage, 'args': args}) + '\n')
        self.server.stdin.flush()
        line = self.server.stdout.readline()
        if not line:
            raise BPException('System Exception', 'stage server died')
        reply = json.loads(line)
        if not reply.get('ok'):
            # real Errors-Only log text (bank CSV, 2026-10-22):
            # "ERROR: Internal : Could not execute code stage because exception thrown by code stage: <ex.Message>"
            raise BPException('System Exception', 'Internal : Could not execute code stage because exception thrown by code stage: '
                              + reply.get('error', 'code stage failed'), stage)
        return reply['out']

    def log(self, msg):
        self.logf('  ' * self.depth + msg)

    # ---- running ---------------------------------------------------------------------
    def run_process(self, name, inputs=None):
        pf = self.files[name]
        if pf.ptype != 'process':
            raise ValueError(f'{name} is not a process')
        return self.run_page(pf, pf.pages['Main'], inputs or {})

    def call_object(self, obj, action, inputs, frame=None):
        pf = self.files.get(obj)
        if pf is None:
            canon = internal_name(obj)
            if canon == 'Work Queues':
                return self.queues.call(action, inputs)
            if canon == 'Credentials':
                return self.credentials.call(action, inputs)
            if canon == 'Environment Locking':
                return self.locks.call(action, inputs)
            if canon == 'Calendars':
                return self.calendars.call(action, inputs)
            if canon == 'Collections':
                return collections_call(action, inputs, frame)
            if canon == 'Windows Credentials':
                return self.wincreds.call(action, inputs)
            if canon == 'Radio buttons':
                return radio_call(action, inputs)
            if canon in ('Event Log', 'Data Gateways'):
                return self.events.call(canon, action, inputs)
            if canon == 'Encryption':
                return self.encryption.call(action, inputs)
            if canon:
                raise BPException('System Exception', f'{canon}.{action} not simulated (Blue Prism internal object; see internal/internal.json)')
            raise BPException('System Exception', f'Object {obj!r} not loaded')
        if action not in pf.pages:
            raise BPException('System Exception', f'Object {obj!r} has no action {action!r}')
        return self.run_page(pf, pf.pages[action], inputs)

    def run_page(self, pf, page, inputs):
        self.depth += 1
        self.log(f'> {pf.name} / {page.name} {({k: (v if not isinstance(v, Collection) else repr(v)) for k, v in inputs.items()} if inputs else "")}')
        frame = Frame(page)
        start = page.start()
        for inp in start.el.iter('input'):
            nm, dest, dt = inp.get('name'), inp.get('stage'), inp.get('type')
            if nm not in inputs:
                raise BPException('System Exception', f'Input {nm!r} not supplied to {pf.name}/{page.name}')
            frame.set(dest, inputs[nm], dt)
        try:
            outputs = self.exec_page(pf, page, frame, start)
        finally:
            self.depth -= 1
        return outputs

    ROW_LIMIT = 20000          # past this the run goes on but stops recording rows (a runaway loop must not eat the memory)

    @staticmethod
    def show(value, dtype=''):
        """A data item's value as the studio shows it: short text; a collection as its size and first rows; a password as dots."""
        if dtype == 'password':
            return '\u25cf\u25cf\u25cf\u25cf' if value not in (None, '') else ''
        if isinstance(value, Collection):
            rows = getattr(value, 'rows', []) or []
            head = json.dumps(rows[:3], default=str, ensure_ascii=False)
            return f'{len(rows)} row' + ('' if len(rows) == 1 else 's') + (': ' + (head if len(head) <= 400 else head[:400] + '..') if rows else '')
        if isinstance(value, bool):
            return 'True' if value else 'False'
        t = '' if value is None else str(value)
        return t if len(t) <= 600 else t[:600] + '..'

    def row_open(self, pf, page, frame, st):
        if len(self.rows) >= self.ROW_LIMIT:
            return None
        if not hasattr(frame, 'fid'):
            self.frame_seq += 1
            frame.fid = self.frame_seq
            frame.shown = {}
        row = {'n': self.stage_count, 'f': frame.fid, 'process': pf.name, 'page': page.name, 'stage': st.name, 'type': st.type, 't': round(time.time() * 1000)}
        self.rows.append(row)
        return row

    def row_close(self, row, pf, frame, ex):
        if row is None:
            return
        row['ms'] = round(time.time() * 1000) - row.pop('t')
        if ex is not None:
            row['error'] = f'{ex.etype}: {ex.detail}'[:600]
        try:
            changed = {}
            for name, value in frame.items.items():
                v = self.show(value, frame.types.get(name, ''))
                if frame.shown.get(name) != v:
                    frame.shown[name] = v
                    changed[name] = v
            if changed:
                row['set'] = changed
            gshown = pf.__dict__.setdefault('_gshown', {})
            gch = {}
            for name, value in pf.object_items.items():
                v = self.show(value, pf.object_types.get(name, ''))
                if gshown.get(name) != v:
                    gshown[name] = v
                    gch[name] = v
            if gch:
                row['gset'] = gch
        except Exception:          # recording must never be what breaks a run
            pass

    def exec_page(self, pf, page, frame, start):
        cur = start
        guard = 0
        while True:
            guard += 1
            self.stage_count += 1
            if guard > 200000:
                raise BPException('System Exception', f'Runaway loop on {pf.name}/{page.name}')
            self.trace.append((pf.name, page.name, cur.name, self.stage_count))
            row = self.row_open(pf, page, frame, cur)
            try:
                nxt = self.exec_stage(pf, page, frame, cur)
                self.row_close(row, pf, frame, None)
            except BPException as ex:
                self.row_close(row, pf, frame, ex)
                if not ex.stage:
                    ex.stage = cur.name
                if not getattr(ex, 'seen', False):
                    ex.seen = True
                    self.throws.append((pf.name, page.name, cur.name, ex.etype, ex.detail))
                rec = page.recover_for(cur)
                if rec is None or cur.type in ('Recover',):
                    raise
                if frame.recovery is not None and cur.type not in ('Resume',):
                    # already in recovery mode: a second failure propagates (Blue Prism behaviour)
                    raise
                self.log(f'  ! {ex.etype} at {cur.name!r}: {ex.detail[:200]} -> {rec.name}')
                frame.recovery = ex
                nxt = rec
                frame.recovery_from = cur
            if nxt is None:
                end = cur
                outs = {}
                for o in end.el.iter('output'):
                    outs[o.get('name')] = frame.items.get(o.get('stage'))
                self.log(f'< {page.name} {({k: (v if not isinstance(v, Collection) else repr(v)) for k, v in outs.items()} if outs else "")}')
                return outs
            cur = nxt

    def goto(self, page, sid, what):
        if sid is None:
            raise BPException('System Exception', f'{what} has no link')
        st = page.stages.get(sid)
        if st is None:
            raise BPException('System Exception', f'{what} links to unknown stage {sid}')
        return st

    def exec_stage(self, pf, page, frame, st):
        ex = Expr(self, frame)
        t = st.type
        if t in ('Start', 'Anchor'):
            return self.goto(page, st.onsuccess, st.name)
        if t == 'End':
            return None
        if t == 'Decision':
            v = ex.eval(st.el.find('decision').get('expression'))
            self.log(f'? {st.name} -> {bool(v)}')
            return self.goto(page, st.ontrue if v else st.onfalse, st.name)
        if t == 'Calculation':
            c = st.el.find('calculation')
            frame.set(c.get('stage'), ex.eval(c.get('expression')))
            return self.goto(page, st.onsuccess, st.name)
        if t == 'MultipleCalculation':
            for c in st.el.find('steps').iter('calculation'):
                frame.set(c.get('stage'), ex.eval(c.get('expression')))
            return self.goto(page, st.onsuccess, st.name)
        if t == 'ChoiceStart':
            for ch in st.el.find('choices').iter('choice'):
                if ex.eval(ch.get('expression')):
                    self.log(f'? {st.name} -> {ch.findtext("name")}')
                    return self.goto(page, ch.findtext('ontrue'), st.name)
            end = next(s for s in page.stages.values() if s.type == 'ChoiceEnd' and s.groupid == st.groupid)
            self.log(f'? {st.name} -> otherwise')
            return self.goto(page, end.onsuccess, end.name)
        if t == 'ChoiceEnd':
            return self.goto(page, st.onsuccess, st.name)
        if t == 'LoopStart':
            coll = frame.get(st.el.findtext('loopdata'))
            end = next(s for s in page.stages.values() if s.type == 'LoopEnd' and s.groupid == st.groupid)
            if not coll.rows:
                return self.goto(page, end.onsuccess, end.name)
            frame.loops[st.groupid] = 0
            coll.current = 0
            return self.goto(page, st.onsuccess, st.name)
        if t == 'LoopEnd':
            start = next(s for s in page.stages.values() if s.type == 'LoopStart' and s.groupid == st.groupid)
            coll = frame.get(start.el.findtext('loopdata'))
            i = frame.loops.get(st.groupid, 0) + 1
            if i < len(coll.rows):
                frame.loops[st.groupid] = i; coll.current = i
                return self.goto(page, start.onsuccess, start.name)
            coll.current = 0
            return self.goto(page, st.onsuccess, st.name)
        if t == 'WaitStart':
            model = self.apps.get(pf.name, {})
            for ch in st.el.iter('choice'):
                name = pf.elements.get(ch.find('element').get('id'), '?')
                cond = ch.findtext('condition/id')
                exists = name in model and model[name] is not MISSING
                want = (ch.findtext('comparetype') or 'Equal') != 'NotEqual'
                if cond == 'CheckExists' and exists == want:
                    self.app_log.append((pf.name, st.name, 'wait', name, 'met'))
                    return self.goto(page, ch.findtext('ontrue'), st.name)
            secs = float(ex.num(ex.eval(st.el.findtext('timeout'))))
            time.sleep(secs * self.wait_scale)
            end = next(s for s in page.stages.values() if s.type == 'WaitEnd' and s.groupid == st.groupid)
            return self.goto(page, end.onsuccess, end.name)
        if t in ('Write', 'Read', 'Navigate'):
            model = self.apps.setdefault(pf.name, {})
            for n, step in enumerate(st.el.iter('step'), 1):
                eid = step.find('element').get('id')
                name = pf.elements.get(eid, eid)
                act = step.findtext('action/id') or ''
                if t == 'Navigate' and eid == pf.app_root and act in ('Launch', 'AttachApplication', 'ActivateApp', 'DetachApplication', 'Terminate', 'IsConnected'):
                    self.app_log.append((pf.name, st.name, 'navigate', name, act))
                    continue
                if name not in model or model[name] is MISSING:
                    self.app_log.append((pf.name, st.name, t.lower(), name, 'NOT FOUND'))
                    raise BPException('System Exception',
                                      f"Internal : Failed to perform step {n} in {t} Stage '{st.name}' on page '{page.name}' - Element not found", st.name)
                if t == 'Write':
                    model[name] = ex.text(ex.eval(step.get('expr')))
                    self.app_log.append((pf.name, st.name, 'write', name, model[name]))
                elif t == 'Read':
                    v = True if act == 'IsConnected' else model[name]
                    frame.set(step.get('stage'), v)
                    self.app_log.append((pf.name, st.name, 'read', name, v))
                else:
                    self.app_log.append((pf.name, st.name, 'navigate', name, act))
            return self.goto(page, st.onsuccess, st.name)
        if t == 'WaitEnd':
            return self.goto(page, st.onsuccess, st.name)
        if t == 'Exception':
            e = st.el.find('exception')
            if (e.get('usecurrent') or '').lower() in ('yes', 'true') and frame.recovery is not None:
                raise BPException(frame.recovery.etype, frame.recovery.detail, frame.recovery.stage)
            raise BPException(e.get('type'), ex.text(ex.eval(e.get('detail') or '""')), st.name)
        if t == 'Recover':
            return self.goto(page, st.onsuccess, st.name)
        if t == 'Resume':
            frame.recovery = None
            return self.goto(page, st.onsuccess, st.name)
        if t == 'Code':
            args = {}
            for inp in st.el.iter('input'):
                args[inp.get('name')] = to_json_value(ex.eval(inp.get('expr')))
            out = self.rpc(pf.name, st.name, args)
            for o in st.el.iter('output'):
                frame.set(o.get('stage'), coerce(out.get(o.get('name')), o.get('type'), o.get('stage')), o.get('type'))
            return self.goto(page, st.onsuccess, st.name)
        if t == 'Action':
            r = st.el.find('resource')
            inputs = {}
            for inp in st.el.iter('input'):
                inputs[inp.get('name')] = ex.eval(inp.get('expr'))
            try:
                outs = self.call_object(r.get('object'), r.get('action'), inputs, frame)
            except BPException as e:
                e.stage = st.name      # Blue Prism: ExceptionStage() in the caller = the calling Action stage (estate 2026-10-23)
                raise
            for o in st.el.iter('output'):
                frame.set(o.get('stage'), coerce(outs.get(o.get('name')), o.get('type'), o.get('stage')), o.get('type'))
            return self.goto(page, st.onsuccess, st.name)
        if t == 'SubSheet':
            target = pf.by_ssid[st.el.findtext('processid')]
            inputs = {}
            for inp in st.el.iter('input'):
                inputs[inp.get('name')] = ex.eval(inp.get('expr'))
            try:
                outs = self.run_page(pf, target, inputs)
            except BPException as e:
                e.stage = st.name
                raise
            for o in st.el.iter('output'):
                frame.set(o.get('stage'), coerce(outs.get(o.get('name')), o.get('type'), o.get('stage')), o.get('type'))
            return self.goto(page, st.onsuccess, st.name)
        if t == 'Alert':      # Blue Prism raises an alert to whoever subscribed; here it goes to the run log
            a = st.el.find('alert')
            text = ex.text(ex.eval(a.get('expression'))) if a is not None and a.get('expression') else ''
            self.log(f'! alert from {st.name!r}: {text[:300]}')
            return self.goto(page, st.onsuccess, st.name)
        if t == 'Process':    # another process, run in place: its Main Page with these inputs, its End outputs back
            pid = (st.el.findtext('processid') or '').strip().lower()
            target = self.process_ids.get(pid)
            tf = self.files.get(target) if target else None
            if tf is None:
                raise BPException('System Exception', f'Internal : The process called by {st.name!r} is not in this release' + (f' ({target})' if target else ''), st.name)
            inputs = {}
            for inp in st.el.iter('input'):
                if inp.get('expr'):
                    inputs[inp.get('name')] = ex.eval(inp.get('expr'))
            try:
                outs = self.run_page(tf, tf.pages['Main'], inputs)
            except BPException as e:
                e.stage = st.name
                raise
            for o in st.el.iter('output'):
                if o.get('stage'):
                    frame.set(o.get('stage'), coerce((outs or {}).get(o.get('name')), o.get('type'), o.get('stage')), o.get('type'))
            return self.goto(page, st.onsuccess, st.name)
        raise BPException('System Exception', f'Stage type {t} not supported ({st.name})')


# =========================================================================================
if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--xml', nargs='+', required=True)
    ap.add_argument('--server', help='stage host: a path (mono off Windows) or nothing = code stages skipped')
    ap.add_argument('--server-cmd', help='stage host as a JSON command list')
    ap.add_argument('--env', help='JSON file: {"environment": {name: value}, "credentials": {name: [user, pass]}, "queues": {name: [rows]}} (or a flat name -> value map)')
    ap.add_argument('--run', required=True, help='process name, or object name with --action')
    ap.add_argument('--action', help='run this action of the object named by --run')
    ap.add_argument('--inputs', help='JSON: input name -> value for the action / process')
    ap.add_argument('--json', help='write the run as JSON here (trace, throws, exception, log)')
    a = ap.parse_args()
    env = {}
    if a.env:
        with open(a.env, encoding='utf-8') as f:
            env = json.load(f)
    nested = isinstance(env, dict) and ('environment' in env or 'credentials' in env or 'queues' in env)
    lines = []
    def logboth(msg):
        lines.append(msg); print(msg)
    server = json.loads(a.server_cmd) if a.server_cmd else a.server
    inputs = json.loads(a.inputs) if a.inputs else {}
    rt = None
    result = {'ok': False, 'run': a.run, 'action': a.action}
    try:
        rt = Runtime(a.xml, server, env.get('environment', {}) if nested else env, env.get('credentials', {}) if nested else {}, log=logboth,
                     queues=env.get('queues', {}) if nested else {}, estate=env if nested else {})
        outs = rt.call_object(a.run, a.action, inputs) if a.action else rt.run_process(a.run, inputs)
        result.update(ok=True, outputs={k: to_json_value(v) for k, v in (outs or {}).items()})
        print('RUN FINISHED, stages executed:', rt.stage_count)
    except BPException as e:
        result['exception'] = {'type': e.etype, 'detail': e.detail, 'stage': e.stage}
        print(f'RUN FAILED: {e.etype} at {e.stage!r}: {e.detail}')
    except Exception as e:
        result['exception'] = {'type': type(e).__name__, 'detail': str(e), 'stage': ''}
        print(f'RUN BROKE: {type(e).__name__}: {e}')
    finally:
        if rt is not None:
            rt.close()
            result.update(stages=rt.stage_count, rows=rt.rows, rows_cut=len(rt.rows) >= rt.ROW_LIMIT, trace=[list(t) for t in rt.trace], throws=[list(t) for t in rt.throws], skipped=[list(t) for t in rt.skipped],
                          queues={n: [{'id': it['id'], 'status': it['status'], 'attempts': it['attempts'], 'exception': it['exception'], 'data': it['data'].rows[0] if it['data'].rows else {}} for it in items] for n, items in rt.queues.queues.items()})
        result['log'] = lines
        if a.json:
            with open(a.json, 'w', encoding='utf-8') as f:
                json.dump(result, f, default=str)
    sys.exit(0 if result['ok'] else 1)
